import React from 'react';
import styled from 'styled-components';
import { Column, Paragraph, SubheadFour } from 'scuid-x';
import { Link } from 'react-router-dom';

/**
 * PropTypes imports
 */
import { PhotoCardsPropType } from '../../constants/prop-types/marketing-prop-types';
import { CustomerPropTypes } from '../../constants/prop-types/customer-prop-types';

/**
 * Styled Components
 */
import { ScuidLink } from '../../utilities/global-styles';

const CustomColumn = styled(Column)`
  padding-left: 5px;
  padding-right: 5px;
`;

const Container = styled.div`
  position: relative;
  background: white;
  min-height: 20rem;
  height: 100%;
`;

const Image = styled.img`
  width: 100%;
  height: auto;
  border-radius: 4px 4px 0 0;
  max-width: 100%;
  margin: 0px;
`;

const Details = styled.div`
  padding: 1rem 1.5rem 2.7rem;
`;

const Description = styled(Paragraph)`
  color: #757575;
  font-size: 0.88rem;
  padding: 0;
`;

const MarketingLink = ScuidLink.extend`
  position: absolute;
  bottom: 0.6rem;
  border-bottom: 2px solid;
  padding-bottom: 0.25rem;
`;

const RouterLink = MarketingLink.withComponent(Link).extend`
  color: #1A7BB3;
  font-weight: 500;
  &:hover {
    color: #103955;
  }
  @media only screen and (min-width: 20em) {
    font-size: calc(0.875rem + 0.125 * ((100vw - 20em) / 48));
  }
  @media only screen and (min-width: 68em) {
    font-size: 1rem;
  }
`;

const MarketingPhotoCard = ({ photoCards, customer }) =>
  photoCards.map((value) => {
    if (value.altText === 'Apple Employer' && customer.corporateEmployer !== 'apple') {
      return '';
    }
    return (
      <CustomColumn medium={6} large={4} key={value.title}>
        <Container>
          <Image src={value.src} {...(value.srcSet ? { srcSet: value.srcSet } : {})} alt={value.altText} />
          <Details>
            <SubheadFour>{value.title}</SubheadFour>
            <Description>{value.description}</Description>
            {customer.corporateEmployer === 'apple' ? (
              <RouterLink to={value.linkHref} data-qa={`marketing-photo-card-${value.title}`}>
                {value.linkText}
              </RouterLink>
            ) : (
              <MarketingLink
                href={value.linkHref}
                data-qa={`marketing-photo-card-${value.title}`}
                data-mjs={`dashboard-photo-card-${value.title}`}
              >
                {value.linkText}
              </MarketingLink>
            )}
          </Details>
        </Container>
      </CustomColumn>
    );
  });

MarketingPhotoCard.propTypes = {
  photoCards: PhotoCardsPropType.isRequired,
  customer: CustomerPropTypes.isRequired,
};

export default MarketingPhotoCard;



// WEBPACK FOOTER //
// ./src/components/marketing/marketing-photo-card.js