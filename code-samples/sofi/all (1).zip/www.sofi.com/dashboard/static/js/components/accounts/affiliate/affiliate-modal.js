import React, { Fragment } from 'react';
import PropTypes from 'prop-types';
import { Modal, Button, HyperLink, NotificationBar } from 'scuid-x';
import styled from 'styled-components';

/**
 * PropTypes imports
 */
import { ReferralSummaryPropTypes } from '../../../constants/prop-types/referral-prop-types';

/**
 * Image imports
 */
import FacebookIcon from '../../../assets/img/icons/icon-facebook.svg';
import TwitterIcon from '../../../assets/img/icons/icon-twitter.svg';
import EmailIcon from '../../../assets/img/icons/icon-email.svg';
import CopyLinkIcon from '../../../assets/img/icons/icon-link.svg';

/**
 * Utilities/function imports
 */
import { formatUrl, facebookHref, twitterHref, emailHref } from './utilities';

/**
 * Styled Components
 */
const ShareLink = styled.div`
  color: #24bdf4;
  display: flex;
  flex-direction: row;
  align-items: baseline;

  @media (min-width: 768px) {
    min-width: 650px;
  }

  @media (max-width: 450px) {
    flex-direction: column;

    div:last-child {
      margin-top: 0.8rem;
    }
  }

  span {
    margin-right: 1.5rem;

    @media (min-width: 768px) {
      margin-right: 3rem;
    }
  }

  a {
    &:not(:last-child) {
      margin-right: 1.5rem;
    }
  }

  &:hover,
  &:active {
    text-decoration: none;
  }
`;

const CustomNotificationBar = styled(NotificationBar)`
  padding: 15px;
  margin-top: 0.8rem;
`;

const ShareModal = ({
  open, copy, toggleOpen, toggleCopy, summary,
}) => (
  <Modal isOpen={open} onDismiss={toggleOpen} title="Share your link with friends:">
    <Modal.Body>
      {summary.unifiedUrl && (
        <Fragment>
          <ShareLink>
            <div>
              <span>{formatUrl(summary.unifiedUrl)}</span>
            </div>
            <div>
              <a
                title="Share referral on Facebook"
                href={facebookHref(summary.unifiedUrl)}
                target="_blank"
                rel="noopener noreferrer"
                data-qa="accounts-shareFacebook"
              >
                <img src={FacebookIcon} alt="Facebook" data-mjs="dashboard-share-popup-facebook" />
              </a>

              <a
                title="Tweet this referral"
                href={twitterHref(summary.unifiedUrl, summary.referralProducts[0])}
                target="_blank"
                rel="noopener noreferrer"
                data-qa="accounts-shareTwitter"
              >
                <img src={TwitterIcon} alt="Tweet" data-mjs="dashboard-share-popup-twitter" />
              </a>

              <a
                title="Share referral through email"
                href={emailHref(summary.unifiedUrl, summary.referralProducts[0])}
                target="_blank"
                rel="noopener noreferrer"
                data-qa="accounts-shareEmail"
              >
                <img src={EmailIcon} alt="Email" data-mjs="dashboard-share-popup-email" />
              </a>

              <HyperLink
                data-qa="accounts-affiliateCopy"
                onClick={() => {
                  toggleCopy(summary.unifiedUrl);
                }}
              >
                <img src={CopyLinkIcon} alt="Copy to Clipboard" data-mjs="dashboard-share-popup-copy" />
              </HyperLink>
            </div>
          </ShareLink>
          {summary.unifiedUrl && copy && <CustomNotificationBar>Your link has been copied to the clipboard.</CustomNotificationBar>}
        </Fragment>
      )}
    </Modal.Body>
    <Modal.Footer>
      <Button data-qa="accounts-affiliate-done-button" small onClick={toggleOpen}>
        Done
      </Button>
    </Modal.Footer>
  </Modal>
);

/* eslint react/no-typos: 0 */
ShareModal.propTypes = {
  open: PropTypes.bool.isRequired,
  copy: PropTypes.bool.isRequired,
  toggleOpen: PropTypes.func.isRequired,
  toggleCopy: PropTypes.func.isRequired,
  summary: ReferralSummaryPropTypes.isRequired,
};

export default ShareModal;



// WEBPACK FOOTER //
// ./src/components/accounts/affiliate/affiliate-modal.js