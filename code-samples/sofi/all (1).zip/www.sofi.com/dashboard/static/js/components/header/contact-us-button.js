import React, { Fragment } from 'react';
import PropTypes from 'prop-types';
import styled from 'styled-components';
import { I18n } from 'react-redux-i18n';
import { Button, FlexColumn } from 'scuid-x';
import breakpoint from 'scuid-x/styles/breakpoint';
import * as color from 'scuid-x/styles/color';

/**
 * Component imports
 */
import Transition from './nav-transition';

/**
 * Styled components
 */
import { SubNav } from './shared-styles';
import { StyledFlexBox } from '../../utilities/global-styles';

const ContactSubNav = SubNav.extend`
  &.contact {
    width: 100%;
    background-color: ${color.White};
    top: calc(100% + 1px);
    box-shadow: 0 2px 6px -1px rgba(0, 0, 0, 0.5);

    > div {
      max-width: 1220px; /* 20px over the max width to calculate for padding on left and right */
      padding: 0 10px;
      margin: 0 auto;

      > div {
        border-left: 1px solid ${color.MediumGray};
        margin: 40px 0 0;
        padding-left: 20px;

        @media screen and (max-width: ${breakpoint.small}) {
          padding-left: 0;
          border: 0;
          padding-top: 12px;
          margin: 0;
        }

        &:first-child {
          border: 0;
          padding-left: 0;
        }
      }
    }

    h5 {
      font-size: 0.813rem;
      color: ${color.DarkGray};
    }

    ul {
      margin: 0 0 20px;
      padding: 0;
      font-size: 0.813rem;
      border: 0;
      background-color: transparent;

      @media screen and (max-width: ${breakpoint.small}) {
        margin: 0 0 12px;
      }

      li {
        font-weight: 500;
        color: ${color.MediumGray};
        border: 0;
        padding: 0;

        &:hover {
          background-color: transparent;
        }

        a {
          padding: 0;
          color: ${color.Blue};
          font-size: 0.875rem;
          cursor: pointer;
          text-decoration: underline;

          &:hover,
          &:focus {
            color: ${color.DarkBlue};
            font-weight: 500;
          }
        }
      }
    }

    p {
      font-size: 0.813rem;
      margin-bottom: 40px;
      width: 100%;

      @media screen and (max-width: ${breakpoint.small}) {
        margin-bottom: 20px;
      }
    }
  }
`;

const ContactButton = styled(Button)`
  @media screen and (max-width: 768px) {
    padding: 12px 15px 13px;
    min-width: 80px;
  }

  @media screen and (max-width: 400px) {
    padding: 12px 10px 12px;
    font-size: 1rem;
  }
`;

const ContactUs = ({ handleOpen, open, corporateEmployer }) => (
  <Fragment>
    <ContactButton
      small
      onClick={handleOpen}
      data-mjs-category="member dashboard"
      data-mjs-action="contact us"
      data-mjs-label="contact us dropdown"
      data-qa="nav-bar-contact-button"
    >
      Contact Us
    </ContactButton>
    <Transition isOpen={open}>
      <ContactSubNav className="contact">
        <StyledFlexBox>
          <FlexColumn compWidth="full xsmall-full small-third">
            <h5>Loans &amp; General Qustions</h5>
            <ul>
              <li>
                <a
                  data-qa="header-nav-bar-apple-email-link"
                  href={`mailto:${I18n.t(corporateEmployer === 'apple' ? 'appleEmail' : 'sofiCustomerServiceEmail')}`}
                >
                  {I18n.t(corporateEmployer === 'apple' ? 'appleEmail' : 'sofiCustomerServiceEmail')}
                </a>
              </li>
              <li>
                <a
                  data-qa="header-nav-bar-apple-phone-link"
                  href={`tel:+${I18n.t(corporateEmployer === 'apple' ? 'applePhoneUnformat' : 'sofiCustomerServicePhoneUnformat')}`}
                >
                  {I18n.t(corporateEmployer === 'apple' ? 'applePhone' : 'sofiCustomerServicePhoneReg')}
                </a>
              </li>
            </ul>

            <ul>
              <li>{I18n.t('sofiCustomerServiceHoursMonThu')}</li>
              <li>{I18n.t('sofiCustomerServiceHoursFriSun')}</li>
            </ul>
          </FlexColumn>

          <FlexColumn compWidth="full xsmall-full small-third">
            <h5>Mortgage General Support</h5>

            <ul>
              <li>
                <a data-qa="header-nav-bar-mort-email-link" href={`mailto:${I18n.t('mortgageEmail')}`}>
                  {I18n.t('mortgageEmail')}
                </a>
              </li>
              <li>
                <a data-qa="header-nav-bar-mort-phone-link" href={`tel:+${I18n.t('mortgagePhoneUnformat')}`}>
                  {I18n.t('mortgagePhoneReg')}
                </a>
              </li>
            </ul>

            <ul>
              <li>{I18n.t('mortgageHoursMonFri')}</li>
              <li>{I18n.t('mortgageHoursSatSun')}</li>
            </ul>
          </FlexColumn>

          <FlexColumn compWidth="full xsmall-full small-third">
            <h5>Wealth</h5>

            <ul>
              <li>
                <a data-qa="header-nav-bar-wealth-email-link" href={`mailto:${I18n.t('wealthEmail')}`}>
                  {I18n.t('wealthEmail')}
                </a>
              </li>
              <li>
                <a data-qa="header-nav-bar-wealth-phone-link" href={`tel:+${I18n.t('wealthPhoneUnformat')}`}>
                  {I18n.t('wealthPhoneReg')}
                </a>
              </li>
            </ul>

            <ul>
              <li>{I18n.t('wealthHoursMonThu')}</li>
              <li>{I18n.t('wealthHoursFri')}</li>
            </ul>
          </FlexColumn>

          <p>All times are PST</p>
        </StyledFlexBox>
      </ContactSubNav>
    </Transition>
  </Fragment>
);

ContactUs.propTypes = {
  handleOpen: PropTypes.func.isRequired,
  open: PropTypes.bool.isRequired,
  corporateEmployer: PropTypes.string,
};

ContactUs.defaultProps = {
  corporateEmployer: null,
};

export default ContactUs;



// WEBPACK FOOTER //
// ./src/components/header/contact-us-button.js