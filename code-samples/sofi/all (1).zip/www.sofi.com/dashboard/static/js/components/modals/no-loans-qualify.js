import React from 'react';
import PropTypes from 'prop-types';
import { Modal, Button, Paragraph } from 'scuid-x';

/**
 * Styled Components
 */
import { ReasonContainer } from './shared-styles';

const Container = ReasonContainer.extend`
  margin-top: -1.4rem;
`;

const NoLoansQualify = ({ isOpen, toggleOpen }) => (
  <Modal isOpen={isOpen} onDismiss={toggleOpen} title="" minWidth={window.innerWidth >= 768 ? 750 : 0}>
    <Modal.Body>
      <Container>
        <Paragraph>Unfortunately it looks like you do not have any qualifying loans with us</Paragraph>
        <Paragraph>The Unemployment Protection Program only applies to serviced Personal Loans and Refi Loans.</Paragraph>
      </Container>
    </Modal.Body>
    <Modal.Footer>
      <Button data-qa="noLoansQualify-close" small secondary onClick={toggleOpen}>
        Close
      </Button>
    </Modal.Footer>
  </Modal>
);

/* eslint react/no-typos: 0 */
NoLoansQualify.propTypes = {
  isOpen: PropTypes.bool.isRequired,
  toggleOpen: PropTypes.func.isRequired,
};

export default NoLoansQualify;



// WEBPACK FOOTER //
// ./src/components/modals/no-loans-qualify.js