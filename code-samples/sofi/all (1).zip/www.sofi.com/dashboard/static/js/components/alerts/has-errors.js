import React from 'react';
import { I18n } from 'react-redux-i18n';
import PropTypes from 'prop-types';

/**
 * Styled components
 */
import { AlertContent, AlertNotification, AlertParagraph } from './shared-styles';

const HasErrors = ({ hasErrors, setAlertDismissableSession }) => (
  <AlertNotification warning dismissible onDismiss={() => setAlertDismissableSession('has.errors')}>
    <AlertContent>
      <AlertParagraph dangerouslySetInnerHTML={{ __html: I18n.t(hasErrors()) || hasErrors() }} />
    </AlertContent>
  </AlertNotification>
);

HasErrors.propTypes = {
  hasErrors: PropTypes.func.isRequired,
  setAlertDismissableSession: PropTypes.func.isRequired,
};

export default HasErrors;



// WEBPACK FOOTER //
// ./src/components/alerts/has-errors.js