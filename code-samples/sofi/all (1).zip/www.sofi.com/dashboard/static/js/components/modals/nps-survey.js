import React, { Fragment } from 'react';
import PropTypes from 'prop-types';
import { Modal, Button, Paragraph, Radio, RadioGroup, DropDown } from 'scuid-x';
import { withFormik, Form } from 'formik';
import Yup from 'yup';
import styled from 'styled-components';

/**
 * PropTypes imports
 */
import { NpsSurveyPropTypes } from '../../constants/prop-types/nps-survey-prop-types';

/**
 * Utilities/function imports
 */
import { mapServerSideErrorsToFormikErrors } from '../../utilities/api-action-helpers';

/**
 * Styled Components
 */

const SurveyRadio = styled(Radio)`
  display: inline-block;
  margin-right: 20px;
`;

const TextArea = styled.textarea`
  width: 100%;
  font-size: inherit;
  padding: 10px;
`;

const NpsSurvey = ({
  isModalOpen,
  toggleOpen,
  npsSurvey,
  scoreSet,
  lowScore,
  surveySelectOptions,
  values,
  errors,
  handleChange,
  handleSubmit,
  setFieldValue,
  touched,
  isSubmitting,
}) => (
  <Modal isOpen={isModalOpen} onDismiss={toggleOpen} title="SoFi Welcome Survey" minWidth={window.innerWidth >= 768 ? 750 : 0}>
    <Modal.Body>
      <Paragraph>Thanks for taking the time to give us your feedback. Welcome to the SoFi Community!</Paragraph>
      <Form data-qa="nps-survey-form">
        {npsSurvey.survey.questions.map(value => (
          <Fragment key={value.id}>
            {value.questionType === 'RADIO_CHOICE_INLINE' &&
              value.id !== 4 && (
                <RadioGroup legend={value.question} errorText={errors.radioChoiceRating}>
                  {value.choices.map(option => (
                    <SurveyRadio
                      group="radioChoiceRating"
                      qa={`npsSurvey-radioChoiceRating-${option.value}`}
                      value={option.choice}
                      errorText={touched.radioChoiceRating && errors.radioChoiceRating}
                      checked={option.choice === values.radioChoiceRating}
                      onChange={(e) => {
                        scoreSet(e.target.value);
                        setFieldValue('radioChoiceRating', e.target.value);
                      }}
                    >
                      {option.choice}
                    </SurveyRadio>
                  ))}
                </RadioGroup>
              )}
            {value.questionType === 'SELECT_LIST' &&
              value.id !== 4 && (
                <DropDown
                  label={value.question}
                  qa="npsSurvey-chosen-product"
                  onChange={e => setFieldValue('chosenProduct', e.target.value)}
                  options={surveySelectOptions(value)}
                  value={values.chosenProduct}
                />
              )}
            {value.questionType === 'TEXT' &&
              value.id !== 4 && (
                <Fragment>
                  <Paragraph>{value.question}</Paragraph>
                  <TextArea
                    id="feedbackComment"
                    name="feedbackComment"
                    data-qa="npsSurvey-feedbackComment"
                    rows="4"
                    onChange={handleChange}
                  >
                    {values.feedbackComment}
                  </TextArea>
                </Fragment>
              )}
            {value.questionType === 'TEXT' &&
              value.id === 4 &&
              lowScore && (
                <Fragment>
                  <Paragraph>{value.question}</Paragraph>
                  <TextArea
                    id="recommendationComment"
                    name="recommendationComment"
                    data-qa="npsSurvey-recommendationComment"
                    rows="4"
                    onChange={handleChange}
                  >
                    {values.recommendationComment}
                  </TextArea>
                </Fragment>
              )}
          </Fragment>
        ))}
      </Form>
    </Modal.Body>
    <Modal.Footer>
      <Button data-qa="npsSurvey-close" small onClick={toggleOpen}>
        Cancel
      </Button>
      <Button data-qa="npsSurvey-submit" small onClick={handleSubmit} disabled={isSubmitting}>
        Save
      </Button>
    </Modal.Footer>
  </Modal>
);

/* eslint react/no-typos: 0 */
NpsSurvey.propTypes = {
  isModalOpen: PropTypes.bool.isRequired,
  toggleOpen: PropTypes.func.isRequired,
  values: PropTypes.object.isRequired, // eslint-disable-line react/forbid-prop-types
  errors: PropTypes.objectOf(PropTypes.string).isRequired,
  handleChange: PropTypes.func.isRequired,
  handleSubmit: PropTypes.func.isRequired,
  setFieldValue: PropTypes.func.isRequired,
  touched: PropTypes.objectOf(PropTypes.bool).isRequired,
  isSubmitting: PropTypes.bool.isRequired,
  npsSurvey: NpsSurveyPropTypes.isRequired,
  surveySelectOptions: PropTypes.shape({
    value: PropTypes.string,
    label: PropTypes.string,
  }).isRequired,
  scoreSet: PropTypes.func.isRequired,
  lowScore: PropTypes.bool.isRequired,
};

export default withFormik({
  mapPropsToValues: () => ({
    radioChoiceRating: '',
    chosenProduct: '',
    feedbackComment: '',
    recommendationComment: '',
  }),
  validationSchema: () =>
    Yup.object().shape({
      radioChoiceRating: Yup.string().required('Please select one option between 0-10'),
    }),
  handleSubmit: (values, { props, setErrors, setSubmitting }) => {
    props.submitSurvey(
      values,
      serverResponse => setErrors(mapServerSideErrorsToFormikErrors(serverResponse)),
      setSubmitting,
      props.toggleOpen,
    );
  },
})(NpsSurvey);



// WEBPACK FOOTER //
// ./src/components/modals/nps-survey.js