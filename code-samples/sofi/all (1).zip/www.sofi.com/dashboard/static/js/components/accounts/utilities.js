export const showServicing = (applications) => {
  let isTrue = false;
  for (let idx = 0; idx < applications.length; idx += 1) {
    if (applications[idx].servicingAccess && applications[idx].type === 'PL') {
      if (applications[idx].servicing) {
        isTrue = false;
        break;
      } else if (!applications[idx].servicing) {
        isTrue = true;
      }
    }
  }
  return isTrue;
};

export const appInfoComparator = (...args) => {
  const numFields = args.length;
  const fields = [];
  let field;
  let cmp;

  const defaultCmp = (a, b) => {
    if (a === b) {
      return 0;
    }
    return a < b ? -1 : 1;
  };

  const getCmpFunc = (primer, reverse) => {
    const dfc = defaultCmp;
    cmp = defaultCmp;
    if (primer) {
      cmp = (a, b) => dfc(primer(a), primer(b));
    }
    if (reverse) {
      return (a, b) => -1 * cmp(a, b);
    }
    return cmp;
  };

  for (let i = 0; i < numFields; i += 1) {
    let name;
    field = args[i];
    if (typeof field === 'string') {
      name = field;
      cmp = defaultCmp;
    } else {
      name = field.name; // eslint-disable-line
      cmp = getCmpFunc(field.primer, field.reverse);
    }
    fields.push({
      name,
      cmp,
    });
  }

  return (A, B) => {
    let result;
    for (let i = 0; i < numFields; i += 1) {
      result = 0;
      field = fields[i];
      const { name } = field;

      result = field.cmp(A[name], B[name]);
      if (result !== 0) {
        break;
      }
    }
    return result;
  };
};

/**
 * Users from Vermont may not participate in the referral program by law.
 *
 * @param customer that might be able to participate in the referral program
 * @returns {boolean} true if the customer is eligible
 */
export const eligibleForReferralProgram = customer => !['VT'].includes(customer.state);

export const canContinueApp = (app) => {
  const { status } = app;
  let canInteract = false;
  if (
    app.type === 'COSIGN' &&
    app.active &&
    (status === 'Incomplete' ||
      status === 'Processing' ||
      status === 'WaitingForSignature' ||
      status === 'MissingInfo' ||
      status === 'NoCreditProcessing' ||
      status === 'Continue' ||
      status === 'Prequalified' ||
      status === 'CosignerSigned')
  ) {
    canInteract = true;
  } else if (
    app.type === 'MORT' &&
    app.active &&
    (status !== 'Withdrawn' &&
      status !== 'Expired' &&
      status !== 'Declined' &&
      status !== 'Funded' &&
      status !== 'AdverseAction' &&
      status !== 'ServicerFunded')
  ) {
    canInteract = true;
  } else if (
    ['REFI', 'PARENT', 'PLUS', 'MEDREFI', 'DENTREFI'].includes(app.type) &&
    app.active &&
    status !== 'FinalDisclosureComplete' &&
    status !== 'Funded' &&
    status !== 'Expired' &&
    status !== 'AdverseAction' &&
    status !== 'Withdrawn' &&
    status !== 'Declined' &&
    status !== 'WFCosignerLFCF' &&
    status !== 'Funding' &&
    status !== 'QCFraudReview' &&
    status !== 'ServicerFunded' &&
    status !== 'CloseFileForIncompleteness' &&
    'CosignerHold'
  ) {
    canInteract = true;
  } else if (
    app.type === 'PL' &&
    app.active &&
    status !== 'FinalDisclosureComplete' &&
    status !== 'Funded' &&
    status !== 'Expired' &&
    status !== 'AdverseAction' &&
    status !== 'Withdrawn' &&
    status !== 'Declined' &&
    status !== 'Funding' &&
    status !== 'QCFraudReview' &&
    status !== 'ServicerFunded' &&
    status !== 'CloseFileForIncompleteness'
  ) {
    canInteract = true;
  }
  return canInteract;
};

export const isEcp = app => app.type === 'CONTRIB';

export const isBankruptcy = (app) => {
  const matchList = ['Bankruptcy', 'Bankruptcy - Charge Off', 'Bankruptcy - Recovery'];
  return matchList.indexOf(app.servicing.status) !== -1;
};

export const isForbearance = (app) => {
  const matchList = ['Active Forbearance', 'Pending Forbearance'];
  return matchList.indexOf(app.servicing.status) !== -1;
};

export const isChargeOff = (app) => {
  const matchList = ['Charge-Off', 'Write-Off', 'Charge-Off Complete', 'Charge-Off Transfer'];
  return matchList.indexOf(app.servicing.status) !== -1;
};

export const isInRepayment = (app) => {
  const matchList = ['In Repayment', 'SCRA', 'Past Due', 'Current', 'Paid in Full'];
  return matchList.indexOf(app.servicing.status) !== -1;
};

export const isUnboardedLoan = (app) => {
  const matchList = ['Unboard Loan'];
  return matchList.indexOf(app.servicing.status) !== -1;
};

export const isUnknownStatus = app =>
  !isBankruptcy(app) &&
  !isForbearance(app) &&
  !isChargeOff(app) &&
  !isInRepayment(app) &&
  !isUnboardedLoan(app) &&
  !isEcp(app) &&
  app.type !== 'MORT';

/**
 * Returns the forbearance status
 */
export const generateForbearanceStatus = (app) => {
  let status = 'Your loan is in forbearance. Please call 855-456-7634 with any questions.';
  if (app.servicing.status === 'Pending Forbearance') {
    status = 'Your loan is pending forbearance. Please call 855-456-7634 with any questions.';
  }
  if (app.servicing.forbearance) {
    if (app.servicing.status === 'Active Forbearance') {
      const { forbearance } = app.servicing;
      if (forbearance.overrideEndDate || forbearance.endDate) {
        const date = forbearance.overrideEndDate ? forbearance.overrideEndDate : forbearance.endDate;
        status = `Your loan is in forbearance. Your forbearance end date is ${date}.`;
      }
    }
    if (app.servicing.status === 'Pending Forbearance') {
      const { forbearance } = app.servicing;
      if (forbearance.startDate) {
        status = `Your loan is pending forbearance. Your forbearance will begin on ${forbearance.startDate}.`;
      }
    }
  }
  return status;
};

export const statusIndicator = (app) => {
  const { status } = app;
  if (
    status === 'NoCreditProcessing' ||
    status === 'Processing' ||
    status === 'Review' ||
    status === 'FinalDisclosureGen' ||
    status === 'FinalDisclosureComplete' ||
    status === 'Funding' ||
    status === 'TransitionToServicer' ||
    status === 'ProcessingPreapproval' ||
    status === 'Underwriting' ||
    status === 'CosignerSigned' ||
    status === 'PreapprovedProcessing' ||
    status === 'UnderwritingConditions'
  ) {
    return 'caution';
  }
  if (
    status === 'SelectProduct' ||
    status === 'MissingInfo' ||
    status === 'WaitingForSignature' ||
    status === 'Incomplete' ||
    status === 'WaitingForApprovalDisclosure' ||
    status === 'WFCosigner' ||
    status === 'WFCosignerLFCF' ||
    status === 'NeedsCosigner'
  ) {
    return 'negative';
  }
  if (
    status === 'Declined' ||
    status === 'Withdrawn' ||
    status === 'AdverseAction' ||
    status === 'Expired' ||
    status === 'Ineligible' ||
    status === 'Inactive' ||
    status === 'FundingCancelled' ||
    status === 'Suspended' ||
    status === 'CloseFileForIncompleteness'
  ) {
    return 'inactive';
  }
  return 'positive';
};

/**
 * Returns the document if it exists
 * @param {Object} app Specific application object
 * @param {String} type Document type
 */
export const findDocument = (app, type) => {
  const foundDoc = app.docs.find(doc => doc.type === type);
  return foundDoc || null;
};

export const needsSigned = (app) => {
  const { status } = app;
  return (
    status === 'Incomplete' ||
    status === 'WaitingForApprovalDisclosure' ||
    status === 'WFCosigner' ||
    status === 'WFCosignerLFCF' ||
    status === 'NeedsCosigner' ||
    status === 'WaitingForSignature' ||
    status === 'MissingInfo' ||
    status === 'OfferChange'
  );
};

export const servicedPl = app => app.type === 'PL' && app.status === 'TransitionToServicer';

const isViewDetailsText = (app) => {
  let viewDetails = false;
  const statusInd = statusIndicator(app);
  const { status } = app;
  if (status !== 'Continue' && status !== 'CosignerComplete' && (statusInd === 'positive' || statusInd === 'caution')) {
    viewDetails = true;
  }
  return viewDetails;
};

const isContinueText = app => !isViewDetailsText(app);

export const generateContinueText = app => (isContinueText(app) ? 'Continue' : 'View details');

export const showWelcomeBonus = (app) => {
  const { status } = app;
  return (
    app.welcomeBonusAmount &&
    app.welcomeBonusStatus &&
    status !== 'Declined' &&
    status !== 'AdverseAction' &&
    status !== 'Expired' &&
    status !== 'Withdrawn' &&
    status !== 'FundingCancelled' &&
    status !== 'Inactive' &&
    status !== 'CloseFileForIncompleteness'
  );
};

export const isProcessingWelcomeBonus = (app) => {
  const { status } = app;
  return status === 'TransitionToServicer' || status === 'Funded' || status === 'ServicerFunded';
};

export const isProductSelect = app => app.status === 'SelectProduct';

export const loanAmountTitle = (app) => {
  const { status } = app;
  if (app.type === 'MORT') {
    return 'Initial loan amount';
  } else if (
    ['REFI', 'PARENT', 'PLUS', 'MEDREFI', 'DENTREFI'].includes(app.type) &&
    status === 'ServicerFunded'
  ) {
    return 'Funded loan amount';
  }
  return 'Loan amount';
};

export const isMortCENLAR = app => app.servicing && app.servicing.status === 'CENLAR';

export const hasMortServicingAccess = (app) => {
  let access = null;
  if (app) {
    const mortApp = app;
    if (mortApp.servicing && mortApp.type === 'MORT') {
      access = mortApp.servicing.servicingUrl;
    }
  }
  return access;
};



// WEBPACK FOOTER //
// ./src/components/accounts/utilities.js