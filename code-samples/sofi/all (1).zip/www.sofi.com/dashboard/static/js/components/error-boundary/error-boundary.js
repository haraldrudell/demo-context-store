import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { NotificationBar, Paragraph, AccordionMultiTitle } from 'scuid-x';
import styled from 'styled-components';
import { errorLogger } from '../../utilities/error-handling';

/**
 * Styled components
 */
const Container = styled.div`
  max-width: 1240px;
  margin: 0px auto;
  padding: 20px;
`;

const CustomAccordion = styled(AccordionMultiTitle)`
  margin-bottom: 0px;
  header {
    box-shadow: none;
    padding: 0px;
    margin-bottom: 0px;
    &:focus {
      outline: none;
    }
  }
`;

class ErrorBoundary extends Component {
  static propTypes = {
    children: PropTypes.node.isRequired,
  };

  state = { error: null, info: null };

  componentDidCatch(error, info) {
    this.setState({ error, info });
    // Log error to error reporting service
    errorLogger(error);
  }

  render() {
    const { children } = this.props;
    const { error, info } = this.state;
    if (info && process.env.NODE_ENV === 'development') {
      console.log('---->', info); // eslint-disable-line no-console
    }
    if (error) {
      return (
        <Container>
          <NotificationBar warning>
            <CustomAccordion title="Something went wrong. Please refresh the page and try again." subTitle="" iconTitle="Details">
              <Paragraph>{error.message}</Paragraph>
            </CustomAccordion>
          </NotificationBar>
        </Container>
      );
    }

    return children;
  }
}

export default ErrorBoundary;



// WEBPACK FOOTER //
// ./src/components/error-boundary/error-boundary.js