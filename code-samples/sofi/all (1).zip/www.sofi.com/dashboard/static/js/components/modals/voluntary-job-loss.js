import React from 'react';
import PropTypes from 'prop-types';
import { Modal, Button, Paragraph } from 'scuid-x';

/**
 * Styled Components
 */
import { ReasonContainer } from './shared-styles';

const Container = ReasonContainer.extend`
  margin-top: -1.4rem;
`;

const VoluntaryJobLoss = ({ isOpen, toggleOpen }) => (
  <Modal isOpen={isOpen} onDismiss={toggleOpen} title="" minWidth={window.innerWidth >= 768 ? 750 : 0}>
    <Modal.Body>
      <Container>
        <Paragraph>You have self-identified as having lost your job voluntarily.</Paragraph>
        <Paragraph>Unfortunately, the Unemployment Protection Program does not apply to those who have voluntarily left work.</Paragraph>
      </Container>
    </Modal.Body>
    <Modal.Footer>
      <Button data-qa="voluntaryJobLoss-close" small secondary onClick={toggleOpen}>
        Close
      </Button>
    </Modal.Footer>
  </Modal>
);

/* eslint react/no-typos: 0 */
VoluntaryJobLoss.propTypes = {
  isOpen: PropTypes.bool.isRequired,
  toggleOpen: PropTypes.func.isRequired,
};

export default VoluntaryJobLoss;



// WEBPACK FOOTER //
// ./src/components/modals/voluntary-job-loss.js