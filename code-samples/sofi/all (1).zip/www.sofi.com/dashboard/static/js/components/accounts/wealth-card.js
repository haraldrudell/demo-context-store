import React from 'react';
import styled from 'styled-components';

/**
 * PropTypes imports
 */
import { DashboardAccountsPropTypes } from '../../constants/prop-types/dashboard-accounts-prop-types';

const WealthData = styled.div`
  display: flex;
  flex-wrap: wrap;
  flex: 1;
`;

const ValuesWrapper = styled.div`
  max-width: 50%;
  margin-top: 0.5rem;
  flex: 0 0 50%;
  font-weight: 500;
  font-family: 'TT Norms', 'proxima-nova', 'Helvetica Neue', Verdana, Arial, Helvetica, sans-serif;
  font-size: 1.125rem;
`;

const Gain = styled.p`
  color: #008000;
`;

const Loss = styled.p`
  color: #ff0000;
`;

const NoChange = styled.p`
  color: #262626;
`;

const ValueLabel = styled.span`
  font-size: 0.813rem;
  letter-spacing: 0.04em;
  color: #757575;
  display: block;
`;

const checkFluctuation = (data) => {
  if (data.match('▲')) {
    return <Gain>{data}</Gain>;
  } else if (data.match('▼')) {
    return <Loss>{data}</Loss>;
  }
  return <NoChange>{data}</NoChange>;
};

const WealthCard = ({ account }) => (
  <WealthData>
    {account.data.topLeftData && (
      <ValuesWrapper>
        {checkFluctuation(account.data.topLeftData)}
        <ValueLabel>{account.data.topLeftLabel}</ValueLabel>
      </ValuesWrapper>
    )}
    {account.data.topRightData && (
      <ValuesWrapper>
        {checkFluctuation(account.data.topRightData)}
        <ValueLabel>{account.data.topRightLabel}</ValueLabel>
      </ValuesWrapper>
    )}
  </WealthData>
);

/* eslint react/no-typos: 0 */
WealthCard.propTypes = {
  account: DashboardAccountsPropTypes.isRequired,
};

export default WealthCard;



// WEBPACK FOOTER //
// ./src/components/accounts/wealth-card.js