import React, { Fragment } from 'react';
import PropTypes from 'prop-types';
import styled from 'styled-components';

/**
 * Component imports
 */
import Transition from './nav-transition';
import NotificationIcon from './notification/icon';
import NotificationList from './notification/notification-list';

/**
 * Styled components
 */
const NotificationContainer = styled.div`
  max-height: inherit;
  position: absolute;
  overflow: hidden;
  z-index: 14;
  right: -25px;
  top: calc(100% + 5px);
`;

const NotificationsIconButton = ({
  handleOpen, open, hasNewNotification, markNewAsUnread, handleKeyDown, ...rest
}) => (
  <Fragment>
    <a data-qa="nav-bar-notification-button" tabIndex={0} role="button" onClick={handleOpen} onKeyDown={handleKeyDown}>
      <NotificationIcon hasNewNotification={hasNewNotification} />
    </a>
    <Transition isOpen={open} relative>
      <NotificationContainer>
        <NotificationList open={open} handleOpen={handleOpen} markNewAsUnread={markNewAsUnread} {...rest} />
      </NotificationContainer>
    </Transition>
  </Fragment>
);

NotificationsIconButton.propTypes = {
  handleOpen: PropTypes.func.isRequired,
  open: PropTypes.bool.isRequired,
  hasNewNotification: PropTypes.bool.isRequired,
  markNewAsUnread: PropTypes.func.isRequired,
  handleKeyDown: PropTypes.func.isRequired,
};

export default NotificationsIconButton;



// WEBPACK FOOTER //
// ./src/components/header/notifications-icon-button.js