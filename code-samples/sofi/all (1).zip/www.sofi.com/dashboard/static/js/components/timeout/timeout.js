import React, { Component } from 'react';
import PropTypes from 'prop-types';

/**
 * Component imports
 */
import TimeoutModal from './timeout-modal';

/**
 * Utilities
 */
import { redirectToTimeout } from '../../utilities/redirect-helpers';

/**
 * Events we are listening to in order to display the timeout modal
 */
const EVENTS = ['mousemove', 'mousedown', 'keydown', 'touchstart', 'scroll'];

class Timeout extends Component {
  static propTypes = {
    kickdog: PropTypes.func.isRequired,
  }

  state = {
    showModal: false,
    idleTime: 15,
    modalTime: 5,
  };

  componentDidMount() {
    this.attachEvents();
    this.isStillMounted = true;
    this.initNewTimeout();
  }

  shouldComponentUpdate(nextProps, nextState) {
    return this.state.showModal !== nextState.showModal;
  }

  componentDidUpdate() {
    if (!this.state.showModal && this.isStillMounted) this.initNewTimeout();
  }

  componentWillUnmount() {
    this.removeEvents();
    this.isStillMounted = false;
    if (this.globalTimeoutID) {
      clearTimeout(this.globalTimeoutID);
      this.globalTimeoutID = undefined;
    }
  }

  isStillMounted = false;
  globalTimeoutID;

  attachEvents = () => {
    EVENTS.forEach((event) => {
      window.addEventListener(event, this.handleEvent, true);
    });
  };

  removeEvents() {
    EVENTS.forEach((event) => {
      window.removeEventListener(event, this.handleEvent, true);
    });
  }

  handleEvent = () => {
    if (!this.state.showModal) {
      this.initNewTimeout();
    }
  };

  initNewTimeout = async () => {
    if (this.state.showModal) {
      this.props.kickdog();
      this.setState({ showModal: false });
    }
    if (this.globalTimeoutID) {
      clearTimeout(this.globalTimeoutID);
    }
    await this.idleTimeout();
    this.showTimeoutModal();
  };

  idleTimeout = async () =>
    new Promise((resolve) => {
      this.globalTimeoutID = setTimeout(() => resolve('Finished'), this.state.idleTime * 60 * 1000);
    });

  showTimeoutModal = () => {
    this.setState({ showModal: true });
  };

  hideTimeoutModal = () => {
    this.initNewTimeout();
  };

  logout = () => {
    this.setState({ showModal: false });
    this.isStillMounted = false;
    if (this.globalTimeoutID) {
      clearTimeout(this.globalTimeoutID);
      this.globalTimeoutID = undefined;
    }
    redirectToTimeout();
  };

  render() {
    return (
      <TimeoutModal
        isOpen={this.state.showModal}
        hideModal={this.hideTimeoutModal}
        logout={this.logout}
        modalTime={this.state.modalTime}
      />
    );
  }
}

export default Timeout;



// WEBPACK FOOTER //
// ./src/components/timeout/timeout.js