import React, { Component } from 'react';
import PropTypes from 'prop-types';

/**
 * Measurementjs
 */
import { fireEvent } from '../../utilities/measurementjs-helpers';

/**
 * PropTypes imports
 */
import { CustomerPropTypes } from '../../constants/prop-types/customer-prop-types';
import { StatesPropTypes } from '../../constants/prop-types//states-prop-types';
import { QueryParamPropTypes } from '../../constants/prop-types/modals-prop-types';
import { ApplicationPropType } from '../../constants/prop-types/application-prop-types';
import { WaitForCosignerErrorPropTypes } from '../../constants/prop-types/wait-for-cosign-error-prop-types';

/**
 * Component imports
 */
import StateMissing from './state-missing';
import SsnMissing from './ssn-missing';
import FrozenCredit from './frozen-credit';
import MortgageCredit from './mortgage-credit';
import Declined from './declined';
import DeclinedCosign from './declined-cosign';
import VoluntaryJobLoss from './voluntary-job-loss';
import NoEmployment from './no-employment';
import SelfEmployment from './self-employment';
import NoLoansQualify from './no-loans-qualify';
import MortgageFrozenCredit from './mortgage-frozen-credit';

const eventForAppType = (appType) => {
  if (appType) {
    if (['REFI', 'PLUS', 'MEDREFI', 'DENTREFI'].includes(appType.toUpperCase())) {
      return 'refiDeclinedSubmit';
    } else if (appType.toUpperCase() === 'PARENT') {
      return 'parentDeclinedSubmit';
    } else if (appType.toUpperCase() === 'MORT') {
      return 'mortDeclinedSubmit';
    }
  }
  return null;
};

class Modals extends Component {
  static propTypes = {
    customer: CustomerPropTypes.isRequired,
    loadStates: PropTypes.func.isRequired,
    statesLoaded: PropTypes.bool,
    states: StatesPropTypes.isRequired,
    updateState: PropTypes.func.isRequired,
    appParams: QueryParamPropTypes.isRequired,
    retryService: PropTypes.func.isRequired,
    updateCosigner: PropTypes.func.isRequired,
    applications: PropTypes.arrayOf(ApplicationPropType).isRequired,
    triggerAlert: PropTypes.func.isRequired,
    setWaitForCosigner: PropTypes.func.isRequired,
    waitForCosignError: WaitForCosignerErrorPropTypes.isRequired,
  };

  static defaultProps = {
    statesLoaded: false,
  };

  state = {
    open: true,
  };

  componentDidMount() {
    const { customer } = this.props;
    if (!customer.state) {
      this.props.loadStates();
    }
  }

  toggleOpen = () => {
    this.setState({ open: !this.state.open });
  };

  render() {
    const {
      customer, appParams, retryService, triggerAlert, setWaitForCosigner, waitForCosignError,
    } = this.props;
    const { open } = this.state;

    // Get the action
    const { action } = appParams;

    if (!customer.state) {
      const { statesLoaded, states, updateState } = this.props;
      return statesLoaded && <StateMissing isOpen={open} toggleOpen={this.toggleOpen} states={states} updateState={updateState} />;
    }

    switch (action) {
      case 'ssn': {
        return (
          <SsnMissing
            isOpen={open}
            toggleOpen={this.toggleOpen}
            customer={customer}
            appParams={appParams}
            retryService={retryService}
            triggerAlert={triggerAlert}
          />
        );
      }
      case 'frozenCredit': {
        return <FrozenCredit isOpen={open} toggleOpen={this.toggleOpen} appParams={appParams} />;
      }
      case 'mortCredit': {
        return (
          <MortgageCredit
            isOpen={open}
            toggleOpen={this.toggleOpen}
            customer={customer}
            appParams={appParams}
            retryService={retryService}
          />
        );
      }
      case 'mortFrozenCredit': {
        return <MortgageFrozenCredit isOpen={open} toggleOpen={this.toggleOpen} />;
      }
      case 'declined': {
        const { appId, appType, reason } = appParams;
        const event = eventForAppType(appType);
        if (event) {
          fireEvent({ event, mjs_app_id: appId, mjs_app_type: appType });
        }
        if (
          appId &&
          ['parentUnqualifiedCosignerNeeded', 'refiUnqualifiedCosignerNeeded', 'plusUnqualifiedCosignerNeeded'].indexOf(reason) >= 0
        ) {
          const applicationsList = this.props.applications.filter(app => !(app.type === 'CONTRIB' || app.type === 'COSIGN'));
          const isTrue = applicationsList.some(app => appId === app.id);
          if (isTrue) {
            const waitingForCosigner = applicationsList.some(app => (appId === app.id && app.status === 'WFCosigner'));
            if (waitingForCosigner) {
              if (!waitForCosignError.hasBeenDisplayed || waitForCosignError.hasBeenClosed) {
                setWaitForCosigner();
              }
              return '';
            }
            const { updateCosigner } = this.props;
            return (
              <DeclinedCosign
                isOpen={open}
                toggleOpen={this.toggleOpen}
                customer={customer}
                appParams={appParams}
                updateCosigner={updateCosigner}
              />
            );
          }
        } else if (reason) {
          return <Declined isOpen={open} toggleOpen={this.toggleOpen} customer={customer} appParams={appParams} />;
        }
        return '';
      }
      case 'upp': {
        const { reason } = appParams;

        if (reason === 'voluntary') return <VoluntaryJobLoss isOpen={open} toggleOpen={this.toggleOpen} />;
        else if (reason === 'noEmployment') return <NoEmployment isOpen={open} toggleOpen={this.toggleOpen} />;
        else if (reason === 'selfEmployment') return <SelfEmployment isOpen={open} toggleOpen={this.toggleOpen} />;
        else if (reason === 'noEligibleLoans') return <NoLoansQualify isOpen={open} toggleOpen={this.toggleOpen} />;

        // No modals need to be shown
        return '';
      }
      default:
        // No modals need to be shown
        return '';
    }
  }
}

export default Modals;



// WEBPACK FOOTER //
// ./src/components/modals/modals.js