import React, { Fragment } from 'react';
import { SubheadFour } from 'scuid-x';

/**
 * PropTypes imports
 */
import { ApplicationPropType } from '../../constants/prop-types/application-prop-types';

/**
 * Styled Components
 */
import { LoanDescription } from './shared-styles';

const UnboardedLoan = ({ app }) => (
  <Fragment>
    <SubheadFour>
      {app.productDesc} (#{app.servicing.accountId})
    </SubheadFour>
    <LoanDescription>{app.servicing.statusDesc}</LoanDescription>
  </Fragment>
);

/* eslint react/no-typos: 0 */
UnboardedLoan.propTypes = {
  app: ApplicationPropType.isRequired,
};

export default UnboardedLoan;



// WEBPACK FOOTER //
// ./src/components/accounts/unboarded-loan.js