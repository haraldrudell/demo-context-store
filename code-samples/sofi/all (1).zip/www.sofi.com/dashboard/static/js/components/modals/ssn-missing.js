import React from 'react';
import PropTypes from 'prop-types';
import { Modal, Button, SsnInput } from 'scuid-x';
import { withFormik, Form } from 'formik';
import Yup from 'yup';
import { I18n } from 'react-redux-i18n';
import styled from 'styled-components';

/**
 * PropTypes imports
 */
import { QueryParamPropTypes } from '../../constants/prop-types/modals-prop-types';

/**
 * Utilities/function imports
 */
import { mapServerSideErrorsToFormikErrors } from '../../utilities/api-action-helpers';

/**
 * Styled Components
 */
import { ReasonContainer } from './shared-styles';

const FormikForm = styled(Form)`
  margin-top: -1.4rem;
`;

const SsnMissing = ({
  isOpen, toggleOpen, values, errors, handleChange, handleSubmit, touched, isSubmitting, appParams, triggerAlert,
}) => {
  const coSsnRequired = appParams.applicantCount > 1;
  const reason = 'nocreditSSN'; // exists in the translation file
  return (
    <Modal isOpen={isOpen} onDismiss={toggleOpen} title="" minWidth={window.innerWidth >= 768 ? 750 : 0}>
      <Modal.Body>
        <FormikForm data-qa="ssn-missing-form">
          {/* dangerouslySetInnerHTML because the Translation files have HTML tags in them */}
          <ReasonContainer dangerouslySetInnerHTML={{ __html: I18n.t(reason) }} />
          <SsnInput
            id="ssn"
            name="ssn"
            halfWidth={window.innerWidth < 540}
            quarterWidth={window.innerWidth >= 540}
            label="SSN"
            placeholder="***-**-****"
            onChange={handleChange}
            value={values.ssn}
            errorText={touched.ssn && errors.ssn}
            qa="ssn-input"
          />
          {coSsnRequired ? (
            <SsnInput
              id="coSsn"
              name="coSsn"
              halfWidth={window.innerWidth < 540}
              quarterWidth={window.innerWidth >= 540}
              label="CO-SSN"
              placeholder="***-**-****"
              onChange={handleChange}
              value={values.coSsn}
              errorText={touched.coSsn && errors.coSsn}
              qa="cossn-input"
            />
          ) : (
            ''
          )}
        </FormikForm>
      </Modal.Body>
      <Modal.Footer>
        <Button
          data-qa="ssn-close"
          small
          onClick={() => {
            toggleOpen();
            triggerAlert();
          }}
        >
          Cancel
        </Button>
        <Button data-qa="ssn-submit" small onClick={handleSubmit} disabled={isSubmitting}>
          Save
        </Button>
      </Modal.Footer>
    </Modal>
  );
};

/* eslint react/no-typos: 0 */
SsnMissing.propTypes = {
  isOpen: PropTypes.bool.isRequired,
  toggleOpen: PropTypes.func.isRequired,
  values: PropTypes.object.isRequired, // eslint-disable-line react/forbid-prop-types
  errors: PropTypes.objectOf(PropTypes.string).isRequired,
  handleChange: PropTypes.func.isRequired,
  handleSubmit: PropTypes.func.isRequired,
  touched: PropTypes.objectOf(PropTypes.bool).isRequired,
  isSubmitting: PropTypes.bool.isRequired,
  appParams: QueryParamPropTypes.isRequired,
  triggerAlert: PropTypes.func.isRequired,
};

export default withFormik({
  mapPropsToValues: () => ({
    ssn: '',
    coSsn: '',
  }),
  validationSchema: props =>
    Yup.lazy(values =>
      Yup.object().shape({
        ssn: Yup.string()
          .required('SSN is a required field')
          .min(9, 'Must be 9 characters'),
        coSsn:
          props.appParams.applicantCount > 1
            ? Yup.string()
              .required('CO-SSN is a required field')
              .min(9, 'Must be 9 characters')
              .notOneOf([values.ssn], 'CO-SSN cannot be the same as SSN')
            : Yup.string().nullable(),
      })),
  handleSubmit: (values, { props, setErrors, setSubmitting }) => {
    /**
     * values -> { ssn: '', coSsn: '' }
     */
    props.retryService(
      values,
      serverResponse => setErrors(mapServerSideErrorsToFormikErrors(serverResponse)),
      setSubmitting,
      props.toggleOpen,
    );
  },
})(SsnMissing);



// WEBPACK FOOTER //
// ./src/components/modals/ssn-missing.js