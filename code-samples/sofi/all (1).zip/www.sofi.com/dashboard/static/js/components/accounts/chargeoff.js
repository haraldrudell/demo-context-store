import React, { Fragment } from 'react';
import { SubheadFour } from 'scuid-x';

/**
 * PropTypes imports
 */
import { ApplicationPropType } from '../../constants/prop-types/application-prop-types';

/**
 * Styled Components
 */
import { LoanDescription } from './shared-styles';

const Chargeoff = ({ app }) => (
  <Fragment>
    <SubheadFour>
      {app.productDesc} (#{app.servicing.accountId})
    </SubheadFour>
    <LoanDescription>{app.servicing.statusDesc}</LoanDescription>
  </Fragment>
);

/* eslint react/no-typos: 0 */
Chargeoff.propTypes = {
  app: ApplicationPropType.isRequired,
};

export default Chargeoff;



// WEBPACK FOOTER //
// ./src/components/accounts/chargeoff.js