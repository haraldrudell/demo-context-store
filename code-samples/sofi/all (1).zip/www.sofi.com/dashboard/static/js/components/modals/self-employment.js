import React from 'react';
import PropTypes from 'prop-types';
import { Modal, Button, Paragraph } from 'scuid-x';

/**
 * Styled Components
 */
import { ReasonContainer } from './shared-styles';

const Container = ReasonContainer.extend`
  margin-top: -1.4rem;
`;

const SelfEmployment = ({ isOpen, toggleOpen }) => (
  <Modal isOpen={isOpen} onDismiss={toggleOpen} title="" minWidth={window.innerWidth >= 768 ? 750 : 0}>
    <Modal.Body>
      <Container>
        <Paragraph>Our records show that you have identified as self-employed.</Paragraph>
        <Paragraph>
          Unfortunately, the Unemployment Protection Program does not apply to those who have identified as self-employed. Should you gain
          outside employment and require assistance, please contact us again.
        </Paragraph>
      </Container>
    </Modal.Body>
    <Modal.Footer>
      <Button data-qa="selfEmployment-close" small secondary onClick={toggleOpen}>
        Close
      </Button>
    </Modal.Footer>
  </Modal>
);

/* eslint react/no-typos: 0 */
SelfEmployment.propTypes = {
  isOpen: PropTypes.bool.isRequired,
  toggleOpen: PropTypes.func.isRequired,
};

export default SelfEmployment;



// WEBPACK FOOTER //
// ./src/components/modals/self-employment.js