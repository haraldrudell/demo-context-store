import React from 'react';
import styled from 'styled-components';
import * as color from 'scuid-x/styles/color';

/**
 * Styled components
 */
const CeoLink = styled.a`
  color: ${color.MediumGray};
  font-weight: 500;
  text-decoration: none;
  font-size: 1rem;

  &:hover,
  &:focus {
    color: ${color.Blue};
    cursor: pointer;
    text-decoration: underline;
  }
`;


const EmailCEO = () => (
  <CeoLink
    data-qa="email-ceo-link"
    href="mailto:anthony@sofi.com"
    data-mjs="dashboard-email-ceo"
  >
    Email CEO
  </CeoLink>
);

export default EmailCEO;



// WEBPACK FOOTER //
// ./src/components/header/email-ceo.js