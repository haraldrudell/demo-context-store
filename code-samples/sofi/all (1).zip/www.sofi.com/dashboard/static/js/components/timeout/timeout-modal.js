import React from 'react';
import PropTypes from 'prop-types';
import { Modal, Button, Paragraph } from 'scuid-x';

/**
 * Component imports
 */
import Timer from './timer';

/**
 * Styled components
 */
import { ResponsiveModalFooter, ResponsiveModalContent } from '../../utilities/global-styles';

const TimeoutModal = ({
  isOpen, hideModal, logout, modalTime,
}) => (
  <Modal isOpen={isOpen} onDismiss={hideModal} title="Your session is about to expire...">
    <Modal.Body>
      <ResponsiveModalContent>
        <Paragraph>
          You will be logged out in <Timer time={modalTime} onTimeUp={logout} /> seconds.
        </Paragraph>
        <Paragraph>Would you like to stay signed in?</Paragraph>
      </ResponsiveModalContent>
    </Modal.Body>

    <Modal.Footer>
      <ResponsiveModalFooter>
        <Button data-qa="timeout-modal-no-button" small secondary onClick={logout}>
          No, log out
        </Button>
        <Button data-qa="timeout-modal-yes-button" small onClick={hideModal}>
          Yes, keep me signed in
        </Button>
      </ResponsiveModalFooter>
    </Modal.Footer>
  </Modal>
);

TimeoutModal.propTypes = {
  isOpen: PropTypes.bool,
  modalTime: PropTypes.number,
  hideModal: PropTypes.func.isRequired,
  logout: PropTypes.func.isRequired,
};

TimeoutModal.defaultProps = {
  isOpen: true,
  modalTime: 1,
};

export default TimeoutModal;



// WEBPACK FOOTER //
// ./src/components/timeout/timeout-modal.js