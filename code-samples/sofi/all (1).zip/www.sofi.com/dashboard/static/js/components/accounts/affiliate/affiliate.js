import React, { Component, Fragment } from 'react';
import PropTypes from 'prop-types';
import { Link } from 'react-router-dom';
import styled from 'styled-components';
import copyText from 'copy-to-clipboard';

/**
 * PropTypes imports
 */
import { CustomerPropTypes } from '../../../constants/prop-types/customer-prop-types';
import { ReferralConsentsPropTypes, ReferralSummaryPropTypes } from '../../../constants/prop-types/referral-prop-types';

/**
 * Component imports
 */
import ShareModal from './affiliate-modal';

/**
 * Image imports
 */
import ShareImage from '../../../assets/img/share.svg';

/**
 * Utilities/function imports
 */
import { findHighestCampaigns, formatUrl } from './utilities';
import { eligibleForReferralProgram } from '../utilities';
import { AFFILIATE_OVERVIEW_URL } from '../../../constants/referral-constants';
import { FORMAT_CURRENCY } from '../../../utilities/currency-format-helpers';

/**
 * Styled Components
 */
import { LoanBody, LoanSummary, LoanAction, LoanAmount, LoanButton, LoanAdditionalInfo } from '../shared-styles';
import { RouterLink } from '../../../utilities/global-styles';

const Container = styled.div`
  padding-bottom: 1.5rem;

  @media (min-width: 768px) {
    padding-bottom: 2rem;
  }
`;

const ReferSpan = styled.span`
  color: #117db0;
  font-weight: 500;
`;

const RLink = RouterLink.extend`
  text-align: center;
  text-decoration: none;
  margin-top: 0.5rem;

  @media (max-width: 767px) {
    margin-top: 0;
    margin-left: 1rem;
  }
`;

const ShareIcon = styled.img`
  margin-left: 5px;
  margin-bottom: -3px;
`;

const ShareSoFi = styled.div`
  display: flex;
  flex-direction: column;
  font-size: 1.6rem;
  font-weight: 500;
  span {
    font-size: initial;
    font-weight: 400;
  }
`;

const ReferSummary = styled(LoanSummary)`
  flex-direction: row;
  align-items: flex-end;
  justify-content: space-between;
`;

const touAutoConsentMinVersion = 3;

const autoEnroll = (postReferralConsent) => {
  const consentObj = { referralConsent: true };
  postReferralConsent(consentObj);
};

class Affiliate extends Component {
  static propTypes = {
    customer: CustomerPropTypes.isRequired,
    referralSummary: ReferralSummaryPropTypes.isRequired,
    consentsTou: PropTypes.number.isRequired,
    referralConsents: ReferralConsentsPropTypes.isRequired,
    postReferralConsent: PropTypes.func.isRequired,
  };

  state = {
    open: false,
    copy: false,
  };

  componentDidMount() {
    const { consentsTou, referralConsents, postReferralConsent } = this.props;

    const displayCampaigns = referralConsents.referralConsent || false;

    if (consentsTou >= touAutoConsentMinVersion && !displayCampaigns) {
      autoEnroll(postReferralConsent);
    }
  }

  toggleOpen = () => {
    this.setState({ open: !this.state.open, copy: false });
  };

  toggleCopy = (url) => {
    copyText(formatUrl(url));
    if (!this.state.copy) {
      this.setState({ copy: true });
    }
  };

  render() {
    const {
      consentsTou, customer, referralSummary, referralConsents,
    } = this.props;
    const { open, copy } = this.state;

    const displayCampaigns = referralConsents.referralConsent || false;
    const isReferralConsented = consentsTou >= touAutoConsentMinVersion;

    const summary = findHighestCampaigns(referralSummary);
    return (
      <Container>
        {displayCampaigns &&
          summary && (
            <Fragment>
              <ReferSpan>Refer a Friend, Get $300.</ReferSpan>
              <LoanBody>
                <ReferSummary>
                  <LoanAmount data-qa="dashboard-total-bonus-earned">
                    {(summary.paid || Number.isInteger(summary.paid)) && FORMAT_CURRENCY(summary.paid)}
                    <span>Total bonuses earned</span>
                  </LoanAmount>
                  <LoanAdditionalInfo data-qa="dashboard-pending-bonus-payments">
                    <div>
                      {(summary.pending || Number.isInteger(summary.pending)) && FORMAT_CURRENCY(summary.pending)}
                      <span>Pending bonus payments</span>
                    </div>
                  </LoanAdditionalInfo>
                </ReferSummary>

                <LoanAction>
                  <LoanButton
                    small
                    onClick={() => {
                      this.toggleOpen();
                    }}
                    data-qa="affiliate-share"
                    data-mjs="dashboard-share-button"
                  >
                    Share <ShareIcon src={ShareImage} />
                  </LoanButton>
                  {/* Share Modal popup */}
                  <ShareModal open={open} copy={copy} toggleOpen={this.toggleOpen} toggleCopy={this.toggleCopy} summary={summary} />
                  <RLink to={AFFILIATE_OVERVIEW_URL} data-qa="affiliate-viewDetails" data-mjs="dashboard-share-view-details">
                    View details
                  </RLink>
                </LoanAction>
              </LoanBody>
            </Fragment>
          )}

        {!isReferralConsented &&
          !displayCampaigns &&
          customer &&
          eligibleForReferralProgram(customer) && (
            <Fragment>
              <ReferSpan>Referral Program</ReferSpan>
              <LoanBody>
                <ShareSoFi>
                  Share SoFi. Earn Money.
                  <span>You&apos;ll get a $300 referral bonus and they&apos;ll get a $100.</span>
                </ShareSoFi>

                {consentsTou < 3 && (
                  <LoanAction>
                    <Link to="/affiliate/consent" data-qa="affiliate-enrollNow" data-mjs="dashboard-refer-enroll-now">
                      <LoanButton data-qa="affiliate-enrollNow-button">Enroll now</LoanButton>
                    </Link>
                  </LoanAction>
                )}
              </LoanBody>
            </Fragment>
          )}
      </Container>
    );
  }
}

export default Affiliate;



// WEBPACK FOOTER //
// ./src/components/accounts/affiliate/affiliate.js