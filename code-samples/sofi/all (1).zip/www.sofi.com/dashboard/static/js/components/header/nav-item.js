import React, { Component } from 'react';
import PropTypes from 'prop-types';

class NavItem extends Component {
  static propTypes = {
    /**
     * Renders whatever function/component etc you give it
     */
    render: PropTypes.func.isRequired,
    /**
     * Adds a class name to the component
     */
    className: PropTypes.string,
    /**
     * The container to whatever is in the render
     * You could use `li`, `div` or a custom component
     */
    container: PropTypes.node,
  };

  static defaultProps = {
    className: null,
    container: 'div',
  };

  state = {
    open: false,
  };

  handleKeyDown = (e) => {
    if (e.key === 'Enter' || e.key === 'Escape') {
      this.handleOpen();
    }
  };

  handleOpen = () => {
    const { open } = this.state;

    if (!open) {
      // If dropdown is not open, add click and focus event listeners
      document.addEventListener('click', this.handleClickOutside, false);
      document.addEventListener('focus', this.handleFocus, true);
    } else {
      // If already open, remove the event listeners
      document.removeEventListener('click', this.handleClickOutside, false);
      document.removeEventListener('focus', this.handleFocus, true);
    }

    this.setState({ open: !open });
  };

  handleFocus = (e) => {
    // ignore focus on the dropdown itself
    // navItem is our DOM element (Container) reference
    if (this.navItem.contains(e.target)) {
      return;
    }
    this.handleOpen();
  };

  handleClickOutside = (e) => {
    // ignore clicks on the dropdown itself
    if (this.navItem.contains(e.target)) {
      return;
    }
    this.handleOpen();
  };

  render() {
    const { className, container: Container } = this.props;
    const { open } = this.state;

    return (
      <Container
        className={className}
        ref={(navItem) => {
          this.navItem = navItem;
        }}
      >
        {this.props.render({ open, handleOpen: this.handleOpen, handleKeyDown: this.handleKeyDown })}
      </Container>
    );
  }
}

export default NavItem;



// WEBPACK FOOTER //
// ./src/components/header/nav-item.js