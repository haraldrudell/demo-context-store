import React, { Component, Fragment } from 'react';
import { Paragraph, Column, HyperLink } from 'scuid-x';
import styled from 'styled-components';
import PropTypes from 'prop-types';
import isEmpty from 'lodash/isEmpty';
import cloneDeep from 'lodash/cloneDeep';
import isEqual from 'lodash/isEqual';

/**
 * PropTypes imports
 */
import { ProductsPropTypes } from '../../constants/prop-types/products-prop-types';
import { CustomerPropTypes } from '../../constants/prop-types/customer-prop-types';
import { BankingPropTypes } from '../../constants/prop-types/banking-prop-types';

/**
 * Component imports
 */
import PaymentsModal from './payments-modal';

/**
 * Utilities/function imports
 */
import { calcBestRate, checkIsOfAge, getApr, handleTransformProducts, hasMetPaymentRequirements } from './utilities';

/**
 * Styled components
 */
const CustomColumn = styled(Column)`
  padding-left: 5px;
  padding-right: 5px;
`;

const Container = styled.div`
  padding: 1rem 0.6rem 1rem 0.8rem;
  background: white;
  width: 100%;
  height: 100%;
  position: relative;
  z-index: 0;
`;

const ProductCard = styled.div`
  display: flex;
  flex-direction: row;
  justify-content: flex-start;
  height: 100%;
  padding-bottom: 2rem;
`;

const ProductDetails = styled.div`
  width: 100%;
  padding-top: 0.5rem;
  display: flex;
  flex-flow: column wrap;
  align-content: flex-start;
`;

const ProductImage = styled.img`
  min-width: 56px;
  height: 56px;
  margin-right: 15px;
`;

const ProductTitle = styled(Paragraph)`
  color: #262626;
  font-weight: 500;
  font-size: 1.1rem;
  padding: 0px;
`;

const ProductDescription = styled(Paragraph)`
  color: #757575;
  padding: 0px;
  font-size: 0.9rem;

  // Set z-index to 2 so the anchor tag with superscript becomes active for banking
  ${({ name }) => name === 'SoFi Money' && 'z-index: 2'};
`;

const ProductLink = styled(HyperLink)`
  width: 100%;
  height: 100%;
  top: 0;
  left: 0;
  z-index: 1;
  cursor: pointer;
  text-decoration: none;
  position: absolute;
`;

const FlexContainer = styled.span`
  display: flex;
  position: absolute;
  bottom: 10px;
  left: 0;
  right: 0;
`;

const RightFlex = styled.span`
  flex: 1;
  display: flex;
`;

const LeftFlex = RightFlex.extend`
  min-width: calc(71px + 0.8rem);
`;

/**
 * Breakpoints for the Cards
 */
const BASE = {
  medium: 480, // two cards minimum width
  large: 768, // three cards
  xlarge: 992, // four cards (current max)
};

class Products extends Component {
  static propTypes = {
    products: ProductsPropTypes.isRequired,
    customer: CustomerPropTypes.isRequired,
    banking: BankingPropTypes.isRequired,
    bankingLoaded: PropTypes.bool.isRequired,
  };

  state = {
    newProducts: [],
    open: false,
  };

  componentDidMount() {
    const { products, banking, bankingLoaded } = this.props;
    let offerings = products;

    if (bankingLoaded) {
      const bankObject = this.bankTile(banking);
      if (bankObject) {
        offerings = cloneDeep(products);
        offerings.push(bankObject);
      }
    }
    // Transform product into an Array that we can map over below in our render method
    // We pass 'this' to the function because we setState in the function
    handleTransformProducts(offerings, this);
  }

  componentWillReceiveProps({ bankingLoaded, banking, products }) {
    if ((!this.props.bankingLoaded && bankingLoaded) || !isEqual(products, this.props.products)) {
      const offerings = cloneDeep(products);
      const bankObject = this.bankTile(banking);
      if (bankObject) offerings.push(bankObject);

      handleTransformProducts(offerings, this);
    }
  }

  bankTile = (banking) => {
    if (isEmpty(banking)) return ({ name: 'BANK_WAITLIST' });
    if (banking.status === 'NEW') return ({ ...banking, name: 'BANK' });
    return null;
  }

  toggleOpen = () => {
    this.setState({ open: !this.state.open });
  };

  handleOnClick = (eligibleProduct) => {
    // If the product is Personal Loan, check if the user has an account with us already
    // and if the user does, check if he/she has made at least 3 payments
    if (eligibleProduct.name === 'PL') {
      if (!hasMetPaymentRequirements(eligibleProduct)) {
        // User hasn't made 3 payments, open Modal to say so
        // Prevent the user from applying for another PL
        this.toggleOpen();
      }
    }
  };

  manualHide = cardName => ({
    Wealth: true,
    BANK: true,
    BANK_WAITLIST: true,
  }[cardName]);

  render() {
    const { customer } = this.props;
    const { newProducts, open } = this.state;

    return newProducts.filter(product => product.eligibility.eligible === true).map((eligibleProduct) => {
      // don't return the wealth or banking cards if customer's age is less than 18
      if (this.manualHide(eligibleProduct.name) && !checkIsOfAge(customer)) return '';

      return (
        <CustomColumn base={BASE} medium={6} large={4} xlarge={3} key={eligibleProduct.displayName}>
          <Container>
            {/* Payments Modal if user already has an active Personal Loan and less than 3 payments */}
            {eligibleProduct.name === 'PL' &&
              !hasMetPaymentRequirements(eligibleProduct) && <PaymentsModal open={open} toggleOpen={this.toggleOpen} />}

            <ProductCard>
              {/* Product image on left */}
              <ProductImage src={eligibleProduct.imageUrl} alt={eligibleProduct.displayName} />
              <ProductDetails>
                {customer.corporateEmployer === 'apple' ? (
                  <ProductTitle>
                    {eligibleProduct.appleDisplayName ? eligibleProduct.appleDisplayName : eligibleProduct.displayName}
                  </ProductTitle>
                ) : (
                  <ProductTitle>{eligibleProduct.displayName}</ProductTitle>
                )}

                {/* For wealth, and Banking only. Key 'description' does not exist in other products */}
                {!eligibleProduct.eligibility.rates && (
                  <ProductDescription name={eligibleProduct.displayName}>{eligibleProduct.description}</ProductDescription>
                )}

                {/* For everything else */}
                {eligibleProduct.eligibility.rates && (
                  <ProductDescription>
                    Rates as low as {calcBestRate(eligibleProduct.name, eligibleProduct.eligibility.rates)}%
                    <sup>{eligibleProduct.footNote}</sup>
                    {/* Only Mortgage has APR */}
                    {eligibleProduct.name === 'MORT' &&
                      eligibleProduct.eligibility.rates.benefitAmount > 0 &&
                      eligibleProduct.eligibility.rates.libor > 0 && (
                        <Fragment> with {getApr(eligibleProduct.eligibility.rates)}% APR</Fragment>
                      )}
                  </ProductDescription>
                )}
              </ProductDetails>
            </ProductCard>
            {/* Bottom Link to the offering/product. Covers the whole card (via absolute positioning) */}
            <ProductLink
              href={
                eligibleProduct.name !== 'PL'
                  ? eligibleProduct.eligibility.startUrl
                  : (hasMetPaymentRequirements(eligibleProduct) && eligibleProduct.eligibility.startUrl) || null
              }
              onClick={() => this.handleOnClick(eligibleProduct)}
              data-qa={`offerings-${eligibleProduct.displayName.replace(/\s+/g, '')}`}
              data-mjs={`dashboard-product-card-${eligibleProduct.displayName.replace(/\s+/g, '-')}`}
            >
              <FlexContainer>
                {/* LeftFlex ensures there is always at least 71px of whitespace to the left of the product link */}
                <LeftFlex />
                <span>{eligibleProduct.linkName}</span>
                {/* RightFlex is an empty <span> that stretches to center the product link */}
                <RightFlex />
              </FlexContainer>
            </ProductLink>
          </Container>
        </CustomColumn>
      );
    });
  }
}

export default Products;



// WEBPACK FOOTER //
// ./src/components/products/products.js