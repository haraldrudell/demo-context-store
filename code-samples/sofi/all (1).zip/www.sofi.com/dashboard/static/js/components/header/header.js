import React from 'react';
import PropTypes from 'prop-types';
import styled from 'styled-components';
import * as color from 'scuid-x/styles/color';

/**
 * Image imports
 */
import SoFiLogo from '../../assets/img/sofi-logo.svg';

/**
 * Component imports
 */
import NavBar from './nav-bar';

/**
 * Styled components
 */
const StyledHeader = styled.header`
  border-bottom: 1px solid ${color.Gray};
  background-color: ${color.White};
  position: relative;
`;

const HeaderContainer = styled.div`
  display: flex;
  justify-content: space-between;
  max-width: 1240px; /* 20px over the max width to calculate for padding on left and right */
  margin: 0 auto;
  padding: 15px 20px;
`;

const Logo = styled.a`
  position: relative;
  display: inline-block;
  align-self: center;
  min-width: 100px;
  max-width: 100px;
  height: 34px;

  img {
    display: block;
    width: 100%;
    height: 34px;
  }
`;

const Header = props => (
  <StyledHeader>
    <HeaderContainer>
      <Logo href="/dashboard/">
        <img src={SoFiLogo} alt="Social Finance Inc" />
      </Logo>

      {props.customerLoaded && <NavBar {...props} />}
    </HeaderContainer>
  </StyledHeader>
);

Header.propTypes = {
  customerLoaded: PropTypes.bool.isRequired,
};

export default Header;



// WEBPACK FOOTER //
// ./src/components/header/header.js