import React, { Component, Fragment } from 'react';
import styled from 'styled-components';
import PropTypes from 'prop-types';

/**
 * PropTypes imports
 */
import { CustomerPropTypes } from '../../constants/prop-types/customer-prop-types';
import { DashboardAccountsPropTypes } from '../../constants/prop-types/dashboard-accounts-prop-types';
import { ReferralConsentsPropTypes, ReferralSummaryPropTypes } from '../../constants/prop-types/referral-prop-types';

/**
 * Component imports
 */
import AccountCardsComponent from './account-cards';
import Affiliate from './affiliate';
import LoadingComponent from '../../components/loading';

/**
 * Utilities/function imports
 */
import { eligibleForReferralProgram } from './utilities';

const Header = styled.h6`
  font-size: 1.5rem;
  font-weight: 700;
  line-height: 1.28;
  letter-spacing: 0.05rem;
  color: #262626;
  padding-top: 20px;
`;

const Container = styled.div`
  max-width: 1240px;
  margin: 0px auto;
  padding-left: 20px;
  padding-right: 20px;
`;

const ReferralSection = styled.section`
  background-color: #fff;
  padding: 2rem 1rem 0.625rem 1rem;
  margin-top: 2rem;
`;

/**
 * Displays all the customer accounts
 */
class AccountsSection extends Component {
  static propTypes = {
    customer: CustomerPropTypes.isRequired,
    dashboardAccounts: DashboardAccountsPropTypes.isRequired,
    dashboardAccountsLoaded: PropTypes.bool.isRequired,
    loadDashboardAccounts: PropTypes.func.isRequired,
    getValueLabelPairs: PropTypes.func.isRequired,
    handleCallback: PropTypes.func.isRequired,
    handleModalOpen: PropTypes.func.isRequired,
    showMohelaModal: PropTypes.bool.isRequired,
    showCenlarModal: PropTypes.bool.isRequired,
    consentsTou: PropTypes.number,
    referralSummaryLoaded: PropTypes.bool.isRequired,
    referralConsentsLoaded: PropTypes.bool.isRequired,
    referralSummary: ReferralSummaryPropTypes.isRequired,
    referralConsents: ReferralConsentsPropTypes.isRequired,
    postReferralConsent: PropTypes.func.isRequired,
    modalContentUrl: PropTypes.string.isRequired,
  };

  static defaultProps = {
    consentsTou: null,
  };

  componentDidMount() {
    const { loadDashboardAccounts } = this.props;
    loadDashboardAccounts();
  }

  render() {
    const {
      customer,
      dashboardAccounts,
      dashboardAccountsLoaded,
      consentsTou,
      referralSummaryLoaded,
      referralConsentsLoaded,
      referralSummary,
      referralConsents,
      postReferralConsent,
      getValueLabelPairs,
      handleCallback,
      handleModalOpen,
      showMohelaModal,
      showCenlarModal,
      modalContentUrl,
    } = this.props;

    if (!dashboardAccountsLoaded) {
      return <LoadingComponent />;
    }

    return (
      <Fragment>
        <Container>
          <Header>Hello, {customer.firstName}!</Header>
          {dashboardAccounts.accountCards &&
            dashboardAccounts.accountCards.length > 0 && (
              <AccountCardsComponent
                dashboardAccounts={dashboardAccounts}
                getValueLabelPairs={getValueLabelPairs}
                handleCallback={handleCallback}
                handleModalOpen={handleModalOpen}
                showMohelaModal={showMohelaModal}
                showCenlarModal={showCenlarModal}
                modalContentUrl={modalContentUrl}
              />
            )}
        </Container>
        <Container>
          <ReferralSection>
            {/* Affiliate Referral Bonus */}
            {eligibleForReferralProgram(customer) &&
              consentsTou &&
              referralSummaryLoaded &&
              referralConsentsLoaded && (
                <Affiliate
                  customer={customer}
                  referralSummary={referralSummary}
                  referralConsents={referralConsents}
                  consentsTou={consentsTou}
                  postReferralConsent={postReferralConsent}
                />
              )}
          </ReferralSection>
        </Container>
      </Fragment>
    );
  }
}

export default AccountsSection;



// WEBPACK FOOTER //
// ./src/components/accounts/accounts-section.js