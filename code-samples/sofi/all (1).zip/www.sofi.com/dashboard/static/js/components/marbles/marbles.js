import React, { Fragment } from 'react';
import { NotificationBar, SubheadFour, Paragraph, FlexBox } from 'scuid-x';
import styled from 'styled-components';

/**
 * Images imports
 */
import MarblesLogo from '../../assets/img/sofi_logo_500.svg';

/**
 * Styled Components
 */
const MarblesWrapper = styled.div`
  img {
    max-height: 90vh;
  }
`;

const NotificationBarWrapper = styled(FlexBox)`
  justify-content: center;
  margin-top: 50px;
  align-items: center;
  padding: 20px;
`;

const Marbles = () => (
  <Fragment>
    <NotificationBarWrapper>
      <NotificationBar info>
        <SubheadFour>Uh oh!</SubheadFour>
        <Paragraph>We&apos;ve lost our marbles! Hang tight while we look for them.</Paragraph>
      </NotificationBar>
    </NotificationBarWrapper>

    <MarblesWrapper>
      <img src={MarblesLogo} alt="marbles" />
    </MarblesWrapper>
  </Fragment>
);

export default Marbles;



// WEBPACK FOOTER //
// ./src/components/marbles/marbles.js