// import { Paragraph } from 'scuid-x';
import styled from 'styled-components';

export const ReasonContainer = styled.div`
  font-size: 1rem;
  ul {
    padding-left: 1rem;
  }
  p {
    margin-top: 10px;
    &:first-child {
      margin-top: 0;
    }
    @media only screen and (min-width: 20em) {
      font-size: calc(0.875rem + 0.125 * ((100vw - 20em) / 48));
    }
  }
  strong {
    font-weight: 500;
  }
`;



// WEBPACK FOOTER //
// ./src/components/modals/shared-styles.js