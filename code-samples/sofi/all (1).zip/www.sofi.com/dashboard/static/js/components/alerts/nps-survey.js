import React from 'react';
import PropTypes from 'prop-types';

/**
 * Styled components
 */
import { AlertContent, AlertNotification } from './shared-styles';

const onKeyDown = (event, startSurvey) => {
  if (event.key === 'Enter') {
    startSurvey();
  }
};

const NpsSurvey = ({ toggleOpen, setAlertDismissableSession }) => (
  <AlertNotification dismissible onDismiss={() => setAlertDismissableSession('nps.survey')}>
    <AlertContent>
      <span>Hello! Please take one minute to provide feedback in the SoFi Welcome Survey.</span>
      <a data-qa="nps-survey-begin-link" role="link" tabIndex={0} onKeyDown={event => onKeyDown(event, toggleOpen)} onClick={toggleOpen}>
        {' '}
        Begin survey
      </a>
    </AlertContent>
  </AlertNotification>
);

NpsSurvey.propTypes = {
  toggleOpen: PropTypes.func.isRequired,
  setAlertDismissableSession: PropTypes.func.isRequired,
};

export default NpsSurvey;



// WEBPACK FOOTER //
// ./src/components/alerts/nps-survey.js