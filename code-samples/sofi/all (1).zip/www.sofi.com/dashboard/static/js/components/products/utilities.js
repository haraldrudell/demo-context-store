import React from 'react';

/**
 * Image imports
 */
import WealthIcon from '../../assets/img/icons/icon-56_wealth.svg';
import PersonalLoanIcon from '../../assets/img/icons/icon-56_loanPersonal.svg';
import MortgageIcon from '../../assets/img/icons/icon-56_loanMortgage.svg';
import StudentLoanIcon from '../../assets/img/icons/icon-56_loanStudent.svg';
import ParentPlusIcon from '../../assets/img/icons/icon-56_loanParentPlus.svg';
import ResRefiIcon from '../../assets/img/icons/icon-56_loanResidentRefi.svg';
import ParentIcon from '../../assets/img/icons/icon-56_loanParent.svg';
import BankingIcon from '../../assets/img/icons/icon-56_banking.svg';

/**
 * Styled components
 */
import { ScuidLink } from '../../utilities/global-styles';

const BankingLink = ScuidLink.extend`
  display: block;
  font-size: 0.9rem;
  color: #757575;
  font-weight: normal;
  &:hover {
    color: #1A7BB3;
  }
`;

/**
 * Wealth is here outside because it is not tied to the products endpoint
 */
const extraProducts = [
  {
    name: 'Wealth',
    displayName: 'Wealth Management',
    description: 'No SoFi fees for borrowers',
    startUrl: '/wealth/',
    imageUrl: WealthIcon,
    displayPosition: 5,
    footNote: '',
    linkName: 'Invest now',
    eligibility: {
      eligible: true,
      startUrl: '/wealth/',
    },
    mjsLabel: 'wealth',
  },
];

/**
 * Handle products attributes update
 * @param {Object} prod Product/offering
 */
const handleProductsAttrUpdate = (prod) => {
  const product = prod;

  // Most of the products have the same linkName
  // Those that don't (Banking), we update the property again in the switch-case
  product.linkName = 'Apply now';

  switch (product.name) {
    case 'REFI': {
      // Name that users see for the product
      product.displayName = 'Student Loan Refi';

      // If the user is an apple employee, we display this name instead
      product.appleDisplayName = 'Apple Subsidized Student Loan Refi';

      // Superscript number (all products have it with the exception of Banking)
      product.footNote = '1';

      // What position/order the product should appear
      product.displayPosition = 1;

      // Image to be displayed
      product.imageUrl = StudentLoanIcon;

      // Measurementjs tag to fire when user clicks on the product
      product.mjsLabel = 'student loan refi';

      break;
    }
    case 'PL': {
      product.displayName = 'Personal Loan';
      product.footNote = '2';
      product.displayPosition = 2;
      product.imageUrl = PersonalLoanIcon;
      product.mjsLabel = 'personal loan';
      break;
    }
    case 'MORT': {
      product.displayName = 'Mortgage';
      product.footNote = '3';
      product.displayPosition = 3;
      product.imageUrl = MortgageIcon;
      product.mjsLabel = 'mortgage';
      break;
    }
    case 'DENTREFI':
    case 'MEDREFI': {
      product.displayName = 'Resident Refi (MD/DDS)';
      product.footNote = '1';
      product.displayPosition = 6;
      product.imageUrl = ResRefiIcon;
      product.mjsLabel = 'residency refi';
      break;
    }
    case 'PARENT': {
      product.displayName = 'Parent (In School)';
      product.footNote = '4';
      product.displayPosition = 7;
      product.imageUrl = ParentIcon;
      product.mjsLabel = 'parent';
      break;
    }
    case 'PLUS': {
      product.displayName = 'Parent Plus Refi';
      product.appleDisplayName = 'Apple Subsidized Parent Plus Refi';
      product.footNote = '1';
      product.displayPosition = 8;
      product.imageUrl = ParentPlusIcon;
      product.mjsLabel = 'parent plus';
      break;
    }
    case 'BANK': {
      product.displayName = 'SoFi Money';

      // We are adding description because the API does not give it to us
      // Banking is unique in the sense its description links to its own page
      product.description = (
        <BankingLink data-qa="utilities-banking-link" href="/money-waitlist/#2">
          Higher interest, no account fees and free ATMs<sup>*</sup>
        </BankingLink>
      );

      // Is the fourth one on the offerings list
      product.displayPosition = 4;
      product.imageUrl = BankingIcon;

      // change the linkName to 'Open an account'
      product.linkName = 'Open an account';

      // add eligibility object (our filter looks for it in the render method)
      product.eligibility = {
        eligible: true,
        startUrl: '/my/money/setup/',
      };
      product.mjsLabel = 'money';
      break;
    }
    case 'BANK_WAITLIST': {
      product.displayName = 'SoFi Money';
      product.description = (
        <BankingLink data-qa="utilities-banking-waitlist-link" href="/money-waitlist/#2">
          Higher interest, no account fees and free ATMs<sup>*</sup>
        </BankingLink>
      );
      product.displayPosition = 9;
      product.imageUrl = BankingIcon;
      product.linkName = 'Join the waitlist';
      product.eligibility = {
        eligible: true,
        startUrl: '/money-waitlist/',
      };
      product.mjsLabel = 'money-waitlist';
      break;
    }
    default: {
      product.eligibility = {
        eligible: false,
        startUrl: '/dashboard',
      };
    }
  }
  return product;
};

/**
 * Check if Payments Modal needs to be shown onClick
 * @param {Object} product Our offering/product
 */
export const hasMetPaymentRequirements = product =>
  !product.eligibility || !product.eligibility.reasons || product.eligibility.reasons.filter(r => r.code === 'PAYMENTS').length < 1;

/**
 * Get APR to display to member
 * @param {Object} rates Rates object inside Mortgage
 */
export const getApr = (rates) => {
  // let rates = product.eligibility.rates;
  const number = rates.libor * 100;

  const longRate = number.toPrecision(5);
  const wholeNumberPart = longRate.split('.')[0];
  let decimalPart = longRate.split('.')[1];

  // strip trailing 0s
  while (decimalPart.charAt(decimalPart.length - 1) === '0' && decimalPart.length > 2) {
    decimalPart = decimalPart.substr(0, decimalPart.length - 1);
  }

  if (decimalPart.length > 3) {
    decimalPart = `${+Math.round(+decimalPart / 10)}`;
  }

  return String(`${+wholeNumberPart}.${decimalPart}`);
};

/**
 * Get us best rate to display to member
 * @param {String} product product/offering name
 * @param {Object} rates our rates object for the offering
 */
export const calcBestRate = (product, rates) => {
  // let rates = product.eligibility.rates;
  // rates come in as fractions, but need to be displayed as percents
  // compare which min rate is actually the lowest
  const minRate = rates.varMin && rates.varMin <= rates.fixedMin ? rates.varMin : rates.fixedMin;
  const benefitAmount = product === 'MORT' ? 0 : rates.benefitAmount;
  const bestRate = (minRate - benefitAmount) * 100;

  // We need the rate to be displayed with either 2 or 3 decimal places, but without trailing 0s
  // The rate has at most 2 digits before the decimal point, so we get the first 5 digits - ex 12.500
  const longRate = bestRate.toPrecision(5);

  const wholeNumberPart = longRate.split('.')[0];

  const decimalPart = longRate.split('.')[1];

  // Then we make sure that in case we had 1.2345, we turn the decimal part into .234
  let shortDecimal = String(decimalPart); // .toPrecision(3);;

  // strip trailing 0s
  while (shortDecimal.charAt(shortDecimal.length - 1) === '0' && shortDecimal.length > 2) {
    shortDecimal = shortDecimal.substr(0, shortDecimal.length - 1);
  }

  // force to 2 digit length
  if (shortDecimal.length > 3) {
    shortDecimal = `${+Math.round(+shortDecimal / 10)}`;
  }

  return String(`${+wholeNumberPart}.${shortDecimal}`);
};

/**
 * Add needed product attributes that don't initially come with our products array
 * @param {Array} productsArray array of products/offerings from the API (with banking added to it)
 * @param {Object} self refers to 'this' from whatever scope it is called from
 */
export const handleTransformProducts = (productsArray, self) => {
  const newProductsArray = [];
  productsArray.forEach((value) => {
    if (value) {
      const newValue = handleProductsAttrUpdate(value);
      newProductsArray.push(newValue);
    }
  });
  // Push all the extra products not in the API
  newProductsArray.push(...extraProducts);
  // Filter out products without a display position and then sort it based on its displayPosition
  const sortedArray = newProductsArray.filter(val => Number(val.displayPosition)).sort((a, b) => a.displayPosition > b.displayPosition);

  self.setState({ newProducts: sortedArray });
};

/**
 * Check if a customer is of age (> 18)
 * @param {Object} customer Our customer object from the API
 */
export const checkIsOfAge = (customer) => {
  const date = new Date();
  if (date.getFullYear() - customer.dobYear < 18) {
    return false;
  } else if (date.getFullYear() - customer.dobYear === 18 && date.getMonth() + 1 < customer.dobMonth.number) {
    return false;
  } else if (
    date.getFullYear() - customer.dobYear === 18 &&
    date.getMonth() + 1 === customer.dobMonth.number &&
    date.getDate() < customer.dobDay
  ) {
    return false;
  }
  return true;
};



// WEBPACK FOOTER //
// ./src/components/products/utilities.js