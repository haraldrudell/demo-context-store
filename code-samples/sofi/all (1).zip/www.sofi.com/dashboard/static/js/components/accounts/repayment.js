import React, { Fragment } from 'react';
import { SubheadFour, Icon, IconType } from 'scuid-x';
import PropTypes from 'prop-types';
import styled from 'styled-components';

/**
 * PropTypes imports
 */
import { ApplicationPropType } from '../../constants/prop-types/application-prop-types';

/**
 * Component imports
 */
import ButtonDropdown from './button-dropdown';

/**
 * Utilities/function imports
 */
import { FORMAT_CURRENCY } from '../../utilities/currency-format-helpers';

/**
 * Styled Components
 */
import {
  LoanBody,
  LoanSummary,
  LoanAction,
  LoanAmount,
  LoanButton,
  LoanAdditionalInfo,
  LoanDescription,
  DropdownContainer,
} from './shared-styles';

const RepaymentAction = styled(LoanAction)`
  margin-top: 0.5rem;
  display: block;
  div {
    display: inline-flex;
    margin-right: 2px;
    margin-bottom: 2px;
  }
`;

const Repayment = ({
  app, index, toggleDropdown, isOpen,
}) => (
  <Fragment>
    <SubheadFour>
      {app.productDesc} (#{app.servicing.accountId}), <span>{app.servicing.status}</span>
    </SubheadFour>
    <LoanDescription>{app.servicing.statusDesc}</LoanDescription>
    <LoanBody>
      <LoanSummary>
        {app.servicing.status !== 'Paid in Full' && (
          <Fragment>
            <LoanAmount data-qa={`loan-amount-due-${app.type}`}>
              {/* Convert amount to currency via custom format helper method */}
              {FORMAT_CURRENCY(app.servicing.paymentAmount)}
              <span>Amount due</span>
            </LoanAmount>
            <LoanAdditionalInfo>
              {app.servicing.status !== 'Paid in Full' && (
                <Fragment>
                  <div data-qa={`loan-next-payment-${app.type}`}>
                    {app.servicing.nextPayment}
                    <span>Next Payment</span>
                  </div>
                  <div data-qa={`loan-remaining-balance-${app.type}`}>
                    {FORMAT_CURRENCY(app.servicing.balance)}
                    <span>Remaining balance</span>
                  </div>
                </Fragment>
              )}
            </LoanAdditionalInfo>
          </Fragment>
        )}
      </LoanSummary>

      <RepaymentAction>
        <div>
          {app.docs &&
            app.docs.length > 0 && (
              <DropdownContainer data-qa="accounts-repayment-dropdown-container">
                <LoanButton
                  small
                  secondary
                  onClick={() => {
                    toggleDropdown(index);
                  }}
                  data-qa="accounts-repaymentDropdown"
                >
                  View details {isOpen ? <Icon size={14} iconType={IconType.CaretUp} /> : <Icon size={14} iconType={IconType.CaretDown} />}
                </LoanButton>

                {/* Dropdown menu */}
                {isOpen && <ButtonDropdown data-qa="accounts-repayment-button-dropdown" app={app} />}
              </DropdownContainer>
            )}
        </div>
        <a data-qa="accounts-repaymentViewAccount" href={`${app.servicing.servicingUrl}/#/${app.servicing.loanId}`}>
          <LoanButton data-qa="accounts-repaymentViewAccount-button" small>View Account</LoanButton>
        </a>
      </RepaymentAction>
    </LoanBody>
  </Fragment>
);

/* eslint react/no-typos: 0 */
Repayment.propTypes = {
  app: ApplicationPropType.isRequired,
  toggleDropdown: PropTypes.func.isRequired,
  isOpen: PropTypes.bool.isRequired,
  index: PropTypes.number.isRequired,
};

Repayment.defaultProps = {};

export default Repayment;



// WEBPACK FOOTER //
// ./src/components/accounts/repayment.js