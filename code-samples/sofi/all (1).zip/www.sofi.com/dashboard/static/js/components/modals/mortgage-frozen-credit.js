import React from 'react';
import PropTypes from 'prop-types';
import { Modal, Button, Paragraph } from 'scuid-x';
import styled from 'styled-components';
import { I18n } from 'react-redux-i18n';

/**
 * Styled Components
 */
const Content = styled.div`
  margin-top: -1.4rem;
`;

const MortgageFrozenCredit = ({ isOpen, toggleOpen }) => (
  <Modal isOpen={isOpen} onDismiss={toggleOpen} title="">
    <Modal.Body>
      <Content>
        <Paragraph>Unfortunately we failed to fetch all necessary credit information.</Paragraph>
        <Paragraph>
            This can happen for a number of reasons, including having a &#39;freeze&#39; put on your credit report. Without proper credit
            information, we are unable to continue your mortgage application at this time. Please verify all the information you have
            entered is correct and up to date. If you have any questions or concerns, please give us a call at{' '}
          <a
            data-qa="mortgage-frozen-cust-service-phone"
            href={`tel:+${I18n.t('sofiCustomerServicePhoneUnformat')}`}
          >
            {I18n.t('sofiCustomerServicePhoneReg')}
          </a>
          so we can try to help.
        </Paragraph>
        <Paragraph>
            If your mortgage application has one or more coborrowers attached, the above cautions apply to them as well. SoFi requires
            pulled credit for all parties involved in a mortgage application to be valid before proceeding.
        </Paragraph>
      </Content>
    </Modal.Body>
    <Modal.Footer>
      <Button data-qa="mortgage-frozen-credit-close" small secondary onClick={toggleOpen}>
          Close
      </Button>
    </Modal.Footer>
  </Modal>
);

/* eslint react/no-typos: 0 */
MortgageFrozenCredit.propTypes = {
  isOpen: PropTypes.bool.isRequired,
  toggleOpen: PropTypes.func.isRequired,
};

export default MortgageFrozenCredit;



// WEBPACK FOOTER //
// ./src/components/modals/mortgage-frozen-credit.js