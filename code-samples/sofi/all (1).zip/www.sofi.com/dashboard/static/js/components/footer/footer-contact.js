import React from 'react';
import PropTypes from 'prop-types';
import { FooterContact, FlexColumn } from 'scuid-x';
import styled from 'styled-components';
import { I18n } from 'react-redux-i18n';

/**
 * Component imports
 */
import NortonSecuredSeal from './norton-secured-seal';

/**
 * Styled components
 */
import { StyledFlexBox } from '../../utilities/global-styles';

const PstTimes = styled.p`
  font-weight: 500;
  @media (max-width: 767px) {
    padding-bottom: 20px;
  }
`;

const Contact = ({ corporateEmployer }) => (
  <FooterContact>
    <StyledFlexBox>
      <FlexColumn compWidth="full xsmall-full small-quarter">
        <h5>Loans &amp; General Qustions</h5>
        <ul>
          <li>
            <a
              data-qa="footer-contact-apple-email-link"
              href={`mailto:${I18n.t(corporateEmployer === 'apple' ? 'appleEmail' : 'sofiCustomerServiceEmail')}`}
            >
              {I18n.t(corporateEmployer === 'apple' ? 'appleEmail' : 'sofiCustomerServiceEmail')}
            </a>
          </li>
          <li>
            <a
              data-qa="footer-contact-apple-phone-link"
              href={`tel:+${I18n.t(corporateEmployer === 'apple' ? 'applePhoneUnformat' : 'sofiCustomerServicePhoneUnformat')}`}
            >
              {I18n.t(corporateEmployer === 'apple' ? 'applePhone' : 'sofiCustomerServicePhoneReg')}
            </a>
          </li>
        </ul>

        <ul>
          <li>{I18n.t('sofiCustomerServiceHoursMonThu')}</li>
          <li>{I18n.t('sofiCustomerServiceHoursFriSun')}</li>
        </ul>

        <PstTimes>All times are PST</PstTimes>
      </FlexColumn>

      <FlexColumn compWidth="full xsmall-full small-quarter">
        <h5>Mortgage General Support</h5>

        <ul>
          <li>
            <a data-qa="footer-contact-mort-email-link" href={`mailto:${I18n.t('mortgageEmail')}`}>{I18n.t('mortgageEmail')}</a>
          </li>
          <li>
            <a
              data-qa="footer-contact-mort-phone-link"
              href={`tel:+${I18n.t('mortgagePhoneUnformat')}`}
            >
              {I18n.t('mortgagePhoneReg')}
            </a>
          </li>
        </ul>

        <ul>
          <li>{I18n.t('mortgageHoursMonFri')}</li>
          <li>{I18n.t('mortgageHoursSatSun')}</li>
        </ul>
      </FlexColumn>

      <FlexColumn compWidth="full xsmall-full small-quarter">
        <h5>Wealth</h5>

        <ul>
          <li>
            <a data-qa="footer-contact-wealth-email-link" href={`mailto:${I18n.t('wealthEmail')}`}>{I18n.t('wealthEmail')}</a>
          </li>
          <li>
            <a
              data-qa="footer-contact-wealth-phone-link"
              href={`tel:+${I18n.t('wealthPhoneUnformat')}`}
            >
              {I18n.t('wealthPhoneReg')}
            </a>
          </li>
        </ul>

        <ul>
          <li>{I18n.t('wealthHoursMonThu')}</li>
          <li>{I18n.t('wealthHoursFri')}</li>
        </ul>
      </FlexColumn>

      <FlexColumn compWidth="full xsmall-full small-quarter">
        <h5>Legal</h5>

        <ul>
          <li>
            <a data-qa="footer-contact-private-n-security-link" href="https://www.sofi.com/privacy-policy/">Privacy &amp; Security</a>
          </li>
          <li>
            <a data-qa="footer-contact-tou-link" href="https://www.sofi.com/terms-of-use/">Terms of Use</a>
          </li>
          <li>
            <a data-qa="footer-contact-disclaimers-link" href="https://www.sofi.com/legal/">Disclaimers</a>
          </li>
          <li>
            <a data-qa="footer-contact-licenses-link" href="https://www.sofi.com/legal#licenses">Licenses</a>
          </li>
          <li>
            <a data-qa="footer-contact-nmls-access-link" href="http://www.nmlsconsumeraccess.org/">NMLS Access</a>
          </li>
          <li>
            <a data-qa="footer-contact-eligibility-link" href="https://www.sofi.com/eligibility-criteria/">Eligibility Criteria</a>
          </li>
        </ul>
        {/* TODO: Norton should eventually be moved to scuid-x */}
        <NortonSecuredSeal hostName="www.sofi.com" siteLink="sofi.com" />
      </FlexColumn>
    </StyledFlexBox>
  </FooterContact>
);

Contact.propTypes = {
  corporateEmployer: PropTypes.string,
};

Contact.defaultProps = {
  corporateEmployer: null,
};

export default Contact;



// WEBPACK FOOTER //
// ./src/components/footer/footer-contact.js