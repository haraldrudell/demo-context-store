export const dateParser = (date) => {
  const parsed = new Date(date);
  if (!Number.isNaN(parsed.valueOf())) {
    return parsed;
  }

  const parts = String(date).match(/\d+/g);
  if (parts == null || parts.length <= 2) {
    return parsed;
  }
  const [firstP, secondP, ...restPs] = parts.map(x => parseInt(x, 10));
  const correctedParts = [firstP, secondP - 1, ...restPs];
  const isoDate = new Date(Date.UTC(...correctedParts));
  return isoDate;
};

export const defaultFormatter = (value, unit, suffix) => {
  if (value !== 1) {
    unit += 's'; // eslint-disable-line
  }
  return `${value} ${unit} ${suffix}`;
};



// WEBPACK FOOTER //
// ./src/components/time-ago/utilities.js