import React from 'react';
import PropTypes from 'prop-types';
import { withRouter } from 'react-router';
import ReactRouterPropTypes from 'react-router-prop-types';

class ScrollToTop extends React.Component {
  static propTypes = {
    location: ReactRouterPropTypes.location.isRequired,
    children: PropTypes.node.isRequired,
  }

  componentDidUpdate(prevProps) {
    if (this.props.location !== prevProps.location) {
      window.scrollTo(0, 0);
    }
  }

  render() {
    return this.props.children;
  }
}

export default withRouter(ScrollToTop);



// WEBPACK FOOTER //
// ./src/components/scroll-to-top/scroll-to-top.js