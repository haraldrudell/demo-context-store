import React from 'react';
import PropTypes from 'prop-types';
import { Modal, Button, HyperLink, Paragraph } from 'scuid-x';

import { ResponsiveModalContent, ResponsiveModalFooter } from '../../utilities/global-styles';

const redirect = (toggleOpen, modalContentUrl) => {
  const cenlar = window.open(modalContentUrl);
  cenlar.opener = null; // prevent phishing attempts
  toggleOpen();
};

const CenlarModal = ({ open, toggleOpen, modalContentUrl }) => (
  <Modal isOpen={open} onDismiss={toggleOpen} title="You are about to leave SoFi">
    <Modal.Body>
      <ResponsiveModalContent>
        <Paragraph>
          To manage your Mortgage, we&#39;re directing you to CENLAR, SoFi&#39;s third-party loan servicer for mortgage loans.
        </Paragraph>
        <Paragraph>
          Make payments and get account details at{' '}
          <HyperLink data-qa="redirect-mort-link" href={modalContentUrl}>
            Cenlar
          </HyperLink>{' '}
          for further assistance.
          <Paragraph>
            While your loan will be serviced by CENLAR, you will still be a SoFi member and be able to take advantage of our unique member
            benefits.
          </Paragraph>
        </Paragraph>
      </ResponsiveModalContent>
    </Modal.Body>
    <Modal.Footer>
      <ResponsiveModalFooter>
        <Button
          data-qa="cenlar-backToSoFi"
          data-mjs="slr-popup-close cenlar"
          secondary
          onClick={() => {
            toggleOpen();
          }}
        >
          Back to SoFi
        </Button>
        <Button
          data-qa="cenlar-continueToCenlar"
          data-mjs="slr-popup-continue to cenlar"
          onClick={() => {
            redirect(toggleOpen, modalContentUrl);
          }}
        >
          Continue to CENLAR
        </Button>
      </ResponsiveModalFooter>
    </Modal.Footer>
  </Modal>
);

CenlarModal.defaultProps = {
  modalContentUrl: '',
};

CenlarModal.propTypes = {
  open: PropTypes.bool.isRequired,
  toggleOpen: PropTypes.func.isRequired,
  modalContentUrl: PropTypes.string,
};

export default CenlarModal;



// WEBPACK FOOTER //
// ./src/components/accounts/cenlar-modal.js