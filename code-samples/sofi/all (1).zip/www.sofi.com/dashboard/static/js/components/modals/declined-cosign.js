import React from 'react';
import PropTypes from 'prop-types';
import { Modal, Button, TextInput, EmailInput } from 'scuid-x';
import { withFormik, Form } from 'formik';
import Yup from 'yup';
import { I18n } from 'react-redux-i18n';
import styled from 'styled-components';

/**
 * PropTypes imports
 */
import { QueryParamPropTypes } from '../../constants/prop-types/modals-prop-types';
import { CustomerPropTypes } from '../../constants/prop-types/customer-prop-types';

/**
 * Utilities/function imports
 */
import { mapServerSideErrorsToFormikErrors } from '../../utilities/api-action-helpers';
import { setupContacts } from './utilities';

/**
 * Styled Components
 */
import { ReasonContainer } from './shared-styles';

const FormikForm = styled(Form)`
  margin-top: -1.4rem;
`;

const DeclinedCosign = ({
  isOpen, toggleOpen, values, errors, handleChange, handleSubmit, touched, isSubmitting, appParams, customer,
}) => {
  const { reason } = appParams; // reason maps to a key in the translation file
  /**
   * We pass in the contact information to the I18n translation
   */
  const contacts = setupContacts(customer);
  const { contactPhone, contactEmail } = contacts;

  return (
    <Modal isOpen={isOpen} onDismiss={toggleOpen} title="" minWidth={window.innerWidth >= 768 ? 750 : 0}>
      <Modal.Body>
        <FormikForm data-qa="declined-cosign-form">
          {/* dangerouslySetInnerHTML because the Translation files have HTML tags in them */}
          <ReasonContainer dangerouslySetInnerHTML={{ __html: I18n.t(reason, { contactPhone, contactEmail }) }} />
          <TextInput
            id="cosignerFirstName"
            name="cosignerFirstName"
            label="Co-Signer First Name"
            type="text"
            qa="declinedCoSign-cosignerFirstName"
            value={values.cosignerFirstName}
            onChange={handleChange}
            errorText={touched.cosignerFirstName && errors.cosignerFirstName}
          />
          <TextInput
            id="cosignerLastName"
            name="cosignerLastName"
            label="Co-Signer Last Name"
            type="text"
            qa="declinedCoSign-cosignerLastName"
            value={values.cosignerLastName}
            onChange={handleChange}
            errorText={touched.cosignerLastName && errors.cosignerLastName}
          />
          <EmailInput
            id="cosignerEmail"
            name="cosignerEmail"
            label="Co-Signer Email"
            type="text"
            qa="declinedCoSign-cosignerEmail"
            value={values.cosignerEmail}
            onChange={handleChange}
            errorText={
              (touched.cosignerEmail && errors.cosignerEmail) || (errors.globalErrorCode === 'cosigner.error' && errors.globalError)
            }
          />
        </FormikForm>
      </Modal.Body>
      <Modal.Footer>
        <Button data-qa="declinedCoSign-close" small onClick={toggleOpen}>
          Cancel
        </Button>
        <Button data-qa="declinedCoSign-submit" small onClick={handleSubmit} disabled={isSubmitting}>
          Save
        </Button>
      </Modal.Footer>
    </Modal>
  );
};

/* eslint react/no-typos: 0 */
DeclinedCosign.propTypes = {
  isOpen: PropTypes.bool.isRequired,
  toggleOpen: PropTypes.func.isRequired,
  values: PropTypes.object.isRequired, // eslint-disable-line react/forbid-prop-types
  errors: PropTypes.objectOf(PropTypes.string).isRequired,
  handleChange: PropTypes.func.isRequired,
  handleSubmit: PropTypes.func.isRequired,
  touched: PropTypes.objectOf(PropTypes.bool).isRequired,
  isSubmitting: PropTypes.bool.isRequired,
  appParams: QueryParamPropTypes.isRequired,
  customer: CustomerPropTypes.isRequired,
};

export default withFormik({
  mapPropsToValues: () => ({
    cosignerFirstName: '',
    cosignerLastName: '',
    cosignerEmail: '',
  }),
  validationSchema: () =>
    Yup.object().shape({
      cosignerFirstName: Yup.string().required("Please enter the cosigner's first name."),
      cosignerLastName: Yup.string().required("Please enter the cosigner's last name."),
      cosignerEmail: Yup.string()
        .email('Invalid Cosigner Email.')
        .required('Email is required!'),
    }),
  handleSubmit: (values, { props, setErrors, setSubmitting }) => {
    /**
     * values -> { cosignerFirstName: '', cosignerLastName: '', cosignerEmail: '' }
     */
    props.updateCosigner(
      values,
      serverResponse => setErrors(mapServerSideErrorsToFormikErrors(serverResponse)),
      setSubmitting,
      props.toggleOpen,
    );
  },
})(DeclinedCosign);



// WEBPACK FOOTER //
// ./src/components/modals/declined-cosign.js