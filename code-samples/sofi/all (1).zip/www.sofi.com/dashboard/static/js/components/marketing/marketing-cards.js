import React from 'react';
import {
  Card,
  CardImage,
  CardContent,
  FlexBox,
  SubheadTwo,
  Paragraph,
  HyperLink,
} from 'scuid-x';
import PropTypes from 'prop-types';
import { MarketingCardPropType } from '../../constants/prop-types/marketing-prop-types';

const MarketingCards = ({ marketingCards, marketingCardsLoaded }) => (
  marketingCardsLoaded &&
  <FlexBox direction="row" justifyContent="space-between">
    {
        marketingCards.map((c) => {
          const card = c.data;
          const callToAction = card.callToAction1;
          return (
            <Card rounded boxShadow backgroundColor="White" style={{ width: '49.5%' }}>
              <CardImage>
                <img
                  src={card.imgSrc}
                  alt={card.altText}
                  srcSet={card.imgSrcSet}
                />
              </CardImage>
              <CardContent>
                <SubheadTwo>{card.title}</SubheadTwo>
                <Paragraph>
                  {card.description}
                </Paragraph>
                {
                  callToAction &&
                  (
                  <HyperLink
                    link={callToAction.url}
                    target="_blank"
                    style={{ display: 'block', marginBottom: '25px' }}
                  >
                    {callToAction.text}
                  </HyperLink>
                  )
                }

              </CardContent>
            </Card>
          );
        })
      }
  </FlexBox>
);

MarketingCards.propTypes = {
  marketingCards: MarketingCardPropType.isRequired, // eslint-disable-line react/no-typos
  marketingCardsLoaded: PropTypes.bool.isRequired,
};

export default MarketingCards;



// WEBPACK FOOTER //
// ./src/components/marketing/marketing-cards.js