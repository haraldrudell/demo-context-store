import styled from 'styled-components';
import { NotificationBar, Paragraph } from 'scuid-x';

export const AlertNotification = styled(NotificationBar)`
  margin-bottom: 10px;
  padding-left: 0px;
  padding-right: 0px;
  .close {
    margin: -6px auto 0;
    max-width: 1230px;
    text-align: right;
    height: 6px;
    position: relative;
  }
`;

export const AlertContent = styled.div`
  max-width: 1200px;
  margin: 0 auto;
  padding-right: 70px;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  font-size: 14px;
  @media (max-width: 1250px) {
    padding-left: 20px;
  }
  @media (min-width: 992px) {
    flex-direction: row;
    span {
      max-width: 85%;
    }
    a {
      text-align: right;
    }
  }
  a {
    cursor: pointer;
    text-decoration: none;
    font-weight: 500;
  }
`;

export const AlertParagraph = styled(Paragraph)`
  padding: 0;
  font-size: 14px;
`;



// WEBPACK FOOTER //
// ./src/components/alerts/shared-styles.js