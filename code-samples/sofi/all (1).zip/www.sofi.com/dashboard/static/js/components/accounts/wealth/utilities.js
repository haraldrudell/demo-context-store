
export const isAccountFunded = profileData => profileData.strategy && profileData.account && profileData.funded;

export const isCompletedAccount = profileData => profileData.completed;

export const isInactiveWealth = profileData => profileData.new;

export const buildFromCta = (ctaInfo) => {
  const profileHtml = {};
  profileHtml.subText = ctaInfo.subText;
  profileHtml.cta = ctaInfo.cta;
  profileHtml.ctaLink = ctaInfo.ctaLink;

  return profileHtml;
};

export const buildProfileData = (data) => {
  const profileData = {};
  profileData.accountId = data.accountId;
  profileData.strategy = data.accountStrategy;
  profileData.account = data.accountNumber;
  profileData.dayChange = data.statistics && data.statistics.dayChange ? data.statistics.dayChange.toString() : '0';
  profileData.totalChangePercentage =
    data.statistics && data.statistics.totalChangePercentage ? `${data.statistics.totalChangePercentage.toFixed(2)}%` : '0.00%';
  profileData.isDayLoss = data.statistics && data.statistics.dayChange && data.statistics.dayChange < 0 ? 'daily-loss' : null;
  profileData.isTotalLoss =
    data.statistics && data.statistics.dayChange && data.statistics.totalChangePercentage < 0 ? 'daily-loss' : null;
  profileData.currentBalance = data.statistics && data.statistics.currentBalance ? data.statistics.currentBalance : 0;
  profileData.accountTypeDescription = data.accountTypeDescription;
  profileData.funded = data.funded;
  profileData.completed = data.completed;
  profileData.new = data.new;
  return profileData;
};



// WEBPACK FOOTER //
// ./src/components/accounts/wealth/utilities.js