import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { FlexBox, Paragraph } from 'scuid-x';
import styled from 'styled-components';

/**
 * PropTypes imports
 */
import { NotificationPropTypes } from '../../../constants/prop-types/notifications-prop-types';

/**
 * Component imports
 */
import TimeAgo from '../../time-ago';

/**
 * Styled components
 */
import { ScuidLink, RouterLink } from '../../../utilities/global-styles';

const Container = styled.div`
  position: relative;
  display: flex;
  flex-direction: column;
  align-items: center;
  margin: 10px;
  overflow: visible;
  width: 400px;
  border: 1px solid #757575;
  border-radius: 12px;
  background: white;
  box-shadow: 0 2px 4px 0 rgba(0, 0, 0, 0.2);

  &:after,
  &:before {
    bottom: 100%;
    left: 370px;
    border: solid transparent;
    content: ' ';
    height: 0;
    width: 0;
    position: absolute;
    pointer-events: none;
  }

  &:after {
    border: 10px solid transparent;
    border-bottom-color: white;
    margin-left: -10px;
  }

  &:before {
    border: 11px solid transparent;
    border-bottom-color: #757575;
    margin-left: -11px;
  }
`;

const NotificationFlex = styled.div`
  display: flex;
  justify-content: space-between;
  border-bottom: 1px solid #c5c7c8;
  width: 100%;
  padding: 0 20px;
`;

const Title = styled(Paragraph)`
  font-size: 12px;
  letter-spacing: 1px;
  font-weight: 600;
`;

const NoneParagraph = styled(Paragraph)`
  color: #757575;
  width: 100%;
  padding: 10px 20px;
  text-align: center;
  font-size: 15px;
`;

const MarkAllReadBtn = styled.button`
  cursor: pointer;
  background-color: transparent;
  border-style: none;
  padding: 0;
  margin: 0;
  font-size: 14px;
  font-weight: 500;
  text-align: right;
  color: #757575;
`;

const NotificationItem = styled.div`
  display: block;
  width: 100%;
  padding: 10px 20px;
  background-color: ${({ isRead }) => (isRead ? '#fff' : '#ddebf4')};
  font-size: 14px;
  cursor: ${({ isRead }) => (isRead ? 'normal' : 'pointer')};
  border-top: 1px solid #c8c8c8;
  &:first-child {
    border-top: none;
  }
  &:focus {
    ${({ isRead }) => isRead && 'outline: none;'};
  }
`;

const Message = styled.p`
  display: block;
  font-weight: 500;
  line-height: 1.43;
  letter-spacing: 0.1px;
  text-align: left;
  color: #262626;
`;

const TimerFlexBox = styled(FlexBox)`
  margin-top: 20px;
  @media (max-width: 768px) {
    flex-direction: row;
  }
`;

const ViewAll = styled.div`
  width: 100%;
  text-align: center;
  padding: 12px 0;
  border-top: 1px solid #c8c8c8;
`;

const onKeyDown = (event, markAsRead, notification) => {
  if (event.key === 'Enter') {
    markAsRead(notification);
  }
};

const determineNotificationCount = (notifications) => {
  let lastIndex = 0;
  notifications.forEach((value, index) => {
    if (value.status !== 'READ') {
      lastIndex = index;
    }
  });
  // show at least 3 notifications
  return Math.max(lastIndex + 1, 3);
};

class NotificationList extends Component {
  static propTypes = {
    filteredNotifications: PropTypes.arrayOf(NotificationPropTypes).isRequired,
    markAllAsRead: PropTypes.func.isRequired,
    markAsRead: PropTypes.func.isRequired,
    markNewAsUnread: PropTypes.func.isRequired,
    open: PropTypes.bool.isRequired,
    handleOpen: PropTypes.func.isRequired,
  };

  componentDidMount() {
    const { open } = this.props;
    // if Notifications is open, find and mark all notifications with status 'NEW' to 'UNREAD'
    if (open) {
      this.props.markNewAsUnread();
    }
  }

  render() {
    const {
      filteredNotifications, markAllAsRead, markAsRead, handleOpen,
    } = this.props;
    const totalNotifications = determineNotificationCount(filteredNotifications);

    // Show a maximum of 5 notifications on the dropdown
    const notifications = filteredNotifications.slice(0, Math.min(totalNotifications, 5));

    return (
      <Container>
        <NotificationFlex>
          <Title>NOTIFICATIONS</Title>
          <MarkAllReadBtn data-qa="notification-list-mark-all-read-button" onClick={markAllAsRead}>
            Mark all as read
          </MarkAllReadBtn>
        </NotificationFlex>
        {notifications.length === 0 && <NoneParagraph>No notifications</NoneParagraph>}
        {notifications.length > 0 &&
          notifications.map((notification, i) => (
            <NotificationItem
              key={notification.notificationID}
              data-qa={`notification-list-item-${i}`}
              role={notification.status === 'READ' ? 'none' : 'link'}
              tabIndex={notification.status === 'READ' ? null : 0}
              onKeyDown={e => onKeyDown(e, markAsRead, notification)}
              onClick={() => markAsRead(notification)}
              isRead={notification.status === 'READ'}
            >
              <Message>{notification.message}</Message>
              <TimerFlexBox>
                <span>
                  <TimeAgo date={notification.created} />
                </span>
                <ScuidLink data-qa={`notification-list-item-action-${i}`} href={notification.actionURL} target="_blank">
                  {notification.actionText}
                </ScuidLink>
              </TimerFlexBox>
            </NotificationItem>
          ))}
        <ViewAll>
          <RouterLink data-qa="notification-list-view-all" to="/notifications" onClick={handleOpen}>
            View all
          </RouterLink>
        </ViewAll>
      </Container>
    );
  }
}

export default NotificationList;



// WEBPACK FOOTER //
// ./src/components/header/notification/notification-list.js