import React from 'react';
import { Translate } from 'react-redux-i18n';
import PropTypes from 'prop-types';

/**
 * Styled components
 */
import { AlertContent, AlertNotification } from './shared-styles';

const StateIneligible = ({ setAlertDismissableSession }) => (
  <AlertNotification warning dismissible onDismiss={() => setAlertDismissableSession('state.ineligible')}>
    <AlertContent>
      <Translate value="waitlistUnsupportedStateAll" />
    </AlertContent>
  </AlertNotification>
);

/* eslint react/no-typos: 0 */
StateIneligible.propTypes = {
  setAlertDismissableSession: PropTypes.func.isRequired,
};

export default StateIneligible;



// WEBPACK FOOTER //
// ./src/components/alerts/state-ineligible.js