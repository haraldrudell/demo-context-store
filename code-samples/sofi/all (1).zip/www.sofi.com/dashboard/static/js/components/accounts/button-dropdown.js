import React from 'react';
import { Link } from 'react-router-dom';
import styled from 'styled-components';

/**
 * PropTypes imports
 */
import { ApplicationPropType } from '../../constants/prop-types/application-prop-types';

/**
 * Utilities/function imports
 */
import { statusIndicator, findDocument } from './utilities';

/**
 * Styled Components
 */

/**
 * Important: The parent of the Dropdown component
 * will need to have a position of relative
 */
const Dropdown = styled.div`
  display: block;
  position: absolute;
  z-index: 5 !important;
  min-width: 9rem;
  right: 0;
  margin-top: 5px;
`;

const DropdownList = styled.ul`
  border: 1px solid #d1d2d4;
  box-shadow: 0 2px 4px 0 rgba(0, 0, 0, 0.5);
  border-radius: 3px;
  list-style-type: none;
  margin: 0;
  padding: 0;
  background: white;

  > li {
    display: flex;
    justify-content: center;

    &:hover,
    &:active {
      background: #ddf2fb;
    }

    + li {
      border-top: 1px solid rgba(0, 0, 0, 0.15);
    }

    > a {
      width: 100%;
      padding: 0.5rem;
      text-align: center;
      font-size: 0.75rem;
      cursor: pointer;
      text-decoration: none;
      color: rgb(61, 61, 61);
      font-weight: 500;
    }
  }
`;

const ButtonDropdown = ({ app }) => (
  <Dropdown data-qa="accounts-button-dropdown">
    <DropdownList data-qa="accounts-button-dropdown-list">
      {findDocument(app, 'Signed Documents') &&
        statusIndicator(app) !== 'inactive' && (
          <li>
            <a data-qa="accounts-SignedDocs" href={findDocument(app, 'Signed Documents').url}>
              Signed documents
            </a>
          </li>
        )}
      {findDocument(app, 'Final Disclosure') &&
        statusIndicator(app) !== 'inactive' && (
          <li>
            <a data-qa="accounts-FinalDisclosure" href={findDocument(app, 'Final Disclosure').url}>
              Final disclosure
            </a>
          </li>
        )}
      {findDocument(app, 'PL TILA') &&
        statusIndicator(app) !== 'inactive' && (
          <li>
            <a data-qa="accounts-PL-TILA" href={findDocument(app, 'PL TILA').url}>
              PL TILA
            </a>
          </li>
        )}
      {findDocument(app, 'Adverse Action') && (
        <li>
          <Link data-qa="accounts-AdverseActionLetter" to={`/decline/${app.id}`}>
            Adverse action letter
          </Link>
        </li>
      )}
      {findDocument(app, 'Mortgage Prequal Letter') && (
        <li>
          <a data-qa="accounts-dropdown-mort-prequal-link" href={findDocument(app, 'Mortgage Prequal Letter').url}>
            Mortgage prequal letter
          </a>
        </li>
      )}
      {findDocument(app, 'Product Select Letter') && (
        <li>
          <a data-qa="accounts-dropdown-prod-select-link" href={findDocument(app, 'Product Select Letter').url}>
            Product select letter
          </a>
        </li>
      )}
      {findDocument(app, 'Gift Letter Form') && (
        <li>
          <a data-qa="accounts-dropdown-gift-letter-link" href={findDocument(app, 'Gift Letter Form').url}>Gift letter</a>
        </li>
      )}
      {findDocument(app, 'Authorization Form') && (
        <li>
          <a data-qa="accounts-dropdown-auth-form-link" href={findDocument(app, 'Authorization Form').url}>Authorization form</a>
        </li>
      )}
      {findDocument(app, 'Balance Sheet') && (
        <li>
          <a data-qa="accounts-dropdown-balance-sheet-link" href={findDocument(app, 'Balance Sheet').url}>Balance sheet</a>
        </li>
      )}
      {findDocument(app, 'Profit And Loss Statement') && (
        <li>
          <a data-qa="accounts-dropdown-profit-n-loss-link" href={findDocument(app, 'Profit And Loss Statement').url}>
            Profit and loss statement
          </a>
        </li>
      )}
      {findDocument(app, 'Demographic Information Addendum') && (
        <li>
          <a data-qa="accounts-dropdown-demo-addendum-link" href={findDocument(app, 'Demographic Information Addendum').url}>
            Demographic addendum
          </a>
        </li>
      )}
      {findDocument(app, 'Coborrower Demographic Information Addendum') && (
        <li>
          <a
            data-qa="accounts-dropdown-cobo-demo-addendum-link"
            href={findDocument(app, 'Coborrower Demographic Information Addendum').url}
          >
            Coborrower Demographic addendum
          </a>
        </li>
      )}
    </DropdownList>
  </Dropdown>
);

/* eslint react/no-typos: 0 */
ButtonDropdown.propTypes = {
  app: ApplicationPropType.isRequired,
};

export default ButtonDropdown;



// WEBPACK FOOTER //
// ./src/components/accounts/button-dropdown.js