import React from 'react';
import styled from 'styled-components';
import PropTypes from 'prop-types';

/**
 * Styled components
 */
import { AlertContent, AlertNotification } from './shared-styles';

const LineBreak = styled.br`
  @media (max-width: 767px) {
    display: none !important;
    margin-top: 0 !important;
  }
`;

const AppleEmployer = ({ setAlertDismissableSession }) => (
  <AlertNotification dismissible onDismiss={() => setAlertDismissableSession('apple.employer')}>
    <AlertContent>
      <span>
        Apple has partnered with SoFi to offer subsidized student loan refinancing products. <LineBreak />
        All other SoFi products are not subsidized by Apple and are not part of the Apple program.
      </span>
    </AlertContent>
  </AlertNotification>
);

/* eslint react/no-typos: 0 */
AppleEmployer.propTypes = {
  setAlertDismissableSession: PropTypes.func.isRequired,
};

export default AppleEmployer;



// WEBPACK FOOTER //
// ./src/components/alerts/apple-employer.js