import React from 'react';
import PropTypes from 'prop-types';
import { Modal, Button, Paragraph } from 'scuid-x';

/**
 * Styled components
 */
import { ResponsiveModalContent } from '../../utilities/global-styles';

const PaymentsModal = ({ open, toggleOpen }) => (
  <Modal
    isOpen={open}
    onDismiss={toggleOpen}
    title="It looks like you already have a personal loan with us."
  >
    <Modal.Body>
      <ResponsiveModalContent>
        <Paragraph>Once you&#39;ve made at least three payments, you&#39;re welcome to apply for another.</Paragraph>
      </ResponsiveModalContent>
    </Modal.Body>
    <Modal.Footer>
      <Button data-qa="offers-closePaymentsModal" small onClick={toggleOpen}>
        Close
      </Button>
    </Modal.Footer>
  </Modal>
);

PaymentsModal.propTypes = {
  open: PropTypes.bool.isRequired,
  toggleOpen: PropTypes.func.isRequired,
};

export default PaymentsModal;



// WEBPACK FOOTER //
// ./src/components/products/payments-modal.js