import React from 'react';
import PropTypes from 'prop-types';

/**
 * Styled components
 */
import { AlertContent, AlertNotification } from './shared-styles';

const UnemploymentProtection = ({ setAlertDismissableSession }) => (
  <AlertNotification dismissible onDismiss={() => setAlertDismissableSession('upp.summary')}>
    <AlertContent>
      <span>
        Your application for SoFi&apos;s Unemployment Protection Program is being reviewed. You will receive a response in 3-5 business
        days. You must continue making monthly payments until the forbearance is approved. If you have questions, please contact our
        Servicing Team at 844-975-7634.
      </span>
    </AlertContent>
  </AlertNotification>
);

/* eslint react/no-typos: 0 */
UnemploymentProtection.propTypes = {
  setAlertDismissableSession: PropTypes.func.isRequired,
};

export default UnemploymentProtection;



// WEBPACK FOOTER //
// ./src/components/alerts/unemployment-protection.js