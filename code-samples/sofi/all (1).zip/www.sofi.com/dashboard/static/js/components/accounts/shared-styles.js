import styled from 'styled-components';
import { Button, FlexBox, Paragraph } from 'scuid-x';

import { Colors } from '../../themes';

export const Attention = styled.span`
  color: ${Colors.attention};
`;

export const LoanBody = styled(FlexBox)`
  @media (max-width: 767px) {
    flex-direction: column;
    margin-top: 0.5rem;
  }
`;

export const LoanSummary = styled.div`
  display: flex;
  align-items: flex-end;
  color: ${Colors.loanAmount};
  font-size: 1.6rem;
  span {
    display: block;
    color: ${Colors.loanTitle};
    font-size: 0.9rem;
  }
  @media (max-width: 767px) {
    justify-content: space-between;
    flex-direction: column;
    align-items: flex-start;
  }
`;

export const LoanAction = styled.div`
  display: flex;
  flex-direction: column;
  &:only-child {
    width: 100%;
    text-align: right;
  }
  @media (max-width: 767px) {
    flex-direction: row;
    align-items: center;
    margin-top: 1rem;
  }
`;

export const LoanAmount = styled.div`
  @media (min-width: 992px) {
    width: 20rem;
    font-size: 1.88rem;
  }
  @media (max-width: 991px) and (min-width: 768px) {
    width: 15rem;
    font-size: 1.5rem;
  }
`;

export const LoanButton = styled(Button)`
  width: 9rem;
  font-size: 0.9rem;
  padding: 9px;
`;

export const LoanAdditionalInfo = styled.div`
  display: flex;
  div:not(:last-child) {
    margin-right: 6rem;
  }
  @media (max-width: 767px) {
    div:not(:last-child) {
      margin-right: 2rem;
    }
  }
`;

export const LoanDescription = styled(Paragraph)`
  color: #757575;
  padding: 0px;
`;

export const DropdownContainer = styled.div`
  position: relative;
`;

export const LoanBottomBorder = styled.div`
  position: relative;
  width: 100%;
  margin-bottom: 1rem;
  padding-bottom: 0.5rem;
  border-bottom: 1px solid #e6e7e8;
  @media (min-width: 768px) {
    padding-bottom: 1rem;
  }
`;



// WEBPACK FOOTER //
// ./src/components/accounts/shared-styles.js