import React from 'react';
import styled from 'styled-components';
import { Column, SubheadFour, HyperLink, Paragraph } from 'scuid-x';

/**
 * PropTypes imports
 */
import { LinkCardPropType } from '../../constants/prop-types/marketing-prop-types';

/**
 * Styled Components
 */
const CustomColumn = styled(Column)`
  padding-left: 5px;
  padding-right: 5px;
`;

const Container = styled.div`
  position: relative;
  background: white;
  min-height: 20rem;
  padding-top: 2rem;
  padding-left: 1.6rem;
  height: 100%;
`;

const MarketingLink = styled(HyperLink)`
  text-decoration: none;
  &:hover {
    text-decoration: none;
  }
`;

const MarketingLinksCard = ({ links }) => (
  <CustomColumn medium={6} large={4}>
    <Container>
      <SubheadFour>Other Links</SubheadFour>
      {links.map(value => (
        <Paragraph key={value.link}>
          <MarketingLink
            href={value.link}
            data-qa={`marketing-links-card-${value.linkText}`}
            data-mjs={`dashboard-marketing-${value.linkText}`}
          >
            {value.linkText}
          </MarketingLink>
        </Paragraph>
      ))}
    </Container>
  </CustomColumn>
);

MarketingLinksCard.propTypes = {
  links: LinkCardPropType,
};

MarketingLinksCard.defaultProps = {
  links: null,
};

export default MarketingLinksCard;



// WEBPACK FOOTER //
// ./src/components/marketing/marketing-links-card.js