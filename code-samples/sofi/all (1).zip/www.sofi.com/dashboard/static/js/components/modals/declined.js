import React from 'react';
import PropTypes from 'prop-types';
import { Modal, Button } from 'scuid-x';
import { I18n } from 'react-redux-i18n';

/**
 * PropTypes imports
 */
import { QueryParamPropTypes } from '../../constants/prop-types/modals-prop-types';
import { CustomerPropTypes } from '../../constants/prop-types/customer-prop-types';

/**
 * Utilities/function imports
 */
import { setupContacts } from './utilities';

/**
 * Styled Components
 */
import { ReasonContainer } from './shared-styles';

const Container = ReasonContainer.extend`
  margin-top: -1.4rem;
`;

const Declined = ({
  isOpen, toggleOpen, appParams, customer,
}) => {
  const { reason } = appParams; // reason maps to a key in the translation file
  /**
   * We pass in the contact information to the I18n translation
   */
  const contacts = setupContacts(customer);
  const { contactPhone, contactEmail } = contacts;

  return (
    <Modal isOpen={isOpen} onDismiss={toggleOpen} title="" minWidth={window.innerWidth >= 768 ? 750 : 0}>
      <Modal.Body>
        {/* dangerouslySetInnerHTML because the Translation files have HTML tags in them */}
        <Container dangerouslySetInnerHTML={{ __html: I18n.t(reason, { contactPhone, contactEmail }) }} />
      </Modal.Body>
      <Modal.Footer>
        <Button data-qa="declined-close" small secondary onClick={toggleOpen}>
          Close
        </Button>
      </Modal.Footer>
    </Modal>
  );
};

/* eslint react/no-typos: 0 */
Declined.propTypes = {
  isOpen: PropTypes.bool.isRequired,
  toggleOpen: PropTypes.func.isRequired,
  appParams: QueryParamPropTypes.isRequired,
  customer: CustomerPropTypes.isRequired,
};

export default Declined;



// WEBPACK FOOTER //
// ./src/components/modals/declined.js