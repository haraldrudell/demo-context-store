import React, { Fragment } from 'react';
import PropTypes from 'prop-types';
import styled from 'styled-components';
import { IconType, StandardAction, IconAction, AccountDropdown } from 'scuid-x';

const StyledFooterDropdown = styled(AccountDropdown)`
  bottom: 0.625rem;
  right: 0.625rem;
`;

const AccountCardFooter = ({ title, callToAction, handleCallback }) => (
  <Fragment>
    {callToAction.type === 'button' ? (
      <IconAction
        data-mjs={`dashboard-${title}-${callToAction.text}`}
        label={callToAction.text}
        iconType={IconType[callToAction.icon]}
        hasActions={Boolean(callToAction.actions)}
        link={callToAction.url ? callToAction.url : null}
        renderActions={({ handleOpen }) => (
          <StyledFooterDropdown
            data-mjs={`dashboard-${title}-${callToAction.text}`}
            actions={callToAction.actions ? callToAction.actions : null}
            handleOpen={handleOpen}
            handleCallback={handleCallback}
          />
        )}
        // is only checking for Modal currently
        {...(callToAction.modalName ? { onClick: () => handleCallback(callToAction) } : {})}
      />
    ) : (
      <StandardAction
        data-mjs={`dashboard-${title}-${callToAction.text}`}
        iconType={callToAction.icon ? IconType[callToAction.icon] : null}
        link={callToAction.url ? callToAction.url : null}
        hasActions={Boolean(callToAction.actions)}
        renderActions={({ handleOpen }) => (
          <StyledFooterDropdown
            data-mjs={`dashboard-${title}-${callToAction.text}`}
            actions={callToAction.actions ? callToAction.actions : null}
            handleOpen={handleOpen}
            handleCallback={handleCallback}
          />
        )}
        // is only checking for Modal currently
        {...(callToAction.modalName ? { onClick: () => handleCallback(callToAction) } : {})}
      >
        {callToAction.text}
      </StandardAction>
    )}
  </Fragment>
);

AccountCardFooter.propTypes = {
  callToAction: PropTypes.shape({
    text: PropTypes.string,
    type: PropTypes.string,
    url: PropTypes.string,
  }).isRequired,
  handleCallback: PropTypes.func.isRequired,
  title: PropTypes.string.isRequired,
};

export default AccountCardFooter;



// WEBPACK FOOTER //
// ./src/components/accounts/account-card-footer.js