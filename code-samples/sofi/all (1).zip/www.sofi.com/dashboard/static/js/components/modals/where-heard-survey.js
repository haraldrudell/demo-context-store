import React, { Fragment } from 'react';
import PropTypes from 'prop-types';
import { Modal, Button, Paragraph, CheckBox } from 'scuid-x';
import { withFormik, Form } from 'formik';
import cloneDeep from 'lodash/cloneDeep';
/**
 * PropTypes imports
 */
import { NpsSurveyPropTypes } from '../../constants/prop-types/nps-survey-prop-types';

/**
 * Utilities/function imports
 */
import { mapServerSideErrorsToFormikErrors } from '../../utilities/api-action-helpers';

/**
 * Styled Components
 */

const WhereHeardSurvey = ({
  isWhereHeardOpen,
  toggleWhereHeardOpen,
  whereHeardSurvey,
  values,
  handleChange,
  handleSubmit,
  isSubmitting,
}) => (
  <Modal
    isOpen={isWhereHeardOpen}
    onDismiss={toggleWhereHeardOpen}
    title={whereHeardSurvey.survey.title}
    minWidth={window.innerWidth >= 768 ? 750 : 0}
  >
    <Modal.Body>
      <Form data-qa="where-heard-survey-form">
        {whereHeardSurvey.survey.questions.map(value => (
          <Fragment key={value.id}>
            <Paragraph>{value.question}</Paragraph>
            {value.choices.map(option => (
              <CheckBox
                value={`survey_choice_${option.id}`}
                group={`survey_choice_${option.id}`}
                checked={values[`survey_choice_${option.id}`]}
                quarterWidth
                onChange={handleChange}
                qa="profile-whereHeardAnswers"
              >
                {option.choice}
              </CheckBox>
            ))}
          </Fragment>
        ))}
      </Form>
    </Modal.Body>
    <Modal.Footer>
      <Button data-qa="whereHeardSurvey-close" small onClick={toggleWhereHeardOpen}>
        Cancel
      </Button>
      <Button data-qa="whereHeardSurvey-submit" small onClick={handleSubmit} disabled={isSubmitting}>
        Save
      </Button>
    </Modal.Footer>
  </Modal>
);

/* eslint react/no-typos: 0 */
WhereHeardSurvey.propTypes = {
  isWhereHeardOpen: PropTypes.bool.isRequired,
  values: PropTypes.object.isRequired, // eslint-disable-line react/forbid-prop-types
  handleChange: PropTypes.func.isRequired,
  handleSubmit: PropTypes.func.isRequired,
  isSubmitting: PropTypes.bool.isRequired,
  whereHeardSurvey: NpsSurveyPropTypes.isRequired,
  toggleWhereHeardOpen: PropTypes.func.isRequired,
};

export default withFormik({
  mapPropsToValues: ({ whereHeardSurvey: { survey: { questions } } }) => {
    // Clone original object to avoid mutation
    const surveyQuestionsClone = cloneDeep(questions[0].choices);
    // Map choices array to Formik keys
    const answerObj = {};
    for (let idx = 0; idx < surveyQuestionsClone.length; idx += 1) {
      answerObj[`survey_choice_${surveyQuestionsClone[idx].id}`] = false;
    }
    return answerObj;
  },
  handleSubmit: (values, { props, setErrors, setSubmitting }) => {
    props.submitWhereHeardSurvey(values, serverResponse => setErrors(mapServerSideErrorsToFormikErrors(serverResponse)), setSubmitting);
  },
})(WhereHeardSurvey);



// WEBPACK FOOTER //
// ./src/components/modals/where-heard-survey.js