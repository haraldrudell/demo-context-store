import React from 'react';
import PropTypes from 'prop-types';
import styled from 'styled-components';
import * as color from 'scuid-x/styles/color';

const NortonSealContainer = styled.table`
  width: 135px;
  padding: 2px; /* Replaces cellpadding */
  border: 0;
  border-spacing: 0; /* Replaces cellspacing */
`;

const NortonSeal = styled.a`
  color: ${color.Black};
  text-decoration: none;
  font: bold 7px verdana, sans-serif;
  letter-spacing: 0.5px;
  text-align: center;
  margin: 0;
  padding: 0;
`;

const NortonSealImage = styled.img`
  margin-bottom: -20px;
  margin-left: -2px;
`;

const NortonSecuredSeal = ({ hostName, siteLink }) => (
  <NortonSealContainer title="Click to Verify - This site chose Symantec SSL for secure e-commerce and confidential communications.">
    <tbody>
      <tr>
        <td width="135" text-align="justify" valign="top" display="inline">
          <script
            type="text/javascript"
            src={`https://seal.websecurity.norton.com/getseal?host_name=${hostName}&amp;size=M&amp;use_flash=NO&amp;use_transparent=NO&amp;lang=en`}
          />
          <br />
          <NortonSeal href="http://www.symantec.com/ssl-certificates" target="_blank" rel="noopener noreferrer">
            <NortonSealImage src={`https://seal.websecurity.norton.com/getseal?at=0&sealid=1&dn=${siteLink}&lang=en&tpt=transparent`} />
            ABOUT SSL CERTIFCATES
          </NortonSeal>
        </td>
      </tr>
    </tbody>
  </NortonSealContainer>
);

NortonSecuredSeal.propTypes = {
  hostName: PropTypes.string.isRequired,
  siteLink: PropTypes.string.isRequired,
};

export default NortonSecuredSeal;



// WEBPACK FOOTER //
// ./src/components/footer/norton-secured-seal.js