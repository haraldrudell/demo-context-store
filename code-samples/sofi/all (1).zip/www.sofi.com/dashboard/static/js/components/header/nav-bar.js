import React from 'react';
import PropTypes from 'prop-types';
import styled from 'styled-components';

/**
 * PropTypes imports
 */
import { CustomerPropTypes } from '../../constants/prop-types/customer-prop-types';

/**
 * Component imports
 */
import NavItem from './nav-item';
import EmailCEO from './email-ceo';
import ContactUsButton from './contact-us-button';
import UserDropDown from './user-dropdown';
import NotificationsIconButton from './notifications-icon-button';

/**
 * Styled components
 */
const StyledNavItem = styled(NavItem)`
  margin-left: 20px;

  @media screen and (max-width: 400px) {
    margin-left: 15px;
  }
`;

const StyledNav = styled.div`
  ul {
    list-style: none;
    margin: 0;
    padding: 0;
    display: flex;

    li {
      align-self: center;

      div {
        ul {
          li {
            width: 100%;
          }
        }
      }
    }
  }
`;

const ListItem = styled.li`
  ${({ desktopOnly }) =>
    desktopOnly &&
    `
    @media screen and (max-width: 768px) {
      display: none;
    }
  `};
`;

const NavBar = ({
  customer, hasNewNotification, markNewAsUnread, ...rest
}) => {
  const { firstName, lastName, corporateEmployer } = customer;
  return (
    <StyledNav>
      <ul>
        <ListItem desktopOnly>
          <StyledNavItem render={() => <EmailCEO />} />
        </ListItem>

        <ListItem>
          <StyledNavItem
            render={({ open, handleOpen }) => <ContactUsButton open={open} handleOpen={handleOpen} corporateEmployer={corporateEmployer} />}
          />
        </ListItem>

        <ListItem desktopOnly>
          <StyledNavItem
            render={({ open, handleOpen, handleKeyDown }) => (
              <NotificationsIconButton
                open={open}
                handleOpen={handleOpen}
                handleKeyDown={handleKeyDown}
                hasNewNotification={hasNewNotification}
                markNewAsUnread={markNewAsUnread}
                {...rest}
              />
            )}
          />
        </ListItem>

        <ListItem>
          <StyledNavItem
            render={({ open, handleOpen, handleKeyDown }) => (
              <UserDropDown
                firstName={firstName}
                lastName={lastName}
                hasNewNotification={hasNewNotification}
                open={open}
                handleKeyDown={handleKeyDown}
                handleOpen={handleOpen}
              />
            )}
          />
        </ListItem>
      </ul>
    </StyledNav>
  );
};

/* eslint react/no-typos: 0 */
NavBar.propTypes = {
  customer: CustomerPropTypes.isRequired,
  hasNewNotification: PropTypes.bool.isRequired,
  markNewAsUnread: PropTypes.func.isRequired,
};

export default NavBar;



// WEBPACK FOOTER //
// ./src/components/header/nav-bar.js