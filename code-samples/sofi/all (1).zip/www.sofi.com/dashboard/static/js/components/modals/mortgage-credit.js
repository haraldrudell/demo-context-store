import React from 'react';
import PropTypes from 'prop-types';
import { Modal, Button, SsnInput } from 'scuid-x';
import { withFormik, Form } from 'formik';
import Yup from 'yup';
import styled from 'styled-components';

/**
 * PropTypes imports
 */
import { QueryParamPropTypes } from '../../constants/prop-types/modals-prop-types';

/**
 * Utilities/function imports
 */
import { mapServerSideErrorsToFormikErrors } from '../../utilities/api-action-helpers';

/**
 * Styled Components
 */
import { ReasonContainer } from './shared-styles';

const FormikForm = styled(Form)`
  margin-top: -1.4rem;
`;

const MortgageCredit = ({
  isOpen, toggleOpen, values, errors, handleChange, handleSubmit, touched, isSubmitting, appParams,
}) => {
  const coSsnRequired = appParams.applicantCount > 1;
  return (
    <Modal isOpen={isOpen} onDismiss={toggleOpen} title="" minWidth={window.innerWidth >= 768 ? 750 : 0}>
      <Modal.Body>
        <FormikForm data-qa="mortgage-credit-form">
          <ReasonContainer>
            <p>
              Unfortunately we&#39;ve been unable to obtain your credit information from the information provided.
              This sometimes happens if:
            </p>
            <ul>
              <li>You&#39;ve recently moved or changed your name</li>
              <li>You have a typo in the name or address in your SoFi application</li>
              <li>You requested that the credit bureau &#39;freeze&#39; your credit report</li>
            </ul>
            <p>
              If you&#39;ve requested that one or more of the credit bureaus &#39;freeze&#39; your report,
              you can remove the freeze from
              your <a data-qa="mortgage-credit-experian-freeze-link" href="https://www.experian.com/freeze/center.html">Experian</a>,
              {' '}
              <a data-qa="mortgage-credit-equifax-freeze-link" href="https://www.freeze.equifax.com/Freeze/jsp/SFF_PersonalIDInfo.jsp">
                Equifax
              </a>, and{' '}
              <a
                data-qa="mortgage-credit-transunion-freeze-link"
                href="https://freeze.transunion.com/sf/securityFreeze/landingPage.jsp"
              >
                Transunion
              </a>
              credit reports. We&#39;ll be unable
              to access your credit report and give you your rate if there is a freeze on your report.
            </p>

            <p>
              If you&#39;re certain that your application details and credit bureau information are correct, please provide your social
              security number (SSN) below. This will not impact your credit score, but it will allow SoFi to access your credit report,
              which helps us understand your track record of meeting financial obligations and offer low rates to our borrowers.
            </p>

            <p>
              We&#39;ll never share your SSN, and we use internationally recognized security standards,
              regulations, and industry-based best
              practices to keep it safe.
            </p>
          </ReasonContainer>
          <SsnInput
            id="ssn"
            name="ssn"
            halfWidth={window.innerWidth < 540}
            quarterWidth={window.innerWidth >= 540}
            label="SSN"
            placeholder="***-**-****"
            onChange={handleChange}
            value={values.ssn}
            errorText={touched.ssn && errors.ssn}
            qa="mortgage-input"
          />
          {coSsnRequired ? (
            <SsnInput
              id="coSsn"
              name="coSsn"
              halfWidth={window.innerWidth < 540}
              quarterWidth={window.innerWidth >= 540}
              label="CO-SSN"
              placeholder="***-**-****"
              onChange={handleChange}
              value={values.coSsn}
              errorText={touched.coSsn && errors.coSsn}
              qa="mortgage-input"
            />
          ) : (
            ''
          )}
        </FormikForm>
      </Modal.Body>
      <Modal.Footer>
        <Button data-qa="mortgage-close" small onClick={toggleOpen}>
          Cancel
        </Button>
        <Button data-qa="mortgage-submit" small onClick={handleSubmit} disabled={isSubmitting}>
          Save
        </Button>
      </Modal.Footer>
    </Modal>
  );
};

/* eslint react/no-typos: 0 */
MortgageCredit.propTypes = {
  isOpen: PropTypes.bool.isRequired,
  toggleOpen: PropTypes.func.isRequired,
  values: PropTypes.object.isRequired, // eslint-disable-line react/forbid-prop-types
  errors: PropTypes.objectOf(PropTypes.string).isRequired,
  handleChange: PropTypes.func.isRequired,
  handleSubmit: PropTypes.func.isRequired,
  touched: PropTypes.objectOf(PropTypes.bool).isRequired,
  isSubmitting: PropTypes.bool.isRequired,
  appParams: QueryParamPropTypes.isRequired,
};

export default withFormik({
  mapPropsToValues: () => ({
    ssn: '',
    coSsn: '',
  }),
  validationSchema: props =>
    Yup.object().shape({
      ssn: Yup.string()
        .required('SSN is a required field')
        .min(9, 'Must be 9 characters'),
      coSsn:
        props.appParams.applicantCount > 1
          ? Yup.string()
            .required('CO-SSN is a required field')
            .min(9, 'Must be 9 characters')
          : Yup.string().nullable(),
    }),
  handleSubmit: (values, { props, setErrors, setSubmitting }) => {
    /**
     * values -> { ssn: '', coSsn: '' }
     */
    props.retryService(
      values,
      serverResponse => setErrors(mapServerSideErrorsToFormikErrors(serverResponse)),
      setSubmitting,
      props.toggleOpen,
    );
  },
})(MortgageCredit);



// WEBPACK FOOTER //
// ./src/components/modals/mortgage-credit.js