import React, { Component, Fragment } from 'react';
import styled from 'styled-components';
import {
  Icon,
  IconType,
  Button,
  AccountCard,
  AccountCardHeader,
  AccountCardContent,
  BigNumber,
  ValuesWithLabels,
  AccountNotes,
  AccountCardFooter,
  AccountDropdown,
  HyperLink,
} from 'scuid-x';
import PropTypes from 'prop-types';
import debounce from 'lodash/debounce';

/**
 * PropTypes imports
 */
import { DashboardAccountsPropTypes } from '../../constants/prop-types/dashboard-accounts-prop-types';

/**
 * Component imports
 */
import AccountCardFooterComponent from './account-card-footer';
import WealthCard from './wealth-card';
import MohelaModal from './mohela-modal-v2';
import CenlarModal from './cenlar-modal';

/**
 * Styled Components
 */
const translateXonClick = (props) => {
  const cardWidth = props.cardWidth || 0;
  const { caretRightCounter } = props;

  // eslint-disable-next-line no-mixed-operators
  const x = cardWidth * caretRightCounter + caretRightCounter * 20;

  return `
    .member-card:nth-child(-n + ${caretRightCounter}) {
      transform: translateX(-${x}px);
      transition: all 0.4s ease-out;
      opacity: 0;
      visibility: hidden;
    }

    .member-card:not(:nth-child(-n + ${caretRightCounter})) {
        transform: translateX(-${x}px);
        opacity: 1;
        visibility: visible;
        transition: all 0.4s ease-out;
    }
  `;
};

const CardContainer = styled.div`
  position: relative;
  margin-top: 20px;
  margin-bottom: 20px;
`;

const Cards = styled.div`
  display: flex;
  flex-flow: row nowrap;
  overflow-x: hidden;
  overflow-y: auto;
  white-space: nowrap;

  &::-webkit-scrollbar {
    display: none;
  }

  @media (max-width: 479px) {
    transition: all 0.4s ease-out;
    flex-direction: column;
    overflow: unset !important;
  }

  @media (min-width: 480px) {
    ${translateXonClick};
  }
`;

const FloatingScrollButton = styled(Button)`
  position: absolute;
  min-width: 40px;
  width: 40px;
  height: 40px;
  padding: 0;
  border-radius: 40px;
  text-align: center;
  box-shadow: 2px 2px 3px #999;
  z-index: 5;
  top: 50%;
  transform: translateY(-50%);
  margin-left: 0 !important;
  left: ${({ isLeft }) => isLeft && -17}px;
  right: ${({ isRight }) => isRight && -17}px;

  svg {
    position: absolute;
    top: 50%;
    right: 50%;
    transform: translate(50%, -50%);
  }

  @media (max-width: 479px) {
    display: none !important;
  }
`;

const StyledHeaderDropdown = styled(AccountDropdown)`
  top: 0.625rem;
  right: 0.625rem;
`;

const CardLink = styled(HyperLink)`
  text-decoration: none !important;
  color: #262626;
  &:hover {
    text-decoration: none !important;
    color: #262626;
  }
`;

class AccountCards extends Component {
  static propTypes = {
    dashboardAccounts: DashboardAccountsPropTypes.isRequired,
    getValueLabelPairs: PropTypes.func.isRequired,
    handleCallback: PropTypes.func.isRequired,
    handleModalOpen: PropTypes.func.isRequired,
    showMohelaModal: PropTypes.bool.isRequired,
    showCenlarModal: PropTypes.bool.isRequired,
    modalContentUrl: PropTypes.string.isRequired,
  };

  state = {
    cardsToSkip: null,
    cardWidth: null,
    caretRightCounter: 0,
  };

  componentDidMount() {
    this.resizeEventAdded = true;
    this.handleWidthChange();

    // add resize event listener for responsiveness
    window.addEventListener('resize', this.handleWidthChange, false);
  }

  componentWillUnmount() {
    if (this.resizeEventAdded) {
      window.removeEventListener('resize', this.handleWidthChange, false);
      this.resizeEventAdded = undefined;
    }
  }

  /**
   * Calculates cards to skip based on cardContainerNode's width
   * Based on it, we either show the right arrow or hide it
   * Debounce set to 66ms (15fps)
   */
  handleWidthChange = debounce(
    () => {
      // get the width of the container
      const containerWidth = this.cardContainerNode.clientWidth;

      // get the width of the first card
      const cardWidth = this.accountCardNode0.clientWidth;
      let extraWidth = 0;

      // calculate extra width to add to the cardWidth (because of margin-left on the card)
      if (containerWidth >= 970) {
        extraWidth += Math.floor(40 / 3);
      } else {
        extraWidth += 10;
      }

      // calculate how many cards are being displayed fully on the screen
      const cardsToSkip = Math.floor(containerWidth / (cardWidth + extraWidth));

      if (cardsToSkip !== this.state.cardsToSkip || cardWidth !== this.state.cardWidth) {
        this.setState(() => ({ cardsToSkip, cardWidth }));
      }
    },
    66,
    {
      trailing: true,
    },
  );

  handleClickCaret = (add) => {
    this.setState(state => ({
      caretRightCounter: add ? state.caretRightCounter + 1 : state.caretRightCounter - 1,
    }));
  };

  resizeEventAdded = undefined;

  render() {
    const {
      dashboardAccounts,
      getValueLabelPairs,
      handleCallback,
      handleModalOpen,
      showMohelaModal,
      showCenlarModal,
      modalContentUrl,
    } = this.props;
    const { cardsToSkip, cardWidth, caretRightCounter } = this.state;

    return (
      <Fragment>
        {showMohelaModal && <MohelaModal open={showMohelaModal} toggleOpen={handleModalOpen('showMohelaModal')} />}
        {showCenlarModal && (
          <CenlarModal open={showCenlarModal} toggleOpen={handleModalOpen('showCenlarModal')} modalContentUrl={modalContentUrl} />
        )}

        <CardContainer
          innerRef={(cardContainerNode) => {
            this.cardContainerNode = cardContainerNode;
          }}
        >
          <Cards caretRightCounter={caretRightCounter} cardWidth={cardWidth}>
            {dashboardAccounts.accountCards.map((account, index) => (
              <AccountCard
                // add reference to the Account card(s) for responsive purpose
                innerRef={(accountCardNode) => {
                  this[`accountCardNode${index}`] = accountCardNode;
                }}
                className="member-card"
                key={account.id}
              >
                <CardLink href={account.data.mainAction}>
                  <AccountCardHeader
                    title={account.data.title}
                    status={account.data.subTitle ? account.data.subTitle : ''}
                    iconType={IconType[account.data.titleIcon]}
                    hasActions={Boolean(account.data.cardActions)}
                    renderActions={({ handleOpen }) => (
                      <StyledHeaderDropdown
                        actions={account.data.cardActions ? account.data.cardActions : null}
                        handleOpen={handleOpen}
                        handleCallback={handleCallback}
                      />
                    )}
                  />
                </CardLink>

                <AccountCardContent>
                  <CardLink href={account.data.mainAction}>
                    {/* Main data in the card. Example: Loan Amount */}
                    {account.data.mainData && <BigNumber value={account.data.mainData} label={account.data.mainLabel} />}

                    {/* Two possible value-label pairs. Example: Term, Term Type, Discounted Rate etc */}
                    {/* TODO: Update this when Scuid-x changes to the ValuesWithLabels component are deployed */}
                    {account.data.title === 'Wealth' && <WealthCard account={account} />}
                    {/* All other accounts that are not wealth cards */}
                    {account.data.title !== 'Wealth' &&
                      account.data.topLeftData && <ValuesWithLabels valueLabelPairs={getValueLabelPairs(account.data)} />}

                    {/* Full width Account notes. Example: 'Your loan has funded.' */}
                    {account.data.fullWidthMessage && <AccountNotes>{account.data.fullWidthMessage}</AccountNotes>}
                  </CardLink>
                </AccountCardContent>

                {/* Hide footer if no CTA present */}
                {(account.data.callToAction1 || account.data.callToAction2) && (
                  <AccountCardFooter>
                    {account.data.callToAction1 && (
                      <AccountCardFooterComponent
                        title={account.data.title}
                        callToAction={account.data.callToAction1}
                        handleCallback={handleCallback}
                      />
                    )}

                    {account.data.callToAction2 && (
                      <AccountCardFooterComponent
                        title={account.data.title}
                        callToAction={account.data.callToAction2}
                        handleCallback={handleCallback}
                      />
                    )}
                  </AccountCardFooter>
                )}
              </AccountCard>
            ))}

            {dashboardAccounts.accountCards &&
              dashboardAccounts.accountCards.length >= 2 && (
                <Fragment>
                  {Number.isInteger(cardsToSkip) &&
                    caretRightCounter < dashboardAccounts.accountCards.length - cardsToSkip && (
                      <FloatingScrollButton isRight onClick={() => this.handleClickCaret(true)}>
                        <Icon iconType={IconType.CaretRight} iconColor="White" />
                      </FloatingScrollButton>
                    )}
                  {caretRightCounter >= 1 && (
                    <FloatingScrollButton isLeft onClick={() => this.handleClickCaret(false)}>
                      <Icon iconType={IconType.CaretLeft} iconColor="White" />
                    </FloatingScrollButton>
                  )}
                </Fragment>
              )}
          </Cards>
        </CardContainer>
      </Fragment>
    );
  }
}

export default AccountCards;



// WEBPACK FOOTER //
// ./src/components/accounts/account-cards.js