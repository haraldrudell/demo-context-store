import React, { Fragment } from 'react';
import PropTypes from 'prop-types';
import styled from 'styled-components';
import { Icon, IconType } from 'scuid-x';
import breakpoint from 'scuid-x/styles/breakpoint';
import * as color from 'scuid-x/styles/color';

/**
 * Component imports
 */
import Transition from './nav-transition';

/**
 * Styled components
 */
import { RouterLink } from '../../utilities/global-styles';
import { SubNav } from './shared-styles';

const User = styled.a`
  display: block;
  color: ${color.MediumGray};
  font-weight: 700;
  position: relative;
  cursor: pointer;
  padding: 0 14px 0 0;

  &:after {
    display: block;
    content: '';
    width: 0;
    height: 0;
    border-style: solid;
    border-width: 4px 3px 0 3px;
    border-color: ${color.MediumGray} transparent transparent transparent;
    position: absolute;
    top: 50%;
    right: 0;
    transform: translateY(-50%);
  }

  &:hover {
    text-decoration: none;
    color: ${color.Blue};

    &:after {
      border-color: ${color.Blue} transparent transparent transparent;
    }
  }

  @media screen and (max-width: ${breakpoint.small}) {
    text-indent: -9999px;
    padding-right: 0;
    align-self: center;
    width: 48px;

    &:after {
      display: none;
    }
  }

  @media screen and (max-width: 400px) {
    width: 40px;
  }
`;

const HamburgerNav = styled.div`
  display: none;
  position: relative;

  // Show Red dot if we have new notifications
  ${({ hasNewNotification }) =>
    hasNewNotification &&
    `div {
        &:after {
          z-index: 2;
          transition: transform 0.3s ease-out;
          opacity: 1;
          right: -4px;
          top: -6px;
      
          content: ' ';
          display: block;
          height: 10px;
          width: 10px;
          border-radius: 50%;
          border: 2px solid #fff;
          position: absolute;
          pointer-events: none;
          background: #fc4c4c;
        }
      }`};

  // Remove Red dot when the hamburger menu is clicked (Show on the list instead)
  ${({ isOpen }) =>
    isOpen &&
    `div {
      &:after {
        z-index: 2;
        transform: scale(0);
      }
    }`};

  span {
    display: block;
    width: 48px;
    height: 5px;
    margin-bottom: 8px;
    position: relative;
    background: ${color.Blue};
    border-radius: 5px;
    z-index: 1;

    &:last-child {
      margin-bottom: 0;
    }
  }

  @media screen and (max-width: ${breakpoint.small}) {
    display: block;
    margin-top: -22px;
  }

  @media screen and (max-width: 400px) {
    width: 40px;

    span {
      width: 40px;
    }
  }
`;

const UserTransition = styled(Transition)`
  @media screen and (max-width: ${breakpoint.small}) {
    position: static;
  }
`;

const MyNotifications = styled.span`
  display: flex;
  flex-direction: row;

  ${({ hasNewNotification }) =>
    hasNewNotification &&
    `&:after {
      right: 15px;
      align-self: center;
      content: ' ';
      display: block;
      height: 10px;
      width: 10px;
      border-radius: 50%;
      position: absolute;
      pointer-events: none;
      background: #fc4c4c;
    }`};

  @media screen and (min-width: 769px) {
    &:after {
      display: none;
    }
  }
`;

const UserDropDown = ({
  firstName, lastName, hasNewNotification, handleOpen, handleKeyDown, open,
}) => (
  <Fragment>
    <User tabIndex={0} role="button" data-qa="nav-bar-user-button" onClick={handleOpen} onKeyDown={handleKeyDown}>
      {`${firstName} ${lastName}`}
      <HamburgerNav hasNewNotification={hasNewNotification} isOpen={open}>
        {hasNewNotification && <div />}
        <span />
        <span />
        <span />
      </HamburgerNav>
    </User>
    <UserTransition isOpen={open} relative>
      <SubNav>
        <ul>
          <li>
            <RouterLink data-qa="nav-bar-home-link" to="/home" onClick={handleOpen}>
              My Home
            </RouterLink>
          </li>
          <li>
            <MyNotifications hasNewNotification={hasNewNotification}>
              <RouterLink data-qa="nav-bar-notifications-link" to="/notifications" onClick={handleOpen}>
                My Notifications
              </RouterLink>
            </MyNotifications>
          </li>
          <li>
            <RouterLink data-qa="nav-bar-profile-link" to="/profile" onClick={handleOpen}>
              My Profile
            </RouterLink>
          </li>
          <li>
            <RouterLink data-qa="nav-bar-preferences-link" to="/preferences" onClick={handleOpen}>
              My Preferences
            </RouterLink>
          </li>
          <li>
            <a data-qa="nav-bar-logout-link" href="/b/logout" onClick={handleOpen}>
              <Icon size={16} iconType={IconType.Logout} />
              Log out
            </a>
          </li>
        </ul>
      </SubNav>
    </UserTransition>
  </Fragment>
);

UserDropDown.propTypes = {
  firstName: PropTypes.string.isRequired,
  lastName: PropTypes.string.isRequired,
  hasNewNotification: PropTypes.bool.isRequired,
  handleOpen: PropTypes.func.isRequired,
  handleKeyDown: PropTypes.func.isRequired,
  open: PropTypes.bool.isRequired,
};

export default UserDropDown;



// WEBPACK FOOTER //
// ./src/components/header/user-dropdown.js