import React, { Component, Fragment } from 'react';
import PropTypes from 'prop-types';
import styled from 'styled-components';
import { Paragraph } from 'scuid-x';
import isEmpty from 'lodash/isEmpty';

/**
 * PropTypes imports
 */
import { ApplicationPropType, MortgageSsoPropType, ServicingPropTypes } from '../../constants/prop-types/application-prop-types';
import { CustomerPropTypes } from '../../constants/prop-types/customer-prop-types';
import { WealthProfilePropTypes } from '../../constants/prop-types/wealth-prop-types';
import { ReferralConsentsPropTypes, ReferralSummaryPropTypes } from '../../constants/prop-types/referral-prop-types';
import { BankingPropTypes } from '../../constants/prop-types/banking-prop-types';

/**
 * Component imports
 */
import Bankruptcy from './bankruptcy';
import UnboardedLoan from './unboarded-loan';
import Forbearance from './forbearance';
import Chargeoff from './chargeoff';
import Repayment from './repayment';
import NotInServicing from './not-in-servicing';
import CannotContinue from './cannot-continue';
import Ecp from './ecp';
import Affiliate from './affiliate';
import Wealth from './wealth';
import SofiMoney from './sofi-money';

/**
 * Utilities/function imports
 */
import {
  isMortCENLAR,
  isEcp,
  isBankruptcy,
  isForbearance,
  isChargeOff,
  isInRepayment,
  isUnboardedLoan,
  isUnknownStatus,
  canContinueApp,
  eligibleForReferralProgram,
  showServicing,
} from './utilities';

/**
 * Styled Components
 */
import { LoanBottomBorder } from './shared-styles';
import { ScuidLink } from '../../utilities/global-styles';

const Header = styled.h6`
  font-size: 0.8rem;
  font-weight: 700;
  line-height: 1.28;
  letter-spacing: 0.1rem;
  color: #262626;
  padding-top: 20px;
  padding-bottom: 10px;
`;

const Servicing = styled(Paragraph)`
  padding-bottom: 15px;
  padding-top: 0px;
`;

/**
 * Displays all the customer accounts
 */
class Accounts extends Component {
  static propTypes = {
    customer: CustomerPropTypes.isRequired,
    applications: PropTypes.arrayOf(ApplicationPropType).isRequired,
    consentsTou: PropTypes.number,
    wealth: PropTypes.arrayOf(WealthProfilePropTypes).isRequired,
    wealthLoaded: PropTypes.bool.isRequired,
    postReferralConsent: PropTypes.func.isRequired,
    referralSummary: ReferralSummaryPropTypes.isRequired,
    referralConsents: ReferralConsentsPropTypes.isRequired,
    referralSummaryLoaded: PropTypes.bool.isRequired,
    referralConsentsLoaded: PropTypes.bool.isRequired,
    mortgageSso: MortgageSsoPropType.isRequired,
    servicingLoaded: PropTypes.bool.isRequired,
    servicing: ServicingPropTypes.isRequired,
    banking: BankingPropTypes.isRequired,
    bankingLoaded: PropTypes.bool.isRequired,
  };

  static defaultProps = {
    consentsTou: null,
  };

  state = {
    isOpen: [],
  };

  toggleDropdown = (i) => {
    const { isOpen } = this.state;
    // if the index does not exist, create it
    if (!isOpen[i]) isOpen[i] = false;
    // now toggle the index
    isOpen[i] = !isOpen[i];
    // set state with the new toggled array
    this.setState({ isOpen });
  };

  render() {
    const {
      customer,
      applications,
      consentsTou,
      wealth,
      wealthLoaded,
      postReferralConsent,
      referralSummary,
      referralConsents,
      referralSummaryLoaded,
      referralConsentsLoaded,
      mortgageSso,
      servicingLoaded,
      servicing,
      banking,
      bankingLoaded,
    } = this.props;

    // isOpen is to track which drop-down is open
    const { isOpen } = this.state;

    // ecp is a type of account that sits outside of the map function in render
    // so we find it (if it exists) from applications here
    const ecp = applications.find(app => isEcp(app));

    if (mortgageSso) {
      for (let idx = 0; idx < applications.length; idx += 1) {
        if (
          applications[idx].type === 'MORT' &&
          applications[idx].servicing &&
          applications[idx].servicing.status === 'CENLAR' &&
          applications[idx].servicing.statusDesc === 'CENLAR_SOFI'
        ) {
          applications[idx].servicing.servicingUrl = mortgageSso[applications[idx].id];
        }
      }
    }

    // Only show the Accounts section if the following conditions match
    // Customer either has application(s), wealth account, banking account or is eligible for the referral program
    const showAccounts =
      applications.length > 0 ||
      (wealth.length > 0 && !!wealth[0].accountId) ||
      (!isEmpty(banking) && banking.status !== 'NEW') ||
      eligibleForReferralProgram(customer);

    return showAccounts ? (
      <section>
        <Header>YOUR ACCOUNT</Header>

        {servicingLoaded &&
          showServicing(applications) &&
          !!servicing.accessUrl && (
            <Servicing>
              Access your account to make payments and see your balance.{' '}
              <ScuidLink data-qa="accounts-access-accounts" href={servicing.accessUrl}>
                Access account
              </ScuidLink>
            </Servicing>
          )}

        {/* Wealth portion of Accounts */}
        {wealthLoaded &&
          wealth.length > 0 &&
          !!wealth[0].accountId &&
          wealth.map(wealthProfile => <Wealth key={wealthProfile.accountId} wealthProfile={wealthProfile} />)}

        {/* Rest of the account */}
        {applications &&
          customer &&
          applications.map((app, i) => (
            <Fragment key={app.continueUrl}>
              {/* bankruptcy card */}
              {app.servicing && isBankruptcy(app) && <Bankruptcy app={app} customer={customer} />}

              {/* unboard loan card */}
              {app.servicing && isUnboardedLoan(app) && <UnboardedLoan app={app} customer={customer} />}

              {/* forbearance card */}
              {app.servicing && isForbearance(app) && <Forbearance app={app} customer={customer} />}

              {/* chargeoff card */}
              {app.servicing && isChargeOff(app) && <Chargeoff app={app} customer={customer} />}

              {/* in repayment or unknown */}
              {((app.servicing && isInRepayment(app)) || (app.servicing && isUnknownStatus(app))) && (
                <Repayment app={app} customer={customer} index={i} toggleDropdown={this.toggleDropdown} isOpen={isOpen[i] || false} />
              )}

              {/* an application that has not gone to servicing */}
              {!app.servicing &&
                canContinueApp(app) && (
                  <NotInServicing
                    app={app}
                    customer={customer}
                    index={i}
                    toggleDropdown={this.toggleDropdown}
                    isOpen={isOpen[i] || false}
                  />
                )}

              {/* an application that cannot be continued at this time */}
              {(!app.servicing || isMortCENLAR(app)) &&
                !canContinueApp(app) && (
                  <CannotContinue
                    app={app}
                    customer={customer}
                    index={i}
                    toggleDropdown={this.toggleDropdown}
                    isOpen={isOpen[i] || false}
                  />
                )}

              {/* Do not show Border/Divider line if application type is 'CONTRIB' */}
              {!isEcp(app) && <LoanBottomBorder />}
            </Fragment>
          ))}

        {/* ecp */}
        {applications &&
          customer &&
          ecp &&
          ecp.servicing && (
            <Fragment>
              <Ecp ecp={ecp} />
              <LoanBottomBorder />
            </Fragment>
          )}

        {/* SoFi Money */}
        {bankingLoaded &&
          !isEmpty(banking) &&
          banking.status !== 'NEW' && (
            <Fragment>
              <SofiMoney banking={banking} />
              <LoanBottomBorder />
            </Fragment>
          )}

        {/* Affiliate Referral Bonus */}
        {eligibleForReferralProgram(customer) &&
          consentsTou &&
          referralSummaryLoaded &&
          referralConsentsLoaded && (
            <Affiliate
              customer={customer}
              referralSummary={referralSummary}
              referralConsents={referralConsents}
              consentsTou={consentsTou}
              postReferralConsent={postReferralConsent}
            />
          )}
      </section>
    ) : null;
  }
}

export default Accounts;



// WEBPACK FOOTER //
// ./src/components/accounts/accounts.js