import React from 'react';
import PropTypes from 'prop-types';
import styled from 'styled-components';

/**
 * Image imports
 */
import JetBlueImage from '../../assets/img/TrueBlueBlack.svg';
import AlaskaAirImage from '../../assets/img/alaska-airlines.svg';

/**
 * Styled components
 */
import { AlertContent, AlertNotification } from './shared-styles';

const AffiliateImage = styled.img`
  max-width: 100%;
  display: block;
  margin-top: 5px;
  padding-left: 20px;
`;

const Container = styled.div`
  display: block;
  max-width: 1440px;
  margin: 0 auto;
`;

const adjustMarginTop = {
  marginTop: '12px',
};

const adjustPaddingBot = {
  paddingBottom: '16px',
};

const AFFILIATE_JETBLUE = 'JETBLUE';
const AFFILIATE_ALASKA_AIRLINES = 'ALASKA_AIRLINES';

const AffiliateMembership = ({ affiliateMembership, setAlertDismissableSession }) => (
  [AFFILIATE_JETBLUE, AFFILIATE_ALASKA_AIRLINES].find(i => i === affiliateMembership.name) ?
    <AlertNotification style={adjustPaddingBot} dismissible onDismiss={() => setAlertDismissableSession('affiliate.membership')}>
      {affiliateMembership.name === AFFILIATE_JETBLUE && (
        <Container>
          <AffiliateImage src={JetBlueImage} alt={AFFILIATE_JETBLUE} />
          <AlertContent style={adjustMarginTop}>
            <span>
            Want your bonus JetBlue points? All you need is your name and member number as it appears on your TrueBlue account. Expires{' '}
              {affiliateMembership.endDate}.
            </span>
            <a data-qa="alerts-affiliate-claim-points" href="/b/affiliate-membership/registration">Claim my points</a>
          </AlertContent>
        </Container>
    )}
      {affiliateMembership.name === AFFILIATE_ALASKA_AIRLINES && (
        <Container>
          <AffiliateImage src={AlaskaAirImage} alt={AFFILIATE_ALASKA_AIRLINES} />
          <AlertContent style={adjustMarginTop}>
            <span>
            Want your bonus Alaska Airlines miles? All you need is your name and member number as it appears on your Mileage Plan account.
            Expires {affiliateMembership.endDate}.&nbsp;
            </span>
            <a data-qa="alerts-affiliate-claim-miles" href="/b/affiliate-membership/registration">Claim my miles</a>
          </AlertContent>
        </Container>
    )}
    </AlertNotification> : null
);

AffiliateMembership.propTypes = {
  affiliateMembership: PropTypes.object.isRequired, // eslint-disable-line
  setAlertDismissableSession: PropTypes.func.isRequired,
};

export default AffiliateMembership;



// WEBPACK FOOTER //
// ./src/components/alerts/affiliate-membership.js