import React, { Fragment } from 'react';
import PropTypes from 'prop-types';
import { Modal, Button, Paragraph, HyperLink } from 'scuid-x';
import styled from 'styled-components';
import { I18n } from 'react-redux-i18n';

/**
 * PropTypes imports
 */
import { QueryParamPropTypes } from '../../constants/prop-types/modals-prop-types';

/**
 * Styled Components
 */
const Content = styled.div`
  margin-top: -1.4rem;
`;

const FrozenCredit = ({ isOpen, toggleOpen, appParams }) => {
  const hasCoborrowers = appParams.applicantCount > 1;
  return (
    <Modal isOpen={isOpen} onDismiss={toggleOpen} title="" minWidth={window.innerWidth >= 768 ? 750 : 0}>
      <Modal.Body>
        <Content>
          <Paragraph>
            Unfortunately, it looks like
            {hasCoborrowers ? (
              <Fragment> the credit files for both you and your co-borrower are </Fragment>
            ) : (
              <Fragment> your credit file is </Fragment>
            )}frozen.
          </Paragraph>
          <Paragraph>
            We are unfortunately unable to access
            {hasCoborrowers ? (
              <Fragment> the credit files for both you and your co-borrower </Fragment>
            ) : (
              <Fragment> your credit report details </Fragment>
            )}
            until the &#39;freeze&#39; is lifted.
            {hasCoborrowers ? <Fragment> You and your co-borrower </Fragment> : <Fragment> You </Fragment>}
            can ask Experian to temporarily remove a freeze by visiting{' '}
            <HyperLink
              data-qa="frozen-credit-lift-freeze-link"
              href="http://www.experian.com/blogs/ask-experian/how-to-lift-a-security-freeze/"
              title="How to Lift a Security Freeze"
            >
              here
            </HyperLink>.
          </Paragraph>
          <Paragraph>
            Once the freeze has been lifted, please return to this page to continue your application. You can always &#39;re-freeze&#39;
            your report after your application is completed. If you {hasCoborrowers && <Fragment>or your co-borrower </Fragment>}
            have not requested that Experian &#39;freeze&#39; your credit, give us a call at {I18n.t('sofiCustomerServicePhoneReg')}, so we
            can try to help.
          </Paragraph>
        </Content>
      </Modal.Body>
      <Modal.Footer>
        <Button data-qa="frozen-ssn-close" small secondary onClick={toggleOpen}>
          Close
        </Button>
      </Modal.Footer>
    </Modal>
  );
};

/* eslint react/no-typos: 0 */
FrozenCredit.propTypes = {
  isOpen: PropTypes.bool.isRequired,
  toggleOpen: PropTypes.func.isRequired,
  appParams: QueryParamPropTypes.isRequired,
};

export default FrozenCredit;



// WEBPACK FOOTER //
// ./src/components/modals/frozen-credit.js