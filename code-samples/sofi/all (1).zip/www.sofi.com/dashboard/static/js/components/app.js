import React from 'react';
import { ChatButton, Main } from 'scuid-x';
import { HashRouter as Router, Switch, Route } from 'react-router-dom';
import styled from 'styled-components';
import Loadable from 'react-loadable';

import '../sofi-icons.css'; // Temporary workaround for missing icons in declines page

/**
 * Global components
 */
import Header from './header';
import Marbles from './marbles';
import Loading from './loading';
import Footer from '../containers/footer';
import ScrollToTop from './scroll-to-top';
import IdleTimeout from '../containers/timeout';

/**
 * Code Splitting based on major routes
 */
const Dashboard = Loadable({
  loader: () => import('../containers/dashboard'),
  loading: Loading,
});

const Profile = Loadable({
  loader: () => import('../containers/profile'),
  loading: Loading,
});

const Preferences = Loadable({
  loader: () => import('../containers/preferences'),
  loading: Loading,
});

const Decline = Loadable({
  loader: () => import('../containers/decline'),
  loading: Loading,
});

const MortgageRedirect = Loadable({
  loader: () => import('../containers/mortgage-redirect'),
  loading: Loading,
});

const Referrals = Loadable({
  loader: () => import('../containers/referrals/referrals'),
  loading: Loading,
});

const ShippingAddress = Loadable({
  loader: () => import('../containers/referrals/referral-shipping-address'),
  loading: Loading,
});

const ReferralsRegister = Loadable({
  loader: () => import('../containers/referrals/referrals-register'),
  loading: Loading,
});

const ReferralsAch = Loadable({
  loader: () => import('../containers/referrals/referrals-ach'),
  loading: Loading,
});

const ReferralsW9 = Loadable({
  loader: () => import('../containers/referrals/referrals-w9'),
  loading: Loading,
});

const GoogleRedirect = Loadable({
  loader: () => import('../containers/referrals/contact-redirect-page'),
  loading: Loading,
});

const PoliciesRedirect = Loadable({
  loader: () => import('./policy'),
  loading: Loading,
});

const Consents = Loadable({
  loader: () => import('../containers/consents'),
  loading: Loading,
});

const AppleSpouse = Loadable({
  loader: () => import('../containers/apple-spouse'),
  loading: Loading,
});

const DpaContainer = Loadable({
  loader: () => import('../containers/dpa'),
  loading: Loading,
});

const Notifications = Loadable({
  loader: () => import('../containers/notifications'),
  loading: Loading,
});

const ReferralsConsent = Loadable({
  loader: () => import('../containers/referrals/referrals-consent'),
  loading: Loading,
});

const HandleIFrameBreakOutAndRedirects = Loadable({
  loader: () => import('../containers/referrals/handle-iframe-break-out-and-redirects'),
  loading: Loading,
});

const WelcomeKit = Loadable({
  loader: () => import('../containers/welcome-kit/welcome-kit'),
  loading: Loading,
});

const CrossBuy = Loadable({
  loader: () => import('../containers/cross-buy/cross-buy'),
  loading: Loading,
});

/**
 * Main container for the application
 */
const AppContainer = styled.div`
  background-color: #f2f2f2;
  min-height: 100vh;
`;

const App = props => (
  <Router>
    <ScrollToTop>
      <AppContainer>
        <Header {...props} />
        <Main>
          <Switch>
            <Route path="/" exact component={Dashboard} />
            <Route path="/home" component={Dashboard} />
            <Route path="/profile" component={Profile} />
            <Route path="/preferences" component={Preferences} />
            <Route path="/affiliate/overview" component={Referrals} />
            <Route path="/affiliate/register" component={ReferralsRegister} />
            <Route path="/affiliate/shipping-address" component={ShippingAddress} />
            <Route path="/affiliate/ach" component={ReferralsAch} />
            <Route path="/affiliate/w9" component={ReferralsW9} />
            <Route path="/affiliate/consent" component={ReferralsConsent} />
            <Route path="/decline/:appId?" component={Decline} />
            <Route path="/mortgage-redirect/:appId?" component={MortgageRedirect} />
            <Route path="/marbles" component={Marbles} />
            <Route path="/google/redirect" component={GoogleRedirect} />
            <Route path="/policy" component={PoliciesRedirect} />
            <Route path="/consents" component={Consents} />
            <Route path="/apple/spouse" component={AppleSpouse} />
            <Route path="/notifications" render={() => <Notifications {...props} />} />
            <Route path="/dpa" component={DpaContainer} />
            <Route path="/iframe-killer" component={HandleIFrameBreakOutAndRedirects} />
            <Route path="/welcomekit" component={WelcomeKit} />
            <Route path="/cross-buy" component={CrossBuy} />
            <Route path="*" component={Marbles} />
          </Switch>
        </Main>
        <Footer />
        <ChatButton />
        <IdleTimeout />
      </AppContainer>
    </ScrollToTop>
  </Router>
);

export default App;



// WEBPACK FOOTER //
// ./src/components/app.js