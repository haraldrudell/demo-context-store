import React from 'react';
import PropTypes from 'prop-types';

class Timer extends React.Component {
  static propTypes = {
    time: PropTypes.number.isRequired,
    onTimeUp: PropTypes.func.isRequired,
  };

  state = {
    count: this.props.time * 60,
  };

  componentDidMount() {
    this.isStillMounted = true;
    this.startTimer();
  }

  shouldComponentUpdate(nextProps, nextState) {
    if (nextState.count === 0) {
      clearTimeout(this.modalTimeout);
      this.props.onTimeUp();
    }
    return nextState.count > 0;
  }

  componentWillUnmount() {
    this.isStillMounted = false;
    if (this.modalTimeout) {
      clearTimeout(this.modalTimeout);
      this.modalTimeout = undefined;
    }
  }

  modalTimeout;
  isStillMounted = false;

  startTimer = () => {
    this.modalTimeout = setTimeout(() => {
      if (!this.isStillMounted) return;
      this.setState(state => ({ count: state.count - 1 }));
      this.startTimer();
    }, 1000);
  };

  render() {
    return this.state.count;
  }
}

export default Timer;



// WEBPACK FOOTER //
// ./src/components/timeout/timer.js