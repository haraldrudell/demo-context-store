import React, { Component } from 'react';
import PropTypes from 'prop-types';

/**
 * Function imports
 */
import { dateParser, defaultFormatter } from './utilities';

const MINUTE = 60;
const HOUR = MINUTE * 60;
const DAY = HOUR * 24;
const WEEK = DAY * 7;
const MONTH = DAY * 30;
const YEAR = DAY * 365;

class TimeAgo extends Component {
  static propTypes = {
    /**
     * If the component should update itself over time
     */
    live: PropTypes.bool,
    /**
     * Minimum amount of time in seceonds between re-renders
     */
    minPeriod: PropTypes.number,
    /**
     * Maximum time between re-renders in seconds.
     */
    maxPeriod: PropTypes.number,
    /**
     * The container to render the string into.
     * You could `span`, `div` or a custom component
     */
    container: PropTypes.node,
    /**
     * The Date to display. An actual Date object or something that can be fed
     * to new Date
     */
    date: PropTypes.oneOfType([PropTypes.number.isRequired, PropTypes.string.isRequired]).isRequired,
  };

  static defaultProps = {
    live: true,
    container: 'time',
    minPeriod: 0,
    maxPeriod: Infinity,
  };

  componentDidMount() {
    this.isStillMounted = true;
    if (this.props.live) {
      this.tick(true);
    }
  }

  componentDidUpdate(lastProps) {
    if (this.props.live !== lastProps.live || this.props.date !== lastProps.date) {
      if (!this.props.live && this.timeoutId) {
        clearTimeout(this.timeoutId);
      }
      this.tick();
    }
  }

  componentWillUnmount() {
    this.isStillMounted = false;
    if (this.timeoutId) {
      clearTimeout(this.timeoutId);
      this.timeoutId = undefined;
    }
  }

  timeoutId;
  isStillMounted = false;

  tick = (refresh) => {
    if (!this.isStillMounted || !this.props.live) {
      return;
    }

    const then = dateParser(this.props.date).valueOf();
    if (!then) {
      return;
    }

    const now = Date.now();
    const seconds = Math.round(Math.abs(now - then) / 1000);

    let unboundPeriod;
    if (seconds < MINUTE) {
      unboundPeriod = 1000;
    } else if (seconds < HOUR) {
      unboundPeriod = 1000 * MINUTE;
    } else if (seconds < DAY) {
      unboundPeriod = 1000 * HOUR;
    } else {
      unboundPeriod = 0;
    }

    const period = Math.min(Math.max(unboundPeriod, this.props.minPeriod * 1000), this.props.maxPeriod * 1000);
    if (period) {
      this.timeoutId = setTimeout(this.tick, period);
    }

    if (!refresh) {
      this.forceUpdate();
    }
  };

  render() {
    const {
      date, container: Container, live, minPeriod, maxPeriod, ...passDownProps
    } = this.props;

    const then = dateParser(date).valueOf();
    if (!then) {
      return null;
    }

    const timeNow = Date.now();
    const seconds = Math.round(Math.abs(timeNow - then) / 1000);
    const suffix = then < timeNow ? 'ago' : 'from now';

    let value;
    let unit;
    if (seconds < MINUTE) {
      [value, unit] = [Math.round(seconds), 'second'];
    } else if (seconds < HOUR) {
      [value, unit] = [Math.round(seconds / MINUTE), 'minute'];
    } else if (seconds < DAY) {
      [value, unit] = [Math.round(seconds / HOUR), 'hour'];
    } else if (seconds < WEEK) {
      [value, unit] = [Math.round(seconds / DAY), 'day'];
    } else if (seconds < MONTH) {
      [value, unit] = [Math.round(seconds / WEEK), 'week'];
    } else if (seconds < YEAR) {
      [value, unit] = [Math.round(seconds / MONTH), 'month'];
    } else {
      [value, unit] = [Math.round(seconds / YEAR), 'year'];
    }

    let passDownTitle;
    if (typeof date === 'string') {
      passDownTitle = date;
    } else {
      passDownTitle = dateParser(date)
        .toISOString()
        .substr(0, 16)
        .replace('T', ' ');
    }

    if (Container === 'time') {
      passDownProps.dateTime = dateParser(date).toISOString();
    }

    const nextFormatter = defaultFormatter.bind(null, value, unit, suffix);

    return (
      <Container {...passDownProps} title={passDownTitle}>
        {defaultFormatter(value, unit, suffix, then, nextFormatter)}
      </Container>
    );
  }
}

export default TimeAgo;



// WEBPACK FOOTER //
// ./src/components/time-ago/time-ago.js