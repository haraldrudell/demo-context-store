import React from 'react';
import PropTypes from 'prop-types';
import { FooterLegal, Row, Column } from 'scuid-x';
import styled from 'styled-components';
import { I18n } from 'react-redux-i18n';

/**
 * PropTypes imports
 */
import { RatesPropTypes } from '../../constants/prop-types/rates-prop-types';

/**
 * Utilities imports
 */
import { toPercent } from '../../utilities/to-percent-helper';

const BottomRow = styled(Row)`
  margin-left: 0;
  margin-right: 0;
  max-width: 100%;
`;

const BottomColumn = styled(Column)`
  padding: 0;
`;

const FooterParagraph = styled.p`
  margin-bottom: 0px !important;
`;

const EqualHousing = styled.p`
  padding-top: 10px;
  float: right;
  @media (max-width: 767px) {
    float: left;
  }
`;

const FooterLink = styled.a`
  text-decoration: underline;
  color: #103955;
  font-weight: 500;
`;

const numTimes100ToPercent = num => toPercent(num * 100);

const Legal = ({
  rates: {
    REFI, PL, PARENT, MORT,
  }, corporateEmployer,
}) => {
  let refiText = (
    <p>
      1. Exact rates for variable and fixed rate REFIs are currently not displaying properly. Contact our customer service line
      {I18n.t(corporateEmployer === 'apple' ? 'appleEmail' : 'sofiCustomerServiceEmail')} for our current rates.
    </p>
  );

  if (REFI) {
    refiText = (
      <p>
        1. Fixed rates from {numTimes100ToPercent(REFI.minFixRate)} APR (with AutoPay) to {numTimes100ToPercent(REFI.maxFixRate)} APR
        (without AutoPay). Variable rates currently from {numTimes100ToPercent(REFI.minVarRate)} APR (with AutoPay) to{' '}
        {numTimes100ToPercent(REFI.maxVarRate)} (without AutoPay). Interest rates on variable rate loans are capped at either{' '}
        {numTimes100ToPercent(REFI.minRateCap)} or {numTimes100ToPercent(REFI.maxRateCap)} depending on term of loan. See{' '}
        <FooterLink href="https://www.sofi.com/refinance-student-loan/refinance-student-loan-rates/">APR examples and terms.</FooterLink>{' '}
        Lowest variable rate of {numTimes100ToPercent(REFI.minVarRate)} APR assumes current 1 month LIBOR rate of{' '}
        {numTimes100ToPercent(REFI.libor)} plus {numTimes100ToPercent(REFI.minVarRateLibor)} margin. If approved for a loan, the fixed or
        variable interest rate offered will depend on your credit history and the term of the loan and will be within the ranges of rates
        listed above. For the SoFi variable rate loan, the 1-month LIBOR index will adjust monthly and the loan payment will be re-amortized
        and may change monthly. APRs for variable rate loans may increase after origination if the LIBOR index increases. The SoFi{' '}
        {REFI.benefitAmount * 100}% AutoPay interest rate reduction requires you to agree to make monthly principal and interest payments by
        an automatic monthly deduction from a savings or checking account. The benefit will discontinue and be lost for periods in which you
        do not pay by automatic deduction from a savings or checking account.
      </p>
    );
  }

  let personalLoansText = (
    <p>
      2. Exact rates for Personal Loans are currently not displaying properly. Contact our customer service line{' '}
      {I18n.t(corporateEmployer === 'apple' ? 'appleEmail' : 'sofiCustomerServiceEmail')} for our current rates.
    </p>
  );

  if (PL) {
    personalLoansText = (
      <p>
        2. Fixed rates from {numTimes100ToPercent(PL.minFixRate)} APR (with AutoPay) to {numTimes100ToPercent(PL.maxFixRate)} (without
        AutoPay). Variable rates from {numTimes100ToPercent(PL.minVarRate)} APR (with AutoPay) to {numTimes100ToPercent(PL.maxVarRate)}{' '}
        (without AutoPay). SoFi rate ranges are current as of January 1, 2018 and are subject to change without notice. Interest rates on
        variable rate loans are capped at {numTimes100ToPercent(PL.minRateCap)}. See&nbsp;
        <FooterLink href="https://www.sofi.com/personal-loans/personal-loan-rates/">APR examples and terms.</FooterLink> Lowest variable
        rate of {numTimes100ToPercent(PL.minVarRate)} APR assumes current 1-month LIBOR rate of {numTimes100ToPercent(PL.libor)} plus{' '}
        {numTimes100ToPercent(PL.minVarRateLibor)} margin minus {PL.benefitAmount * 100}% for AutoPay. Not all applicants qualify for the
        lowest rate. If approved for a loan, to qualify for the lowest rate, you must have excellent credit and meet other conditions. Your
        actual rate will be within the range of rates listed above and will depend on a variety of factors, including credit score, credit
        usage and history, years of experience, our ability to verify your income and employment and other factors. For the SoFi variable
        rate loan, the 1-month LIBOR index may adjust monthly and the loan payment will be re-amortized and may change monthly. APRs for
        variable rate loans may increase after origination if the LIBOR index increases. The SoFi {PL.benefitAmount * 100}% AutoPay interest
        rate reduction applies if you make monthly principal and interest payments by an automatic monthly deduction from a savings or
        checking account. The benefit will discontinue and be lost for periods in which you do not pay by automatic deduction from a savings
        or checking account. AutoPay is not required to obtain a loan.
      </p>
    );
  }

  let mortgageLoanText = (
    <p>
      3. We offer a variety of mortgage products. View here:{' '}
      <FooterLink href="https://www.sofi.com/mortgage-loan/mortgage-loan-rates">
        Current Mortgage Rates for Primary Home Purchase.
      </FooterLink>
    </p>
  );

  if (MORT) {
    mortgageLoanText = (
      <p>
        3. Lowest rates are based on the top tier for well qualified borrowers with a minimum of {MORT.benefitAmount} discount points. Not
        all applicants will qualify for the top tier. The lowest rates are based on 80% LTV for a purchase transaction of an owner occupied
        single family residence. Rates are subject to change and may not be available at the time of lock or loan commitment. APR for
        adjustable rate mortgages are subject to increase after fixed rate period and does not include 3rd party costs or prepaid interest.
      </p>
    );
  }

  let parentLoansText = (
    <p>
      4. Exact rates for variable and fixed rate Parent Loans are currently not displaying properly. Contact our customer service line{' '}
      {I18n.t(corporateEmployer === 'apple' ? 'appleEmail' : 'sofiCustomerServiceEmail')} for our current rates.
    </p>
  );

  if (PARENT) {
    parentLoansText = (
      <p>
        4. Fixed rates from {numTimes100ToPercent(PARENT.minFixRate)} APR (with AutoPay) to {numTimes100ToPercent(PARENT.maxFixRate)} APR
        (without AutoPay). Variable rates currently from {numTimes100ToPercent(PARENT.minVarRate)} APR (with AutoPay) to{' '}
        {numTimes100ToPercent(PARENT.maxVarRate)} (without AutoPay). Interest rates on variable rate loans are capped at{' '}
        {numTimes100ToPercent(PARENT.minRateCap)}. Lowest variable rate of {numTimes100ToPercent(PARENT.minVarRate)} APR assumes current 1
        month LIBOR rate of {numTimes100ToPercent(PARENT.libor)} plus {numTimes100ToPercent(PARENT.minVarRateLibor)} margin. If approved for
        a loan, the fixed or variable interest rate offered will depend on your credit history and the term of the loan and will be within
        the ranges of rates listed above. For the SoFi variable rate loan, the 1-month LIBOR index will adjust monthly and the loan payment
        will be re-amortized and may change monthly. APRs for variable rate loans may increase after origination if the LIBOR index
        increases. The SoFi {PARENT.benefitAmount * 100}% AutoPay interest rate reduction requires you to agree to make monthly principal
        and interest payments by an automatic monthly deduction from a savings or checking account. The benefit will discontinue and be lost
        for periods in which you do not pay by automatic deduction from a savings or checking account.
      </p>
    );
  }

  return (
    <FooterLegal>
      <p>
        SoFi is not affiliated with colleges and universities listed on SoFi.com. Colleges and universities listed on SoFi.com do not
        endorse, promote or recommend SoFi loan products.
      </p>
      <h5>Referral Program</h5>
      <div>
        <p>
          For the purposes of this Program, A SoFi Community Member (&#8220;Member&#8221;) is defined as a funded SoFi refinance student
          loan borrower, funded SoFi parent PLUS student loan borrower, funded SoFi Medical Resident refinance loan borrower, funded SoFi
          parent loan borrower or funded SoFi Personal Loan borrower, who has begun repayment with SoFi. Individuals who have created a
          SoFi account but are not borrowers shall be referred to as (&#8220;Non-members&#8221;). The Program is open to all Members and
          Non-members who reside outside of Vermont and who are of the legal age of majority in the state in which they reside. SoFi
          Employees are not eligible to participate in this Program.
        </p>
        <p>SoFi Members shall be eligible for cash and swag bonuses. Non-members shall only be eligible for cash bonuses. </p>
        <p>
          To receive credit for a referral under the Program, eligible referrers must create a Program account, receive their unique
          referral links, and send the relevant link(s) to the people whom they intend to refer to SoFi for Student Loan Refinancing,
          Medical Resident Refinancing, Parent PLUS refinancing, a Parent Loan or a Personal Loan.{' '}
        </p>
        <p>
          By referring friends via email you agree to allow us to send an email on your behalf giving your friends the opportunity to apply
          for a student loan refinance, parent loan, or personal loan. Your friends&#39; email addresses will only be used for this offer
          and will not be used for any other marketing solicitations or sold to third parties. If your friend already has a SoFi account, is
          on our opt-out list or the national email opt-out list, lives in a state where SoFi is not licensed, has already received a unique
          URL, or if the email address you provided is incorrect or no longer valid, your friend may not receive the email. Due to the
          confidential nature, we cannot disclose any information about qualifying accounts opened by the friends you invite. Participation
          in this Program serves as a one-time waiver of privacy rights by both parties, whereas each may be aware of the presence of an
          account relationship.
        </p>
        <p>
          In order for the referring party to receive credit for an email invite the email address provided must belong to an eligible
          recipient as described above. In order for the referring party to receive credit for an application start, each recipient must
          use their referrer&#39;s relevant unique link to first register for a SoFi account, and then create their student loan
          refinancing application, Medical Resident loan application, Parent Plus loan application, parent loan application or personal
          loan application. In order for either party to receive credit for cash bonuses, each recipient must use their referrer&#39;s
          relevant unique link to first register for a SoFi account, and then create their student loan refinancing application, Medical
          Resident loan application, Parent Plus loan application, parent loan application or personal loan application, and then proceed
          all the way through funding in at least one of those loans.
        </p>
        <p>
          Only one cash bonus and one welcome bonus will be awarded for each referred Member, regardless of whether the Member takes out
          multiple loans or multiple types of loans. Members and Non-Members are limited to 20 cash referral bonuses in any preceding
          12-month period and 60 total lifetime cash referral bonuses. Referrers will NOT receive a cash referral bonus for a new referral
          if they have received 20 cash referral bonuses in the preceding 12 months or if they have received 60 total lifetime cash referral
          bonuses. Swag bonuses are available only to Members and limited to 1 water bottle and 1 backpack, there is no limit on cash
          bonuses. Swag and Referral bonuses are considered miscellaneous income, and may be reportable to you and the IRS on Form 1099-MISC
          (or Form 1042-S, if applicable). A referrer will not earn a referral reward if their referred friend has an existing SoFi account
          or if their referred friend does not use their unique referral link.
        </p>
        <p>
          Referrers will not receive credit for referring themselves, including for a refinance of their existing SoFi student loan, or for
          submitting an application via their own unique referral link. Referrers are limited to referring their own friends, colleagues,
          family members, and direct acquaintances whom they believe may be eligible for a SoFi student loan refinance, Medical Resident
          refinance, parent PLUS, parent loan or personal loan. Any referred borrower must be able to personally identify their referrer.
          SoFi reserves the right to disqualify anyone from this Program at any time. Anyone who violates these official rules is ineligible
          for payment of any bonus.
        </p>
        <p>
          The Program supports referrals to SoFi student loan refinancing loans, Medical Resident refinancing loans, parent PLUS loans,
          parent loans and personal loans only, and no payments will be made for referrals to other SoFi products.
        </p>

        <p>
          Additional terms and conditions apply, please review our official rules at{' '}
          <FooterLink href="/refer-a-friend">sofi.com/refer-a-friend</FooterLink>
          .
        </p>
      </div>

      <h5>Borrowing</h5>
      <p>
        Terms and Conditions Apply. SOFI RESERVES THE RIGHT TO MODIFY OR DISCONTINUE PRODUCTS AND BENEFITS AT ANY TIME WITHOUT NOTICE. To
        qualify, a borrower must be a U.S. citizen or permanent resident and meet SoFi&#39;s underwriting requirements. Lowest rates are
        reserved for the best borrowers. This information is current as of January 1, 2018 and is subject to change. SoFi loans are
        originated by SoFi Lending Corp (dba SoFi) California Finance Lender #6054612. NMLS #1121636.{' '}
        <FooterLink data-qa="footer-legal-nmls-consumer-access" href="http://www.nmlsconsumeraccess.org/">
          NMLS Consumer Access
        </FooterLink>
      </p>

      <h5>Investing</h5>
      <p>
        The information contained herein does not constitute an offer to sell securities or a solicitation of an offer to buy securities.
        Purchases or sales of securities privately offered by SoFi or its affiliates (the &#8220;Securities&#8221;) can only be made by
        private placement memorandum and related subscription documents, which will be provided to accredited investors on a confidential
        basis at their request for their consideration in connection with such offering. Investment in the Securities will involve
        significant risks, including loss of principal. The Securities will have limited liquidity options, as there is a limited
        secondary market for the Securities. None of the information contained in this website release is a recommendation for investment
        in any securities. SoFi is not affiliated with or officially endorsed by any listed universities.
      </p>

      <h5>Refinance Loans</h5>
      {refiText}

      <h5>Personal Loans</h5>
      {personalLoansText}

      <h5>Mortgage Loans</h5>
      {mortgageLoanText}

      <h5>Parent Loans</h5>
      {parentLoansText}

      <BottomRow spacer={0}>
        <BottomColumn small={12} medium={9}>
          <ul className="footer-nav">
            <li>
              <FooterParagraph>&copy;2018 Social Finance, Inc.</FooterParagraph>
            </li>
            <li>
              <a data-qa="footer-legal-tou-link" href="https://www.sofi.com/terms-of-use/">
                Terms of Use
              </a>
            </li>
            <li>
              <a data-qa="footer-legal-sitemap-link" href="https://www.sofi.com/sitemap/">
                Sitemap
              </a>
            </li>
            <li>
              <a data-qa="footer-legal-privacy-policy-link" href="https://www.sofi.com/privacy-policy/">
                Privacy Policy
              </a>
            </li>
            <li>
              <a data-qa="footer-legal-legal-link" href="https://www.sofi.com/legal/">
                Legal
              </a>
            </li>
            <li>
              <FooterParagraph>Version 2.0.0</FooterParagraph> {/** Version should NOT be handled manually */}
            </li>
          </ul>
        </BottomColumn>
        <BottomColumn small={12} medium={3}>
          <EqualHousing>
            <i className="icon-equal-housing-lender" title="Equal Housing Lender" />
            Equal Housing Lender
          </EqualHousing>
        </BottomColumn>
      </BottomRow>
    </FooterLegal>
  );
};

Legal.propTypes = {
  rates: RatesPropTypes.isRequired,
  corporateEmployer: PropTypes.string.isRequired,
};

export default Legal;



// WEBPACK FOOTER //
// ./src/components/footer/footer-legal.js