import React from 'react';
import { I18n } from 'react-redux-i18n';
import PropTypes from 'prop-types';

/**
 * Styled components
 */
import { AlertContent, AlertNotification, AlertParagraph } from './shared-styles';

const HasInfo = ({ hasInfo, setAlertDismissableSession }) => (
  <AlertNotification warning dismissible onDismiss={() => setAlertDismissableSession('has.info')}>
    <AlertContent>
      <AlertParagraph dangerouslySetInnerHTML={{ __html: I18n.t(hasInfo()) || hasInfo() }} />
    </AlertContent>
  </AlertNotification>
);

HasInfo.propTypes = {
  hasInfo: PropTypes.func.isRequired,
  setAlertDismissableSession: PropTypes.func.isRequired,
};

export default HasInfo;



// WEBPACK FOOTER //
// ./src/components/alerts/has-info.js