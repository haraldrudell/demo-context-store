import React from 'react';

/**
 * Styled components
 */
import { AlertContent, AlertNotification } from './shared-styles';

const removeMarginTop = {
  marginTop: '0px',
};

const WelcomeKit = () => (
  <AlertNotification>
    <AlertContent style={removeMarginTop}>
      <span>
        {"We're going to send you an official SoFi member kit filled with essential info and a free gift. Please fill out your information"}
      </span>
      <a data-qa="alerts-welcome-kit" href="/dashboard/#/welcomekit">Get Welcome Kit!</a>
    </AlertContent>
  </AlertNotification>
);

export default WelcomeKit;



// WEBPACK FOOTER //
// ./src/components/alerts/welcome-kit.js