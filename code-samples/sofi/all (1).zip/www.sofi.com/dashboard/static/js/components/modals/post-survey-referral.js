import React from 'react';
import PropTypes from 'prop-types';
import { Modal, Button, Paragraph } from 'scuid-x';

/**
 * Styled Components
 */
import { ReasonContainer } from './shared-styles';
import { ScuidLink } from '../../utilities/global-styles';

const Container = ReasonContainer.extend`
  margin-top: -1.4rem;
`;

const PostSurveyReferralModal = ({
  isThankYouOpen, toggleOpenThankYouModal, referralLinkObj, highRating,
}) => (
  <Modal isOpen={isThankYouOpen} onDismiss={toggleOpenThankYouModal} title="Thank you!" minWidth={window.innerWidth >= 768 ? 750 : 0}>
    <Modal.Body>
      <Container>
        <Paragraph>
          Thank you for sharing your feedback! You will receive a series of welcome emails over the next few weeks explaining all the
          benefits you have as a SoFi member.{' '}
        </Paragraph>
        <Paragraph>Before you go, will you give 3 minutes, write a review and help others find SoFi? </Paragraph>
        <Paragraph>
          We value your feedback, and so do future SoFi customers. Online reviews are an important part of many customer&#39;s decision to
          fund a loan with SoFi. Your opinion will help others evaluate SoFi.{' '}
        </Paragraph>
        {highRating && (
          <ScuidLink data-qa="post-survey-referral-review-link" href={referralLinkObj.reviewUrl} onClick={toggleOpenThankYouModal}>
            {referralLinkObj.reviewText}
          </ScuidLink>
        )}
      </Container>
    </Modal.Body>
    <Modal.Footer>
      <Button data-qa="noEmployment-close" small secondary onClick={toggleOpenThankYouModal}>
        Ok, got it!
      </Button>
    </Modal.Footer>
  </Modal>
);

/* eslint react/no-typos: 0 */
PostSurveyReferralModal.propTypes = {
  isThankYouOpen: PropTypes.bool.isRequired,
  toggleOpenThankYouModal: PropTypes.func.isRequired,
  referralLinkObj: PropTypes.shape({
    reviewText: PropTypes.string.isRequired,
    reviewUrl: PropTypes.string.isRequired,
  }).isRequired,
  highRating: PropTypes.bool.isRequired,
};

export default PostSurveyReferralModal;



// WEBPACK FOOTER //
// ./src/components/modals/post-survey-referral.js