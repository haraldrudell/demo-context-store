import React from 'react';
import PropTypes from 'prop-types';
import { Modal, Button, Paragraph, DropDown } from 'scuid-x';
import { withFormik, Form } from 'formik';
import Yup from 'yup';

/**
 * PropTypes imports
 */
import { StatesPropTypes } from '../../constants/prop-types//states-prop-types';

const StateMissing = ({
  isOpen, toggleOpen, states, values, errors, setFieldValue, handleSubmit, touched, isSubmitting,
}) => (
  <Modal isOpen={isOpen} onDismiss={toggleOpen} title="Select State of Residence" minWidth={window.innerWidth >= 768 ? 750 : 0}>
    <Modal.Body>
      <Paragraph>
        The products SoFi can offer you may vary based on state law. Please provide your state of residence to continue.
      </Paragraph>
      <Form data-qa="state-missing-form">
        <DropDown
          name="selectedState"
          value={values.selectedState}
          onChange={e => setFieldValue('selectedState', e.target.value)}
          options={states}
          qa="state-dropdown"
          label="State"
          errorText={touched.selectedState && errors.selectedState}
        />
      </Form>
    </Modal.Body>
    <Modal.Footer>
      <Button data-qa="state-close" small onClick={toggleOpen}>
        Cancel
      </Button>
      <Button data-qa="state-submit" small onClick={handleSubmit} disabled={isSubmitting}>
        Save
      </Button>
    </Modal.Footer>
  </Modal>
);

/* eslint react/no-typos: 0 */
StateMissing.propTypes = {
  isOpen: PropTypes.bool.isRequired,
  toggleOpen: PropTypes.func.isRequired,
  values: PropTypes.object.isRequired, // eslint-disable-line react/forbid-prop-types
  errors: PropTypes.objectOf(PropTypes.string).isRequired,
  setFieldValue: PropTypes.func.isRequired,
  handleSubmit: PropTypes.func.isRequired,
  touched: PropTypes.objectOf(PropTypes.bool).isRequired,
  isSubmitting: PropTypes.bool.isRequired,
  states: StatesPropTypes.isRequired,
};

export default withFormik({
  mapPropsToValues: () => ({
    selectedState: '',
  }),
  validationSchema: () =>
    Yup.object().shape({
      selectedState: Yup.string().required('Please select a State'),
    }),
  handleSubmit: (values, { props }) => {
    /**
     * Convert the selected state back to the original object
     * original = { alpha2: UT , name: Utah }, values.selectedState = 'UT'
     */
    const data = props.states.find(element => element.alpha2 === values.selectedState);
    props.updateState(data, props.toggleOpen);
  },
})(StateMissing);



// WEBPACK FOOTER //
// ./src/components/modals/state-missing.js