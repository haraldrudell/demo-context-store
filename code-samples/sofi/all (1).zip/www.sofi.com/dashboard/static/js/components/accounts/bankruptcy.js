import React, { Fragment } from 'react';
import { SubheadFour } from 'scuid-x';

/**
 * PropTypes imports
 */
import { ApplicationPropType } from '../../constants/prop-types/application-prop-types';

/**
 * Styled Components
 */
import { LoanDescription } from './shared-styles';

const Bankruptcy = ({ app }) => (
  <Fragment>
    <SubheadFour>
      {app.productDesc} (#{app.servicing.accountId})
    </SubheadFour>
    <LoanDescription>{app.servicing.statusDesc}</LoanDescription>
  </Fragment>
);

/* eslint react/no-typos: 0 */
Bankruptcy.propTypes = {
  app: ApplicationPropType.isRequired,
};

Bankruptcy.defaultProps = {};

export default Bankruptcy;



// WEBPACK FOOTER //
// ./src/components/accounts/bankruptcy.js