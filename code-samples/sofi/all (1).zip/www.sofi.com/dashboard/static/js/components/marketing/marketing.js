import React, { Fragment } from 'react';

/**
 * PropTypes imports
 */
import { PhotoCardsPropType, LinkCardPropType } from '../../constants/prop-types/marketing-prop-types';
import { CustomerPropTypes } from '../../constants/prop-types/customer-prop-types';

/**
 * Component imports
 */
import MarketingPhotoCard from './marketing-photo-card';
import MarketingLinksCard from './marketing-links-card';

const Marketing = ({
  photoCards, links, customer,
}) => (
  <Fragment>
    <MarketingPhotoCard photoCards={photoCards} customer={customer} />
    <MarketingLinksCard links={links} />
  </Fragment>
);

/* eslint react/no-typos: 0 */
Marketing.propTypes = {
  photoCards: PhotoCardsPropType.isRequired,
  links: LinkCardPropType.isRequired,
  customer: CustomerPropTypes.isRequired,
};

export default Marketing;



// WEBPACK FOOTER //
// ./src/components/marketing/marketing.js