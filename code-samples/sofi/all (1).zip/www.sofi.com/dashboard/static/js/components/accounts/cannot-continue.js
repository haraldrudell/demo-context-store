import React, { Component, Fragment } from 'react';
import PropTypes from 'prop-types';
import { SubheadFour, Icon, IconType } from 'scuid-x';
import { Translate, I18n } from 'react-redux-i18n';

/**
 * PropTypes imports
 */
import { ApplicationPropType } from '../../constants/prop-types/application-prop-types';

/**
 * Utilities/function imports
 */
import {
  findDocument,
  servicedPl,
  needsSigned,
  isMortCENLAR,
  hasMortServicingAccess,
  showWelcomeBonus,
  isProcessingWelcomeBonus,
  loanAmountTitle,
} from './utilities';
import { FORMAT_CURRENCY } from '../../utilities/currency-format-helpers';

/**
 * Component imports
 */
import MohelaModal from './mohela-modal';
import ButtonDropdown from './button-dropdown';

/**
 * Styled Components
 */
import { LoanBody, LoanSummary, LoanAmount, LoanAction, LoanButton, Attention, LoanDescription, DropdownContainer } from './shared-styles';
import { RouterLink } from '../../utilities/global-styles';
import { AFFILIATE_REGISTER_URL } from '../../constants/referral-constants';

class CannotContinue extends Component {
  static propTypes = {
    index: PropTypes.number.isRequired,
    app: ApplicationPropType.isRequired,
    toggleDropdown: PropTypes.func.isRequired,
    isOpen: PropTypes.bool.isRequired,
  };

  state = {
    openMohela: false,
  };

  toggleOpen = () => {
    this.setState({ openMohela: !this.state.openMohela });
  };

  render() {
    const {
      app, index, toggleDropdown, isOpen,
    } = this.props;
    const { openMohela } = this.state;
    return (
      <Fragment>
        <SubheadFour>
          <span>
            {app.productDesc} (#{app.id}),
            {app.type === 'COSIGN' ? ` for ${app.primaryApplicantName}` : ''}
          </span>
          {servicedPl(app) && <span> Transitioning to Servicing</span>}
          {!servicedPl(app) && (
            <span>
              {' '}
              <Translate value={app.status} />
            </span>
          )}
        </SubheadFour>
        <LoanDescription>
          {['REFI', 'PARENT', 'PLUS', 'MEDREFI', 'DENTREFI'].includes(app.type) &&
            app.status === 'ServicerFunded' && (
              <span>Make payments and see account details with our third party servicing partner, MOHELA.</span>
            )}

          {needsSigned(app) && !app.rateLockDate && <Attention data-qa="accounts-cannotContinue-alert">{app.statusDesc}</Attention>}

          {needsSigned(app) &&
            !!app.rateLockDate &&
            app.type === 'COSIGN' && (
              <Attention data-qa="accounts-cannotContinue-new-rate-expire">
                {app.statusDesc} Your new rate will expire on {app.rateLockDate}.{' '}
              </Attention>
            )}

          {needsSigned(app) &&
            !!app.rateLockDate &&
            app.type !== 'COSIGN' && (
              <Attention data-qa="accounts-cannotContinue-selected-rate-expire">
                {app.statusDesc} Your selected rate will expire on {app.rateLockDate}.
              </Attention>
            )}

          {!needsSigned(app) &&
            !servicedPl(app) &&
            !(app.status === 'AdverseAction' && !findDocument(app, 'Adverse Action')) && <span>{app.statusDesc}</span>}

          {app.status === 'AdverseAction' &&
            !findDocument(app, 'Adverse Action') && (
              <span>
                {app.statusDesc} We are currently collecting the details for the decline - please wait a couple of seconds and refresh the
                page.
              </span>
            )}

          {!needsSigned(app) && servicedPl(app) && <span> Transitioning to Servicing</span>}

          {isMortCENLAR(app) &&
            !hasMortServicingAccess(app) &&
            app.servicing.statusDesc === 'OTHER' && <span> Your loan is no longer held by SoFi</span>}

          {isMortCENLAR(app) &&
            !hasMortServicingAccess(app) &&
            app.servicing.statusDesc !== 'OTHER' && (
              <span>
                Your Servicer online portal is loading and may take up to 30 seconds to appear. Please contact{' '}
                <a data-qa="accounts-mort-phone-link" href={`tel:+${I18n.t('mortgagePhoneUnformat')}`}>
                  <Translate value="mortgagePhoneReg" />
                </a>{' '}
                for further assistance if it still has not appeared after that time.
              </span>
            )}

          {showWelcomeBonus(app) &&
            !!app.welcomeBonusUrl && (
              <span>
                {' '}
                <RouterLink data-qa="accounts-enterBankInfo" to={AFFILIATE_REGISTER_URL}>
                  Enter bank information
                </RouterLink>{' '}
                for Welcome Bonus of ${app.welcomeBonusAmount}
              </span>
            )}

          {showWelcomeBonus(app) &&
            !app.welcomeBonusUrl &&
            app.welcomeBonusStatus === 'Pending' &&
            isProcessingWelcomeBonus(app) && (
              <span> Welcome Bonus of ${app.welcomeBonusAmount} is processing. Please allow up to a few weeks for completion.</span>
            )}

          {showWelcomeBonus(app) &&
            !app.welcomeBonusUrl &&
            app.welcomeBonusStatus === 'Pending' &&
            !isProcessingWelcomeBonus(app) && <span> Welcome Bonus of ${app.welcomeBonusAmount} is pending loan completion.</span>}

          {showWelcomeBonus(app) &&
            !app.welcomeBonusUrl &&
            app.welcomeBonusStatus === 'W-9' && (
              <span> Welcome Bonus of ${app.welcomeBonusAmount} is processing. Please allow up to a few weeks for completion.</span>
            )}

          {showWelcomeBonus(app) &&
            !app.welcomeBonusUrl &&
            app.welcomeBonusStatus !== 'Pending' &&
            app.welcomeBonusStatus !== 'W-9' && (
              <span>
                {' '}
                Welcome Bonus of ${app.welcomeBonusAmount} is {app.welcomeBonusStatus}
              </span>
            )}
        </LoanDescription>
        <LoanBody>
          {!!app.amount && (
            <LoanSummary>
              <LoanAmount data-qa={`loan-amount-${app.type}`}>
                {/* Convert amount to currency via custom format helper method */}
                {FORMAT_CURRENCY(app.amount)} <span>{loanAmountTitle(app)}</span>
              </LoanAmount>
            </LoanSummary>
          )}

          <LoanAction>
            <div>
              {['REFI', 'PARENT', 'PLUS', 'MEDREFI', 'DENTREFI'].includes(app.type) &&
                app.status === 'ServicerFunded' && (
                  <LoanButton data-qa="accounts-clickMohelaPopup" small onClick={this.toggleOpen}>
                    Manage account
                  </LoanButton>
                )}

              {/* Mohela Modal popup */}
              <MohelaModal open={openMohela} toggleOpen={this.toggleOpen} />

              {isMortCENLAR(app) &&
                hasMortServicingAccess(app) && (
                  <a target="_blank" href={hasMortServicingAccess(app)} data-qa="accounts-mortgageCenlar" data-mjs="dashboard-mort-cenlar">
                    <LoanButton data-qa="accounts-cannot-continue-loan-details" small>
                      Loan details
                    </LoanButton>
                  </a>
                )}

              {app.docs &&
                app.docs.length > 0 && (
                  <DropdownContainer data-qa="accounts-cenlar-dropdown-container">
                    {(['REFI', 'PARENT', 'PLUS', 'MEDREFI', 'DENTREFI'].includes(app.type) && app.status === 'ServicerFunded') ||
                    (isMortCENLAR(app) && hasMortServicingAccess(app)) ? (
                      '' // do nothing
                    ) : (
                      <LoanButton
                        small
                        secondary
                        onClick={() => {
                          toggleDropdown(index);
                        }}
                        data-qa="accounts-cenlarDropdown"
                      >
                        View details{' '}
                        {isOpen ? (
                          <Icon size={14} blueIcon iconType={IconType.CaretUp} />
                        ) : (
                          <Icon size={14} blueIcon iconType={IconType.CaretDown} />
                        )}
                      </LoanButton>
                    )}

                    {/* Dropdown menu */}
                    {isOpen && <ButtonDropdown data-qa="accounts-cenlar-button-dropdown" app={app} />}
                  </DropdownContainer>
                )}
            </div>
          </LoanAction>
        </LoanBody>
      </Fragment>
    );
  }
}

export default CannotContinue;



// WEBPACK FOOTER //
// ./src/components/accounts/cannot-continue.js