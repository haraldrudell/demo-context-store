import React from 'react';
import { Link } from 'react-router-dom';
import PropTypes from 'prop-types';

/**
 * PropTypes imports
 */
import { ReferralSummaryPropTypes } from '../../constants/prop-types/referral-prop-types';

/**
 * Styled components
 */
import { AlertContent, AlertNotification } from './shared-styles';

const W9Claim = ({ referralSummary, setAlertDismissableSession }) => (
  <AlertNotification dismissible onDismiss={() => setAlertDismissableSession('w9.referral.info')}>
    <AlertContent>
      <span>
        Complete form W-9 to claim your
        {referralSummary && referralSummary.registrations > 0 ? ' referral or ' : ' '}
        welcome bonus. We will issue you a 1099 if you exceed $599 in bonus payments in a calendar year.
      </span>
      <Link data-qa="alerts-w9-claim-link" to="/affiliate/w9">Click here</Link>
    </AlertContent>
  </AlertNotification>
);

/* eslint react/no-typos: 0 */
W9Claim.propTypes = {
  referralSummary: ReferralSummaryPropTypes.isRequired,
  setAlertDismissableSession: PropTypes.func.isRequired,
};

export default W9Claim;



// WEBPACK FOOTER //
// ./src/components/alerts/w9-claim.js