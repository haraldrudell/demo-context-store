import React from 'react';
import PropTypes from 'prop-types';
import { Modal, Button, Paragraph } from 'scuid-x';

/**
 * Styled Components
 */
import { ReasonContainer } from './shared-styles';
import { RouterLink } from '../../utilities/global-styles';

const Container = ReasonContainer.extend`
  margin-top: -1.4rem;
`;

const NoEmployment = ({ isOpen, toggleOpen }) => (
  <Modal isOpen={isOpen} onDismiss={toggleOpen} title="" minWidth={window.innerWidth >= 768 ? 750 : 0}>
    <Modal.Body>
      <Container>
        <Paragraph>Unfortunately it looks like you have not saved any employment information with us currently.</Paragraph>
        <Paragraph>
          If you would like to be a part of the Unemployment Protection Program, please update your employment information{' '}
          <RouterLink data-qa="no-employment-profile-link" to="/profile" onClick={toggleOpen}>here</RouterLink>.
          You must also have a funded loan with SoFi in order to continue.
        </Paragraph>
      </Container>
    </Modal.Body>
    <Modal.Footer>
      <Button data-qa="noEmployment-close" small secondary onClick={toggleOpen}>
        Close
      </Button>
    </Modal.Footer>
  </Modal>
);

/* eslint react/no-typos: 0 */
NoEmployment.propTypes = {
  isOpen: PropTypes.bool.isRequired,
  toggleOpen: PropTypes.func.isRequired,
};

export default NoEmployment;



// WEBPACK FOOTER //
// ./src/components/modals/no-employment.js