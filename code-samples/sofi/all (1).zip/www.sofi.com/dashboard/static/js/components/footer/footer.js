import React from 'react';
import { Footer } from 'scuid-x';

/**
 * Component imports
 */
import Contact from './footer-contact';
import Legal from './footer-legal';

const FooterComponent = props => (
  <Footer>
    <Contact {...props} />
    <Legal {...props} />
  </Footer>
);

export default FooterComponent;



// WEBPACK FOOTER //
// ./src/components/footer/footer.js