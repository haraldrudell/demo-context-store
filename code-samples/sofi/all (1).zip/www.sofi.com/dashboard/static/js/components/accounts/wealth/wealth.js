import React, { Fragment } from 'react';
import { SubheadFour } from 'scuid-x';

/**
 * PropTypes imports
 */
import { WealthProfilePropTypes } from '../../../constants/prop-types/wealth-prop-types';

/**
 * Utilities/function imports
 */
import { buildProfileData, buildFromCta, isAccountFunded, isCompletedAccount } from './utilities';
import { FORMAT_CURRENCY } from '../../../utilities/currency-format-helpers';

/**
 * Styled Components
 */
import {
  LoanSummary,
  LoanBody,
  LoanAdditionalInfo,
  LoanAction,
  LoanAmount,
  LoanButton,
  LoanDescription,
  LoanBottomBorder,
} from '../shared-styles';

/**
 * Wealth component/card in Accounts
 */
const Wealth = ({ wealthProfile }) => {
  const profileData = buildProfileData(wealthProfile);
  const profileHtml = buildFromCta(wealthProfile.ctaInfo);
  return (
    <Fragment>
      {/* account funded  */}
      {isAccountFunded(profileData) && (
        <Fragment>
          <SubheadFour>
            {profileData.accountTypeDescription} (#{profileData.account})
          </SubheadFour>
          <LoanBody>
            <LoanSummary>
              <LoanAmount>
                {/* Convert amount to currency via custom format helper method */}
                {FORMAT_CURRENCY(profileData.currentBalance)}
                <span>Current value</span>
              </LoanAmount>
              <LoanAdditionalInfo>
                <div>
                  {/* Convert amount to currency via custom format helper method */}
                  {FORMAT_CURRENCY(profileData.dayChange)}
                  <span>Day change</span>
                </div>
              </LoanAdditionalInfo>
            </LoanSummary>

            <LoanAction>
              <a data-qa="accounts-wealthCtaLink" href={profileHtml.ctaLink ? profileHtml.ctaLink : '/wealth/#/'}>
                <LoanButton data-qa="accounts-wealthCtaLink-button" small>
                  {profileData.funded ? 'View Details' : 'Continue'}
                </LoanButton>
              </a>
            </LoanAction>
          </LoanBody>
        </Fragment>
      )}
      {/* account not funded */}
      {!isAccountFunded(profileData) && (
        <Fragment>
          {isCompletedAccount(profileData) && (
            <SubheadFour>
              {profileData.accountTypeDescription} (#{profileData.account})
            </SubheadFour>
          )}
          {!isCompletedAccount(profileData) && <SubheadFour>Wealth Plan</SubheadFour>}
          <LoanDescription>{profileHtml.subText}</LoanDescription>
          <LoanBody>
            <LoanSummary>
              <LoanAmount>
                {FORMAT_CURRENCY(profileData.currentBalance)}
                <span>Current value</span>
              </LoanAmount>
            </LoanSummary>

            <LoanAction>
              <a data-qa="accounts-wealthCtaLink" href={profileHtml.ctaLink ? profileHtml.ctaLink : '/wealth/#/'}>
                <LoanButton data-qa="accounts-wealthCtaLink-button" small>
                  {profileHtml.cta}
                </LoanButton>
              </a>
            </LoanAction>
          </LoanBody>
        </Fragment>
      )}
      {/* Border/Divider */}
      <LoanBottomBorder />
    </Fragment>
  );
};

/* eslint react/no-typos: 0 */
Wealth.propTypes = {
  wealthProfile: WealthProfilePropTypes.isRequired,
};

export default Wealth;



// WEBPACK FOOTER //
// ./src/components/accounts/wealth/wealth.js