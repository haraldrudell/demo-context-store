import React from 'react';
import PropTypes from 'prop-types';
import { FeatureFlag } from 'react-launch-darkly';
/**
 * Styled components
 */
import { AlertContent, AlertNotification } from './shared-styles';
import { FEATURE_FLAG_WEALTH_BANNER_AD } from '../../constants/launch-darkly-constants';

function renderAd(content, ctaText, ctaLink, dataQa, dataMjs, setAlertDismissableSession) {
  return (
    <AlertNotification dismissible onDismiss={() => setAlertDismissableSession('wealth.advisor.ad')}>
      <AlertContent>
        <span>{content}</span>
        <a data-qa={dataQa} data-mjs={dataMjs} href={ctaLink}>
          {ctaText}
        </a>
      </AlertContent>
    </AlertNotification>
  );
}

function renderDefaultAd(setAlertDismissableSession) {
  return renderAd(
    'Want to know how to invest while paying down debt? SoFi Members get complimentary access to financial advisors.',
    'Schedule an Appointment',
    '/calendaring-ui',
    'wealth-advisor-ad-schedule',
    'dashboard-wealth-advisor-ad-schedule',
    setAlertDismissableSession,
  );
}

const WealthAdvisorAd = ({ setAlertDismissableSession }) => (
  <FeatureFlag
    flagKey={FEATURE_FLAG_WEALTH_BANNER_AD}
    renderFeatureCallback={(val) => {
      switch (val.key) {
        case 'kfa-career':
          return renderAd(val.content, val.ctaText, val.ctaLink, 'wealth-advisor-ad-kfa', val.dataMjs, setAlertDismissableSession);
        default:
          return renderDefaultAd(setAlertDismissableSession);
      }
    }}
    renderDefaultCallback={() => renderDefaultAd(setAlertDismissableSession)}
  />
);

WealthAdvisorAd.propTypes = {
  setAlertDismissableSession: PropTypes.func.isRequired,
};

export default WealthAdvisorAd;



// WEBPACK FOOTER //
// ./src/components/alerts/wealth-advisor-ad.js