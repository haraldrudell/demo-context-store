import React, { Fragment } from 'react';
import { SubheadFour, Icon, IconType } from 'scuid-x';
import { Translate } from 'react-redux-i18n';
import PropTypes from 'prop-types';

/**
 * PropTypes imports
 */
import { ApplicationPropType } from '../../constants/prop-types/application-prop-types';

/**
 * Component imports
 */
import ButtonDropdown from './button-dropdown';

/**
 * Utilities/function imports
 */
import {
  needsSigned,
  servicedPl,
  generateContinueText,
  showWelcomeBonus,
  isProcessingWelcomeBonus,
  isProductSelect,
  loanAmountTitle,
} from './utilities';
import { FORMAT_CURRENCY } from '../../utilities/currency-format-helpers';

/**
 * Styled Components
 */
import { LoanBody, LoanSummary, LoanAction, LoanAmount, LoanButton, Attention, LoanDescription, DropdownContainer } from './shared-styles';
import { ScuidLink } from '../../utilities/global-styles';

const ServicingButton = LoanButton.extend`
  ${props =>
    props.flatSide &&
    `
    border-bottom-right-radius: 0;
    border-top-right-radius: 0;
  `};
`;

const ServicingDropdown = LoanButton.extend`
  margin-left: 1px;
  min-width: 0;
  width: auto;
  border-bottom-left-radius: 0;
  border-top-left-radius: 0;
  svg {
    path {
      fill: white !important;
    }
  }
`;

const NotInServicing = ({
  app, index, toggleDropdown, isOpen,
}) => (
  <Fragment>
    <SubheadFour>
      {app.productDesc} (#{app.id}),
      {app.type === 'COSIGN' ? ` for ${app.primaryApplicantName}` : ''}
      {servicedPl(app) && <span> Transitioning to Servicing</span>}
      {!servicedPl(app) && (
        <span>
          {' '}
          <Translate value={app.status} />
        </span>
      )}
    </SubheadFour>

    <LoanDescription>
      {needsSigned(app) && !app.rateLockDate && <Attention data-qa="accounts-notInServicing-alert">{app.statusDesc}</Attention>}

      {needsSigned(app) &&
        app.rateLockDate &&
        app.type === 'COSIGN' && (
          <Attention data-qa="accounts-notInServicing-new-rate-expire">
            {app.statusDesc} Your new rate will expire on {app.rateLockDate}.{' '}
          </Attention>
        )}

      {needsSigned(app) &&
        app.rateLockDate &&
        app.type !== 'COSIGN' && (
          <Attention data-qa="accounts-notInServicing-selected-rate-expire">
            {app.statusDesc} Your selected rate will expire on {app.rateLockDate}.{' '}
          </Attention>
        )}

      {!needsSigned(app) &&
        !servicedPl(app) && (
          <span>
            {app.statusDesc + (app.rateLockDate && isProductSelect(app) ? ` Your rates will expire on ${app.rateLockDate}. ` : ' ')}
          </span>
        )}

      {!needsSigned(app) && servicedPl(app) && <span> Transitioning to Servicing</span>}

      {showWelcomeBonus(app) &&
        app.welcomeBonusUrl && (
          <span>
            <ScuidLink data-qa="accounts-not-servicing-enter-bank-info-link" href={app.welcomeBonusUrl}>
              {' '}
              Enter bank information
            </ScuidLink>{' '}
            for Welcome Bonus of ${app.welcomeBonusAmount}
          </span>
        )}

      {showWelcomeBonus(app) &&
        !app.welcomeBonusUrl &&
        app.welcomeBonusStatus === 'Pending' &&
        isProcessingWelcomeBonus(app) && (
          <span> Welcome Bonus of ${app.welcomeBonusAmount} is processing. Please allow up to a few weeks for completion.</span>
        )}

      {showWelcomeBonus(app) &&
        !app.welcomeBonusUrl &&
        app.welcomeBonusStatus === 'Pending' &&
        !isProcessingWelcomeBonus(app) && <span> Welcome Bonus of ${app.welcomeBonusAmount} is pending loan completion.</span>}

      {showWelcomeBonus(app) &&
        !app.welcomeBonusUrl &&
        app.welcomeBonusStatus === 'W-9' && (
          <span> Welcome Bonus of ${app.welcomeBonusAmount} is processing. Please allow up to a few weeks for completion.</span>
        )}

      {showWelcomeBonus(app) &&
        !app.welcomeBonusUrl &&
        app.welcomeBonusStatus !== 'Pending' &&
        app.welcomeBonusStatus !== 'W-9' && (
          <span>
            {' '}
            Welcome Bonus of ${app.welcomeBonusAmount} is {app.welcomeBonusStatus}
          </span>
        )}
    </LoanDescription>

    <LoanBody>
      {!!app.amount && (
        <LoanSummary>
          <LoanAmount data-qa={`loan-amount-${app.type}`}>
            {/* Convert amount to currency via custom format helper method */}
            {FORMAT_CURRENCY(app.amount)} <span>{loanAmountTitle(app)}</span>
          </LoanAmount>
        </LoanSummary>
      )}

      <LoanAction>
        <div>
          <a data-qa="accounts-notInServicingContinue" href={app.continueUrl}>
            <ServicingButton data-qa="accounts-notInServicingContinue-button" flatSide={app.docs && app.docs.length > 0} small>
              {generateContinueText(app)}
            </ServicingButton>
          </a>
          {app.docs &&
            app.docs.length > 0 && (
              <Fragment>
                <ServicingDropdown
                  small
                  onClick={() => {
                    toggleDropdown(index);
                  }}
                  data-qa="accounts-notInServicingDropdown"
                >
                  {isOpen ? <Icon size={14} iconType={IconType.CaretUp} /> : <Icon size={14} iconType={IconType.CaretDown} />}
                </ServicingDropdown>
                <DropdownContainer data-qa="accounts-notInServicingContinue-dropdown-container">
                  {/* Dropdown menu */}
                  {isOpen && <ButtonDropdown data-qa="accounts-notInServicingContinue-button-dropdown" app={app} />}
                </DropdownContainer>
              </Fragment>
            )}
        </div>
      </LoanAction>
    </LoanBody>
  </Fragment>
);

/* eslint react/no-typos: 0 */
NotInServicing.propTypes = {
  app: ApplicationPropType.isRequired,
  toggleDropdown: PropTypes.func.isRequired,
  isOpen: PropTypes.bool.isRequired,
  index: PropTypes.number.isRequired,
};

NotInServicing.defaultProps = {};

export default NotInServicing;



// WEBPACK FOOTER //
// ./src/components/accounts/not-in-servicing.js