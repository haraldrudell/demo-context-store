import styled from 'styled-components';
import breakpoint from 'scuid-x/styles/breakpoint';
import * as color from 'scuid-x/styles/color';

/**
 * Component imports
 */
import NavItem from './nav-item';

export const SubNav = styled.div`
  background-color: ${color.White};
  display: block;
  width: ${props => (props.fullLength ? '100%' : 'auto')};
  min-width: 160px;
  position: absolute;
  top: calc(100% + 12px);
  right: 0;
  left: ${props => (props.fullLength ? '0' : 'inherit')};
  overflow: hidden;
  z-index: 14;
  max-height: inherit;

  @media screen and (max-width: ${breakpoint.small}) {
    width: 100%;
    top: 100%;
  }

  ul {
    display: block;
    list-style: none;
    margin: 0;
    padding: 0;
    flex-direction: column;
    background-color: ${color.White};
    border: 1px solid ${color.Gray};

    li {
      border-bottom: 1px solid ${color.Gray};

      &:last-child {
        border: 0;
      }

      &:hover {
        background-color: ${color.LightGray};
      }

      a {
        display: inline-block;
        width: 100%;
        padding: 8px 14px;
        text-decoration: none;
        color: ${color.DarkGray};
        font-size: 0.875rem;
        cursor: pointer;
        font-weight: normal;

        &:hover {
          text-decoration: none;
        }

        svg {
          margin-right: 5px;
        }
      }
    }
  }
`;

export const StyledNavItem = styled(NavItem)`
  margin-left: 20px;

  @media screen and (max-width: 400px) {
    margin-left: 15px;
  }
`;



// WEBPACK FOOTER //
// ./src/components/header/shared-styles.js