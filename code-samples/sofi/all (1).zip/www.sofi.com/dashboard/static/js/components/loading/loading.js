import React from 'react';
import styled from 'styled-components';
import { Loader } from 'scuid-x';
import PropTypes from 'prop-types';

/**
 * Styled Components
 */
const Container = styled.div`
  min-height: 70vh;
`;

const Loading = ({ error, label, fullPage }) => {
  if (error) {
    window.location.href = '/dashboard/#/marbles';
    return null;
  }
  return (
    <Container>
      <Loader label={label} fullPage={fullPage} />
    </Container>
  );
};

Loading.propTypes = {
  error: PropTypes.bool,
  label: PropTypes.string,
  fullPage: PropTypes.bool,
};

Loading.defaultProps = {
  error: false,
  label: 'Loading, please wait',
  fullPage: true,
};

export default Loading;



// WEBPACK FOOTER //
// ./src/components/loading/loading.js