import React from 'react';
import { Translate } from 'react-redux-i18n';
import PropTypes from 'prop-types';

/**
 * Styled components
 */
import { AlertContent, AlertNotification } from './shared-styles';

const WaitForCosigner = ({ clearAlert }) => (
  <AlertNotification warning dismissible onDismiss={() => clearAlert()}>
    <AlertContent>
      <Translate value="waitForCosigner" />
    </AlertContent>
  </AlertNotification>
);

/* eslint react/no-typos: 0 */
WaitForCosigner.propTypes = {
  clearAlert: PropTypes.func.isRequired,
};

export default WaitForCosigner;



// WEBPACK FOOTER //
// ./src/components/alerts/wait-for-cosigner.js