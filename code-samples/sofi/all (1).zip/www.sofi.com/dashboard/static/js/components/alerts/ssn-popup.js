import React from 'react';
import PropTypes from 'prop-types';
import { Translate } from 'react-redux-i18n';

/**
 * Styled components
 */
import { AlertContent, AlertNotification } from './shared-styles';

const SsnPopup = ({ ssnPopupMessage, setAlertDismissableSession }) => (
  <AlertNotification warning dismissible onDismiss={() => setAlertDismissableSession('ssn.popup')}>
    <AlertContent>
      <Translate value={ssnPopupMessage} />
    </AlertContent>
  </AlertNotification>
);

SsnPopup.propTypes = {
  ssnPopupMessage: PropTypes.string.isRequired,
  setAlertDismissableSession: PropTypes.func.isRequired,
};

export default SsnPopup;



// WEBPACK FOOTER //
// ./src/components/alerts/ssn-popup.js