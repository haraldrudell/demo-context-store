import React, { Fragment } from 'react';
import PropTypes from 'prop-types';
import { SubheadFour } from 'scuid-x';

/**
 * Utilities/functions imports
 */
import { FORMAT_CURRENCY } from '../../utilities/currency-format-helpers';

/**
 * Styled Components
 */
import { LoanBody, LoanSummary, LoanAmount, LoanAction, LoanButton, LoanDescription } from './shared-styles';

const Ecp = ({ ecp }) => (
  <Fragment>
    <SubheadFour>
      {ecp.servicing.servicerPlan} {ecp.servicing.servicerName}
    </SubheadFour>
    <LoanDescription>{ecp.servicing.statusDesc}</LoanDescription>
    <LoanBody>
      <LoanSummary>
        {!!ecp.servicing.monthlyContrib && (
          <LoanAmount>
            {/* Convert amount to currency via custom format helper method */}
            {FORMAT_CURRENCY(ecp.servicing.monthlyContrib)}
            <span>Monthly contribution</span>
          </LoanAmount>
        )}
        {!!ecp.servicing.yearlyContrib && (
          <LoanAmount>
            {/* Convert amount to currency via custom format helper method */}
            {FORMAT_CURRENCY(ecp.servicing.yearlyContrib)}
            <span>Yearly contribution</span>
          </LoanAmount>
        )}
        {!ecp.servicing.monthlyContrib &&
          !ecp.servicing.yearlyContrib && <LoanAmount>{ecp.servicing.status}...</LoanAmount>}
      </LoanSummary>

      {!!ecp.servicing.servicingUrl && (
        <LoanAction>
          <a data-qa="accounts-ecpContinue" href={ecp.servicing.servicingUrl}>
            <LoanButton data-qa="accounts-ecpContinue-button" small>Continue</LoanButton>
          </a>
        </LoanAction>
      )}

      {!ecp.servicing.servicingUrl && ecp.servicing.contribDetailsUrl && (
        <LoanAction>
          <a data-qa="accounts-ecpViewDetails" href={ecp.servicing.contribDetailsUrl}>
            <LoanButton data-qa="accounts-ecpViewDetails-button" small>View Details</LoanButton>
          </a>
        </LoanAction>
      )}
    </LoanBody>
  </Fragment>
);

Ecp.propTypes = {
  ecp: PropTypes.object.isRequired, // eslint-disable-line
};

export default Ecp;



// WEBPACK FOOTER //
// ./src/components/accounts/ecp.js