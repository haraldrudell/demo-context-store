const emailString = (url, welcomeBonus) =>
  `mailto:?Subject=You%20should%20check%20out%20SoFi&Body=I%20recommend%20SoFi%20to%20refinance%20student%20loans%20and%20get%20low%20rate%20personal%20loans.%20Use%20my%20link%20to%20grab%20an%20extra%20${encodeURI(welcomeBonus, // eslint-disable-line
  )}%20bonus%20after%20your%20loan%20funds:%20${encodeURI(url)}`; // eslint-disable-line

const facebookString = url => `http://www.facebook.com/sharer.php?u=${encodeURI(url)}`;

const twitterString = (url, welcomeBonus) =>
  `https://twitter.com/intent/tweet?text=@SoFi%20and%20I%20want%20to%20give%20you%20${encodeURIComponent(welcomeBonus,
  )}.%20Just%20use%20my%20link%20to%20refinance%20student%20loans%20or%20get%20a%20personal%20loan:%20${encodeURI(url)}`; // eslint-disable-line

const formatBonus = bonus => `$${bonus.toFixed()}`;

export const formatUrl = (url) => {
  let newUrl = url;
  if (newUrl !== null) {
    const [, one] = newUrl.split('/share');
    newUrl = `sofi.com/share${one}`;
  }
  return newUrl;
};

export const emailHref = (url, referral) => {
  if (referral && referral.campaign && referral.campaign.welcomeBonus) {
    return emailString(formatUrl(url), formatBonus(referral.campaign.welcomeBonus));
  }
  return '';
};

export const facebookHref = url => facebookString(formatUrl(url));

export const twitterHref = (url, referral) => {
  if (referral && referral.campaign && referral.campaign.welcomeBonus) {
    return twitterString(formatUrl(url), formatBonus(referral.campaign.welcomeBonus));
  }
  return '';
};

export const findHighestCampaigns = (summary) => {
  if (!summary.referralProducts) {
    return summary;
  }

  const products = summary.referralProducts;

  const types = [];
  const bestProducts = [];
  for (let i = 0; i < products.length; i += 1) {
    if (types.indexOf(products[i].campaign.target) < 0) {
      types.push(products[i].campaign.target);
    }
  }

  for (let i = 0; i < types.length; i += 1) {
    let product = null;
    for (let j = 0; j < products.length; j += 1) {
      if (products[j].campaign.target === types[i]) {
        if (product == null) {
          product = products[j];
        } else if (product.campaign.affiliateFee < products[j].campaign.affiliateFee) {
          product = products[j];
        } else if (product.campaign.affiliateFee === products[j].campaign.affiliateFee) {
          // TODO: find if products[j].campaign.affiliateFee is a date type
          const c1 = new Date(product.campaign.createdDate);
          const c2 = new Date(products[j].campaign.affiliateFee);
          if (c2.getTime() < c1.getTime()) {
            product = products[j];
          }
        }
      }
    }
    bestProducts.push(product);
  }
  summary.referralProducts = bestProducts; // eslint-disable-line
  return summary;
};



// WEBPACK FOOTER //
// ./src/components/accounts/affiliate/utilities.js