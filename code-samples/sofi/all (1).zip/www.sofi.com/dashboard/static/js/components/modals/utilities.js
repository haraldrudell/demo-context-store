import { I18n } from 'react-redux-i18n';

export const setupContacts = (customer) => {
  const phoneKey = customer.corporateEmployer === 'apple' ? 'applePhone' : 'sofiCustomerServicePhone';
  const emailKey = customer.corporateEmployer === 'apple' ? 'appleEmail' : 'sofiCustomerServiceEmail';
  return {
    contactPhone: I18n.t(phoneKey),
    contactEmail: I18n.t(emailKey),
  };
};



// WEBPACK FOOTER //
// ./src/components/modals/utilities.js