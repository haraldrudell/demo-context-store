import React, { Fragment } from 'react';
import PropTypes from 'prop-types';
import styled from 'styled-components';
import { CSSTransitionGroup } from 'react-transition-group';

const Container = styled.div`
  ${({ relative }) => relative && 'position: relative;'};

  .drop-enter {
    max-height: 0px;
  }

  .drop-enter.drop-enter-active {
    max-height: 800px;
    transition: max-height 0.4s ease-in-out;
  }

  .drop-leave {
    max-height: 800px;
  }

  .drop-leave.drop-leave-active {
    max-height: 0px;
    transition: max-height 0.4s ease-in-out;
  }
`;

const NavTransition = ({
  children, isOpen, relative, ...rest
}) => (
  <Container relative={relative} {...rest}>
    <CSSTransitionGroup transitionEnterTimeout={400} transitionLeaveTimeout={400} transitionName="drop">
      {isOpen && <Fragment key="navItem">{children}</Fragment>}
    </CSSTransitionGroup>
  </Container>
);

NavTransition.propTypes = {
  children: PropTypes.node.isRequired,
  isOpen: PropTypes.bool.isRequired,
  relative: PropTypes.bool,
};

NavTransition.defaultProps = {
  relative: false,
};

export default NavTransition;



// WEBPACK FOOTER //
// ./src/components/header/nav-transition.js