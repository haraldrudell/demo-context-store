/* eslint-disable max-len */

import React from 'react';
import styled from 'styled-components';
import PropTypes from 'prop-types';

const NotificationIcon = styled.div`
  width: 28px;
  height: 28px;
  position: relative;
  cursor: pointer;

  // unread notifications dot
  ${({ hasNewNotification }) =>
    hasNewNotification &&
    `
  &:after {
    @include scale(0);
    @include transition(transform 0.3s ease-out);

    right: -1px;
    top: 1px;
    content: ' ';
    display: block;
    height: 10px;
    width: 10px;
    border-radius: 50%;
    border: 2px solid #fff;
    position: absolute;
    pointer-events: none;
    background: #fc4c4c;
  }
  `};

  .notification-empty,
  .notification-filled {
    @include transition(opacity 0.3s ease-out, fill 0.3s ease-out, stroke 0.3s ease-out);
    fill: #0d3a54;
    stroke: #0d3a54;
    position: absolute;
    top: 0;
    left: 0;
  }

  .notification-empty {
    ${({ hasNewNotification }) => (hasNewNotification ? 'opacity: 0;' : 'opacity: 1;')};
  }
  .notification-filled {
    ${({ hasNewNotification }) => (hasNewNotification ? 'opacity: 1;' : 'opacity: 0;')};
  }

  &:hover {
    .notification-empty,
    .notification-filled {
      fill: #0d648c;
      stroke: #0d648c;
    }
  }
`;

const Icon = ({ hasNewNotification }) => (
  <NotificationIcon hasNewNotification={hasNewNotification}>
    <svg className="notification-empty" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
      <g stroke="none" fillRule="nonzero">
        <path d="M17.01 9.866c-.166-2.188-1.023-4.084-2.414-5.02-1.672-1.125-3.679-1.129-5.292-.008-1.346.936-2.197 2.86-2.372 5.033-.185 2.298-.725 4.285-1.58 6.285-.296.691-1.215 2.586-1.332 2.876-.133.333.298.968.728.968h14.523c.42 0 .84-.629.708-1.021-.15-.447-1.26-2.868-1.373-3.134-.904-2.113-1.444-3.982-1.595-5.98zm.998-.076c.3 3.962 2.34 7.148 2.919 8.87.328.977-.486 2.34-1.656 2.34H4.748c-1.17 0-2.04-1.38-1.656-2.34.646-1.612 2.48-4.36 2.843-8.87.17-2.104.992-4.517 2.798-5.773 1.965-1.365 4.42-1.347 6.421 0 1.86 1.25 2.69 3.635 2.854 5.773z" />
        <path d="M9.27 21.02a108.428 108.428 0 0 1-1.065-.01A2.79 2.79 0 0 1 8 20c.01.008.4.014 1.001.018.017.38.149.718.376 1.003H9.27zm5.513 0a100.61 100.61 0 0 0 1.042-.01c.113-.3.175-.635.175-1.01.01.008-.383.014-1 .019a1.67 1.67 0 0 1-.326 1.002h.109zm-2.747.007c-.985 0-1.934-.002-2.66-.006.491.614 1.427.979 2.624.979 1.265 0 2.208-.352 2.674-.98-.714.005-1.656.007-2.638.007zM12 23c-2 0-3.953-.964-4-3 .037.028 4.957.034 7.062.018-.012.47.043.52.333.778l.604-.795C16 22.131 14 23 12 23zM10.626 3.278c0-.682.618-1.252 1.401-1.252s1.402.57 1.402 1.252a.5.5 0 1 0 1 0c0-1.253-1.084-2.252-2.402-2.252s-2.4.998-2.4 2.252a.5.5 0 1 0 1 0z" />
      </g>
    </svg>
    <svg className="notification-filled" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
      <defs>
        <path
          id="a"
          d="M15.008 8.79c-.163-2.138-.995-4.523-2.854-5.773-2-1.347-4.456-1.365-6.42 0-1.807 1.256-2.63 3.67-2.799 5.773C2.572 13.3.738 16.048.092 17.66-.292 18.62.578 20 1.748 20h14.523c1.17 0 1.984-1.363 1.656-2.34-.578-1.722-2.62-4.908-2.92-8.87z"
        />
        <path id="b" d="M13 19c0 2.131-2 3-4 3s-3.953-.964-4-3c.047.036 8.047.036 8 0z" />
      </defs>
      <g fillRule="evenodd">
        <g transform="translate(3 1)">
          <use xlinkHref="#a" />
          <path d="M14.51 8.828c-.178-2.327-1.098-4.363-2.635-5.396-1.841-1.24-4.072-1.244-5.856-.004-1.488 1.034-2.4 3.095-2.586 5.402-.18 2.24-.706 4.176-1.541 6.13-.288.674-1.211 2.576-1.336 2.886-.265.662.409 1.654 1.192 1.654h14.523c.771 0 1.42-.972 1.182-1.68-.16-.477-1.284-2.93-1.388-3.171-.883-2.067-1.41-3.887-1.556-5.821z" />
        </g>
        <g transform="translate(3 1)">
          <use xlinkHref="#b" />
          <path d="M5.571 19.515a2.322 2.322 0 0 1-.071-.527L5 19l-.303.398c.286.116.286.116.298.104l.087.004a16.944 16.944 0 0 0 .49.009zm6.875 0a51.204 51.204 0 0 0 .49-.009l.084-.004.062-.008c.031-.004.031-.004.126-.039.32-.204.32-.204.095-.853l-.803-.61V19c0 .18-.018.352-.054.515zm0 0C12.17 20.783 10.847 21.5 9 21.5c-1.773 0-3.11-.75-3.429-1.985l.703.005a493.548 493.548 0 0 0 6.172-.005zM5.18 18.509l.123.093c-.129-.098.157-.085-.123-.093zm0 0z" />
        </g>
        <path strokeLinecap="round" strokeLinejoin="round" d="M10.126 3.278c0-.968.85-1.752 1.901-1.752 1.05 0 1.902.784 1.902 1.752" />
      </g>
    </svg>
  </NotificationIcon>
);

Icon.propTypes = {
  hasNewNotification: PropTypes.bool.isRequired,
};

export default Icon;



// WEBPACK FOOTER //
// ./src/components/header/notification/icon.js