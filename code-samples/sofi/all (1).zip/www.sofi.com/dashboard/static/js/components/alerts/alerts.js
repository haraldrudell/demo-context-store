import React, { Fragment } from 'react';
import PropTypes from 'prop-types';

/**
 * PropTypes imports
 */
import { CustomerPropTypes } from '../../constants/prop-types/customer-prop-types';
import { ReferralSummaryPropTypes } from '../../constants/prop-types/referral-prop-types';
import { NpsSurveyPropTypes } from '../../constants/prop-types/survey-prop-types';
import { W9ReferralInfoPropTypes } from '../../constants/prop-types/w9-referral-info-prop-types';
import { UppSummaryPropTypes } from '../../constants/prop-types/upp-summary-prop-types';
import { WaitForCosignerErrorPropTypes } from '../../constants/prop-types/wait-for-cosign-error-prop-types';
import { TrackingBannerPropTypes } from '../../constants/prop-types/tracking-banner-prop-types';

/**
 * Component imports
 */
import NpsSurvey from './nps-survey';
import StateIneligible from './state-ineligible';
import W9Claim from './w9-claim';
import WealthAdvisorAd from './wealth-advisor-ad';
import AffiliateMembership from './affiliate-membership';
import AppleEmployer from './apple-employer';
import UnemploymentProtection from './unemployment-protection';
import SsnPopup from './ssn-popup';
import HasInfo from './has-info';
import HasErrors from './has-errors';
import GlobalError from './global-error';
import WaitForCosigner from './wait-for-cosigner';
import WelcomeKit from './welcome-kit';

/**
 * Styled components
 */

const Alerts = ({
  customer,
  referralSummary,
  npsSurvey,
  toggleOpen,
  uppSummary,
  w9ReferralInfo,
  isStateIneligible,
  hasInfo,
  hasErrors,
  ssnPopupMessage,
  showUppAlert,
  globalErrors,
  setAlertDismissableSession,
  getAlertSessionKey,
  waitForCosignError,
  clearWaitForCosigner,
  trackingBanner,
}) =>
  (
    <Fragment>
      {trackingBanner && trackingBanner.some(val => val.name === 'WELCOME_KIT') && <WelcomeKit />}

      {!getAlertSessionKey('nps.survey') &&
        npsSurvey &&
        npsSurvey.needsSurvey && <NpsSurvey toggleOpen={toggleOpen} setAlertDismissableSession={setAlertDismissableSession} />}

      {!getAlertSessionKey('wealth.advisor.ad') && <WealthAdvisorAd setAlertDismissableSession={setAlertDismissableSession} />}

      {!getAlertSessionKey('state.ineligible') &&
        isStateIneligible && <StateIneligible setAlertDismissableSession={setAlertDismissableSession} />}

      {!getAlertSessionKey('wait.for.cosigner') &&
        waitForCosignError.showMessage && <WaitForCosigner clearAlert={clearWaitForCosigner} />}

      {!getAlertSessionKey('w9.referral.info') &&
        w9ReferralInfo &&
        (w9ReferralInfo.w9Status === 'UNSIGNED' || w9ReferralInfo.w9Status === 'TAXABLE') && (
          <W9Claim referralSummary={referralSummary} setAlertDismissableSession={setAlertDismissableSession} />
        )}

      {!getAlertSessionKey('upp.summary') &&
        uppSummary &&
        showUppAlert && <UnemploymentProtection setAlertDismissableSession={setAlertDismissableSession} />}

      {!getAlertSessionKey('affiliate.membership.jetblue') &&
        trackingBanner &&
        trackingBanner.some(val => val.name === 'JETBLUE') && (
          <AffiliateMembership affiliateMembership={trackingBanner.find(val => val.name === 'JETBLUE')} setAlertDismissableSession={setAlertDismissableSession} />
        )}

      {!getAlertSessionKey('affiliate.membership.alaska') &&
        trackingBanner &&
        trackingBanner.some(val => val.name === 'ALASKA_AIRLINES') && (
          <AffiliateMembership affiliateMembership={trackingBanner.find(val => val.name === 'ALASKA_AIRLINES')} setAlertDismissableSession={setAlertDismissableSession} />
        )}

      {!getAlertSessionKey('apple.employer') &&
        customer.corporateEmployer === 'apple' && <AppleEmployer setAlertDismissableSession={setAlertDismissableSession} />}

      {!getAlertSessionKey('has.info') &&
        hasInfo() && <HasInfo hasInfo={hasInfo} setAlertDismissableSession={setAlertDismissableSession} />}

      {!getAlertSessionKey('has.errors') &&
        hasErrors() &&
        !isStateIneligible && <HasErrors hasErrors={hasErrors} setAlertDismissableSession={setAlertDismissableSession} />}

      {Object.entries(globalErrors).map(([errorCode, error]) =>
          !getAlertSessionKey(errorCode) && (
            <GlobalError
              key={errorCode}
              globalError={error}
              sessionKeyName={errorCode}
              setAlertDismissableSession={setAlertDismissableSession}
            />
          ))}

      {!getAlertSessionKey('ssn.popup') && !!ssnPopupMessage && <SsnPopup ssnPopupMessage={ssnPopupMessage} />}
    </Fragment>
  );

/* eslint react/no-typos: 0 */
Alerts.propTypes = {
  customer: CustomerPropTypes.isRequired,
  referralSummary: ReferralSummaryPropTypes.isRequired,
  npsSurvey: NpsSurveyPropTypes.isRequired,
  toggleOpen: PropTypes.func.isRequired,
  isStateIneligible: PropTypes.bool.isRequired,
  hasInfo: PropTypes.func.isRequired,
  hasErrors: PropTypes.func.isRequired,
  w9ReferralInfo: W9ReferralInfoPropTypes.isRequired,
  uppSummary: UppSummaryPropTypes.isRequired,
  ssnPopupMessage: PropTypes.string,
  showUppAlert: PropTypes.bool.isRequired,
  globalErrors: PropTypes.objectOf(PropTypes.shape({
    message: PropTypes.string,
    code: PropTypes.string,
  })).isRequired,
  setAlertDismissableSession: PropTypes.func.isRequired,
  getAlertSessionKey: PropTypes.func.isRequired,
  waitForCosignError: WaitForCosignerErrorPropTypes.isRequired,
  clearWaitForCosigner: PropTypes.func.isRequired,
  trackingBanner: TrackingBannerPropTypes.isRequired,
};

Alerts.defaultProps = {
  ssnPopupMessage: null,
};

export default Alerts;



// WEBPACK FOOTER //
// ./src/components/alerts/alerts.js