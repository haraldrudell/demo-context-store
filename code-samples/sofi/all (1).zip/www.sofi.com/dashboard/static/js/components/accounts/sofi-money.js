import React, { Fragment } from 'react';
import { SubheadFour } from 'scuid-x';

/**
 * PropTypes imports
 */
import { BankingPropTypes } from '../../constants/prop-types/banking-prop-types';

/**
 * Utilities/function imports
 */
import { FORMAT_CURRENCY } from '../../utilities/currency-format-helpers';

/**
 * Styled Components
 */
import { LoanBody, LoanSummary, LoanAction, LoanAmount, LoanButton } from './shared-styles';

const SofiMoney = ({ banking }) => {
  const accountNumber = banking.accountNumber || '';

  // We are not using balance currently
  // Remove the eslint-disable once/if we use it in the future
  // eslint-disable-next-line no-unused-vars
  const balance = banking.balance || '0';

  return (
    <Fragment>
      <SubheadFour>SoFi Money (#{accountNumber.slice(-4)})</SubheadFour>
      <LoanBody>
        <LoanSummary>
          <LoanAmount>
            {/* Convert amount to currency via custom format helper method */}
            {FORMAT_CURRENCY(banking.available)}
            <span>Available balance</span>
          </LoanAmount>
        </LoanSummary>

        <LoanAction>
          <a data-qa="accounts-money-redirect-link" href={banking.redirectUrl}>
            <LoanButton data-qa="accounts-money-redirect-button" small>View account</LoanButton>
          </a>
        </LoanAction>
      </LoanBody>
    </Fragment>
  );
};

/* eslint react/no-typos: 0 */
SofiMoney.propTypes = {
  banking: BankingPropTypes.isRequired,
};

export default SofiMoney;



// WEBPACK FOOTER //
// ./src/components/accounts/sofi-money.js