import React, { Fragment } from 'react';
import { SubheadFour } from 'scuid-x';

/**
 * PropTypes imports
 */
import { ApplicationPropType } from '../../constants/prop-types/application-prop-types';

/**
 * Utilities/function imports
 */
import { generateForbearanceStatus } from './utilities';

/**
 * Styled Components
 */
import { LoanBody, LoanAction, LoanButton, LoanDescription } from './shared-styles';

const Forbearance = ({ app }) => (
  <Fragment>
    <SubheadFour>
      {app.productDesc} (#{app.servicing.accountId})
    </SubheadFour>
    <LoanDescription>{generateForbearanceStatus(app)}</LoanDescription>
    <LoanBody>
      <LoanAction>
        <a data-qa="accounts-forbearanceDetails" href={`${app.servicing.servicingUrl}/#/${app.servicing.loanId}`}>
          <LoanButton data-qa="accounts-forbearanceDetails-button" small>View details</LoanButton>
        </a>
      </LoanAction>
    </LoanBody>
  </Fragment>
);

/* eslint react/no-typos: 0 */
Forbearance.propTypes = {
  app: ApplicationPropType.isRequired,
};

Forbearance.defaultProps = {};

export default Forbearance;



// WEBPACK FOOTER //
// ./src/components/accounts/forbearance.js