import React from 'react';
import PropTypes from 'prop-types';
import { Modal, Button, HyperLink, Paragraph } from 'scuid-x';

const redirect = (toggleOpen) => {
  const mohela = window.open('https://sofi.mohela.com/');
  mohela.opener = null; // prevent phishing attempts
  toggleOpen();
};

const MohelaModal = ({ open, toggleOpen }) => (
  <Modal isOpen={open} onDismiss={toggleOpen} title="You are about to leave SoFi" minWidth={window.innerWidth >= 768 ? 650 : 0}>
    <Modal.Body>
      <Paragraph>
        To manage your Student Loan ReFi, we&#39;re directing you to MOHELA, SoFi&#39;s third-party loan servicer for student loans.
      </Paragraph>
      <Paragraph>
        Make payments and get account details at{' '}
        <HyperLink data-qa="mohela-goToMohela" href="https://sofi.mohela.com/" target="_blank" rel="noopener noreferrer">
          sofi.mohela.com
        </HyperLink>{' '}
        or by calling <HyperLink data-qa="mohela-telephone-number" href="tel:8772927470">(877) 292-7470</HyperLink>.
        While your loan will be serviced by MOHELA, you will
        still be a SoFi member and be able to take advantage of our unique member benefits.
      </Paragraph>
    </Modal.Body>
    <Modal.Footer>
      <Button
        data-qa="mohela-backToSoFi"
        data-mjs="dashboard-slr-popup-close"
        small
        secondary
        onClick={() => {
          toggleOpen();
        }}
      >
        Back to SoFi
      </Button>
      <Button
        data-qa="mohela-continueToMohela"
        data-mjs="dashboard-slr-popup-continue"
        small
        onClick={() => {
          redirect(toggleOpen);
        }}
      >
        Continue to MOHELA
      </Button>
    </Modal.Footer>
  </Modal>
);

MohelaModal.propTypes = {
  open: PropTypes.bool.isRequired,
  toggleOpen: PropTypes.func.isRequired,
};

export default MohelaModal;



// WEBPACK FOOTER //
// ./src/components/accounts/mohela-modal.js