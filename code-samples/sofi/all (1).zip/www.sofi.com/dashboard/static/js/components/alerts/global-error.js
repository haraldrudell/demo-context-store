import React from 'react';
import PropTypes from 'prop-types';

/**
 * Styled components
 */
import { AlertContent, AlertNotification } from './shared-styles';

const GlobalError = ({ globalError: { message }, setAlertDismissableSession, sessionKeyName }) => (
  <AlertNotification warning dismissible onDismiss={() => setAlertDismissableSession(sessionKeyName)}>
    <AlertContent>
      {message}
    </AlertContent>
  </AlertNotification>
);

GlobalError.propTypes = {
  globalError: PropTypes.object.isRequired, // eslint-disable-line
  setAlertDismissableSession: PropTypes.func.isRequired,
  sessionKeyName: PropTypes.string.isRequired,
};

export default GlobalError;



// WEBPACK FOOTER //
// ./src/components/alerts/global-error.js