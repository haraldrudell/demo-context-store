import en from './en';
import es from './es';
import fr from './fr';

export default {
  en,
  es,
  fr,
};



// WEBPACK FOOTER //
// ./src/translations/index.js