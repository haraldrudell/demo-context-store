export default {
  company: 'Social Finance, Inc',
  loadedLabel: 'Chargé',
  yes: 'Oui',
  no: 'Non',
};



// WEBPACK FOOTER //
// ./src/translations/fr.js