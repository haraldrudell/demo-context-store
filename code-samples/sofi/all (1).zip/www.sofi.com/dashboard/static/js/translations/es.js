export default {
  company: 'Social Finance, Inc',
  loadedLabel: 'Cargado',
  yes: 'Sí',
  no: 'No',
};



// WEBPACK FOOTER //
// ./src/translations/es.js