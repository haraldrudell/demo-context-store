import 'core-js/es6/symbol';

import React from 'react';
import ReactDOM from 'react-dom';
import { Provider } from 'react-redux';
import App from './containers/app';
import { unregister } from './registerServiceWorker';
import configure from './store';

const store = configure(undefined);

ReactDOM.render(
  <Provider store={store}>
    <App />
  </Provider>,
  document.getElementById('root'),
);

/**
 * Unregister service-worker for now
 * It is OPT-in in the next version of CRA
 * https://github.com/facebook/create-react-app/pull/3817
 */
unregister();



// WEBPACK FOOTER //
// ./src/index.js