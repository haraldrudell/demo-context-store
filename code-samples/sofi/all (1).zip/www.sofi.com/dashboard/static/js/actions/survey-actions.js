import { performGet, performPost } from '../utilities/api-action-helpers';
import { API_URL } from '../constants';
import * as c from '../constants/survey-constants';

export const getNpsSurvey = () => (dispatch) => {
  performGet(dispatch, `${API_URL}/surveys/nps`, {}, c.GET_NPS_SURVEY);
};

export const postNpsSurvey = (data, setErrors) => (dispatch) => {
  performPost(dispatch, `${API_URL}/surveys/nps`, {}, data, c.POST_NPS_SURVEY, setErrors);
};

export const getWhereHeardSurvey = () => (dispatch) => {
  performGet(dispatch, `${API_URL}/surveys/whereheard`, {}, c.GET_WHERE_HEARD_SURVEY);
};

export const postWhereHeardSurvey = (data, setErrors) => (dispatch) => {
  performPost(dispatch, `${API_URL}/surveys/whereheard`, {}, data, c.POST_WHERE_HEARD_SURVEY, setErrors);
};



// WEBPACK FOOTER //
// ./src/actions/survey-actions.js