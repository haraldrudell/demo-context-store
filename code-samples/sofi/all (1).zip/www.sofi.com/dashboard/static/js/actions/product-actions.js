import { performGet } from '../utilities/api-action-helpers';
import { API_URL } from '../constants';
import * as c from '../constants/product-constants';

export const getProducts = () => (dispatch) => {
  performGet(dispatch, `${API_URL}/products`, {}, c.GET_PRODUCTS, true);
};



// WEBPACK FOOTER //
// ./src/actions/product-actions.js