import { performGet } from '../utilities/api-action-helpers';
import { API_URL } from '../constants';
import * as c from '../constants/tracking-banner-constants';

export const getTrackingBanner = () => dispatch =>
  performGet(dispatch, `${API_URL}/tracking-banner`, {}, c.GET_TRACKING_BANNER);



// WEBPACK FOOTER //
// ./src/actions/tracking-banner-actions.js