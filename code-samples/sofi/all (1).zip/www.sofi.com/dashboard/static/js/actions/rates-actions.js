import { API_URL } from '../constants';
import * as c from '../constants/rates-constants';
import { performGet } from '../utilities/api-action-helpers';

export const getRates = () => dispatch => performGet(dispatch, `${API_URL}/rates`, {}, c.GET_RATES);



// WEBPACK FOOTER //
// ./src/actions/rates-actions.js