import { performGet, performPost, performPut } from '../utilities/api-action-helpers';
import { API_URL, REFERRAL_URL, REFERRER_URL } from '../constants';
import * as c from '../constants/referral-constants';

export const getReferralSummary = () => dispatch =>
  performGet(dispatch, `${API_URL}/affiliate/referral/summary`, {}, c.GET_REFERRAL_SUMMARY, true);

export const getReferralConsents = () => (dispatch) => {
  performGet(dispatch, `${API_URL}/affiliate/referral/consents`, {}, c.GET_REFERRAL_CONSENTS);
};

export const updateReferralConsent = (referralConsent, setErrors) => dispatch =>
  performPost(dispatch, `${API_URL}/affiliate/referral/consents`, {}, referralConsent, c.POST_REFERRAL_CONSENTS, setErrors);

export const getReferrer = () => (dispatch) => {
  performGet(dispatch, `${REFERRAL_URL}/referrer`, {}, c.GET_REFERRER);
};

export const postCreateReferrer = createReferrer => (dispatch) => {
  performPost(dispatch, `${REFERRAL_URL}/referrer`, {}, createReferrer, c.POST_CREATE_REFERRER);
};

export const getReferrerProgress = () => (dispatch) => {
  performGet(dispatch, `${REFERRAL_URL}/referrer/progress`, {}, c.GET_REFERRER_PROGRESS);
};

export const getWaterBottleModalStatus = () => (dispatch) => {
  performGet(dispatch, `${REFERRER_URL}/referral-modal/REFERRAL`, {}, c.GET_WATER_BOTTLE_MODAL_STATUS);
};

export const getBackpackModalStatus = () => (dispatch) => {
  performGet(dispatch, `${REFERRER_URL}/referral-modal/APP_CREATED`, {}, c.GET_BACKPACK_MODAL_STATUS);
};

export const updateRewardModalVisibility = (type, setErrors) => (dispatch) => {
  performPut(dispatch, `${REFERRER_URL}/referral-modal/${type}`, {}, c.UPDATE_REWARD_MODAL_VISIBILITY, setErrors);
};

export const getContacts = () => async (dispatch) => {
  performGet(dispatch, `${REFERRAL_URL}/contacts/google`, {}, c.GET_REFERRAL_CONTACTS);
};

// eslint-disable-next-line arrow-body-style
export const postReferralContacts = postBody => (dispatch) => {
  return performPost(dispatch, `${REFERRAL_URL}/referrer/referrals`, {}, postBody, c.POST_REFERRAL_CONTACTS);
};

export const getReferralBankAccount = () => (dispatch) => {
  performGet(dispatch, `${API_URL}/affiliate/referral/ach`, {}, c.GET_BANK_ACCOUNT);
};

export const updateReferralBankAccount = (accountInfo, setErrors) => (dispatch) => {
  performPost(dispatch, `${API_URL}/affiliate/referral/ach`, {}, accountInfo, c.UPDATE_BANK_ACCOUNT, setErrors);
};

const REFERRAL_W9_INFO = `${API_URL}/affiliate/referral/w9/info`;

export const getReferralW9 = () => (dispatch) => {
  performGet(dispatch, REFERRAL_W9_INFO, {}, c.GET_W9_INFO, true);
};

export const updateReferralW9 = setErrors => (dispatch) => {
  performPost(dispatch, REFERRAL_W9_INFO, {}, null, c.POST_W9_INFO, setErrors);
};

export const getReferrerals = () => (dispatch) => {
  performGet(dispatch, `${REFERRAL_URL}/referrer/referrals`, {}, c.GET_REFERRALS);
};



// WEBPACK FOOTER //
// ./src/actions/referral-actions.js