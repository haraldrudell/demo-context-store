import { performGet } from '../utilities/api-action-helpers';
import { WEALTH_URL } from '../constants';
import * as c from '../constants/wealth-constants';

/**
 * Important: This action uses the wealth service instead of dashboard-service
 * So url starts with /wealth
 */
export const getWealth = () => (dispatch) => {
  performGet(dispatch, `${WEALTH_URL}/backend/v1/json/dashboard/summary`, {}, c.GET_WEALTH);
};



// WEBPACK FOOTER //
// ./src/actions/wealth-actions.js