import { API_URL } from '../constants';
import { performGet } from '../utilities/api-action-helpers';
import * as c from '../constants/timeout-constants';

export const getKickdog = () => dispatch => performGet(dispatch, `${API_URL}/hb`, {}, c.TIMEOUT);



// WEBPACK FOOTER //
// ./src/actions/timeout-actions.js