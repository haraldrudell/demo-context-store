import { performGet, performPost } from '../utilities/api-action-helpers';
import { API_URL, DASHBOARD_API_URL } from '../constants';
import * as c from '../constants/application-constants';

/**
 * Get all the customer applications
 */
export const getApplications = () => dispatch => performGet(dispatch, `${API_URL}/applications`, {}, c.GET_APPLICATIONS);

/**
 * Get all the applications currently in servicing
 */
export const getApplicationsServicing = () => (dispatch) => {
  performGet(dispatch, `${API_URL}/applications/servicing`, {}, c.GET_APPLICATIONS_SERVICING);
};

/**
 * Get mortgage (if the customer has been servicing)
 */
export const getMortgageSso = () => (dispatch) => {
  performGet(dispatch, `${API_URL}/applications/mortgage-sso`, {}, c.GET_MORTGAGE_SSO);
};

/**
 * Post application retry with correct SSN
 * @param {Object} appRetry { appId: number, appType: '', coSsnRequired: bool, ssn: '', coSsn: '' }
 * @param {function} setErrors Formik's setErrors function (needed for server validation errors)
 */
export const postApplicationRetry = (appRetry, setErrors) => dispatch =>
  performPost(dispatch, `${API_URL}/applications/retry`, {}, appRetry, c.POST_APPLICATION_RETRY, setErrors);

/**
 * Get all the accounts for a member
 */
export const getDashboardAccounts = () => (dispatch) => {
  performGet(dispatch, `${DASHBOARD_API_URL}/group?key=accountCards`, {}, c.GET_DASHBOARD_ACCOUNTS);
};



// WEBPACK FOOTER //
// ./src/actions/application-actions.js