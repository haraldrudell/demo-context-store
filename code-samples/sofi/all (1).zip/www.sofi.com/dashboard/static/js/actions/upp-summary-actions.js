import { performGet } from '../utilities/api-action-helpers';
import { API_URL } from '../constants';
import * as c from '../constants/upp-summary-constants';

export const getUppSummary = () => (dispatch) => {
  performGet(dispatch, `${API_URL}/upp/upp-summary`, {}, c.GET_UPP_SUMMARY);
};



// WEBPACK FOOTER //
// ./src/actions/upp-summary-actions.js