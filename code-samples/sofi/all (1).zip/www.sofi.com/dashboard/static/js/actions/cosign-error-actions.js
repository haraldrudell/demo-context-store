import { createAction } from 'redux-actions';

import * as c from '../constants/global-error-constants';

export const setWaitCosignerError = () => (dispatch) => {
  dispatch(createAction(c.SET_WAIT_COSIGNER_ERROR)());
};

export const clearWaitCosignerError = () => (dispatch) => {
  dispatch(createAction(`${c.SET_WAIT_COSIGNER_ERROR}:NONE`)());
};



// WEBPACK FOOTER //
// ./src/actions/cosign-error-actions.js