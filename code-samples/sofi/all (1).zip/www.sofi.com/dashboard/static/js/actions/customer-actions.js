import { performGet, performPost } from '../utilities/api-action-helpers';
import { API_URL } from '../constants';
import * as c from '../constants/customer-constants';

/**
 * Get customer info
 */
export const getCustomer = () => dispatch => performGet(dispatch, `${API_URL}/customer`, {}, c.GET_CUSTOMER, true);

/**
 * Get customer consents
 */
export const getConsents = () => (dispatch) => {
  performGet(dispatch, `${API_URL}/customer/consents`, {}, c.GET_CONSENTS, true);
};

/**
 * Get consents tou version (number)
 */
export const getConsentsTou = () => (dispatch) => {
  performGet(dispatch, `${API_URL}/customer/consents/tou`, {}, c.GET_CONSENTS_TOU, true);
};

/**
 * Post customer consent
 * @param {Object} data { consents: true }
 * @param {function} setErrors Formik's setErrors function (needed for server validation errors)
 */
export const postConsents = (data, setErrors) => dispatch =>
  performPost(dispatch, `${API_URL}/customer/consents`, {}, data, c.POST_CONSENTS, setErrors);

/**
 * Post customer's state
 * @param {Object} newState { alpha2: 'UT', name: 'Utah' }
 */
export const postCustomerState = newState => dispatch =>
  performPost(dispatch, `${API_URL}/customer/state`, {}, newState, c.POST_CUSTOMER_STATE);

/**
 * Post customer's cosigner info
 * @param {Object} data { appId: number, cosignerFirstName: '', cosignerLastName: '', cosignerEmail: '' }
 * @param {function} setErrors Formik's setErrors function (needed for server validation errors)
 */
export const postCustomerCosign = (data, setErrors) => dispatch =>
  performPost(dispatch, `${API_URL}/customer/cosign`, {}, data, c.POST_CUSTOMER_COSIGN, setErrors);

/**
 * Post new customer object
 * @param {Object} profile New customer profile Object
 * @param {function} setErrors Formik's setErrors function (needed for server validation errors)
 */
export const postUpdatedCustomer = (profile, setErrors) => dispatch =>
  performPost(dispatch, `${API_URL}/customer`, {}, profile, c.POST_UPDATED_PROFILE, setErrors);

/**
 * Partially update the customer object
 * @param {Object} customer Partially updated customer Object
 * @param {function} setErrors Formik's setErrors function (needed for server validation errors)
 */
export const updateCustomerPartial = (customer, setErrors) => dispatch =>
  performPost(dispatch, `${API_URL}/customer/partial`, {}, customer, c.UPDATE_CUSTOMER_PARTIAL, setErrors);

/**
 * Update customer's shipping address
 * @param {Object} shippingAddress shipping address values
 * @param {function} setErrors Formik's setErrors function (needed for server validation errors)
 */
export const updateCustomerShipping = (shippingAddress, setErrors) => dispatch =>
  performPost(dispatch, `${API_URL}/customer/shipping-address`, {}, shippingAddress, c.UPDATE_CUSTOMER_SHIPPING, setErrors);



// WEBPACK FOOTER //
// ./src/actions/customer-actions.js