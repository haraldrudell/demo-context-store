import { performGet } from '../utilities/api-action-helpers';
import { DASHBOARD_CONTENT_URL } from '../constants';
import * as c from '../constants/marketing-cards-constants';

// TODO update this to piggy back off call that is being made to get account cards. (we can make one call to get all cards)
export const getMarketingCards = () => async (dispatch) => {
  performGet(dispatch, `${DASHBOARD_CONTENT_URL}/group/dashboardCards`, {}, c.GET_MARKETING_CARDS);
};



// WEBPACK FOOTER //
// ./src/actions/marketing-cards-actions.js