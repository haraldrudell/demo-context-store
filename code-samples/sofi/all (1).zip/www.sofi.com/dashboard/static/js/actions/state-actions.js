import { performGet } from '../utilities/api-action-helpers';
import { API_URL } from '../constants';
import * as c from '../constants/states-constants';

export const getStates = () => (dispatch) => {
  performGet(dispatch, `${API_URL}/states`, {}, c.GET_STATES);
};



// WEBPACK FOOTER //
// ./src/actions/state-actions.js