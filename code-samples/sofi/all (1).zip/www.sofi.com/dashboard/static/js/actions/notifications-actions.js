import { createAction } from 'redux-actions';

import { performGet, performPut } from '../utilities/api-action-helpers';
import { API_URL } from '../constants';
import * as c from '../constants/notifications-constants';

/**
 * Holds the global state for notifications
 * @param {Array} data New/Updated Notifications Array of Objects
 */
export const notificationsState = data => (dispatch) => {
  dispatch(createAction(c.UPDATE_NOTIFICATIONS_STATE)(data));
};

/**
 * Returns notifications for that page
 * @param {Number} pageNumber Page number for pagination
 */
export const getNotificationsPage = pageNumber => dispatch =>
  performGet(dispatch, `${API_URL}/notifications?page=${pageNumber}&pageSize=20`, {}, c.GET_NOTIFICATIONS_PAGE);

/**
 * Marks all notifications as 'READ'
 */
export const putMarkAllAsRead = () => dispatch => performPut(dispatch, `${API_URL}/notifications`, {}, null, c.PUT_MARK_ALL_READ);

/**
 * Updates the given notification to its new status
 * @param {String} notificationID Unique notification ID
 * @param {String} status New status for the notification
 */
export const putOneNotificationStatus = (notificationID, status) => dispatch =>
  performPut(dispatch, `${API_URL}/notifications/${notificationID}`, {}, { status }, c.PUT_ONE_NOTIFICATION_STATUS);



// WEBPACK FOOTER //
// ./src/actions/notifications-actions.js