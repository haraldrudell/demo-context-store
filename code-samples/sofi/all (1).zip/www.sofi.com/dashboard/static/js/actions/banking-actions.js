import { performGet } from '../utilities/api-action-helpers';
import { API_URL } from '../constants';
import * as c from '../constants/banking-constants';

export const getBanking = () => (dispatch) => {
  performGet(dispatch, `${API_URL}/banking/summary`, {}, c.GET_BANKING);
};

export const getIsBanking = () => (dispatch) => {
  performGet(dispatch, `${API_URL}/banking/validate-customer`, {}, c.GET_IS_BANKING);
};



// WEBPACK FOOTER //
// ./src/actions/banking-actions.js