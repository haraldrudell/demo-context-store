import { createStore, applyMiddleware, compose } from 'redux';
import thunk from 'redux-thunk';
import { loadTranslations, setLocale, syncTranslationWithStore } from 'react-redux-i18n';
import rootReducer from '../reducers';
import translationsObject from '../translations';

export default function configure(initialState) {
  const create = window.devToolsExtension && process.env.NODE_ENV !== 'production'
    ? window.devToolsExtension()(createStore)
    : createStore;

  const createStoreWithMiddleware = compose(applyMiddleware(thunk)(create));

  const store = createStoreWithMiddleware(rootReducer, initialState);

  if (module.hot) {
    module.hot.accept('../reducers', () => {
      // eslint-disable-next-line global-require, import/no-unresolved
      const nextReducer = require('../reducers');
      store.replaceReducer(nextReducer);
    });
  }

  syncTranslationWithStore(store);
  store.dispatch(loadTranslations(translationsObject));
  store.dispatch(setLocale('en'));

  return store;
}



// WEBPACK FOOTER //
// ./src/store/index.js