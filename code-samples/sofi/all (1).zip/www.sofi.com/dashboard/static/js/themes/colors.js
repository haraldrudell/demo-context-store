const colors = {
  defaultText: '#757575',
  loanAmount: '#262626',
  loanTitle: '#757575',
  attention: '#ee6352',
  policy: {
    text: '#797979',
    link: '#117db0',
    borderBottom: '#e6e7e8',
    footer: '#757575',
    tableHeader: '#262626',
  },
};

export default colors;



// WEBPACK FOOTER //
// ./src/themes/colors.js