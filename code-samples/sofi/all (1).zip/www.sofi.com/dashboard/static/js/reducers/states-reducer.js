import { handleActions } from 'redux-actions';
import * as c from '../constants/states-constants';

const initialState = {
  states: { data: [], loaded: false },
};

export default handleActions(
  {
    [`${c.GET_STATES}:GET_START`](state) {
      return {
        ...state,
      };
    },
    [`${c.GET_STATES}:GET_SUCCESS`](state, { payload }) {
      // Rename states object key/value (add value & label)
      // so they can be used in select dropdown
      const remapStatesForDropDown = payload.map(value => ({ value: value.alpha2, label: value.name }));
      // For Scuid-X DropDown component to work
      remapStatesForDropDown.unshift({});

      return {
        ...state,
        states: { data: remapStatesForDropDown, loaded: true },
      };
    },
  },
  initialState,
);



// WEBPACK FOOTER //
// ./src/reducers/states-reducer.js