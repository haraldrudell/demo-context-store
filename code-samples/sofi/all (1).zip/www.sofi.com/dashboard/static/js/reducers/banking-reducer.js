import { handleActions } from 'redux-actions';
import * as c from '../constants/banking-constants';

const initialState = {
  banking: { data: {}, loaded: false },
  isBanking: { data: {}, loaded: false },
};

export default handleActions(
  {
    [`${c.GET_BANKING}:GET_START`](state) {
      return {
        ...state,
      };
    },
    [`${c.GET_BANKING}:GET_SUCCESS`](state, { payload }) {
      return {
        ...state,
        banking: { data: { ...payload }, loaded: true },
      };
    },
    [`${c.GET_IS_BANKING}:GET_START`](state) {
      return {
        ...state,
      };
    },
    [`${c.GET_IS_BANKING}:GET_SUCCESS`](state, { payload }) {
      return {
        ...state,
        isBanking: { data: payload.bankingCustomer, loaded: true },
      };
    },
  },
  initialState,
);



// WEBPACK FOOTER //
// ./src/reducers/banking-reducer.js