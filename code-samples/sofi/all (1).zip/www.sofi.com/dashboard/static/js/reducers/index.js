import { combineReducers } from 'redux';
import { i18nReducer as i18n } from 'react-redux-i18n';

/**
 * Reducer imports
 */
import marketingCardsReducer from './marketing-cards-reducer';
import customerReducer from './customer-reducer';
import applicationReducer from './application-reducer';
import productReducer from './product-reducer';
import statesReducer from './states-reducer';
import profileReducer from './profile-reducer';
import referralReducer from './referral-reducer';
import wealthReducer from './wealth-reducer';
import bankingReducer from './banking-reducer';
import preferencesReducer from './preferences-reducer';
import surveyReducer from './survey-reducer';
import appleSpouseReducer from './apple-spouse-reducer';
import notificationsReducer from './notifications-reducer';
import uppSummaryReducer from './upp-summary-reducer';
import dpaReducer from './dpa-reducer';
import globalErrorReducer from './global-error-reducer';
import welcomeKitReducer from './welcome-kit-reducer';
import trackingBannerReducer from './tracking-banner-reducer';
import ratesReducer from './rates-reducer';

export default combineReducers({
  i18n,
  marketingCardsReducer,
  customerReducer,
  applicationReducer,
  productReducer,
  statesReducer,
  profileReducer,
  referralReducer,
  wealthReducer,
  bankingReducer,
  preferencesReducer,
  surveyReducer,
  appleSpouseReducer,
  notificationsReducer,
  uppSummaryReducer,
  dpaReducer,
  globalErrorReducer,
  welcomeKitReducer,
  trackingBannerReducer,
  ratesReducer,
});



// WEBPACK FOOTER //
// ./src/reducers/index.js