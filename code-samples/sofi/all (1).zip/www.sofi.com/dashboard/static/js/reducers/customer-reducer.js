import { handleActions } from 'redux-actions';
import * as c from '../constants/customer-constants';

const initialState = {
  customer: { data: {}, loaded: false },
  consents: { data: {}, loaded: false },
  consentsTou: { data: null, loaded: false },
  saveProfileSuccess: false,
};

export default handleActions(
  {
    [`${c.GET_CUSTOMER}:GET_START`](state) {
      return {
        ...state,
      };
    },
    [`${c.GET_CUSTOMER}:GET_SUCCESS`](state, { payload }) {
      return {
        ...state,
        customer: { data: { ...payload }, loaded: true },
      };
    },
    [`${c.GET_CONSENTS}:GET_START`](state) {
      return {
        ...state,
      };
    },
    [`${c.GET_CONSENTS}:GET_SUCCESS`](state, { payload }) {
      return {
        ...state,
        consents: { data: { ...payload }, loaded: true },
      };
    },
    [`${c.GET_CONSENTS_TOU}:GET_START`](state) {
      return {
        ...state,
      };
    },
    [`${c.GET_CONSENTS_TOU}:GET_SUCCESS`](state, { payload }) {
      return {
        ...state,
        consentsTou: { data: payload, loaded: true },
      };
    },
    [`${c.POST_CONSENTS}:POST_START`](state) {
      return {
        ...state,
        postConsentsSuccess: false,
      };
    },
    [`${c.POST_CONSENTS}:POST_SUCCESS`](state, { payload }) {
      return {
        ...state,
        consents: { data: { ...payload }, loaded: true },
        postConsentsSuccess: true,
      };
    },
    [`${c.POST_CUSTOMER_STATE}:POST_START`](state) {
      return {
        ...state,
      };
    },
    [`${c.POST_CUSTOMER_STATE}:POST_SUCCESS`](state, { payload }) {
      /**
       * Successful state POST returns the updated customer object
       */
      return {
        ...state,
        customer: { data: { ...payload }, loaded: true },
      };
    },
    [`${c.POST_CUSTOMER_COSIGN}:POST_START`](state) {
      return {
        ...state,
        cosignerUpdated: false,
      };
    },
    [`${c.POST_CUSTOMER_COSIGN}:POST_SUCCESS`](state) {
      /**
       * Not using the payload back currently. TODO: Figure out what it returns if sucessful
       */
      return {
        ...state,
        cosignerUpdated: true,
      };
    },
    [`${c.POST_UPDATED_PROFILE}:POST_START`](state) {
      return {
        ...state,
        saveProfileSuccess: false,
      };
    },
    [`${c.POST_UPDATED_PROFILE}:POST_SUCCESS`](state, { payload }) {
      return {
        ...state,
        customer: { data: { ...payload }, loaded: true },
        saveProfileSuccess: true,
      };
    },
    [`${c.UPDATE_CUSTOMER_PARTIAL}:POST_START`](state) {
      return {
        ...state,
        partialCustomerSuccess: false,
      };
    },
    [`${c.UPDATE_CUSTOMER_PARTIAL}:POST_SUCCESS`](state, { payload }) {
      return {
        ...state,
        customer: { data: { ...payload }, loaded: true },
        partialCustomerSuccess: true,
      };
    },
    [`${c.UPDATE_CUSTOMER_SHIPPING}:POST_START`](state) {
      return {
        ...state,
        shippingCustomerSuccess: false,
      };
    },
    [`${c.UPDATE_CUSTOMER_SHIPPING}:POST_SUCCESS`](state, { payload }) {
      return {
        ...state,
        customer: { data: { ...payload }, loaded: true },
        shippingCustomerSuccess: true,
      };
    },
  },
  initialState,
);



// WEBPACK FOOTER //
// ./src/reducers/customer-reducer.js