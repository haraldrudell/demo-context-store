import { handleActions } from 'redux-actions';
import * as c from '../constants/upp-summary-constants';

const initialState = {
  uppSummary: { data: [], loaded: false },
};

export default handleActions(
  {
    [`${c.GET_UPP_SUMMARY}:GET_START`](state) {
      return {
        ...state,
      };
    },
    [`${c.GET_UPP_SUMMARY}:GET_SUCCESS`](state, { payload }) {
      return {
        ...state,
        uppSummary: { data: [...payload], loaded: true },
      };
    },
  },
  initialState,
);



// WEBPACK FOOTER //
// ./src/reducers/upp-summary-reducer.js