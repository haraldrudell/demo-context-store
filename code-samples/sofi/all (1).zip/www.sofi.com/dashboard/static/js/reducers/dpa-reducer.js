import { handleActions } from 'redux-actions';
import * as c from '../constants/dpa-constants';

const initialState = {
  dpa: {
    data: {},
    loaded: false,
  },
  dpaPostSuccess: false,
};

export default handleActions(
  {
    [`${c.GET_DPA}:GET_START`](state) {
      return {
        ...state,
      };
    },
    [`${c.GET_DPA}:GET_SUCCESS`](state, { payload }) {
      return {
        ...state,
        dpa: { data: { ...payload }, loaded: true },
      };
    },
    [`${c.POST_DPA}:POST_START`](state) {
      return {
        ...state,
        dpaPostSuccess: false,
      };
    },
    [`${c.POST_DPA}:POST_SUCCESS`](state, { payload }) {
      return {
        ...state,
        dpa: { data: { ...payload }, loaded: true },
        dpaPostSuccess: true,
      };
    },
  },
  initialState,
);



// WEBPACK FOOTER //
// ./src/reducers/dpa-reducer.js