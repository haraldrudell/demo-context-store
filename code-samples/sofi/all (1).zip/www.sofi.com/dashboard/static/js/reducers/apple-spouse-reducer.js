import { handleActions } from 'redux-actions';
import * as c from '../constants/apple-spouse-constants';

const initialState = {
  appleSpouse: { data: {}, loaded: false, errors: false },
};

export default handleActions(
  {
    [`${c.GET_SPOUSE}:GET_START`](state) {
      return {
        ...state,
      };
    },
    [`${c.GET_SPOUSE}:GET_SUCCESS`](state, { payload }) {
      return {
        ...state,
        appleSpouse: { data: { ...payload }, loaded: true },
      };
    },
    [`${c.POST_SPOUSE}:POST_START`](state) {
      return {
        ...state,
      };
    },
    [`${c.POST_SPOUSE}:POST_SUCCESS`](state, { payload }) {
      return {
        ...state,
        appleSpouse: { data: { ...payload }, loaded: true },
      };
    },
  },
  initialState,
);



// WEBPACK FOOTER //
// ./src/reducers/apple-spouse-reducer.js