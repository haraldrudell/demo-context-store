import { handleActions } from 'redux-actions';
import * as c from '../constants/notifications-constants';

const initialState = {
  notifications: {
    data: [],
    loaded: false,
    hasMoreData: true,
    success: false,
  },
  hasNewNotification: false,
  putOneNotificationSuccess: false,
  filteredNotifications: [],
};

export default handleActions(
  {
    [`${c.GET_NOTIFICATIONS_PAGE}:GET_START`](state) {
      // Set notifications request success to false
      return {
        ...state,
        notifications: {
          ...state.notifications,
          success: false,
        },
      };
    },
    [`${c.GET_NOTIFICATIONS_PAGE}:GET_SUCCESS`](state, { payload }) {
      // check if all notifications have loaded
      const hasMoreData = state.notifications.hasMoreData && payload.length !== 0;
      return {
        ...state,
        notifications: {
          hasMoreData,
          data: payload,
          loaded: true,
          success: true,
        },
      };
    },
    [`${c.PUT_MARK_ALL_READ}:PUT_START`](state) {
      return {
        ...state,
        markAllReadSuccess: false,
      };
    },
    [`${c.PUT_MARK_ALL_READ}:PUT_SUCCESS`](state) {
      // PUT returns a 200 if successful
      return {
        ...state,
        markAllReadSuccess: true,
      };
    },
    [`${c.PUT_ONE_NOTIFICATION_STATUS}:PUT_START`](state) {
      return {
        ...state,
        putOneNotificationSuccess: false,
      };
    },
    [`${c.PUT_ONE_NOTIFICATION_STATUS}:PUT_SUCCESS`](state) {
      // PUT returns a 200 if successful
      return {
        ...state,
        putOneNotificationSuccess: true,
      };
    },
    [`${c.UPDATE_NOTIFICATIONS_STATE}`](state, { payload }) {
      let hasNewNotification = false;
      // filter duplicates
      const notificationIds = payload.map(mapObj => mapObj.notificationID);
      // keep ONLY the first occurrences of any given notification, before we update UI
      const filteredNotifications = payload.filter((obj, pos) => {
        if (obj.status === 'NEW') hasNewNotification = true;
        return notificationIds.indexOf(obj.notificationID) === pos;
      });
      return {
        ...state,
        hasNewNotification,
        filteredNotifications,
      };
    },
  },
  initialState,
);



// WEBPACK FOOTER //
// ./src/reducers/notifications-reducer.js