import { handleActions } from 'redux-actions';
import * as c from '../constants/tracking-banner-constants';

const initialState = {
  banners: {
    data: [],
    loaded: false,
  },
};

export default handleActions(
  {
    [`${c.GET_TRACKING_BANNER}:GET_START`](state) {
      return {
        ...state,
      };
    },
    [`${c.GET_TRACKING_BANNER}:GET_SUCCESS`](state, { payload }) {
      return {
        ...state,
        banners: {
          data: payload,
          loaded: true,
        },
      };
    },
  },
  initialState,
);



// WEBPACK FOOTER //
// ./src/reducers/tracking-banner-reducer.js