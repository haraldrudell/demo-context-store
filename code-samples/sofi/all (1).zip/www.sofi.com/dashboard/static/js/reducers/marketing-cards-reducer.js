import { handleActions } from 'redux-actions';
import * as c from '../constants/marketing-cards-constants';

const initialState = {
  marketingCards: { data: [], loaded: false },
};

export default handleActions(
  {
    [`${c.GET_MARKETING_CARDS}:GET_START`](state) {
      return {
        ...state,
      };
    },
    [`${c.GET_MARKETING_CARDS}:GET_SUCCESS`](state, { payload }) {
      return {
        ...state,
        marketingCards: { data: [...payload], loaded: true },
      };
    },
  },
  initialState,
);



// WEBPACK FOOTER //
// ./src/reducers/marketing-cards-reducer.js