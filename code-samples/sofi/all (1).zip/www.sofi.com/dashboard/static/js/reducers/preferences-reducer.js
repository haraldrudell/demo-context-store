import { handleActions } from 'redux-actions';
import * as c from '../constants/preferences-constants';

const initialState = {
  preferences: { data: {}, loaded: false },
  twoFactor: { data: {}, loaded: false },
  hb: { data: {}, loaded: false },
  preferencesUpdateSuccess: false,
  passwordUpdateSuccess: false,
};

export default handleActions(
  {
    [`${c.GET_PREFERENCES}:GET_START`](state) {
      return {
        ...state,
      };
    },
    [`${c.GET_PREFERENCES}:GET_SUCCESS`](state, { payload }) {
      return {
        ...state,
        preferences: { data: { ...payload }, loaded: true },
      };
    },
    [`${c.POST_PREFERENCES}:POST_START`](state) {
      return {
        ...state,
        preferencesUpdateSuccess: false,
      };
    },
    [`${c.POST_PREFERENCES}:POST_SUCCESS`](state, { payload }) {
      return {
        ...state,
        preferences: { data: { ...payload }, loaded: true },
        preferencesUpdateSuccess: true,
      };
    },
    [`${c.GET_TWOFACTOR}:GET_START`](state) {
      return {
        ...state,
      };
    },
    [`${c.GET_TWOFACTOR}:GET_SUCCESS`](state, { payload }) {
      return {
        ...state,
        twoFactor: { data: { ...payload }, loaded: true },
      };
    },
    [`${c.POST_TWOFACTOR_AUTH}:POST_START`](state) {
      return {
        ...state,
        postTwoFactorSuccess: false,
      };
    },
    [`${c.POST_TWOFACTOR_AUTH}:POST_SUCCESS`](state, { payload }) {
      return {
        ...state,
        twoFactor: { data: { ...payload }, loaded: true },
        postTwoFactorSuccess: true,
      };
    },
    [`${c.POST_RESET_TWOFACTOR_AUTH}:POST_START`](state) {
      return {
        ...state,
      };
    },
    [`${c.POST_RESET_TWOFACTOR_AUTH}:POST_SUCCESS`](state) {
      return {
        ...state,
      };
    },
    [`${c.POST_PASSWORD}:POST_START`](state) {
      return {
        ...state,
        passwordUpdateSuccess: false,
      };
    },
    [`${c.POST_PASSWORD}:POST_SUCCESS`](state, { payload }) {
      return {
        ...state,
        password: { data: { ...payload }, loaded: true },
        passwordUpdateSuccess: true,
      };
    },
  },
  initialState,
);



// WEBPACK FOOTER //
// ./src/reducers/preferences-reducer.js