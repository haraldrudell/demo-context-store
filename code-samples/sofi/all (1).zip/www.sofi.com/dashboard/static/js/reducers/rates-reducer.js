import { handleActions } from 'redux-actions';
import * as c from '../constants/rates-constants';

const initialState = {
  rates: { data: {}, loaded: false },
};

const ratesObject = (soFiRates) => {
  const rates = {};
  soFiRates.forEach((rate) => {
    if (!rate) return;
    rates[rate.title] = {};
    const rateObj = rates[rate.title];
    const benefit = rate.benefitAmount;
    rateObj.minFixRate = rate.fixedMin - benefit;
    rateObj.minVarRate = rate.varMin - benefit;
    rateObj.minVarRateLibor = rate.varMin - benefit - rate.libor;
    rateObj.maxFixRate = rate.fixedMax;
    rateObj.maxVarRate = rate.varMax;
    rateObj.libor = rate.libor;
    rateObj.minRateCap = rate.minVarCap;
    rateObj.maxRateCap = rate.maxVarCap;
    rateObj.benefitAmount = rate.benefitAmount;
  });
  return rates;
};

export default handleActions(
  {
    [`${c.GET_RATES}:GET_START`](state) {
      return {
        ...state,
      };
    },
    [`${c.GET_RATES}:GET_SUCCESS`](state, { payload }) {
      const rates = ratesObject(payload);
      return {
        ...state,
        rates: { data: rates, loaded: true },
      };
    },
  },
  initialState,
);



// WEBPACK FOOTER //
// ./src/reducers/rates-reducer.js