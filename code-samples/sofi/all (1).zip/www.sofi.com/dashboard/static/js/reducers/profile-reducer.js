import { handleActions } from 'redux-actions';
import * as c from '../constants/profile-constants';

const initialState = {
  underGradPrograms: { data: [], loaded: false },
  gradPrograms: { data: [], loaded: false },
  employers: { data: [], loaded: false }, // returns array of objects that match
  colleges: { data: [], loaded: false }, // returns array of strings that match
};

export default handleActions(
  {
    [`${c.GET_UNDERGRAD_PROGRAMS}:GET_START`](state) {
      return {
        ...state,
      };
    },
    [`${c.GET_UNDERGRAD_PROGRAMS}:GET_SUCCESS`](state, { payload }) {
      // Remap undergrad programs object key/value (add value & label)
      // so they can be used in select dropdown
      const remapUndergradForDropdown = payload.map(value => ({ value: String(value.id), label: String(value.name) }));
      // For Scuid-X DropDown component to work
      remapUndergradForDropdown.unshift({});

      return {
        ...state,
        underGradPrograms: { data: remapUndergradForDropdown, loaded: true },
      };
    },
    [`${c.GET_GRAD_PROGRAMS}:GET_START`](state) {
      return {
        ...state,
      };
    },
    [`${c.GET_GRAD_PROGRAMS}:GET_SUCCESS`](state, { payload }) {
      // Remap grad programs object key/value (add value & label)
      // so they can be used in select dropdown
      const remapGradForDropdown = payload.map(value => ({ value: String(value.id), label: String(value.name) }));
      // For Scuid-X DropDown component to work
      remapGradForDropdown.unshift({});

      return {
        ...state,
        gradPrograms: { data: remapGradForDropdown, loaded: true },
      };
    },
    [`${c.GET_COLLEGES}:GET_START`](state) {
      return {
        ...state,
      };
    },
    [`${c.GET_COLLEGES}:GET_SUCCESS`](state, { payload }) {
      return {
        ...state,
        colleges: { data: [...payload], loaded: true },
      };
    },
    [`${c.GET_EMPLOYERS}:GET_START`](state) {
      return {
        ...state,
      };
    },
    [`${c.GET_EMPLOYERS}:GET_SUCCESS`](state, { payload }) {
      // Remap states object key/value (add value)
      // so they can be used in Autocomplete dropdown
      const remapEmployersForAutocomplete = payload.map(value => value.name);

      return {
        ...state,
        employers: { data: remapEmployersForAutocomplete, loaded: true },
      };
    },
    [`${c.GET_EMPLOYERS}:GET_ERROR`](state) {
      return {
        ...state,
        employers: { data: [], loaded: true },
      };
    },
  },
  initialState,
);



// WEBPACK FOOTER //
// ./src/reducers/profile-reducer.js