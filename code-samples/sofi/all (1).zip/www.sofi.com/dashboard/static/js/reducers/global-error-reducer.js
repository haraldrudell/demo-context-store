import { handleActions } from 'redux-actions';
import cloneDeep from 'lodash/cloneDeep';
import * as c from '../constants/global-error-constants';

const initialState = {
  globalErrors: {},
  waitForCosignError: {
    hasBeenDisplayed: false,
    showMessage: false,
    hasBeenClosed: false,
  },
};

export default handleActions(
  {
    [`${c.SET_GLOBAL_ERROR}`](state, { payload: { data: { globalError, globalErrorCode } } }) {
      return {
        ...state,
        globalErrors: {
          ...state.globalErrors,
          [globalErrorCode]: {
            message: globalError,
            code: globalErrorCode,
          },
        },
      };
    },
    [`${c.SET_GLOBAL_ERROR}:NONE`](state, { payload: { globalErrorCode } }) {
      const baseState = cloneDeep(state);
      if (baseState.globalErrors[globalErrorCode]) delete baseState.globalErrors[globalErrorCode];
      return baseState;
    },
    [`${c.SET_WAIT_COSIGNER_ERROR}`](state) {
      return {
        ...state,
        waitForCosignError: {
          hasBeenDisplayed: true,
          showMessage: true,
          hasBeenClosed: false,
        },
      };
    },
    [`${c.SET_WAIT_COSIGNER_ERROR}:NONE`](state) {
      return {
        ...state,
        waitForCosignError: {
          hasBeenDisplayed: true,
          showMessage: false,
          hasBeenClosed: true,
        },
      };
    },
  },
  initialState,
);



// WEBPACK FOOTER //
// ./src/reducers/global-error-reducer.js