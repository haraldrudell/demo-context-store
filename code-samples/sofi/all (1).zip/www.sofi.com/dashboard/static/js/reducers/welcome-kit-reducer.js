import { handleActions } from 'redux-actions';
import * as c from '../constants/welcome-kit-constants';

const initialState = {
  welcomeKit: { data: {}, loaded: false },
  saveWelcomeKitSuccess: false,
};

export default handleActions(
  {
    [`${c.POST_WELCOME_KIT}:POST_START`](state) {
      return {
        ...state,
        saveWelcomeKitSuccess: false,
      };
    },
    [`${c.POST_WELCOME_KIT}:POST_SUCCESS`](state, { payload }) {
      return {
        ...state,
        welcomeKit: { data: { ...payload }, loaded: true },
        saveWelcomeKitSuccess: true,
      };
    },
    [`${c.GET_WELCOME_KIT}:GET_START`](state) {
      return {
        ...state,
      };
    },
    [`${c.GET_WELCOME_KIT}:GET_SUCCESS`](state, { payload }) {
      return {
        ...state,
        welcomeKit: { data: { ...payload }, loaded: true },
      };
    },
  },
  initialState,
);



// WEBPACK FOOTER //
// ./src/reducers/welcome-kit-reducer.js