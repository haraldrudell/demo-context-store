import { handleActions } from 'redux-actions';
import * as c from '../constants/product-constants';

const initialState = {
  products: { data: [], loaded: false },
};

export default handleActions(
  {
    [`${c.GET_PRODUCTS}:GET_START`](state) {
      return {
        ...state,
      };
    },
    [`${c.GET_PRODUCTS}:GET_SUCCESS`](state, { payload }) {
      return {
        ...state,
        products: { data: [...payload], loaded: true },
      };
    },
    [`${c.GET_PRODUCTS}:GET_ERROR`](state) {
      return {
        ...state,
        products: { data: [], loaded: true },
      };
    },
  },
  initialState,
);



// WEBPACK FOOTER //
// ./src/reducers/product-reducer.js