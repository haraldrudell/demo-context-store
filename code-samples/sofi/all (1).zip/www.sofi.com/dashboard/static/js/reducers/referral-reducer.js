import { handleActions } from 'redux-actions';
import * as c from '../constants/referral-constants';

const initialState = {
  referralSummary: { data: {}, loaded: false },
  referralConsents: { data: {}, loaded: false },
  referrerProgress: { data: [], loaded: false },
  referrer: { data: {}, loaded: false },
  hasWaterBottleModalBeenShown: { data: null, loaded: false },
  hasBackpackModalBeenShown: { data: null, loaded: false },
  contacts: { data: {}, loaded: false },
  bankAccount: { data: {}, loaded: false },
  w9: { data: {}, loadedGet: false, loadedPost: false },
  postReferralConsentSuccess: false,
  referrals: { data: [], loaded: false },
  postContactsSuccess: false,
};

export default handleActions(
  {
    [`${c.GET_REFERRAL_SUMMARY}:GET_START`](state) {
      return {
        ...state,
      };
    },
    [`${c.GET_REFERRAL_SUMMARY}:GET_SUCCESS`](state, { payload }) {
      return {
        ...state,
        referralSummary: { data: { ...payload }, loaded: true },
      };
    },
    [`${c.GET_REFERRAL_CONSENTS}:GET_START`](state) {
      return {
        ...state,
      };
    },
    [`${c.GET_REFERRAL_CONSENTS}:GET_SUCCESS`](state, { payload }) {
      return {
        ...state,
        referralConsents: { data: { ...payload }, loaded: true },
      };
    },
    [`${c.POST_REFERRAL_CONSENTS}:POST_START`](state) {
      return {
        ...state,
        postReferralConsentSuccess: false,
      };
    },
    [`${c.POST_REFERRAL_CONSENTS}:POST_SUCCESS`](state, { payload }) {
      return {
        ...state,
        referralConsents: { data: { ...payload }, loaded: true },
        postReferralConsentSuccess: true,
      };
    },
    [`${c.GET_REFERRER}:GET_START`](state) {
      return {
        ...state,
      };
    },
    [`${c.GET_REFERRER}:GET_SUCCESS`](state, { payload }) {
      return {
        ...state,
        referrer: { data: { ...payload }, loaded: true },
      };
    },
    [`${c.GET_REFERRER}:GET_ERROR`](state, { payload }) {
      return {
        ...state,
        referrer: { data: { ...payload }, loaded: false },
      };
    },
    [`${c.POST_CREATE_REFERRER}:POST_START`](state) {
      return {
        ...state,
      };
    },
    [`${c.GET_WATER_BOTTLE_MODAL_STATUS}:GET_START`](state) {
      return {
        ...state,
      };
    },
    [`${c.GET_WATER_BOTTLE_MODAL_STATUS}:GET_SUCCESS`](state, { payload }) {
      return {
        ...state,
        hasWaterBottleModalBeenShown: { data: payload, loaded: true },
      };
    },
    [`${c.GET_WATER_BOTTLE_MODAL_STATUS}:GET_ERROR`](state, { payload }) {
      return {
        ...state,
        hasWaterBottleModalBeenShown: { ...payload },
      };
    },
    [`${c.GET_BACKPACK_MODAL_STATUS}:GET_START`](state) {
      return {
        ...state,
      };
    },
    [`${c.GET_BACKPACK_MODAL_STATUS}:GET_SUCCESS`](state, { payload }) {
      return {
        ...state,
        hasBackpackModalBeenShown: { data: payload, loaded: true },
      };
    },
    [`${c.GET_BACKPACK_MODAL_STATUS}:GET_ERROR`](state, { payload }) {
      return {
        ...state,
        hasBackpackModalBeenShown: { ...payload },
      };
    },
    [`${c.POST_CREATE_REFERRER}:POST_SUCCESS`](state, { payload }) {
      return {
        ...state,
        referrer: { data: { ...payload }, loaded: true },
      };
    },
    [`${c.GET_REFERRER_PROGRESS}:GET_START`](state) {
      return {
        ...state,
      };
    },
    [`${c.GET_REFERRER_PROGRESS}:GET_SUCCESS`](state, { payload }) {
      return {
        ...state,
        referrerProgress: { data: [...payload], loaded: true },
      };
    },
    [`${c.GET_REFERRAL_CONTACTS}:GET_START`](state) {
      return {
        ...state,
      };
    },
    [`${c.GET_REFERRAL_CONTACTS}:GET_SUCCESS`](state, { payload }) {
      return {
        ...state,
        contacts: { data: { ...payload }, loaded: true },
      };
    },
    [`${c.POST_REFERRAL_CONTACTS}:POST_START`](state) {
      return {
        ...state,
        postContactsSuccess: false,
      };
    },
    [`${c.POST_REFERRAL_CONTACTS}:POST_SUCCESS`](state, { payload }) {
      return {
        ...state,
        referralConsents: { data: { ...payload }, loaded: true },
        postContactsSuccess: true,
      };
    },
    [`${c.GET_W9_INFO}:GET_START`](state) {
      return {
        ...state,
        w9: { data: { ...state.w9.data }, loadedGet: false, loadedPost: state.w9.loadedPost },
      };
    },
    [`${c.GET_W9_INFO}:GET_SUCCESS`](state, { payload }) {
      return {
        ...state,
        w9: { data: { ...payload }, loadedGet: true, loadedPost: state.w9.loadedPost },
      };
    },
    [`${c.POST_W9_INFO}:POST_START`](state) {
      return {
        ...state,
        w9: { data: { ...state.w9.data }, loadedGet: state.w9.loadedGet, loadedPost: false },
      };
    },
    [`${c.POST_W9_INFO}:POST_SUCCESS`](state, { payload }) {
      return {
        ...state,
        w9: { data: { ...payload }, loadedGet: state.w9.loadedGet, loadedPost: true },
      };
    },
    [`${c.GET_BANK_ACCOUNT}:GET_SUCCESS`](state, { payload }) {
      const displaySsn = !payload.ssn;
      return {
        ...state,
        bankAccount: { data: { ...payload, displaySsn }, loaded: true },
      };
    },
    [`${c.UPDATE_BANK_ACCOUNT}:POST_START`](state) {
      return {
        ...state,
        bankAccountUpdateSuccessful: false,
      };
    },
    [`${c.UPDATE_BANK_ACCOUNT}:POST_SUCCESS`](state, { payload }) {
      return {
        ...state,
        bankAccount: { data: { ...payload }, loaded: true },
        bankAccountUpdateSuccessful: true,
      };
    },
    [`${c.GET_REFERRALS}:GET_SUCCESS`](state, { payload }) {
      return {
        ...state,
        referrals: { data: [...payload], loaded: true },
      };
    },
  },
  initialState,
);



// WEBPACK FOOTER //
// ./src/reducers/referral-reducer.js