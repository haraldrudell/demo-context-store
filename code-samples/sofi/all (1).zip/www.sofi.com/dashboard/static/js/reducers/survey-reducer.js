import { handleActions } from 'redux-actions';
import * as c from '../constants/survey-constants';

const initialState = {
  npsSurvey: { data: {}, loaded: false },
  whereHeardSurvey: { data: {}, loaded: false },
};

export default handleActions(
  {
    [`${c.GET_NPS_SURVEY}:GET_START`](state) {
      return {
        ...state,
      };
    },
    [`${c.GET_NPS_SURVEY}:GET_SUCCESS`](state, { payload }) {
      return {
        ...state,
        npsSurvey: { data: { ...payload }, loaded: true },
      };
    },
    [`${c.POST_NPS_SURVEY}:POST_START`](state) {
      return {
        ...state,
      };
    },
    [`${c.POST_NPS_SURVEY}:POST_SUCCESS`](state, { payload }) {
      return {
        ...state,
        npsSurvey: { data: { ...payload }, loaded: true },
      };
    },
    [`${c.GET_WHERE_HEARD_SURVEY}:GET_START`](state) {
      return {
        ...state,
      };
    },
    [`${c.GET_WHERE_HEARD_SURVEY}:GET_SUCCESS`](state, { payload }) {
      return {
        ...state,
        whereHeardSurvey: { data: { ...payload }, loaded: true },
      };
    },
    [`${c.POST_WHERE_HEARD_SURVEY}:POST_START`](state) {
      return {
        ...state,
      };
    },
    [`${c.POST_WHERE_HEARD_SURVEY}:POST_SUCCESS`](state, { payload }) {
      return {
        ...state,
        whereHeardSurvey: { data: { ...payload }, loaded: true },
      };
    },
  },
  initialState,
);



// WEBPACK FOOTER //
// ./src/reducers/survey-reducer.js