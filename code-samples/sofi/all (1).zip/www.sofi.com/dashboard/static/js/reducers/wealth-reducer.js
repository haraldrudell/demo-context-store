import { handleActions } from 'redux-actions';
import * as c from '../constants/wealth-constants';

const initialState = {
  wealth: { data: [], loaded: false },
};

export default handleActions(
  {
    [`${c.GET_WEALTH}:GET_START`](state) {
      return {
        ...state,
      };
    },
    [`${c.GET_WEALTH}:GET_SUCCESS`](state, { payload }) {
      return {
        ...state,
        wealth: { data: [...payload], loaded: true },
      };
    },
  },
  initialState,
);



// WEBPACK FOOTER //
// ./src/reducers/wealth-reducer.js