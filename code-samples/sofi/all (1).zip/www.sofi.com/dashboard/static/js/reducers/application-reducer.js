import { handleActions } from 'redux-actions';
import * as c from '../constants/application-constants';

import { appInfoComparator } from '../components/accounts/utilities';

const initialState = {
  applications: { data: [], loaded: false },
  dashboardAccounts: { data: {}, loaded: false },
  servicing: { data: {}, loaded: false },
  mortgageSso: { data: {}, loaded: false },
};

export default handleActions(
  {
    [`${c.GET_APPLICATIONS}:GET_START`](state) {
      return {
        ...state,
      };
    },
    [`${c.GET_APPLICATIONS}:GET_SUCCESS`](state, { payload }) {
      // Sort all the user applications
      const sortedApplications = payload.sort(appInfoComparator(
        { name: 'active', reverse: true },
        { name: 'amount', reverse: true },
        { name: 'docs', reverse: true },
        { name: 'esigned', reverse: true },
        { name: 'id', reverse: false },
      ));

      return {
        ...state,
        applications: { data: sortedApplications, loaded: true },
      };
    },
    [`${c.GET_DASHBOARD_ACCOUNTS}:GET_START`](state) {
      return {
        ...state,
      };
    },
    [`${c.GET_DASHBOARD_ACCOUNTS}:GET_SUCCESS`](state, { payload }) {
      return {
        ...state,
        dashboardAccounts: { data: payload, loaded: true },
      };
    },
    [`${c.GET_APPLICATIONS_SERVICING}:GET_START`](state) {
      return {
        ...state,
      };
    },
    [`${c.GET_APPLICATIONS_SERVICING}:GET_SUCCESS`](state, { payload }) {
      return {
        ...state,
        servicing: { data: { ...payload }, loaded: true },
      };
    },
    [`${c.GET_MORTGAGE_SSO}:GET_START`](state) {
      return {
        ...state,
      };
    },
    [`${c.GET_MORTGAGE_SSO}:GET_SUCCESS`](state, { payload }) {
      return {
        ...state,
        mortgageSso: { data: { ...payload }, loaded: true },
      };
    },
    [`${c.POST_APPLICATION_RETRY}:POST_START`](state) {
      return {
        ...state,
        applicationRetrySuccess: false,
      };
    },
    [`${c.POST_APPLICATION_RETRY}:POST_SUCCESS`](state) {
      // Add payload here?
      /**
       * Not using the payload back currently. TODO: Figure out what it returns if sucessful
       */
      return {
        ...state,
        applicationRetrySuccess: true,
      };
    },
  },
  initialState,
);



// WEBPACK FOOTER //
// ./src/reducers/application-reducer.js