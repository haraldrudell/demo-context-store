import PropTypes from 'prop-types';

export const ProductsPropTypes = PropTypes.arrayOf(PropTypes.shape({
  eligibility: PropTypes.object.isRequired,
  eligible: PropTypes.bool,
  rates: PropTypes.shape({
    benefitAmount: PropTypes.number.isRequired,
    fixedMax: PropTypes.number.isRequired,
    fixedMin: PropTypes.number.isRequired,
    libor: PropTypes.number.isRequired,
    maxVarCap: PropTypes.number.isRequired,
    minVarCap: PropTypes.number.isRequired,
    title: PropTypes.string.isRequired,
    varMax: PropTypes.number.isRequired,
    varMin: PropTypes.number.isRequired,
  }),
  reasons: PropTypes.arrayOf(PropTypes.shape({
    code: PropTypes.string.isRequired,
    reason: PropTypes.string.isRequired,
    startUrl: PropTypes.string.isRequired,
  })),
  name: PropTypes.string.isRequired,
  version: PropTypes.number.isRequired,
}));



// WEBPACK FOOTER //
// ./src/constants/prop-types/products-prop-types.js