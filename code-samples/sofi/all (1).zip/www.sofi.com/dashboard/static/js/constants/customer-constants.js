export const GET_CUSTOMER = 'customer:GET_CUSTOMER';
export const GET_CONSENTS = 'customer:GET_CONSENTS';
export const GET_CONSENTS_TOU = 'customer:GET_CONSENTS_TOU';
export const GET_SMS_TCPA_CONSENT = 'customer:GET_SMS_TCPA_CONSENT';

export const POST_UPDATED_PROFILE = 'customer:POST_UPDATED_PROFILE';
export const POST_CONSENTS = 'customer:POST_CONSENTS';
export const POST_CUSTOMER_STATE = 'customer:POST_CUSTOMER_STATE';
export const POST_CUSTOMER_COSIGN = 'customer:POST_CUSTOMER_COSIGN';

export const UPDATE_CUSTOMER_PARTIAL = 'customer:UPDATE_CUSTOMER_PARTIAL';
export const UPDATE_CUSTOMER_SHIPPING = 'customer:UPDATE_CUSTOMER_SHIPPING';



// WEBPACK FOOTER //
// ./src/constants/customer-constants.js