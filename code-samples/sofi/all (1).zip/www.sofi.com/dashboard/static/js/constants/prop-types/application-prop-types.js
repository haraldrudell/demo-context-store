import PropTypes from 'prop-types';

export const DeclinesPropTypes = PropTypes.shape({
  avantDecline: PropTypes.bool,
  code: PropTypes.string,
  declineDocUrl: PropTypes.string,
  description: PropTypes.string,
  ficoReasons: PropTypes.arrayOf(PropTypes.string),
  icon: PropTypes.string,
  title: PropTypes.string,
});

export const ApplicationPropType = PropTypes.shape({
  id: PropTypes.number.isRequired,
  type: PropTypes.string.isRequired,
  amount: PropTypes.number,
  currentRate: PropTypes.number,
  status: PropTypes.string.isRequired,
  statusDesc: PropTypes.string.isRequired,
  servicingAccess: PropTypes.string,
  servicing: PropTypes.shape({
    accountId: PropTypes.number,
    statusDesc: PropTypes.string,
    status: PropTypes.string,
  }),
  continueUrl: PropTypes.string.isRequired,
  docs: PropTypes.arrayOf(PropTypes.shape({
    type: PropTypes.string.isRequired,
    url: PropTypes.string.isRequired,
  })),
  welcomeBonusAmount: PropTypes.number,
  welcomeBonusStatus: PropTypes.string,
  welcomeBonusUrl: PropTypes.string,
  primaryApplicantName: PropTypes.string,
  declines: PropTypes.arrayOf(PropTypes.arrayOf(DeclinesPropTypes)),
  rateLockDate: PropTypes.string,
  active: PropTypes.bool.isRequired,
  role: PropTypes.string,
  otherApplicant: PropTypes.string,
  esigned: PropTypes.bool.isRequired,
  productDesc: PropTypes.string.isRequired,
});

export const MortgageSsoPropType = PropTypes.shape({
  id: PropTypes.string,
});

export const ServicingPropTypes = PropTypes.shape({
  accessUrl: PropTypes.string,
});



// WEBPACK FOOTER //
// ./src/constants/prop-types/application-prop-types.js