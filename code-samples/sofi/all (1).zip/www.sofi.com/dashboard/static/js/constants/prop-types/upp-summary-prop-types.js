import PropTypes from 'prop-types';

export const UppSummaryPropTypes = PropTypes.arrayOf(PropTypes.shape({
  applicationEndDate: PropTypes.string,
  city: PropTypes.string,
  email: PropTypes.string,
  employer: PropTypes.string,
  enrollmentDate: PropTypes.string,
  enrollmentStatus: PropTypes.string,
  forbEndDate: PropTypes.string,
  forbStartDate: PropTypes.string,
  jobFunctions: PropTypes.string,
  jobIndustry: PropTypes.string,
  jobTitle: PropTypes.string,
  linkedIn: PropTypes.string,
  loanApplicationId: PropTypes.number,
  name: PropTypes.string,
  phone: PropTypes.string,
  salary: PropTypes.number,
  state: PropTypes.string,
  streetAddress: PropTypes.string,
  terminationDate: PropTypes.string,
  terminationType: PropTypes.string,
  uppApplicationId: PropTypes.number,
  userId: PropTypes.number,
  zip: PropTypes.string,
}));



// WEBPACK FOOTER //
// ./src/constants/prop-types/upp-summary-prop-types.js