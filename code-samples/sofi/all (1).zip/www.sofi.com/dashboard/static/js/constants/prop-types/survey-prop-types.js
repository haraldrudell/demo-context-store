import PropTypes from 'prop-types';

export const NpsSurveyPropTypes = PropTypes.shape({
  name: PropTypes.string,
  needsSurvey: PropTypes.bool,
  survey: PropTypes.shape({
    questions: PropTypes.arrayOf(PropTypes.shape({
      question: PropTypes.string,
      questionType: PropTypes.string,
      choices: PropTypes.arrayOf(PropTypes.shape({
        choice: PropTypes.string,
      })),
    })),
  }),
});



// WEBPACK FOOTER //
// ./src/constants/prop-types/survey-prop-types.js