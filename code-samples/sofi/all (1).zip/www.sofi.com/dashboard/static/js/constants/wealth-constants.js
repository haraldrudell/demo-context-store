export const GET_WEALTH = 'wealth:GET_WEALTH';



// WEBPACK FOOTER //
// ./src/constants/wealth-constants.js