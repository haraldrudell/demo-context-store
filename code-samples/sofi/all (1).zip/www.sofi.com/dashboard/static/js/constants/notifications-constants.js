export const GET_NOTIFICATIONS_PAGE = 'notifications:GET_NOTIFICATIONS_PAGE';

export const PUT_MARK_ALL_READ = 'notifications:PUT_MARK_ALL_READ';
export const PUT_ONE_NOTIFICATION_STATUS = 'notifications:PUT_ONE_NOTIFICATION_STATUS';

export const UPDATE_NOTIFICATIONS_STATE = 'notifications:UPDATE_NOTIFICATIONS_STATE';



// WEBPACK FOOTER //
// ./src/constants/notifications-constants.js