import PropTypes from 'prop-types';

export const CardPropTypes = PropTypes.shape({
  title: PropTypes.shape({
    value: PropTypes.String,
  }),
  titleIcon: PropTypes.shape({
    value: PropTypes.String,
  }),
  heading1: PropTypes.shape({
    value: PropTypes.String,
  }),
  heading2: PropTypes.shape({
    value: PropTypes.String,
  }),
  heading3: PropTypes.shape({
    value: PropTypes.String,
  }),
  heading4: PropTypes.shape({
    value: PropTypes.String,
  }),
  topLeftData: PropTypes.shape({
    value: PropTypes.String,
  }),
  topLeftLabel: PropTypes.shape({
    value: PropTypes.String,
  }),
  topRightData: PropTypes.shape({
    value: PropTypes.String,
  }),
  topRightLabel: PropTypes.shape({
    value: PropTypes.String,
  }),
  bottomLeftLabel: PropTypes.shape({
    value: PropTypes.String,
  }),
  bottomLeftData: PropTypes.shape({
    value: PropTypes.String,
  }),
  bottomRightData: PropTypes.shape({
    value: PropTypes.String,
  }),
  bottomRightLabel: PropTypes.shape({
    value: PropTypes.String,
  }),
  callToAction1: PropTypes.shape({
    value: PropTypes.shape({
      text: PropTypes.shape({
        value: PropTypes.String,
      }),
      type: PropTypes.shape({
        value: PropTypes.String,
      }),
      url: PropTypes.shape({
        value: PropTypes.String,
      }),
      icon: PropTypes.shape({
        value: PropTypes.String,
      }),
    }),
  }),
  callToAction2: PropTypes.shape({
    value: PropTypes.shape({
      text: PropTypes.shape({
        value: PropTypes.String,
      }),
      type: PropTypes.shape({
        value: PropTypes.String,
      }),
      url: PropTypes.shape({
        value: PropTypes.String,
      }),
      icon: PropTypes.shape({
        value: PropTypes.String,
      }),
    }),
  }),
  fullWidthMessage: PropTypes.shape({
    value: PropTypes.String,
  }),
  expandUrl: PropTypes.shape({
    value: PropTypes.String,
  }),
});

export const DashboardAccountsPropTypes = PropTypes.shape({
  accountCards: PropTypes.arrayOf(PropTypes.shape({
    templateName: PropTypes.String,
    data: CardPropTypes,
    id: PropTypes.number,
  })),
});



// WEBPACK FOOTER //
// ./src/constants/prop-types/dashboard-accounts-prop-types.js