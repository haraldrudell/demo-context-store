export const GET_PREFERENCES = 'preferences:GET_PREFERENCES';
export const GET_TWOFACTOR = 'preferences:GET_TWOFACTOR';
export const GET_HB = 'preferences:GET_HB';
export const POST_PREFERENCES = 'preferences:POST_PREFERENCES';
export const POST_PASSWORD = 'preferences:POST_PASSWORD';
export const POST_TWOFACTOR_AUTH = 'preferences:POST_TWOFACTOR_AUTH';
export const POST_RESET_TWOFACTOR_AUTH = 'preferences:POST_RESET_TWOFACTOR_AUTH';



// WEBPACK FOOTER //
// ./src/constants/preferences-constants.js