// Client Ids
export const LAUNCH_DARKLY_CLIENT_ID_TEST = '59d554b757557d0acab6119c';
export const LAUNCH_DARKLY_CLIENT_ID_STAGING = '5ada0bfd42755c2e1c10ab0e';
export const LAUNCH_DARKLY_CLIENT_ID_PROD = '59d554b757557d0acab6119d';

// Feature Flags
export const FEATURE_FLAG_ACCOUNT_CARDS = 'account-cards';
export const FEATURE_FLAG_WEALTH_BANNER_AD = 'wealth-banner-ad';
export const FEATURE_FLAG_DASHBOARD_CONTENT_CARDS = 'dashboard-content-cards';
export const FEATURE_FLAG_MEMBER_DASHBOARD_CMS_PRODUCT_OFFERINGS = 'member-dashboard-cms-product-offerings';



// WEBPACK FOOTER //
// ./src/constants/launch-darkly-constants.js