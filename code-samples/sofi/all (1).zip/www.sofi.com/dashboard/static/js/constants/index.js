export const API_URL = '/dashboard-service';
export const WEALTH_URL = '/wealth';
export const REFERRAL_URL = '/referral/api/v1';
export const DASHBOARD_API_URL = '/dashboard-content';
export const REFERRER_URL = '/referral/api/v1/referrer';
export const DASHBOARD_CONTENT_URL = '/dashboard-content';



// WEBPACK FOOTER //
// ./src/constants/index.js