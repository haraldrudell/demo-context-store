export const GET_SPOUSE = 'apple:GET_SPOUSE';
export const POST_SPOUSE = 'apple:POST_SPOUSE';



// WEBPACK FOOTER //
// ./src/constants/apple-spouse-constants.js