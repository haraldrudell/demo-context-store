export const GET_UNDERGRAD_PROGRAMS = 'profile:GET_UNDERGRAD_PROGRAMS';
export const GET_GRAD_PROGRAMS = 'profile:GET_GRAD_PROGRAMS';
export const GET_COLLEGES = 'profile:GET_COLLEGES';
export const GET_EMPLOYERS = 'profile:GET_EMPLOYERS';



// WEBPACK FOOTER //
// ./src/constants/profile-constants.js