import PropTypes from 'prop-types';

export const W9ReferralInfoPropTypes = PropTypes.shape({
  docusignUrl: PropTypes.string,
  userId: PropTypes.number.isRequired,
  w9DocumentId: PropTypes.number,
  w9Status: PropTypes.string.isRequired,
});



// WEBPACK FOOTER //
// ./src/constants/prop-types/w9-referral-info-prop-types.js