export const GET_MARKETING_CARDS = 'marketing:GET_MARKETING_CARDS';



// WEBPACK FOOTER //
// ./src/constants/marketing-cards-constants.js