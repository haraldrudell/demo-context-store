import PropTypes from 'prop-types';

// Alpha2 and name is what comes back from API, but we need value and label for Scuid Dropdown
export const StatesPropTypes = PropTypes.arrayOf(PropTypes.shape({
  label: PropTypes.string,
  value: PropTypes.string,
  alpha2: PropTypes.string,
  name: PropTypes.string,
}));



// WEBPACK FOOTER //
// ./src/constants/prop-types/states-prop-types.js