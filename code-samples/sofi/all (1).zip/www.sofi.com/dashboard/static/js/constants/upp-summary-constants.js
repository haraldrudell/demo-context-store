export const GET_UPP_SUMMARY = 'upp:GET_UPP_SUMMARY';



// WEBPACK FOOTER //
// ./src/constants/upp-summary-constants.js