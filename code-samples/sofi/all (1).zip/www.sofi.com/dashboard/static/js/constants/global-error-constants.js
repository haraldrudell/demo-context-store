export const SET_GLOBAL_ERROR = 'SET_GLOBAL_ERROR';
export const SET_WAIT_COSIGNER_ERROR = 'SET_WAIT_COSIGNER_ERROR';



// WEBPACK FOOTER //
// ./src/constants/global-error-constants.js