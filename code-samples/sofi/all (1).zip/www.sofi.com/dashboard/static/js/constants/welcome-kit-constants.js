/**
 * Actions
 */
export const POST_WELCOME_KIT = 'welcome-kit:POST_WELCOME_KIT';
export const GET_WELCOME_KIT = 'welcome-kit:GET_WELCOME_KIT';



// WEBPACK FOOTER //
// ./src/constants/welcome-kit-constants.js