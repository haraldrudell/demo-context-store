export const GET_PRODUCTS = 'product:GET_PRODUCTS';



// WEBPACK FOOTER //
// ./src/constants/product-constants.js