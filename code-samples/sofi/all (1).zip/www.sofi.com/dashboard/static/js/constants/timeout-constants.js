export const TIMEOUT = 'timeout:TIMEOUT';



// WEBPACK FOOTER //
// ./src/constants/timeout-constants.js