import PropTypes from 'prop-types';

export const WaitForCosignerErrorPropTypes = PropTypes.shape({
  hasBeenDisplayed: PropTypes.bool.isRequired,
  showMessage: PropTypes.bool.isRequired,
  hasBeenClosed: PropTypes.bool.isRequired,
});



// WEBPACK FOOTER //
// ./src/constants/prop-types/wait-for-cosign-error-prop-types.js