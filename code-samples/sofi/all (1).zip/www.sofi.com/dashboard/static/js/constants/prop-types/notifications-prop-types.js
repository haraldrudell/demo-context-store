import PropTypes from 'prop-types';

export const NotificationPropTypes = PropTypes.shape({
  notificationID: PropTypes.string,
  message: PropTypes.string,
  actionText: PropTypes.string,
  actionURL: PropTypes.string,
  created: PropTypes.number,
  status: PropTypes.string,
});



// WEBPACK FOOTER //
// ./src/constants/prop-types/notifications-prop-types.js