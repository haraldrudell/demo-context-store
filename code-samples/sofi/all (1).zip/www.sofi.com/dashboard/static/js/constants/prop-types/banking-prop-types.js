import PropTypes from 'prop-types';

export const BankingPropTypes = PropTypes.shape({
  accountNumber: PropTypes.string,
  accountHolder: PropTypes.string,
  accountType: PropTypes.string,
  balance: PropTypes.string,
  available: PropTypes.string,
  redirectUrl: PropTypes.string,
  status: PropTypes.string,
});



// WEBPACK FOOTER //
// ./src/constants/prop-types/banking-prop-types.js