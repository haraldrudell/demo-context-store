import PropTypes from 'prop-types';

export const TrackingBannerPropTypes = PropTypes.arrayOf(PropTypes.shape({
  id: PropTypes.number,
  named: PropTypes.string,
  targetType: PropTypes.string,
  targetId: PropTypes.string,
  active: PropTypes.bool,
  endDate: PropTypes.string,
}));



// WEBPACK FOOTER //
// ./src/constants/prop-types/tracking-banner-prop-types.js