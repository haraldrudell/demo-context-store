export const GET_NPS_SURVEY = 'survey:GET_NPS_SURVEY';
export const POST_NPS_SURVEY = 'survey:POST_NPS_SURVEY';
export const GET_WHERE_HEARD_SURVEY = 'survey:GET_WHERE_HEARD_SURVEY';
export const POST_WHERE_HEARD_SURVEY = 'survey:POST_WHERE_HEARD_SURVEY';



// WEBPACK FOOTER //
// ./src/constants/survey-constants.js