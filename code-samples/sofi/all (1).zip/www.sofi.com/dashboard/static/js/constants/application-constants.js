export const GET_APPLICATIONS = 'application:GET_APPLICATIONS';
export const GET_APPLICATIONS_SERVICING = 'application:GET_APPLICATIONS_SERVICING';
export const GET_MORTGAGE_SSO = 'application:GET_MORTGAGE_SSO';
export const GET_DASHBOARD_ACCOUNTS = 'application:GET_DASHBOARD_ACCOUNTS';
export const POST_APPLICATION_RETRY = 'application:POST_APPLICATION_RETRY';



// WEBPACK FOOTER //
// ./src/constants/application-constants.js