import PropTypes from 'prop-types';

export const ReferralConsentsPropTypes = PropTypes.shape({
  referralConsent: PropTypes.bool,
});

export const ReferralSummaryPropTypes = PropTypes.shape({
  isSubscribed: PropTypes.bool,
  registrations: PropTypes.number,
  funded: PropTypes.number,
  earned: PropTypes.number,
  paid: PropTypes.number,
  pending: PropTypes.number,
  eligible: PropTypes.bool,
  unifiedUrl: PropTypes.string,
  referralProducts: PropTypes.arrayOf(PropTypes.shape({
    affiliate: PropTypes.shape({
      id: PropTypes.number,
      name: PropTypes.string,
      email: PropTypes.string,
      type: PropTypes.string,
      industry: PropTypes.string,
      accountOwner: PropTypes.string,
      vendorInternalId: PropTypes.string,
      vendorId: PropTypes.string,
      startDate: PropTypes.string,
      createdDate: PropTypes.string,
    }),
    campaign: PropTypes.shape({
      id: PropTypes.number,
      name: PropTypes.string,
      target: PropTypes.string,
      department: PropTypes.string,
      description: PropTypes.string,
      redirectUrl: PropTypes.string,
      allowsCustomValues: PropTypes.bool,
      affiliateFee: PropTypes.number,
      welcomeBonus: PropTypes.number,
      campaignOwner: PropTypes.string,
      category: PropTypes.string,
      numberTargeted: PropTypes.string,
      createdDate: PropTypes.string,
    }),
    customUrl: PropTypes.string,
    displayUrl: PropTypes.string,
    redirectUrl: PropTypes.string,
    daysRetention: PropTypes.number,
    startDate: PropTypes.string,
    createdDate: PropTypes.string,
  })),
  referralStatistics: PropTypes.arrayOf(PropTypes.shape({
    campaignTarget: PropTypes.string,
    registrations: PropTypes.number,
    funded: PropTypes.number,
    paid: PropTypes.number,
    pending: PropTypes.number,
  })),
});

export const ReferrerPropTypes = PropTypes.shape({
  referrerId: PropTypes.string.isRequired,
  firstName: PropTypes.string.isRequired,
  lastName: PropTypes.string.isRequired,
  email: PropTypes.string.isRequired,
  mobile: PropTypes.string.isRequired,
  partyId: PropTypes.number.isRequired,
  affiliateId: PropTypes.string.isRequired,
  eligibility: PropTypes.bool.isRequired,
  memberStartDate: PropTypes.string.isRequired,
});

export const ReferrerBankAccountPropTypes = PropTypes.shape({
  accountType: PropTypes.string,
  accountNo: PropTypes.string,
  routingNo: PropTypes.string,
  ssn: PropTypes.string,
  displaySsn: PropTypes.bool,
});

export const ReferrerShippingAddressPropTypes = PropTypes.shape({
  address: PropTypes.string,
  apartment: PropTypes.string,
  city: PropTypes.string,
  state: PropTypes.string,
  postalCode: PropTypes.string,
});

export const ReferrerW9PropType = PropTypes.shape({
  docusignUrl: PropTypes.string,
  userId: PropTypes.number,
  w9DocumentId: PropTypes.string,
  w9Status: PropTypes.string,
});

export const ReferralGamePropTypes = PropTypes.shape({
  ruleId: PropTypes.string.isRequired,
  giftId: PropTypes.string.isRequired,
  giftName: PropTypes.string.isRequired,
  giftDescription: PropTypes.string.isRequired,
  achievementsRequired: PropTypes.number.isRequired,
  achievementsCompleted: PropTypes.number.isRequired,
  achievementType: PropTypes.string.isRequired,
});

export const ReferrerProgressPropTypes = PropTypes.arrayOf(ReferralGamePropTypes);

export const ReferralContactPropTypes = PropTypes.shape({
  firstName: PropTypes.string,
  lastName: PropTypes.string,
  email: PropTypes.string,
});

export const ReferralContactsPropTypes = PropTypes.shape({
  authorized: PropTypes.bool,
  contacts: PropTypes.arrayOf(ReferralContactPropTypes),
});

export const ReferralSelectedContactsPropTypes = PropTypes.objectOf(ReferralContactPropTypes);

export const ReferralTagPropTypes = PropTypes.arrayOf(PropTypes.string);

export const ReferralPropTypes = PropTypes.shape({
  affiliateId: PropTypes.string,
  eligibility: PropTypes.bool,
  email: PropTypes.string,
  firstName: PropTypes.string,
  lastName: PropTypes.string,
  memberStartDate: PropTypes.string,
  mobile: PropTypes.string,
  partyId: PropTypes.number,
  referrerId: PropTypes.string,
});



// WEBPACK FOOTER //
// ./src/constants/prop-types/referral-prop-types.js