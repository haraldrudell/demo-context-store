import { API_URL } from './index';

/**
 * Actions
 */
export const GET_REFERRAL_SUMMARY = 'referral:GET_REFERRAL_SUMMARY';
export const GET_REFERRAL_CONTACTS = 'referral:GET_REFERRAL_CONTACTS';
export const GET_REFERRAL_CONSENTS = 'referral:GET_REFERRAL_CONSENTS';
export const POST_REFERRAL_CONSENTS = 'referral:POST_REFERRAL_CONSENTS';
export const GET_REFERRER = 'referral:GET_REFERRER';
export const POST_CREATE_REFERRER = 'referral:POST_CREATE_REFERRER';
export const GET_WATER_BOTTLE_MODAL_STATUS = 'referral:GET_WATER_BOTTLE_MODAL_STATUS';
export const GET_BACKPACK_MODAL_STATUS = 'referral:GET_BACKPACK_MODAL_STATUS';
export const UPDATE_REWARD_MODAL_VISIBILITY = 'referral:UPDATE_REWARD_MODAL_VISIBILITY';
export const GET_REFERRER_PROGRESS = 'referral:GET_REFERRER_PROGRESS';
export const POST_REFERRAL_CONTACTS = 'referral:POST_REFERRAL_CONTACTS';
export const GET_BANK_ACCOUNT = 'referral:GET_BANK_ACCOUNT';
export const GET_W9_INFO = 'referral:GET_W9_INFO';
export const POST_W9_INFO = 'referral:POST_W9_INFO';
export const UPDATE_BANK_ACCOUNT = 'referral:UPDATE_BANK_ACCOUNT';
export const UPDATE_CUSTOMER_WITH_PHONE_AND_ADDRESS = 'referral:UPDATE_CUSTOMER_WITH_PHONE_AND_ADDRESS';
export const GET_REFERRALS = 'referral:GET_REFERRALS';

export const AFFILIATE_OVERVIEW_URL = '/affiliate/overview';
export const AFFILIATE_ACH_URL = '/affiliate/ach';
export const AFFILIATE_REGISTER_URL = '/affiliate/register';
export const AFFILIATE_SHIPPING_ADDRESS = '/affiliate/shipping-address';
export const AFFILIATE_W9_URL = '/affiliate/w9';
export const AFFILIATE_W9_DOWNLOAD_URL = `${API_URL}/affiliate/referral/signed-w9.pdf`;
export const MAX_ITEMS_MOBILE = 12;
export const MAX_ITEMS_BROWSER = MAX_ITEMS_MOBILE * 2;
export const MOBILE_WINDOW_SIZE = 600;
export const REFERRAL_OAUTH_APP_ID = 'referral-contacts';
export const REFERRAL_OAUTH_CONTINUE_URI = '/dashboard/#/google/redirect';
export const REFERRAL_OAUTH_CONTACTS_SCOPE = 'https://www.googleapis.com/auth/contacts.readonly';

const TAXABLE = 'TAXABLE';
const NOTTAXABLE = 'NOTTAXABLE';
const SIGNED = 'SIGNED';
const UNSIGNED = 'UNSIGNED';

export const W9_STATUSES = {
  TAXABLE,
  NOTTAXABLE,
  SIGNED,
  UNSIGNED,
};




// WEBPACK FOOTER //
// ./src/constants/referral-constants.js