export const GET_BANKING = 'banking:GET_BANKING';
export const GET_IS_BANKING = 'banking:GET_IS_BANKING';



// WEBPACK FOOTER //
// ./src/constants/banking-constants.js