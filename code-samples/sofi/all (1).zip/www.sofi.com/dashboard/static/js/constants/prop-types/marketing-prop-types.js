import PropTypes from 'prop-types';

export const PhotoCardsPropType = PropTypes.arrayOf(PropTypes.shape({
  src: PropTypes.string.isRequired,
  srcSet: PropTypes.string,
  altText: PropTypes.string.isRequired,
  title: PropTypes.string.isRequired,
  description: PropTypes.node.isRequired,
  linkText: PropTypes.string.isRequired,
}));

export const LinkCardPropType = PropTypes.arrayOf(PropTypes.shape({
  linkText: PropTypes.string.isRequired,
  link: PropTypes.string.isRequired,
}));

export const MarketingCardPropType = PropTypes.arrayOf(PropTypes.shape({
  templateName: PropTypes.string.isRequired,
  id: PropTypes.number.isRequired,
  data: PropTypes.shape({
    imgSrc: PropTypes.string.isRequired,
    imgSrcSet: PropTypes.string.isRequired,
    altText: PropTypes.string.isRequired,
    title: PropTypes.string.isRequired,
    description: PropTypes.string.isRequired,
  }),
}));



// WEBPACK FOOTER //
// ./src/constants/prop-types/marketing-prop-types.js