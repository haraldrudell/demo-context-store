export const GET_TRACKING_BANNER = 'tracking-banner:GET_TRACKING_BANNER';



// WEBPACK FOOTER //
// ./src/constants/tracking-banner-constants.js