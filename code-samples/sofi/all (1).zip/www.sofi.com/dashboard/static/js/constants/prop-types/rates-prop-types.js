import PropTypes from 'prop-types';

const ratesShape = PropTypes.shape({
  minFixRate: PropTypes.number,
  minVarRate: PropTypes.number,
  minVarRateLibor: PropTypes.number,
  maxFixRatex: PropTypes.number,
  maxVarRate: PropTypes.number,
  libor: PropTypes.number,
  minRateCap: PropTypes.number,
  maxRateCap: PropTypes.number,
  benefitAmount: PropTypes.number,
});

export const RatesPropTypes = {
  customer: PropTypes.shape({
    appleEmployee: PropTypes.bool,
  }),
  rates: PropTypes.shape({
    REFI: ratesShape,
    PL: ratesShape,
    MORT: ratesShape,
    PARENT: ratesShape,
  }),
  version: PropTypes.string,
};



// WEBPACK FOOTER //
// ./src/constants/prop-types/rates-prop-types.js