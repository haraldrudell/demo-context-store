import PropTypes from 'prop-types';

export const NpsSurveyPropTypes = PropTypes.shape({
  name: PropTypes.string,
  needsSurvey: PropTypes.bool,
  survey: PropTypes.shape({
    name: PropTypes.string,
    title: PropTypes.string,
    questions: PropTypes.arrayOf(PropTypes.shape({
      id: PropTypes.number,
      questionType: PropTypes.string,
      question: PropTypes.string,
      questionOrder: PropTypes.number,
      choices: PropTypes.arrayOf(PropTypes.shape({
        id: PropTypes.number,
        choice: PropTypes.string,
        displayOreder: PropTypes.number,
      })),
      required: PropTypes.bool,
      answer: PropTypes.string,
    })),
  }),
});



// WEBPACK FOOTER //
// ./src/constants/prop-types/nps-survey-prop-types.js