export const GET_STATES = 'states:GET_STATES';



// WEBPACK FOOTER //
// ./src/constants/states-constants.js