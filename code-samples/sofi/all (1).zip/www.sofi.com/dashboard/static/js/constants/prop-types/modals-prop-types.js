import PropTypes from 'prop-types';

export const QueryParamPropTypes = PropTypes.shape({
  action: PropTypes.string.isRequired,
  appId: PropTypes.number,
  appType: PropTypes.string.isRequired,
  applicantCount: PropTypes.number.isRequired,
  reason: PropTypes.string.isRequired,
});



// WEBPACK FOOTER //
// ./src/constants/prop-types/modals-prop-types.js