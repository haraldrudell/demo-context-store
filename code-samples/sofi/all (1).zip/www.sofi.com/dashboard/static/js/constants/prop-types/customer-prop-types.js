import PropTypes from 'prop-types';

export const CustomerPropTypes = PropTypes.shape({
  affiliateMembership: PropTypes.string,
  annualIncome: PropTypes.string,
  citizenship: PropTypes.string,
  city: PropTypes.string,
  corporateEmployer: PropTypes.string,
  dobDay: PropTypes.number,
  dobMonth: PropTypes.shape({
    name: PropTypes.string.isRequired,
    shortName: PropTypes.string.isRequired,
    displayName: PropTypes.string.isRequired,
    number: PropTypes.number.isRequired,
  }),
  dobYear: PropTypes.number,
  email: PropTypes.string,
  employer: PropTypes.shape({
    id: PropTypes.number,
    name: PropTypes.string.isRequired,
    subsidiaries: PropTypes.string,
    source: PropTypes.string,
  }),
  employmentStartMonth: PropTypes.shape({
    name: PropTypes.string.isRequired,
    shortName: PropTypes.string.isRequired,
    displayName: PropTypes.string.isRequired,
    number: PropTypes.number.isRequired,
  }),
  employmentStartYear: PropTypes.string,
  employmentStatus: PropTypes.string,
  firstName: PropTypes.string,
  gradCompletionMonth: PropTypes.shape({
    name: PropTypes.string.isRequired,
    shortName: PropTypes.string.isRequired,
    displayName: PropTypes.string.isRequired,
    number: PropTypes.number.isRequired,
  }),
  gradCompletionYear: PropTypes.number,
  gradProgram: PropTypes.number,
  gradUniversity: PropTypes.string,
  hasCreditPull: PropTypes.bool,
  housing: PropTypes.string,
  id: PropTypes.number,
  isAppleEmployee: PropTypes.bool,
  isProfileCurrent: PropTypes.bool,
  isSelfEmployed: PropTypes.bool,
  lastName: PropTypes.string,
  middleName: PropTypes.string,
  military: PropTypes.bool,
  noCollege: PropTypes.bool,
  notGraduatedGrad: PropTypes.bool,
  notGraduatedUndergrad: PropTypes.bool,
  ownership: PropTypes.bool,
  phoneNumber: PropTypes.string,
  profilePreferencesForm: PropTypes.shape({
    marketingEmail: PropTypes.bool.isRequired,
    marketingSms: PropTypes.bool.isRequired,
    marketingAutoDial: PropTypes.bool.isRequired,
    businessSms: PropTypes.bool.isRequired,
    businessAutoDial: PropTypes.bool.isRequired,
  }),
  selfEmployedType: PropTypes.shape({
    displayName: PropTypes.string.isRequired,
    name: PropTypes.string.isRequired,
    ownership: PropTypes.bool.isRequired,
    wageIncome: PropTypes.bool.isRequired,
    year1099: PropTypes.bool.isRequired,
  }),
  state: PropTypes.string,
  street1: PropTypes.string,
  street2: PropTypes.string,
  undergradCompletionMonth: PropTypes.shape({
    name: PropTypes.string.isRequired,
    shortName: PropTypes.string.isRequired,
    displayName: PropTypes.string.isRequired,
    number: PropTypes.number.isRequired,
  }),
  undergradCompletionYear: PropTypes.number,
  undergradProgram: PropTypes.number,
  undergradUniversity: PropTypes.string,
  wageIncome: PropTypes.bool,
  year1099: PropTypes.bool,
  yearsOfExperience: PropTypes.string,
  zip: PropTypes.string,
  waitForCosigner: PropTypes.bool,
  shippingAddress: PropTypes.shape({
    address: PropTypes.string,
    apartment: PropTypes.string,
    city: PropTypes.string,
    state: PropTypes.string,
    postalCode: PropTypes.string,
  }),
});

export const ConsentsPropTypes = PropTypes.shape({
  consents: PropTypes.bool,
});



// WEBPACK FOOTER //
// ./src/constants/prop-types/customer-prop-types.js