export const GET_DPA = 'apple:GET_DPA';
export const POST_DPA = 'apple:POST_DPA';



// WEBPACK FOOTER //
// ./src/constants/dpa-constants.js