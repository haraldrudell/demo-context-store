import PropTypes from 'prop-types';

export const WealthProfilePropTypes = PropTypes.shape({
  accountId: PropTypes.number,
  accountStrategy: PropTypes.string,
  accountTypeDescription: PropTypes.string,
  contributions: PropTypes.array,
  holdings: PropTypes.array,
  statistics: PropTypes.shape({}), // TODO: Update this
  ctaInfo: PropTypes.shape({
    subText: PropTypes.string,
    cta: PropTypes.string,
    ctaLink: PropTypes.string,
  }),
  funded: PropTypes.bool,
  completed: PropTypes.bool,
  isNew: PropTypes.bool,
});



// WEBPACK FOOTER //
// ./src/constants/prop-types/wealth-prop-types.js