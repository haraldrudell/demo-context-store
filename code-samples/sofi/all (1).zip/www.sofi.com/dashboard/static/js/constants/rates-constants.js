export const GET_RATES = 'rates:GET_RATES';



// WEBPACK FOOTER //
// ./src/constants/rates-constants.js