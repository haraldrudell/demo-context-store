import { Link } from 'react-router-dom';
import { HyperLink, FlexBox } from 'scuid-x';
import breakpoint from 'scuid-x/styles/breakpoint';
import styled from 'styled-components';

/**
 * React Router Link styled the same way as SCUID-X HyperLink
 */
export const RouterLink = styled(Link)`
  text-decoration: none;
  color: #1a7bb3;
  font-weight: 500;
  &:hover {
    color: #103955;
  }
`;

/**
 * Anchor tag (a) from SCUID-X
 */
export const ScuidLink = styled(HyperLink)`
  text-decoration: none;
  &:hover {
    text-decoration: none;
  }
`;

/**
 * FlexBox that breaks at 767px
 */
export const StyledFlexBox = styled(FlexBox)`
  @media screen and (max-width: ${breakpoint.small}) {
    flex-direction: column;
  }
`;

/**
 * Responsive Modal Content, all it does is give the content a min-width
 * so that it's width is not too small on big screens
 */
export const ResponsiveModalContent = styled.div`
  @media (min-width: 768px) {
    min-width: 600px;
  }
`;

/**
 * Responsive Modal Footer when you have two actions (buttons) in your Modal
 * If your action labels have small lengths (example just 'Yes' + 'No'), you may not need this
 * because you may not run into responsive issues
 */
export const ResponsiveModalFooter = styled.div`
  @media (max-width: 767px) {
    display: flex;
    flex-direction: column;

    button {
      width: 100%;
      margin-left: 0;

      &:first-child {
        margin-bottom: 10px;
      }
    }
  }
`;



// WEBPACK FOOTER //
// ./src/utilities/global-styles.js