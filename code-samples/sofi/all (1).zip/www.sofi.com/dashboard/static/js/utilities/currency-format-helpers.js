// To replace formatCurrency
export const FORMAT_CURRENCY = (val) => {
  const num = Number(val);
  if (num < 0) {
    // Handle negative formatting
    return `-$${Math.abs(num).toFixed(2).replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1,')}`;
  }
  return `$${num.toFixed(2).replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1,')}`;
};



// WEBPACK FOOTER //
// ./src/utilities/currency-format-helpers.js