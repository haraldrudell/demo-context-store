/**
 * Returns the session value as a boolean
 * @param {String} key name of the session for the specific alert being dismissed
 */
export const getAlertSessionKey = (key) => {
  const res = sessionStorage.getItem(key);
  const sessionBool = (res === 'true');
  return sessionBool;
};

/**
 * Sets the session key/value to hide alert
 * @param {String} key name of the session for the specific alert being dismissed
 */
export const setAlertDismissableSession = (key) => {
  const value = true;
  sessionStorage.setItem(key, value);
};



// WEBPACK FOOTER //
// ./src/utilities/session-storage-helpers.js