import {
  LAUNCH_DARKLY_CLIENT_ID_PROD,
  LAUNCH_DARKLY_CLIENT_ID_STAGING,
  LAUNCH_DARKLY_CLIENT_ID_TEST,
} from '../constants/launch-darkly-constants';

/**
 * Get the LaunchDarkly client id
 *
 * @returns string environment id
 */
export const getClientId = () => {
  const windowLocationHostName = window.location.hostname;
  if (windowLocationHostName === 'www.sofi.com') {
    return LAUNCH_DARKLY_CLIENT_ID_PROD;
  } else if (windowLocationHostName === 'www.sofitest.com') {
    return LAUNCH_DARKLY_CLIENT_ID_STAGING;
  }
  return LAUNCH_DARKLY_CLIENT_ID_TEST;
};

/**
 * Get the LaunchDarkly user
 *
 * @param customer the customer data object
 * @returns {{key: string}} the LaunchDarkly user object
 */
export const getUser = customer => ({ key: `${customer.id}` });



// WEBPACK FOOTER //
// ./src/utilities/launch-darkly-helpers.js