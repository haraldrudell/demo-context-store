import axios from 'axios';
import { createAction } from 'redux-actions';

import { getCookie } from './cookie-helpers';
import { errorLogger, createError } from './error-handling';
import { urlExceptions } from './redirect-helpers';

/**
 * Unauthorized check
 * @param {Object} error Response object from axios
 */
const handleExceptions = (error) => {
  const res = error.response;
  if (res && process.env.NODE_ENV !== 'development' && !urlExceptions.includes(window.location.hash)) {
    // Logout if unauthorized or CustomerNotFound
    if (res.status === 401) {
      window.location.assign('/b/logout?flash=timeout');
      return true;
    } else if (res.status === 400 && res.data && res.data.globalErrorCode === 'customer.notFound') {
      window.location.assign('/b/logout?flash=unexpected');
      return true;
    }
  }
  return false;
};

/**
 * Mapping server-side validation errors to formik acceptable error object
 */
export const mapServerSideErrorsToFormikErrors = (fromServer) => {
  const { response: { data: serverSideErrors } } = fromServer;
  if (!serverSideErrors) return {};
  const errors = {
    globalError: serverSideErrors.globalError ? serverSideErrors.globalError : serverSideErrors,
    globalErrorCode: serverSideErrors.globalErrorCode || null,
  };
  const { fieldErrors } = serverSideErrors;
  if (fieldErrors) {
    fieldErrors.forEach((error) => {
      let newErrorMessage;
      if (errors[error.errorCode]) {
        newErrorMessage = `${errors[error.errorCode]}\n${error.message}`;
      } else {
        newErrorMessage = error.message;
      }
      errors[error.errorCode] = newErrorMessage;
    });
  }
  return errors;
};

/**
 * Performs a request with `get` http method.
 */
export const performGet = async (dispatch, url, requestOptions, actionBase, notifyOnGlobalError) => {
  const startAction = createAction(`${actionBase}:GET_START`);
  const successAction = createAction(`${actionBase}:GET_SUCCESS`);
  const errorAction = createAction(`${actionBase}:GET_ERROR`);

  dispatch(startAction());
  try {
    const res = await axios.get(url, { ...requestOptions, withCredentials: true });
    dispatch(successAction(res.data));
    dispatch(createAction('SET_GLOBAL_ERROR:NONE')({ url }));
  } catch (e) {
    // Log GET errors to Newrelic
    errorLogger(createError('GET', e));
    if (!handleExceptions(e)) {
      if (notifyOnGlobalError && e.response && e.response.data && e.response.data.globalError) {
        dispatch(createAction('SET_GLOBAL_ERROR')({ url, data: e.response.data }));
      }
      dispatch(errorAction(e));
    }
  }
};

/**
 * Performs a request with `delete` http method.
 */
export const performDelete = async (dispatch, url, requestOptions, actionBase, notifyOnGlobalError) => {
  const startAction = createAction(`${actionBase}:DELETE_START`);
  const successAction = createAction(`${actionBase}:DELETE_SUCCESS`);
  const errorAction = createAction(`${actionBase}:DELETE_ERROR`);

  dispatch(startAction());
  try {
    const res = await axios.delete(url, { ...requestOptions, withCredentials: true });
    dispatch(successAction(res.data));
    dispatch(createAction('SET_GLOBAL_ERROR:NONE')({ url }));
  } catch (e) {
    // Log DELETE errors to Newrelic
    errorLogger(createError('DELETE', e));
    if (!handleExceptions(e)) {
      if (notifyOnGlobalError && e.response && e.response.data && e.response.data.globalError) {
        dispatch(createAction('SET_GLOBAL_ERROR')({ url, data: e.response.data }));
      }
      dispatch(errorAction(e));
    }
  }
};

/**
 * Performs a request with `post` http method.
 */
export const performPost = async (dispatch, url, requestOptions, body, actionBase, setErrors) => {
  const startAction = createAction(`${actionBase}:POST_START`);
  const successAction = createAction(`${actionBase}:POST_SUCCESS`);
  const errorAction = createAction(`${actionBase}:POST_ERROR`, undefined, setErrors);

  dispatch(startAction());
  try {
    const res = await axios.post(url, body, {
      ...requestOptions,
      withCredentials: true,
      headers: { 'Csrf-Token': getCookie('SOFI_R_CSRF_TOKEN') },
    });
    dispatch(successAction(res.data));
  } catch (e) {
    // Log POST errors to Newrelic
    errorLogger(createError('POST', e));
    if (!handleExceptions(e)) {
      dispatch(errorAction(e));
    }
  }
};

/**
 * Performs a request with `put` http method.
 */
export const performPut = async (dispatch, url, requestOptions, body, actionBase, setErrors) => {
  const startAction = createAction(`${actionBase}:PUT_START`);
  const successAction = createAction(`${actionBase}:PUT_SUCCESS`);
  const errorAction = createAction(`${actionBase}:PUT_ERROR`, undefined, setErrors);

  dispatch(startAction());
  try {
    const res = await axios.put(url, body, {
      ...requestOptions,
      withCredentials: true,
      headers: { 'Csrf-Token': getCookie('SOFI_R_CSRF_TOKEN') },
    });
    dispatch(successAction(res.data));
  } catch (e) {
    // Log PUT errors to Newrelic
    errorLogger(createError('PUT', e));
    if (!handleExceptions(e)) {
      dispatch(errorAction(e));
    }
  }
};



// WEBPACK FOOTER //
// ./src/utilities/api-action-helpers.js