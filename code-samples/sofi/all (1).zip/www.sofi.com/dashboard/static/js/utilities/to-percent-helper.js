import round from 'lodash/round';

/**
 * Returns a percentage. Eg. 4 becomes 4.00%
 * @param {number} num - Input number to add % suffix to
 */
export const toPercent = (num) => {
  const roundNumber = round(num, 4);
  const decimalPart = String(roundNumber).split('.')[1];

  if (!decimalPart || decimalPart.length <= 2) {
    return `${roundNumber.toFixed(2)}%`;
  }

  return `${roundNumber.toFixed(decimalPart.length)}%`;
};



// WEBPACK FOOTER //
// ./src/utilities/to-percent-helper.js