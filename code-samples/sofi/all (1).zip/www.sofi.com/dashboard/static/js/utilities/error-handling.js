/**
 * @param {Object} err is the error response object with more helpful information for reporting service
 */
export const errorLogger = (err) => {
  /* eslint-disable */
  if ('newrelic' in window) {
    newrelic.noticeError(err);
  }
  if ('Rollbar' in window) {
    Rollbar.error(err);
  }
};

/**
 * Returns a new Error consumed by newrelic
 * @param {Object} err Error object from Axios
 */
export const createError = (prefix, err) => {
  try {
    const { response } = err;
    const error = new Error(
      `${prefix} ${err.message}${
        response && response.data && response.data.globalErrorCode ? ` with globalErrorCode: ${response.data.globalErrorCode}` : ''
      }${response && response.request && response.request.responseURL ? ` for URL ${response.request.responseURL}` : ''} at ${
        window.location.hash || 'localhost'
      }`,
    );
    return error;
  } catch (err) {
    const error = new Error(`Error in createError: ${err.message}`);
    return error;
  }
};



// WEBPACK FOOTER //
// ./src/utilities/error-handling.js