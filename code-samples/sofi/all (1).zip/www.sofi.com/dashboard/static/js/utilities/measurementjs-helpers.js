const MJS = window._mjs; // eslint-disable-line no-underscore-dangle

/**
 * Provides context to mjs
 * @param {Object} customer Our customer object
 */
export const prepareMjs = (customer) => {
  const mjsObject = {
    mjs_app_type: '',
    mjs_app_id: '',
    mjs_user_id: customer.id.toString(),
    mjs_email: customer.email,
    mjs_first_name: customer.firstName,
    mjs_last_name: customer.lastName,
    mjs_zip_code: customer.zip || '',
    mjs_phone: customer.phoneNumber || '',
  };
  if (MJS) MJS.prepare(mjsObject);
};

/**
 * When declines happen for any reason
 * @param {Object} event { event: String, mjs_app_id: Number, mjs_app_type: String }
 */
export const fireEvent = (event) => {
  if (MJS) MJS.fire(event);
};

/**
 * Click events/interactions
 * @param {Array<String>} args We get 4 parameter here
 */
export const fireInteraction = (...args) => {
  if (MJS) MJS.fireInteraction(...args);
};



// WEBPACK FOOTER //
// ./src/utilities/measurementjs-helpers.js