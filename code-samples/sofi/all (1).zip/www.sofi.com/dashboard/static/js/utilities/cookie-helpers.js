/**
 * Finds and returns the cookie if it exists
 * @param {string} cname Cookie name
 */
export const getCookie = (cname) => {
  const name = `${cname}=`;
  const cookies = document.cookie.split(';');
  for (let i = 0; i < cookies.length; i += 1) {
    let cookie = cookies[i];
    while (cookie.charAt(0) === ' ') {
      cookie = cookie.substring(1);
    }
    if (cookie.indexOf(name) === 0) {
      return cookie.substring(name.length, cookie.length);
    }
  }
  return '';
};

/**
 * Sets an error cookie
 * @param {string} value Name of the error
 * @param {number} expireSeconds Cookie expiration time
 */
export const setErrorCookie = (value, expireSeconds) => {
  const d = new Date();
  const expireMilliseconds = expireSeconds * 1000;
  d.setTime(d.getTime() + expireMilliseconds);
  const expires = `expires=${d.toUTCString()}`;
  document.cookie = `ERR_COOKIE=${value}; ${expires}; path=/`;
};

/**
 * Returns any info cookie prefixed 'INFO_COOKIE'
 */
export const getInfoCookie = () => getCookie('INFO_COOKIE');

/**
 * Returns any error cookie prefixed 'ERR_COOKIE'
 */
export const getErrorCookie = () => getCookie('ERR_COOKIE');



// WEBPACK FOOTER //
// ./src/utilities/cookie-helpers.js