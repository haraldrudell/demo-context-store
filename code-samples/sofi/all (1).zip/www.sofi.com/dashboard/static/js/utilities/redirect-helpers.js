export const redirectToTimeout = () => {
  if (process.env.NODE_ENV === 'development') {
    window.location.assign('/#/b/logout?flash=timeout');
  } else {
    window.location.assign('/b/logout?flash=timeout');
  }
};

export const redirectToUnexpected = () => {
  if (process.env.NODE_ENV === 'development') {
    window.location.assign('/#/b/logout?flash=unexpected');
  } else {
    window.location.assign('/b/logout?flash=unexpected');
  }
};

export const redirectToMarbles = () => {
  window.location.assign('/dashboard/#/marbles');
};

export const urlExceptions = ['#/policy/esig', '#/policy/privacy', '#/policy/privacy/ca', '#/policy/arbitration', '#/policy/tcpa'];



// WEBPACK FOOTER //
// ./src/utilities/redirect-helpers.js