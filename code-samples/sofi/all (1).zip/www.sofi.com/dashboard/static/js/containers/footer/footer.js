import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';

/**
 * PropTypes imports
 */
import { CustomerPropTypes } from '../../constants/prop-types/customer-prop-types';
import { RatesPropTypes } from '../../constants/prop-types/rates-prop-types';

/**
 * Action imports
 */
import { getRates } from '../../actions/rates-actions';

/**
 * Component imports
 */
import Footer from '../../components/footer';

class FooterContainer extends Component {
  static propTypes = {
    customer: CustomerPropTypes.isRequired,
    rates: RatesPropTypes.isRequired,
    loadRates: PropTypes.func.isRequired,
  };

  componentDidMount() {
    const { loadRates } = this.props;
    loadRates();
  }

  render() {
    const { rates, customer } = this.props;

    return <Footer corporateEmployer={customer.corporateEmployer} rates={rates} />;
  }
}

const mapStateToProps = state => ({
  customer: state.customerReducer.customer.data,
  rates: state.ratesReducer.rates.data,
});

const mapDispatchToProps = dispatch => ({
  loadRates: () => dispatch(getRates()),
});

export default connect(mapStateToProps, mapDispatchToProps)(FooterContainer);



// WEBPACK FOOTER //
// ./src/containers/footer/footer.js