import { getErrorCookie, getInfoCookie } from '../../utilities/cookie-helpers';

export const HAS_ERRORS = () => {
  const cookie = getErrorCookie();
  const cookieError = cookie || null;
  return cookieError;
};

export const HAS_INFO = () => {
  const cookie = getInfoCookie();
  const cookieInfo = cookie || null;
  return cookieInfo;
};

export const FIND_IF_STATE_IS_ELIGIBLE = (products) => {
  let eligiblityStatus = false;
  const matchList = ['REFI', 'PL', 'PLUS', 'PARENT'];
  for (let i = 0; i < products.length; i += 1) {
    const p = products[i];
    if (p && !p.eligibility.eligible && matchList.indexOf(p.name) !== -1) {
      // TODO: Redo this map down the road, works for now!
      p.eligibility.reasons.map((r) => {// eslint-disable-line
        if (r.code === 'STATE') {
          eligiblityStatus = true;
          return eligiblityStatus;
        }
      });
    }
  }
  return eligiblityStatus;
};

export const NPS_SURVEY_SELECT_OPTIONS = (data) => {
  const { choices } = data;
  const options = choices.map(value => ({ value: String(value.id), label: value.choice }));
  return options;
};

const ORIGINAL_SELECT_OPTIONS = [
  { id: 12, choice: 'Student Loan Refinancing', displayOrder: 1 },
  { id: 13, choice: 'MBA Loan (In-School)', displayOrder: 2 },
  { id: 14, choice: 'Mortgage', displayOrder: 3 },
  { id: 15, choice: 'Parent Loan', displayOrder: 4 },
  { id: 16, choice: 'Personal Loan', displayOrder: 5 },
  { id: 17, choice: 'Wealth', displayOrder: 6 },
];

// REBUILD NPS SURVEY OBJECT
const buildChosenProductAnswerObj = (option) => {
  const numOption = Number(option);
  const selectedObj = ORIGINAL_SELECT_OPTIONS.filter(obj => numOption === obj.id);
  return selectedObj[0].choice;
};

export const REBUILD_SURVEY_OBJECT = (data, originalData) => {
  const chosenProductAnswer = data.chosenProduct ? buildChosenProductAnswerObj(data.chosenProduct) : null;
  const newSurveyObject = {
    name: originalData.name,
    needsSurvey: false,
    survey: {
      name: originalData.survey.name,
      title: originalData.survey.title,
      questions: [
        {
          id: originalData.survey.questions[0].id,
          questionType: originalData.survey.questions[0].questionType,
          question: originalData.survey.questions[0].question,
          questionOrder: originalData.survey.questions[0].questionOrder,
          choices: originalData.survey.questions[0].choices,
          required: originalData.survey.questions[0].required,
          answer: data.radioChoiceRating,
        },
        {
          id: originalData.survey.questions[1].id,
          questionType: originalData.survey.questions[1].questionType,
          question: originalData.survey.questions[1].question,
          questionOrder: originalData.survey.questions[1].questionOrder,
          choices: originalData.survey.questions[1].choices,
          required: originalData.survey.questions[1].required,
          answer: chosenProductAnswer,
        },
        {
          id: originalData.survey.questions[2].id,
          questionType: originalData.survey.questions[2].questionType,
          question: originalData.survey.questions[2].question,
          questionOrder: originalData.survey.questions[2].questionOrder,
          choices: originalData.survey.questions[2].choices,
          required: originalData.survey.questions[2].required,
          answer: data.feedbackComment,
        },
        {
          id: originalData.survey.questions[3].id,
          questionType: originalData.survey.questions[3].questionType,
          question: originalData.survey.questions[3].question,
          questionOrder: originalData.survey.questions[3].questionOrder,
          choices: originalData.survey.questions[3].choices,
          required: originalData.survey.questions[3].required,
          answer: data.recommendationComment,
        },
      ],
    },
  };
  return newSurveyObject;
};

// REBUILD WHERE HEARD SURVEY OBJECT
export const REBUILD_WHERE_HEARD_SURVEY_OBJECT = (data, originalData) => {
  const newSurveyObject = {
    name: originalData.name,
    needsSurvey: false,
    survey: {
      name: originalData.survey.name,
      title: originalData.survey.title,
      questions: [
        {
          id: originalData.survey.questions[0].id,
          questionType: originalData.survey.questions[0].questionType,
          question: originalData.survey.questions[0].question,
          questionOrder: originalData.survey.questions[0].questionOrder,
          choices: originalData.survey.questions[0].choices,
          required: originalData.survey.questions[0].required,
          answer: data,
        },
      ],
    },
  };
  return newSurveyObject;
};

// RANDOMIZE AND DETERMINE PROPERTY TO SEND MEMBER TO FOR REVIEW IF RATING IS >= 9
export const DETERMINE_REVIEW_URL = () => {
  const roll = Math.floor(Math.random() * 9);
  let referralObj = {};
  switch (roll) {
    case 0:
      referralObj = {
        reviewUrl: 'https://www.creditkarma.com/reviews/student-loan/single/id/sofi-student-loan',
        reviewText: 'REVIEW SOFI ON CREDIT KARMA',
      };
      break;
    case 1:
      referralObj = {
        reviewUrl: 'http://whitecoatinvestor.com/new-players-in-student-loan-refinancing/',
        reviewText: 'REVIEW SOFI ON WHITE COAT INVESTOR',
      };
      break;
    case 2:
      referralObj = {
        reviewUrl: 'http://studentloansherpa.com/sofi-aka-social-finance-inc-student-loan-review/#comments',
        reviewText: 'REVIEW SOFI ON STUDENT LOAN SHERPA',
      };
      break;
    case 3:
      referralObj = {
        reviewUrl: 'https://www.lendingtree.com/loan-companies/sofi-reviews-28905',
        reviewText: 'REVIEW SOFI ON LENDING TREE',
      };
      break;
    case 4:
      referralObj = {
        reviewUrl: 'http://www.yelp.com/biz/sofi-san-francisco',
        reviewText: 'REVIEW SOFI ON YELP',
      };
      break;
    case 5:
      referralObj = {
        reviewUrl:
          'https://secure.creditsesame.com/s/public/personal-loans/marketplace/details?' +
          'lender=SOFI&intent=PERSONALLOAN_CARDPAYOFF&loanAmount=5000&loanTerm=THREE_YEARS&scrollSection=DETAILS_REVIEWS',
        reviewText: 'REVIEW SOFI ON CREDIT SESAME',
      };
      break;
    case 6:
      referralObj = {
        reviewUrl: 'http://thebestcompanys.com/loans/company/sofi/',
        reviewText: 'REVIEW SOFI ON THE BEST DEBT COMPANYS',
      };
      break;
    case 7:
      referralObj = {
        reviewUrl: 'https://www.supermoney.com/reviews/personal-loans/sofi',
        reviewText: 'REVIEW SOFI ON SUPERMONEY',
      };
      break;
    default:
      referralObj = { reviewUrl: 'http://www.zillow.com/profile/SoFi-Lending-Corp/Reviews/', reviewText: 'REVIEW SOFI ON ZILLOW' };
      break;
  }
  return referralObj;
};

// Determin whether to display the UPP alert
export const CHECK_UPP_ALERT_NEEDS_DISPLAY = (uppSummary) => {
  const isTrue = uppSummary.some((val) => {
    if (val.enrollmentStatus === 'EMPLOYMENT_VERIFICATION' || val.enrollmentStatus === 'PENDING_FORBEARANCE') {
      return true;
    }
    return false;
  });
  return isTrue;
};

export const GET_VALUE_LABEL_PAIRS = (account) => {
  const pairs = [];
  if (account.topLeftData) {
    pairs.push([account.topLeftData, account.topLeftLabel ? account.topLeftLabel : '']);
  }
  if (account.topRightData) {
    pairs.push([account.topRightData, account.topRightLabel ? account.topRightLabel : '']);
  }
  return pairs;
};



// WEBPACK FOOTER //
// ./src/containers/dashboard/utilities.js