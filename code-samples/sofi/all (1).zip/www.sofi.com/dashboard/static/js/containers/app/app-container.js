import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import debounce from 'lodash/debounce';

/**
 * Measurementjs
 */
import { prepareMjs } from '../../utilities/measurementjs-helpers';

/**
 * PropTypes imports
 */
import { NotificationPropTypes } from '../../constants/prop-types/notifications-prop-types';
import { CustomerPropTypes } from '../../constants/prop-types/customer-prop-types';

/**
 * Action imports
 */
import { getCustomer } from '../../actions/customer-actions';
import { getNotificationsPage, putMarkAllAsRead, putOneNotificationStatus, notificationsState } from '../../actions/notifications-actions';

/**
 * Component imports
 */
import App from '../../components/app';

class AppContainer extends Component {
  static propTypes = {
    customer: CustomerPropTypes.isRequired,
    customerLoaded: PropTypes.bool.isRequired,
    loadCustomer: PropTypes.func.isRequired,
    loadNotification: PropTypes.func.isRequired,
    fetchSuccess: PropTypes.bool.isRequired,
    updateMarkAllAsRead: PropTypes.func.isRequired,
    updateNotification: PropTypes.func.isRequired,
    notifications: PropTypes.arrayOf(NotificationPropTypes).isRequired,
    filteredNotifications: PropTypes.arrayOf(NotificationPropTypes).isRequired,
    updateNotificationsState: PropTypes.func.isRequired,
  };

  state = {
    appInitialized: false,
  };

  componentDidMount() {
    const { loadCustomer } = this.props;

    // Get the customer data
    loadCustomer();
  }

  componentWillReceiveProps(nextProps) {
    if (nextProps.customerLoaded !== this.props.customerLoaded && !this.state.appInitialized) {
      this.setState(() => ({ appInitialized: true }));

      // Prepare MJS
      prepareMjs(nextProps.customer);

      const { loadNotification, updateNotificationsState } = this.props;

      // Get the first page of notifications for the customer
      loadNotification(0).then(() => {
        // We have our initial data
        // Now update redux state with the notifications
        updateNotificationsState(this.props.notifications);
      });

      // start our timeout to get new notifications every 30 seconds
      this.startNotificationRefreshInterval();
    }
  }

  componentWillUnmount() {
    if (this.getNewNotificationsTimer) {
      clearTimeout(this.getNewNotificationsTimer);
      this.getNewNotificationsTimer = undefined;
    }
  }

  /**
   * Our Notification timer property
   */
  getNewNotificationsTimer;

  /**
   * Always gets the first page of notification
   * For our recurring setTimeout
   */
  getFirstNotificationsPage = async () => {
    const { loadNotification } = this.props;
    await loadNotification(0);
    const { fetchSuccess } = this.props;
    if (fetchSuccess) {
      const { updateNotificationsState, notifications, filteredNotifications } = this.props;
      updateNotificationsState([...notifications, ...filteredNotifications]);
    }
  };

  /**
   * Marks notifications with status 'NEW' as 'UNDREAD'
   */
  markNewAsUnread = () => {
    const notifications = this.props.filteredNotifications;

    // Check for notifications with NEW status
    // And mark them as UNREAD
    const unreadArray = [];
    const updatedArray = notifications.map((val) => {
      if (val.status === 'NEW') {
        unreadArray.push(val.notificationID);
      }
      return {
        ...val,
        status: val.status === 'NEW' ? 'UNREAD' : val.status,
      };
    });

    // Make a PUT request to update its status to UNREAD if we have NEW messages
    if (unreadArray.length > 0) {
      this.updateOneNotification(true, unreadArray, 'UNREAD', updatedArray);
    }
  };

  /**
   * Makes a PUT request to update the notification(s) status
   * @param {bool} batch If notificationID is an array of IDs
   * @param {string | array} notificationID Our notificaionID to update (is either one or many)
   * @param {string} status New status for our notification
   * @param {array?} updatedArray Optional array with already updated 'status' supplied if batch is true
   */
  updateOneNotification = async (batch, notificationID, status, updatedArray) => {
    // Stop pinging server for new notifications
    this.stopNotificationRefreshInterval();

    const { updateNotification } = this.props;

    if (!batch) {
      await updateNotification(notificationID, status);
    } else {
      let results = [];

      // Make a maximum of 5 PUT requests at once
      for (let idx = 0; idx < notificationID.length; idx += 1) {
        if (idx !== 0 && idx % 5 === 0) {
          await Promise.all(results); // eslint-disable-line
          results = [];
        }
        results.push(updateNotification(notificationID[idx], status));
      }
      if (results.length > 0) {
        await Promise.all(results);
        results = [];
      }
    }

    // Check if the PUT request was successful
    // If successful, update the state
    const { putOneNotificationSuccess } = this.props;
    if (putOneNotificationSuccess) {
      if (batch) {
        const { updateNotificationsState } = this.props;
        updateNotificationsState(updatedArray);
      } else {
        const { updateNotificationsState, filteredNotifications } = this.props;
        const notifications = filteredNotifications.map(val => ({
          ...val,
          status: val.notificationID === notificationID ? status : val.status,
        }));
        updateNotificationsState(notifications);
      }
    }

    // Resume check for new notifications
    this.startNotificationRefreshInterval();
  };

  /**
   * Mark all the notifications as 'READ'
   */
  markAllAsRead = debounce(
    async () => {
      const { updateMarkAllAsRead } = this.props;
      await updateMarkAllAsRead();

      const { markAllReadSuccess } = this.props;
      if (markAllReadSuccess) {
        const { updateNotificationsState, filteredNotifications } = this.props;
        const notifications = filteredNotifications.map(d => ({ ...d, status: 'READ' }));
        updateNotificationsState(notifications);
      }
    },
    200,
    {
      leading: true,
    },
  );

  /**
   * Mark one notification as 'READ'
   */
  markAsRead = debounce(
    (notification) => {
      if (notification.status !== 'READ') {
        this.updateOneNotification(false, notification.notificationID, 'READ');
      }
    },
    200,
    {
      leading: true,
    },
  );

  /**
   * Starts a recursive setTimeout that pings the server every 30seconds for new notifications
   */
  startNotificationRefreshInterval = () => {
    const self = this;

    // Recursive setTimeout set for 30seconds
    this.getNewNotificationsTimer = setTimeout(async function tick() {
      await self.getFirstNotificationsPage();
      self.getNewNotificationsTimer = setTimeout(tick, 30000);
    }, 30000);
  };

  /**
   * Stops the recursive setTimeout if it is running
   */
  stopNotificationRefreshInterval = () => {
    if (this.getNewNotificationsTimer) {
      clearTimeout(this.getNewNotificationsTimer);
    }
  };

  render() {
    return <App {...this.props} markNewAsUnread={this.markNewAsUnread} markAsRead={this.markAsRead} markAllAsRead={this.markAllAsRead} />;
  }
}

const mapStateToProps = state => ({
  customer: state.customerReducer.customer.data,
  customerLoaded: state.customerReducer.customer.loaded,
  notifications: state.notificationsReducer.notifications.data,
  filteredNotifications: state.notificationsReducer.filteredNotifications,
  fetchSuccess: state.notificationsReducer.notifications.success,
  markAllReadSuccess: state.notificationsReducer.markAllReadSuccess,
  putOneNotificationSuccess: state.notificationsReducer.putOneNotificationSuccess,
  hasNewNotification: state.notificationsReducer.hasNewNotification,
});

const mapDispatchToProps = dispatch => ({
  loadCustomer: () => dispatch(getCustomer()),
  updateNotificationsState: data => dispatch(notificationsState(data)),
  loadNotification: page => dispatch(getNotificationsPage(page)),
  updateMarkAllAsRead: () => dispatch(putMarkAllAsRead()),
  updateNotification: (notificationID, status) => dispatch(putOneNotificationStatus(notificationID, status)),
});

export default connect(mapStateToProps, mapDispatchToProps)(AppContainer);



// WEBPACK FOOTER //
// ./src/containers/app/app-container.js