import React, { Component, Fragment } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { Helmet } from 'react-helmet';
import ReactRouterPropTypes from 'react-router-prop-types';
import { LaunchDarkly } from 'react-launch-darkly';

/**
 * PropTypes imports
 */
import { ConsentsPropTypes, CustomerPropTypes } from '../../constants/prop-types/customer-prop-types';

/**
 * Component imports
 */
import ErrorBoundary from '../../components/error-boundary';
import LoadingComponent from '../../components/loading';
import Alerts from './alerts-container';
import Accounts from './accounts-container';
import Products from './products-container';
import Marketing from './marketing-container';
import Modals from './modals-container';

/**
 * Action imports
 */
import { getConsents, getConsentsTou } from '../../actions/customer-actions';
import { getApplications, getApplicationsServicing, getDashboardAccounts } from '../../actions/application-actions';
import { getProducts } from '../../actions/product-actions';
import { getWealth } from '../../actions/wealth-actions';
import { getReferralSummary, getReferralConsents } from '../../actions/referral-actions';
import { getBanking } from '../../actions/banking-actions';
import { getClientId, getUser } from '../../utilities/launch-darkly-helpers';

/**
 * Displays the dashboard including Accounts, Offerings, and Marketing
 */
class DashboardContainer extends Component {
  static propTypes = {
    loadConsents: PropTypes.func.isRequired,
    loadApplications: PropTypes.func.isRequired,
    loadServicing: PropTypes.func.isRequired,
    loadProducts: PropTypes.func.isRequired,
    applicationsLoaded: PropTypes.bool.isRequired,
    customerLoaded: PropTypes.bool.isRequired,
    productsLoaded: PropTypes.bool.isRequired,
    loadWealth: PropTypes.func.isRequired,
    loadConsentsTou: PropTypes.func.isRequired,
    loadReferralSummary: PropTypes.func.isRequired,
    loadReferralConsents: PropTypes.func.isRequired,
    consents: ConsentsPropTypes.isRequired,
    history: ReactRouterPropTypes.history.isRequired,
    loadBanking: PropTypes.func.isRequired,
    dashboardAccountsLoaded: PropTypes.bool.isRequired,
    loadDashboardAccounts: PropTypes.func.isRequired,
    customer: CustomerPropTypes.isRequired,
  };

  state = {
    ssnPopupMessage: null,
  };

  componentDidMount() {
    const {
      loadConsents,
      loadApplications,
      loadServicing,
      loadProducts,
      loadWealth,
      loadConsentsTou,
      loadReferralSummary,
      loadReferralConsents,
      loadBanking,
    } = this.props;

    /**
     * Load consents
     */
    loadConsents();

    /**
     * Specific to Your Accounts section
     */
    loadWealth();
    loadBanking(); // Accounts and Offerings both
    loadApplications();
    loadProducts(); // Offerings section only
    loadServicing();
    loadConsentsTou();
    loadReferralSummary();
    loadReferralConsents();
  }

  componentWillReceiveProps(nextProps) {
    /**
     * Check for consents
     * If the customer hasn't consented go to /consents
     */
    if (nextProps.consents && nextProps.consents !== this.props.consents) {
      const { consents } = nextProps;
      if (!consents.consents) {
        this.props.history.push('/consents');
      }
    }
  }

  componentWillUnmount() {
    if (this.popUpTimer) {
      clearTimeout(this.popUpTimer);
      this.popUpTimer = undefined;
    }
  }

  // Availing the timer here so we can clear it when user navigates away from page
  popUpTimer;

  // Trigger display for SSN Alert
  triggerAlert = () => {
    this.setState({ ssnPopupMessage: 'nocredit' });
    const self = this;
    this.popUpTimer = setTimeout(() => {
      self.setState({ ssnPopupMessage: null });
    }, 30000);
  };

  render() {
    const {
      applicationsLoaded, customerLoaded, productsLoaded,
    } = this.props;

    const { ssnPopupMessage } = this.state;

    // Show Loading screen if we do not have customer, and products info
    if (!customerLoaded || !applicationsLoaded) return <LoadingComponent />;
    return (
      <LaunchDarkly clientId={getClientId()} user={getUser(this.props.customer)}>
        <Fragment>
          <Helmet>
            <title>SoFi - My Home</title>
          </Helmet>

          {/* Modals */}
          <Modals {...this.props} triggerAlert={this.triggerAlert} />

          {/* Alerts */}
          <Alerts {...this.props} ssnPopupMessage={ssnPopupMessage} />

          {/* Accounts */}
          <ErrorBoundary>
            <Accounts {...this.props} />
          </ErrorBoundary>

          {/* Offerings */}
          <ErrorBoundary>{productsLoaded && <Products {...this.props} />}</ErrorBoundary>

          {/* Marketing */}
          <ErrorBoundary>
            <Marketing {...this.props} />
          </ErrorBoundary>
        </Fragment>
      </LaunchDarkly>
    );
  }
}

const mapStateToProps = state => ({
  consents: state.customerReducer.consents.data,
  customer: state.customerReducer.customer.data,
  customerLoaded: state.customerReducer.customer.loaded,
  applications: state.applicationReducer.applications.data,
  applicationsLoaded: state.applicationReducer.applications.loaded,
  dashboardAccounts: state.applicationReducer.dashboardAccounts.data,
  dashboardAccountsLoaded: state.applicationReducer.dashboardAccounts.loaded,
  products: state.productReducer.products.data,
  productsLoaded: state.productReducer.products.loaded,
  wealth: state.wealthReducer.wealth.data,
  wealthLoaded: state.wealthReducer.wealth.loaded,
  consentsTou: state.customerReducer.consentsTou.data,
  referralSummary: state.referralReducer.referralSummary.data,
  referralSummaryLoaded: state.referralReducer.referralSummary.loaded,
  referralConsents: state.referralReducer.referralConsents.data,
  referralConsentsLoaded: state.referralReducer.referralConsents.loaded,
  banking: state.bankingReducer.banking.data,
  bankingLoaded: state.bankingReducer.banking.loaded,
});

const mapDispatchToProps = dispatch => ({
  loadConsents: () => dispatch(getConsents()),
  loadApplications: () => dispatch(getApplications()),
  loadServicing: () => dispatch(getApplicationsServicing()),
  loadProducts: () => dispatch(getProducts()),
  loadWealth: () => dispatch(getWealth()),
  loadConsentsTou: () => dispatch(getConsentsTou()),
  loadReferralSummary: () => dispatch(getReferralSummary()),
  loadReferralConsents: () => dispatch(getReferralConsents()),
  loadBanking: () => dispatch(getBanking()),
  loadDashboardAccounts: () => dispatch(getDashboardAccounts()),
});

export default connect(mapStateToProps, mapDispatchToProps)(DashboardContainer);



// WEBPACK FOOTER //
// ./src/containers/dashboard/dashboard-container.js