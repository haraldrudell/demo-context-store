import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';

/**
 * Action imports
 */
import { getKickdog } from '../../actions/timeout-actions';

/**
 * Component imports
 */
import TimeoutModal from '../../components/timeout';

const TimeoutContainer = ({ kickdog }) => (
  <TimeoutModal kickdog={kickdog} />
);

TimeoutContainer.propTypes = {
  kickdog: PropTypes.func.isRequired,
};

const mapStateToProps = () => ({});

const mapDispatchToProps = dispatch => ({
  kickdog: () => dispatch(getKickdog()),
});

export default connect(mapStateToProps, mapDispatchToProps)(TimeoutContainer);



// WEBPACK FOOTER //
// ./src/containers/timeout/timeout.js