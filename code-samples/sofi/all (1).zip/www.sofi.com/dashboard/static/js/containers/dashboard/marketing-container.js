import React, { Fragment, Component } from 'react';
import styled from 'styled-components';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';
import { FeatureFlag } from 'react-launch-darkly';

/**
 * Image imports
 */
// TODO remove images after successful release with LD
import EventsImage1x from '../../assets/img/EventsImage@1x.png';
import EventsImage2x from '../../assets/img/EventsImage@2x.png';

import SocialEvents1x from '../../assets/img/SocialComparison@1x.png';
import SocialEvents2x from '../../assets/img/SocialComparison@2x.png';

import MortgageAd1x from '../../assets/img/CrossSellImage-SoFi-Mortgages@1x.jpg';
import MortgageAd2x from '../../assets/img/CrossSellImage-SoFi-Mortgages@2x.jpg';

/**
 * Component imports
 */
// TODO remove component after successful release with LD
import MarketingComponent from '../../components/marketing/';

/**
 * Styled components
 */
import { ScuidLink } from '../../utilities/global-styles';

// dashboard content card release dependencies
import { MarketingCardPropType } from '../../constants/prop-types/marketing-prop-types';
import { getMarketingCards } from '../../actions/marketing-cards-actions';
import MarketingCards from '../../components/marketing/marketing-cards';
import { FEATURE_FLAG_DASHBOARD_CONTENT_CARDS } from '../../constants/launch-darkly-constants';

const Container = styled.div`
  max-width: 1240px;
  margin: 0px auto;
  padding: 30px 20px 30px 20px;
`;

const Marketing = styled.div`
  display: flex;
  flex-wrap: wrap;
  list-style-type: none;
  margin: 0px;
  padding: 0px;
`;

const EventsLink = ScuidLink.extend`
  font-size: 0.88rem;
  font-weight: 400;
`;

// holds all the marketing card with images
const photoCards = [
  {
    src: EventsImage1x,
    srcSet: `${EventsImage1x} 1x, ${EventsImage2x} 2x`,
    altText: 'SoFi Events',
    title: 'Join us for an event in your city',
    description: (
      <Fragment>
        Discover happy hours, educational events, and member dinners happening in your neighborhood. Questions or concerns? Email{' '}
        <EventsLink data-qa="dashboard-marketing-events-link" href="mailto:events@sofi.com">events@sofi.com</EventsLink>
      </Fragment>
    ),
    linkText: '', // has been removed for now
    linkHref: `${window.location.origin}/events`,
  },
  {
    src: SocialEvents1x,
    srcSet: `${SocialEvents1x} 1x, ${SocialEvents2x} 2x`,
    altText: 'Social Comparison',
    title: 'Social Comparison',
    description: 'See how you compare to other SoFi members.',
    linkText: 'Compare now',
    linkHref: `${window.location.origin}/b/social-compare`,
  },
  {
    src: 'https://unsplash.it/380/174',
    altText: 'Apple Employer',
    title: 'Apple Subsidized Student Loan Refi for Spouse or Domestic Partner',
    description: 'Register your spouse or domestic partner to refinance his or her student loan with the Apple subsidy.',
    linkText: '+ Spouse/Domestic partner',
    linkHref: '/apple/spouse',
  },
  {
    src: MortgageAd1x,
    srcSet: `${MortgageAd1x} 1x, ${MortgageAd2x} 2x`,
    altText: 'choose your mortgage terms',
    title: 'SoFi Mortgages',
    description: '10% down. 100% home. Discounted member rates. Mortgages up to $3M with no origination fees or borrower-paid private mortgage insurance.',
    linkText: 'See your rate in 2 min',
    linkHref: '/mortgage-loan/',
  },
];

// holds the marketing with the links
const links = [
  {
    linkText: 'See upcoming events',
    link: 'https://www.sofi.com/events/',
  },
  {
    linkText: 'Explore our blog',
    link: 'https://www.sofi.com/blog/',
  },
  {
    linkText: 'Contact Career Advisory Group',
    link: `${window.location.origin}/career-assistance/`,
  },
];

class MarketingContainer extends Component {
  static propTypes = {
    marketingCards: MarketingCardPropType.isRequired,
    loadMarketingCards: PropTypes.func.isRequired,
    marketingCardsLoaded: PropTypes.bool.isRequired,
  }

  componentDidMount() {
    const { loadMarketingCards } = this.props;
    loadMarketingCards();
  }

  render() {
    const { marketingCards, marketingCardsLoaded } = this.props;
    return (
      <Container>
        <Marketing>
          <FeatureFlag
            flagKey={FEATURE_FLAG_DASHBOARD_CONTENT_CARDS}
            renderFeatureCallback={() => (
              <MarketingCards marketingCards={marketingCards} marketingCardsLoaded={marketingCardsLoaded} />
                )}
            renderDefaultCallback={() => (
              <MarketingComponent photoCards={photoCards} links={links} {...this.props} />
              )}
          />
        </Marketing>
      </Container>
    );
  }
}

const mapStateToProps = state => ({
  marketingCards: state.marketingCardsReducer.marketingCards.data,
  marketingCardsLoaded: state.marketingCardsReducer.marketingCards.loaded,
});

const mapDispatchToProps = dispatch => ({
  loadMarketingCards: () => dispatch(getMarketingCards()),
});

export default connect(mapStateToProps, mapDispatchToProps)(MarketingContainer);



// WEBPACK FOOTER //
// ./src/containers/dashboard/marketing-container.js