import React from 'react';
import PropTypes from 'prop-types';
import styled from 'styled-components';
import { FeatureFlag } from 'react-launch-darkly';

/**
 * PropTypes imports
 */
import { ProductsPropTypes } from '../../constants/prop-types/products-prop-types';
import { CustomerPropTypes } from '../../constants/prop-types/customer-prop-types';
import { BankingPropTypes } from '../../constants/prop-types/banking-prop-types';

/**
 * Component imports
 */
import ProductsComponent from '../../components/products';

import { FEATURE_FLAG_MEMBER_DASHBOARD_CMS_PRODUCT_OFFERINGS } from '../../constants/launch-darkly-constants';

/**
 * Styled components
 */
const Container = styled.div`
  max-width: 1240px;
  margin: 0px auto;
  padding-left: 20px;
  padding-right: 20px;
`;

const Header = styled.h6`
  font-size: 0.8rem;
  font-weight: 700;
  line-height: 1.28;
  letter-spacing: 0.1rem;
  color: #262626;
  padding-top: 20px;
  padding-bottom: 10px;
`;

const Offerings = styled.div`
  display: flex;
  flex-flow: row wrap;
  align-content: flex-end;
  margin: 0px;
  padding: 0px;
`;


/**
 * May change into a Container in the future
 */
const Products = ({
  customer, products, banking, bankingLoaded,
}) => (
  <Container>
    <Header>OUR OFFERINGS</Header>
    <FeatureFlag
      flagKey={FEATURE_FLAG_MEMBER_DASHBOARD_CMS_PRODUCT_OFFERINGS}
      renderFeatureCallback={() => (
          // TODO new product cards go here
        <Offerings>
          <ProductsComponent
            customer={customer}
            products={products}
            banking={banking}
            bankingLoaded={bankingLoaded}
          />
        </Offerings>
                      )}
      renderDefaultCallback={() => (
        <Offerings>
          <ProductsComponent
            customer={customer}
            products={products}
            banking={banking}
            bankingLoaded={bankingLoaded}
          />
        </Offerings>
                    )}
    />
  </Container>
);

/* eslint react/no-typos: 0 */
Products.propTypes = {
  customer: CustomerPropTypes.isRequired,
  products: ProductsPropTypes.isRequired,
  banking: BankingPropTypes.isRequired,
  bankingLoaded: PropTypes.bool.isRequired,
};

export default Products;



// WEBPACK FOOTER //
// ./src/containers/dashboard/products-container.js