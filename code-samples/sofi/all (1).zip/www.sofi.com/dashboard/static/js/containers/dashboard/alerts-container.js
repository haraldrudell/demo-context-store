import React, { Component, Fragment } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import isEmpty from 'lodash/isEmpty';

/**
 * Component imports
 */
import Alerts from '../../components/alerts';
import NpsSurvey from '../../components/modals/nps-survey';
import WhereHeardSurvey from '../../components/modals/where-heard-survey';
import PostSurveyReferralModal from '../../components/modals/post-survey-referral';

/**
 * Action imports
 */
import { getNpsSurvey, postNpsSurvey, getWhereHeardSurvey, postWhereHeardSurvey } from '../../actions/survey-actions';
import { getReferralW9 } from '../../actions/referral-actions';
import { getUppSummary } from '../../actions/upp-summary-actions';
import { clearWaitCosignerError } from '../../actions/cosign-error-actions';
import { getTrackingBanner } from '../../actions/tracking-banner-actions';

/**
 * PropTypes imports
 */
import { ProductsPropTypes } from '../../constants/prop-types/products-prop-types';
import { NpsSurveyPropTypes } from '../../constants/prop-types/nps-survey-prop-types';
import { UppSummaryPropTypes } from '../../constants/prop-types/upp-summary-prop-types';
import { WaitForCosignerErrorPropTypes } from '../../constants/prop-types/wait-for-cosign-error-prop-types';
import { TrackingBannerPropTypes } from '../../constants/prop-types/tracking-banner-prop-types';

/**
 * Utlilities imports
 */
import {
  HAS_INFO,
  HAS_ERRORS,
  FIND_IF_STATE_IS_ELIGIBLE,
  NPS_SURVEY_SELECT_OPTIONS,
  REBUILD_SURVEY_OBJECT,
  DETERMINE_REVIEW_URL,
  REBUILD_WHERE_HEARD_SURVEY_OBJECT,
  CHECK_UPP_ALERT_NEEDS_DISPLAY,
} from './utilities';
import { setAlertDismissableSession, getAlertSessionKey } from '../../utilities/session-storage-helpers';

class AlertsContainer extends Component {
  static propTypes = {
    isNpsSurveyLoaded: PropTypes.bool.isRequired,
    loadNpsSurvey: PropTypes.func.isRequired,
    isW9ReferralInfoLoaded: PropTypes.bool.isRequired,
    loadW9ReferralInfo: PropTypes.func.isRequired,
    loadUppSummary: PropTypes.func.isRequired,
    products: ProductsPropTypes.isRequired,
    npsSurvey: NpsSurveyPropTypes.isRequired,
    whereHeardSurvey: NpsSurveyPropTypes.isRequired,
    submitNpsSurvey: PropTypes.func.isRequired,
    loadWhereHeardSurvey: PropTypes.func.isRequired,
    submitWhereHeardSurvey: PropTypes.func.isRequired,
    uppSummary: UppSummaryPropTypes.isRequired,
    waitForCosignError: WaitForCosignerErrorPropTypes.isRequired,
    clearWaitForCosigner: PropTypes.func.isRequired,
    loadTrackingBanner: PropTypes.func.isRequired,
    trackingBanner: TrackingBannerPropTypes.isRequired,
  };

  state = {
    isModalOpen: false,
    lowScore: false,
    isWhereHeardOpen: false,
    isThankYouOpen: false,
    highRating: false,
    referralLinkObj: {},
    showUppAlert: false,
  };

  componentDidMount() {
    const {
      loadNpsSurvey, loadW9ReferralInfo, loadUppSummary, loadWhereHeardSurvey, loadTrackingBanner,
    } = this.props;
    loadNpsSurvey();
    loadWhereHeardSurvey();
    loadW9ReferralInfo();
    loadUppSummary();
    loadTrackingBanner();
  }

  componentWillReceiveProps(nextProps) {
    if (!isEmpty(nextProps.uppSummary) && nextProps.uppSummary !== this.props.uppSummary) {
      const { uppSummary } = nextProps;
      const showUpp = CHECK_UPP_ALERT_NEEDS_DISPLAY(uppSummary);
      if (showUpp) this.setState({ showUppAlert: true });
    }
  }

  // Call method in UTILS to prepare object for POST request
  submitSurvey = (data) => {
    const originalData = this.props.npsSurvey;
    const survey = REBUILD_SURVEY_OBJECT(data, originalData);
    this.props.submitNpsSurvey(survey);
    // Close NPS Survey modal
    this.toggleOpen();
    // Open Where Heard Survey modal
    this.toggleWhereHeardOpen();
    this.checkReferral(data.radioChoiceRating);
  };

  submitWhereHeardSurvey = (data) => {
    const { whereHeardSurvey: { survey: { questions } } } = this.props;
    const { choices } = questions[0];
    const selectedChoices = [];
    const dataKeys = Object.keys(data);
    for (let idx = 0; idx < dataKeys.length; idx += 1) {
      if (data[dataKeys[idx]]) {
        const choice = choices.find(value => value.id === Number(dataKeys[idx].replace('survey_choice_', '')));
        selectedChoices.push(choice.choice);
      }
    }
    const surveyResponseString = selectedChoices.join(',');
    const originalData = this.props.whereHeardSurvey;
    const survey = REBUILD_WHERE_HEARD_SURVEY_OBJECT(surveyResponseString, originalData);
    this.props.submitWhereHeardSurvey(survey);
    this.toggleWhereHeardOpen();
    // Open Thank you modal with referral link to leave review
    this.toggleOpenThankYouModal();
  };

  toggleOpen = () => {
    this.setState({ isModalOpen: !this.state.isModalOpen });
  };

  toggleWhereHeardOpen = () => {
    this.setState({ isWhereHeardOpen: !this.state.isWhereHeardOpen });
  };

  toggleOpenThankYouModal = () => {
    const referralObj = DETERMINE_REVIEW_URL();
    this.setState({
      isThankYouOpen: !this.state.isThankYouOpen,
      referralLinkObj: referralObj,
    });
  };

  scoreSet = (number) => {
    const score = Number(number);
    if (score > 9) {
      this.setState({ lowScore: false });
    } else {
      this.setState({ lowScore: true });
    }
  };

  checkReferral = (score) => {
    if (score >= 9) {
      this.setState({ highRating: true });
    }
  };

  render() {
    const {
      isNpsSurveyLoaded, isW9ReferralInfoLoaded, npsSurvey, whereHeardSurvey, waitForCosignError, clearWaitForCosigner, trackingBanner,
    } = this.props;
    const {
      isModalOpen, lowScore, isWhereHeardOpen, isThankYouOpen, referralLinkObj, highRating, showUppAlert,
    } = this.state;
    const isStateIneligible = FIND_IF_STATE_IS_ELIGIBLE(this.props.products);

    return isW9ReferralInfoLoaded && isNpsSurveyLoaded ? (
      <Fragment>
        <Alerts
          {...this.props}
          toggleOpen={this.toggleOpen}
          isStateIneligible={isStateIneligible}
          hasInfo={HAS_INFO}
          hasErrors={HAS_ERRORS}
          showUppAlert={showUppAlert}
          setAlertDismissableSession={setAlertDismissableSession}
          getAlertSessionKey={getAlertSessionKey}
          waitForCosignError={waitForCosignError}
          clearWaitForCosigner={clearWaitForCosigner}
          trackingBanner={trackingBanner}
        />
        {isModalOpen && (
          <NpsSurvey
            isModalOpen={isModalOpen}
            toggleOpen={this.toggleOpen}
            npsSurvey={npsSurvey}
            lowScore={lowScore}
            scoreSet={this.scoreSet}
            surveySelectOptions={NPS_SURVEY_SELECT_OPTIONS}
            submitSurvey={this.submitSurvey}
          />
        )}
        {isWhereHeardOpen && (
          <WhereHeardSurvey
            isWhereHeardOpen={isWhereHeardOpen}
            toggleWhereHeardOpen={this.toggleWhereHeardOpen}
            whereHeardSurvey={whereHeardSurvey}
            submitWhereHeardSurvey={this.submitWhereHeardSurvey}
          />
        )}
        {isThankYouOpen && (
          <PostSurveyReferralModal
            isThankYouOpen={isThankYouOpen}
            toggleOpenThankYouModal={this.toggleOpenThankYouModal}
            referralLinkObj={referralLinkObj}
            highRating={highRating}
          />
        )}
      </Fragment>
    ) : (
      ''
    );
  }
}

const mapStateToProps = state => ({
  isNpsSurveyLoaded: state.surveyReducer.npsSurvey.loaded,
  npsSurvey: state.surveyReducer.npsSurvey.data,
  isWhereHeardSurveyLoaded: state.surveyReducer.whereHeardSurvey.loaded,
  whereHeardSurvey: state.surveyReducer.whereHeardSurvey.data,
  w9ReferralInfo: state.referralReducer.w9.data,
  isW9ReferralInfoLoaded: state.referralReducer.w9.loadedGet,
  isUppSummaryLoaded: state.uppSummaryReducer.uppSummary.loaded,
  uppSummary: state.uppSummaryReducer.uppSummary.data,
  globalErrors: state.globalErrorReducer.globalErrors,
  waitForCosignError: state.globalErrorReducer.waitForCosignError,
  trackingBanner: state.trackingBannerReducer.banners.data,
});

const mapDispatchToProps = dispatch => ({
  loadNpsSurvey: () => dispatch(getNpsSurvey()),
  loadWhereHeardSurvey: () => dispatch(getWhereHeardSurvey()),
  loadUppSummary: () => dispatch(getUppSummary()),
  loadW9ReferralInfo: () => dispatch(getReferralW9()),
  loadTrackingBanner: () => dispatch(getTrackingBanner()),
  submitNpsSurvey: data => dispatch(postNpsSurvey(data)),
  submitWhereHeardSurvey: data => dispatch(postWhereHeardSurvey(data)),
  clearWaitForCosigner: () => dispatch(clearWaitCosignerError()),
});

export default connect(mapStateToProps, mapDispatchToProps)(AlertsContainer);



// WEBPACK FOOTER //
// ./src/containers/dashboard/alerts-container.js