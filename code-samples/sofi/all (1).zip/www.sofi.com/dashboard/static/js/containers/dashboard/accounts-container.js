import React, { Component } from 'react';
import PropTypes from 'prop-types';
import styled from 'styled-components';
import { connect } from 'react-redux';
import { FeatureFlag } from 'react-launch-darkly';

/**
 * PropTypes imports
 */
import { ApplicationPropType } from '../../constants/prop-types/application-prop-types';

/**
 * Component imports
 */
import AccountsComponent from '../../components/accounts'; // Old accounts
import AccountsSectionComponent from '../../components/accounts/accounts-section'; // New accounts

/**
 * Action imports
 */
import { updateReferralConsent, getReferralSummary } from '../../actions/referral-actions';
import { getMortgageSso } from '../../actions/application-actions';

/**
 * Utilties
 */
import { GET_VALUE_LABEL_PAIRS } from './utilities';
import { FEATURE_FLAG_ACCOUNT_CARDS } from '../../constants/launch-darkly-constants';
import { CustomerPropTypes } from '../../constants/prop-types/customer-prop-types';

/**
 * Styled Components
 */
const OldContainer = styled.div`
  padding-top: 20px;
  background: white;
  section {
    max-width: 1240px;
    margin: 0px auto;
    padding-left: 20px;
    padding-right: 20px;
  }
`;

/**
 * Accounts container (at the top of the dashboard)
 */
class Accounts extends Component {
  static propTypes = {
    applications: PropTypes.arrayOf(ApplicationPropType).isRequired,
    servicing: PropTypes.object.isRequired, // eslint-disable-line
    postUpdateReferralConsent: PropTypes.func.isRequired,
    loadMortgageSso: PropTypes.func.isRequired,
    mortgageSsoLoaded: PropTypes.bool.isRequired,
    isReferralSubscribed: PropTypes.bool.isRequired,
    loadDashboardAccounts: PropTypes.func.isRequired,
  };

  state = {
    showMohelaModal: false,
    showCenlarModal: false,
    caretRightCounter: 0,
    customer: CustomerPropTypes.isRequired,
    modalContentUrl: '',
  };

  componentDidMount() {
    const { loadMortgageSso, applications } = this.props;

    const hasCelnarServicedApps = applications.filter((app) => {
      const isTrue =
        app.type === 'MORT' && app.servicing && app.servicing.status === 'CENLAR' && app.servicing.statusDesc === 'CENLAR_SOFI';
      return isTrue;
    }).length;

    if (hasCelnarServicedApps) {
      loadMortgageSso();
    }
  }

  refreshReferralState = async () => {
    const { loadReferralSummary } = this.props;
    await loadReferralSummary();
  };

  refreshConsentData = async () => {
    await this.refreshReferralState();
    const { isReferralSubscribed } = this.props;
    if (!isReferralSubscribed) {
      // poll dashboard api until data has been propagated
      setTimeout(() => {
        this.refreshConsentData();
      }, 2000);
    }
  };

  postReferralConsent = async (referralConsent) => {
    const { postUpdateReferralConsent } = this.props;
    await postUpdateReferralConsent(referralConsent);
    this.refreshConsentData();
  };

  handleCallback = (action) => {
    // Check if we need to trigger a modal
    const { modalName, modalContentUrl } = action;
    if (modalName) {
      const name = modalName;

      switch (name) {
        case 'mohelaModal': {
          this.setState({ showMohelaModal: true });
          break;
        }
        case 'mortgageModal': {
          this.setState({ showCenlarModal: true, modalContentUrl });
          break;
        }
        default: {
          // do nothing for now
        }
      }
    }
  };

  handleModalOpen = modalKey => () => {
    this.setState({ [modalKey]: !this.state[modalKey] });
  };

  render() {
    const { showMohelaModal, showCenlarModal, modalContentUrl } = this.state;

    return (
      <FeatureFlag
        flagKey={FEATURE_FLAG_ACCOUNT_CARDS}
        renderFeatureCallback={() => (
          <AccountsSectionComponent
            {...this.props}
            postReferralConsent={this.postReferralConsent}
            getValueLabelPairs={GET_VALUE_LABEL_PAIRS}
            handleCallback={this.handleCallback}
            handleModalOpen={this.handleModalOpen}
            handleClickCaret={this.handleClickCaret}
            showMohelaModal={showMohelaModal}
            showCenlarModal={showCenlarModal}
            modalContentUrl={modalContentUrl}
          />
        )}
        renderDefaultCallback={() => (
          <OldContainer>
            <AccountsComponent {...this.props} postReferralConsent={this.postReferralConsent} />
          </OldContainer>
        )}
      />
    );
  }
}

const mapStateToProps = state => ({
  mortgageSso: state.applicationReducer.mortgageSso.data,
  mortgageSsoLoaded: state.applicationReducer.mortgageSso.loaded,
  servicing: state.applicationReducer.servicing.data,
  servicingLoaded: state.applicationReducer.servicing.loaded,
  isReferralSubscribed: state.referralReducer.referralSummary.loaded && state.referralReducer.referralSummary.data.isSubscribed,
});

const mapDispatchToProps = dispatch => ({
  postUpdateReferralConsent: referralConsent => dispatch(updateReferralConsent(referralConsent)),
  loadMortgageSso: () => dispatch(getMortgageSso()),
  loadReferralSummary: () => dispatch(getReferralSummary()),
});

export default connect(mapStateToProps, mapDispatchToProps)(Accounts);



// WEBPACK FOOTER //
// ./src/containers/dashboard/accounts-container.js