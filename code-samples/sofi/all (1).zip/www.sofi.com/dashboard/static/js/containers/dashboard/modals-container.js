import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import debounce from 'lodash/debounce';
import queryString from 'query-string';
import ReactRouterPropTypes from 'react-router-prop-types';

/**
 * Action imports
 */
import { getStates } from '../../actions/state-actions';
import { postCustomerState, postCustomerCosign } from '../../actions/customer-actions';
import { postApplicationRetry, getApplications } from '../../actions/application-actions';
import { setWaitCosignerError, clearWaitCosignerError } from '../../actions/cosign-error-actions';

/**
 * Component imports
 */
import Modals from '../../components/modals';

class ModalsContainer extends Component {
  static propTypes = {
    loadStates: PropTypes.func.isRequired,
    updateState: PropTypes.func.isRequired,
    location: ReactRouterPropTypes.location.isRequired,
  };

  state = {
    appParams: {
      action: '',
      appId: null,
      appType: '',
      reason: '',
      applicantCount: 0,
    },
  };

  componentDidMount() {
    /**
     * Parse QueryParams to see if/which modal needs to be shown
     */
    const parsedQueryString = queryString.parse(this.props.location.search);
    if (parsedQueryString.action) {
      const {
        action, appId, appType, applicantCount, reason,
      } = parsedQueryString;
      const appParams = {
        action,
        appType,
        reason,
        appId: Number(appId) || null,
        applicantCount: parseInt(applicantCount, 10) || 0,
      };
      this.updateAppParams(appParams);
    }
  }

  // To avoid using setState in componentDidMount (react/no-did-mount-set-state)
  updateAppParams = appParams => this.setState({ appParams });

  /**
   * Load all the states (USA)
   */
  loadStates = () => {
    const { loadStates } = this.props;
    loadStates();
  };

  /**
   * Update customer's state of residence
   */
  updateState = debounce(
    async (newState, toggleModal) => {
      const { updateState } = this.props;
      await updateState(newState);
      toggleModal();
    },
    200,
    {
      trailing: true,
    },
  );

  /**
   * Common retryService POST
   * Used by ssn-missing, and mortgage-credit modals
   */
  retryService = debounce(
    async (values, setErrors, setSubmitting, toggleModal) => {
      const { appParams } = this.state;
      const data = {
        appId: appParams.appId,
        appType: appParams.appType,
        coSsnRequired: appParams.applicantCount > 1,
        ssn: values.ssn,
        coSsn: values.coSsn,
      };
      const { retryApplication } = this.props;
      await retryApplication(data, setErrors);

      /**
       * Check if the POST request was successful
       */
      const { applicationRetrySuccess } = this.props;
      if (applicationRetrySuccess) {
        // Close Modal
        toggleModal();
      } else {
        // Enable submit button
        setSubmitting(false);
      }
    },
    200,
    {
      trailing: true,
    },
  );

  /**
   * Update customer's cosigner information
   */
  updateCosigner = debounce(
    async (values, mapServerSideErrorsToFormik, setSubmitting, toggleModal) => {
      const { appParams } = this.state;
      const data = {
        appId: appParams.appId,
        cosignerFirstName: values.cosignerFirstName,
        cosignerLastName: values.cosignerLastName,
        cosignerEmail: values.cosignerEmail,
      };
      const { updateCosigner, loadApplications } = this.props;
      await updateCosigner(data, mapServerSideErrorsToFormik);

      /**
       * Check if the POST request was successful
       */
      const { cosignerUpdated } = this.props;
      if (cosignerUpdated) {
        // Refresh applications
        loadApplications();
        // Close modal
        toggleModal();
      } else {
        // Enable submit button
        setSubmitting(false);
      }
    },
    200,
    {
      trailing: true,
    },
  );

  render() {
    const { appParams } = this.state;
    return (
      <Modals
        {...this.props}
        appParams={appParams}
        loadStates={this.loadStates}
        updateState={this.updateState}
        retryService={this.retryService}
        updateCosigner={this.updateCosigner}
      />
    );
  }
}

const mapStateToProps = state => ({
  states: state.statesReducer.states.data,
  statesLoaded: state.statesReducer.states.loaded,
  cosignerUpdated: state.customerReducer.cosignerUpdated,
  applicationRetrySuccess: state.applicationReducer.applicationRetrySuccess,
  waitForCosignError: state.globalErrorReducer.waitForCosignError,
});

const mapDispatchToProps = dispatch => ({
  loadStates: () => dispatch(getStates()),
  updateState: newState => dispatch(postCustomerState(newState)),
  retryApplication: (appObj, setErrors) => dispatch(postApplicationRetry(appObj, setErrors)),
  updateCosigner: (data, setErrors) => dispatch(postCustomerCosign(data, setErrors)),
  loadApplications: () => dispatch(getApplications()),
  setWaitForCosigner: () => dispatch(setWaitCosignerError()),
  clearWaitForCosigner: () => dispatch(clearWaitCosignerError()),
});

export default connect(mapStateToProps, mapDispatchToProps)(ModalsContainer);



// WEBPACK FOOTER //
// ./src/containers/dashboard/modals-container.js