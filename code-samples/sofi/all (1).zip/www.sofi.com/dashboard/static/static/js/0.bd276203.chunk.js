webpackJsonp([0],Array(1022).concat([
/* 1022 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__dashboard_container__ = __webpack_require__(1242);
/* harmony reexport (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return __WEBPACK_IMPORTED_MODULE_0__dashboard_container__["a"]; });


/***/ }),
/* 1023 */,
/* 1024 */,
/* 1025 */,
/* 1026 */,
/* 1027 */,
/* 1028 */,
/* 1029 */,
/* 1030 */,
/* 1031 */,
/* 1032 */,
/* 1033 */,
/* 1034 */,
/* 1035 */,
/* 1036 */,
/* 1037 */,
/* 1038 */,
/* 1039 */,
/* 1040 */,
/* 1041 */,
/* 1042 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;

var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };

exports.default = SchemaType;

var _has = __webpack_require__(1044);

var _has2 = _interopRequireDefault(_has);

var _cloneDeepWith = __webpack_require__(1091);

var _cloneDeepWith2 = _interopRequireDefault(_cloneDeepWith);

var _toArray = __webpack_require__(1092);

var _toArray2 = _interopRequireDefault(_toArray);

var _locale = __webpack_require__(1045);

var _Condition = __webpack_require__(1099);

var _Condition2 = _interopRequireDefault(_Condition);

var _runValidations = __webpack_require__(1055);

var _runValidations2 = _interopRequireDefault(_runValidations);

var _merge = __webpack_require__(1100);

var _merge2 = _interopRequireDefault(_merge);

var _isSchema = __webpack_require__(1043);

var _isSchema2 = _interopRequireDefault(_isSchema);

var _isAbsent = __webpack_require__(1048);

var _isAbsent2 = _interopRequireDefault(_isAbsent);

var _createValidation = __webpack_require__(1101);

var _createValidation2 = _interopRequireDefault(_createValidation);

var _printValue = __webpack_require__(1054);

var _printValue2 = _interopRequireDefault(_printValue);

var _Reference = __webpack_require__(1049);

var _Reference2 = _interopRequireDefault(_Reference);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var notEmpty = function notEmpty(value) {
  return !(0, _isAbsent2.default)(value);
};

function extractTestParams(name, message, test) {
  var opts = name;

  if (typeof message === 'function') {
    test = message;message = _locale.mixed.default;name = null;
  }

  if (typeof name === 'function') {
    test = name;message = _locale.mixed.default;name = null;
  }

  if (typeof name === 'string' || name === null) opts = { name: name, test: test, message: message, exclusive: false };

  if (typeof opts.test !== 'function') throw new TypeError('`test` is a required parameters');

  return opts;
}

function SchemaType() {
  var _this = this;

  var options = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

  if (!(this instanceof SchemaType)) return new SchemaType();

  this._deps = [];
  this._conditions = [];
  this._options = { abortEarly: true, recursive: true };
  this._exclusive = Object.create(null);
  this._whitelist = new Set();
  this._blacklist = new Set();
  this.tests = [];
  this.transforms = [];

  this.withMutation(function () {
    _this.typeError(_locale.mixed.notType);
  });

  if ((0, _has2.default)(options, 'default')) this._defaultDefault = options.default;

  this._type = options.type || 'mixed';
}

SchemaType.prototype = {

  __isYupSchema__: true,

  constructor: SchemaType,

  clone: function clone() {
    var _this2 = this;

    if (this._mutate) return this;

    // if the nested value is a schema we can skip cloning, since
    // they are already immutable
    return (0, _cloneDeepWith2.default)(this, function (value) {
      if ((0, _isSchema2.default)(value) && value !== _this2) return value;
    });
  },
  label: function label(_label) {
    var next = this.clone();
    next._label = _label;
    return next;
  },
  meta: function meta(obj) {
    if (arguments.length === 0) return this._meta;

    var next = this.clone();
    next._meta = _extends(next._meta || {}, obj);
    return next;
  },
  withMutation: function withMutation(fn) {
    this._mutate = true;
    var result = fn(this);
    this._mutate = false;
    return result;
  },
  concat: function concat(schema) {
    if (!schema) return this;

    if (schema._type !== this._type && this._type !== 'mixed') throw new TypeError('You cannot `concat()` schema\'s of different types: ' + this._type + ' and ' + schema._type);
    var cloned = this.clone();
    var next = (0, _merge2.default)(this.clone(), schema.clone());

    // undefined isn't merged over, but is a valid value for default
    if ((0, _has2.default)(schema, '_default')) next._default = schema._default;

    next.tests = cloned.tests;
    next._exclusive = cloned._exclusive;

    // manually add the new tests to ensure
    // the deduping logic is consistent
    schema.tests.forEach(function (fn) {
      next = next.test(fn.TEST);
    });

    next._type = schema._type;

    return next;
  },
  isType: function isType(v) {
    if (this._nullable && v === null) return true;
    return !this._typeCheck || this._typeCheck(v);
  },
  resolve: function resolve(_ref) {
    var context = _ref.context,
        parent = _ref.parent;

    if (this._conditions.length) {
      return this._conditions.reduce(function (schema, match) {
        return match.resolve(schema, match.getValue(parent, context));
      }, this);
    }

    return this;
  },
  cast: function cast(value) {
    var options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};

    var resolvedSchema = this.resolve(options);
    var result = resolvedSchema._cast(value, options);

    if (value !== undefined && options.assert !== false && resolvedSchema.isType(result) !== true) {
      var formattedValue = (0, _printValue2.default)(value);
      var formattedResult = (0, _printValue2.default)(result);
      throw new TypeError('The value of ' + (options.path || 'field') + ' could not be cast to a value ' + ('that satisfies the schema type: "' + resolvedSchema._type + '". \n\n') + ('attempted value: ' + formattedValue + ' \n') + (formattedResult !== formattedValue ? 'result of cast: ' + formattedResult : ''));
    }

    return result;
  },
  _cast: function _cast(rawValue) {
    var _this3 = this;

    var value = rawValue === undefined ? rawValue : this.transforms.reduce(function (value, fn) {
      return fn.call(_this3, value, rawValue);
    }, rawValue);

    if (value === undefined && (0, _has2.default)(this, '_default')) {
      value = this.default();
    }

    return value;
  },
  _validate: function _validate(_value) {
    var _this4 = this;

    var options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};

    var value = _value;
    var originalValue = options.originalValue != null ? options.originalValue : _value;

    var isStrict = this._option('strict', options);
    var endEarly = this._option('abortEarly', options);

    var sync = options.sync;
    var path = options.path;
    var label = this._label;

    if (!isStrict) {
      value = this._cast(value, _extends({ assert: false }, options));
    }
    // value is cast, we can check if it meets type requirements
    var validationParams = { value: value, path: path, schema: this, options: options, label: label, originalValue: originalValue, sync: sync };
    var initialTests = [];

    if (this._typeError) initialTests.push(this._typeError(validationParams));

    if (this._whitelistError) initialTests.push(this._whitelistError(validationParams));

    if (this._blacklistError) initialTests.push(this._blacklistError(validationParams));

    return (0, _runValidations2.default)({ validations: initialTests, endEarly: endEarly, value: value, path: path, sync: sync }).then(function (value) {
      return (0, _runValidations2.default)({
        path: path,
        sync: sync,
        value: value,
        endEarly: endEarly,
        validations: _this4.tests.map(function (fn) {
          return fn(validationParams);
        })
      });
    });
  },
  validate: function validate(value) {
    var options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};

    var schema = this.resolve(options);
    return schema._validate(value, options);
  },
  validateSync: function validateSync(value) {
    var options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};

    var schema = this.resolve(options);
    var result = void 0,
        err = void 0;

    schema._validate(value, _extends({}, options, { sync: true })).then(function (r) {
      return result = r;
    }).catch(function (e) {
      return err = e;
    });

    if (err) throw err;
    return result;
  },
  isValid: function isValid(value, options) {
    return this.validate(value, options).then(function () {
      return true;
    }).catch(function (err) {
      if (err.name === 'ValidationError') return false;

      throw err;
    });
  },
  isValidSync: function isValidSync(value, options) {
    try {
      this.validateSync(value, _extends({}, options));
      return true;
    } catch (err) {
      if (err.name === 'ValidationError') return false;
      throw err;
    }
  },
  getDefault: function getDefault(_ref2) {
    var context = _ref2.context,
        parent = _ref2.parent;

    return this._resolve(context, parent).default();
  },
  default: function _default(def) {
    if (arguments.length === 0) {
      var defaultValue = (0, _has2.default)(this, '_default') ? this._default : this._defaultDefault;

      return typeof defaultValue === 'function' ? defaultValue.call(this) : (0, _cloneDeepWith2.default)(defaultValue);
    }

    var next = this.clone();
    next._default = def;
    return next;
  },
  strict: function strict() {
    var next = this.clone();
    next._options.strict = true;
    return next;
  },
  required: function required(msg) {
    return this.test('required', msg || _locale.mixed.required, notEmpty);
  },
  nullable: function nullable(value) {
    var next = this.clone();
    next._nullable = value === false ? false : true;
    return next;
  },
  transform: function transform(fn) {
    var next = this.clone();
    next.transforms.push(fn);
    return next;
  },


  /**
   * Adds a test function to the schema's queue of tests.
   * tests can be exclusive or non-exclusive.
   *
   * - exclusive tests, will replace any existing tests of the same name.
   * - non-exclusive: can be stacked
   *
   * If a non-exclusive test is added to a schema with an exclusive test of the same name
   * the exclusive test is removed and further tests of the same name will be stacked.
   *
   * If an exclusive test is added to a schema with non-exclusive tests of the same name
   * the previous tests are removed and further tests of the same name will replace each other.
   */
  test: function test(name, message, _test) {
    var opts = extractTestParams(name, message, _test),
        next = this.clone();

    var validate = (0, _createValidation2.default)(opts);

    var isExclusive = opts.exclusive || opts.name && next._exclusive[opts.name] === true;

    if (opts.exclusive && !opts.name) {
      throw new TypeError('Exclusive tests must provide a unique `name` identifying the test');
    }

    next._exclusive[opts.name] = !!opts.exclusive;

    next.tests = next.tests.filter(function (fn) {
      if (fn.TEST_NAME === opts.name) {
        if (isExclusive) return false;
        if (fn.TEST.test === validate.TEST.test) return false;
      }
      return true;
    });

    next.tests.push(validate);

    return next;
  },
  when: function when(keys, options) {
    var next = this.clone(),
        deps = [].concat(keys).map(function (key) {
      return new _Reference2.default(key);
    });

    deps.forEach(function (dep) {
      if (!dep.isContext) next._deps.push(dep.key);
    });

    next._conditions.push(new _Condition2.default(deps, options));

    return next;
  },
  typeError: function typeError(message) {
    var next = this.clone();

    next._typeError = (0, _createValidation2.default)({
      name: 'typeError',
      message: message,
      test: function test(value) {
        if (value !== undefined && !this.schema.isType(value)) return this.createError({
          params: {
            type: this.schema._type
          }
        });
        return true;
      }
    });
    return next;
  },
  oneOf: function oneOf(enums) {
    var message = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : _locale.mixed.oneOf;

    var next = this.clone();

    enums.forEach(function (val) {
      if (next._blacklist.has(val)) next._blacklist.delete(val);
      next._whitelist.add(val);
    });

    next._whitelistError = (0, _createValidation2.default)({
      message: message,
      name: 'oneOf',
      test: function test(value) {
        var valids = this.schema._whitelist;
        if (valids.size && !(value === undefined || valids.has(value))) return this.createError({
          params: {
            values: (0, _toArray2.default)(valids).join(', ')
          }
        });
        return true;
      }
    });

    return next;
  },
  notOneOf: function notOneOf(enums) {
    var message = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : _locale.mixed.notOneOf;

    var next = this.clone();

    enums.forEach(function (val) {
      next._whitelist.delete(val);
      next._blacklist.add(val);
    });

    next._blacklistError = (0, _createValidation2.default)({
      message: message,
      name: 'notOneOf',
      test: function test(value) {
        var invalids = this.schema._blacklist;
        if (invalids.size && invalids.has(value)) return this.createError({
          params: {
            values: (0, _toArray2.default)(invalids).join(', ')
          }
        });
        return true;
      }
    });

    return next;
  },
  strip: function strip() {
    var strip = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : true;

    var next = this.clone();
    next._strip = strip;
    return next;
  },
  _option: function _option(key, overrides) {
    return (0, _has2.default)(overrides, key) ? overrides[key] : this._options[key];
  },
  describe: function describe() {
    var next = this.clone();

    return {
      type: next._type,
      meta: next._meta,
      label: next._label,
      tests: next.tests.map(function (fn) {
        return fn.TEST_NAME;
      }, {})
    };
  }
};

var aliases = {
  oneOf: ['equals', 'is'],
  notOneOf: ['not', 'nope']
};

Object.keys(aliases).forEach(function (method) {
  aliases[method].forEach(function (alias) {
    return SchemaType.prototype[alias] = SchemaType.prototype[method];
  });
});
module.exports = exports['default'];

/***/ }),
/* 1043 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;

exports.default = function (obj) {
  return obj && obj.__isYupSchema__;
};

module.exports = exports["default"];

/***/ }),
/* 1044 */
/***/ (function(module, exports, __webpack_require__) {

var baseHas = __webpack_require__(1087),
    hasPath = __webpack_require__(1061);

/**
 * Checks if `path` is a direct property of `object`.
 *
 * @static
 * @since 0.1.0
 * @memberOf _
 * @category Object
 * @param {Object} object The object to query.
 * @param {Array|string} path The path to check.
 * @returns {boolean} Returns `true` if `path` exists, else `false`.
 * @example
 *
 * var object = { 'a': { 'b': 2 } };
 * var other = _.create({ 'a': _.create({ 'b': 2 }) });
 *
 * _.has(object, 'a');
 * // => true
 *
 * _.has(object, 'a.b');
 * // => true
 *
 * _.has(object, ['a', 'b']);
 * // => true
 *
 * _.has(other, 'a');
 * // => false
 */
function has(object, path) {
  return object != null && hasPath(object, path, baseHas);
}

module.exports = has;


/***/ }),
/* 1045 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;
exports.array = exports.object = exports.boolean = exports.date = exports.number = exports.string = exports.mixed = undefined;

var _printValue = __webpack_require__(1054);

var _printValue2 = _interopRequireDefault(_printValue);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var mixed = exports.mixed = {
  default: '${path} is invalid',
  required: '${path} is a required field',
  oneOf: '${path} must be one of the following values: ${values}',
  notOneOf: '${path} must not be one of the following values: ${values}',
  notType: function notType(_ref) {
    var path = _ref.path,
        type = _ref.type,
        value = _ref.value,
        originalValue = _ref.originalValue;

    var isCast = originalValue != null && originalValue !== value;
    var msg = path + ' must be a `' + type + '` type, ' + ('but the final value was: `' + (0, _printValue2.default)(value, true) + '`') + (isCast ? ' (cast from the value `' + (0, _printValue2.default)(originalValue, true) + '`).' : '.');

    if (value === null) {
      msg += '\n If "null" is intended as an empty value be sure to mark the schema as `.nullable()`';
    }

    return msg;
  }
};

var string = exports.string = {
  length: '${path} must be exactly ${length} characters',
  min: '${path} must be at least ${min} characters',
  max: '${path} must be at most ${max} characters',
  matches: '${path} must match the following: "${regex}"',
  email: '${path} must be a valid email',
  url: '${path} must be a valid URL',
  trim: '${path} must be a trimmed string',
  lowercase: '${path} must be a lowercase string',
  uppercase: '${path} must be a upper case string'
};

var number = exports.number = {
  min: '${path} must be greater than or equal to ${min}',
  max: '${path} must be less than or equal to ${max}',
  positive: '${path} must be a positive number',
  negative: '${path} must be a negative number',
  integer: '${path} must be an integer'
};

var date = exports.date = {
  min: '${path} field must be later than ${min}',
  max: '${path} field must be at earlier than ${max}'
};

var boolean = exports.boolean = {};

var object = exports.object = {
  noUnknown: '${path} field cannot have keys not specified in the object shape'
};

var array = exports.array = {
  min: '${path} field must have at least ${min} items',
  max: '${path} field must have less than ${max} items'
};

exports.default = {
  mixed: mixed,
  string: string,
  number: number,
  date: date,
  object: object,
  array: array,
  boolean: boolean
};

/***/ }),
/* 1046 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;

var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };

exports.default = inherits;
function inherits(ctor, superCtor, spec) {
  ctor.prototype = Object.create(superCtor.prototype, {
    constructor: {
      value: ctor,
      enumerable: false,
      writable: true,
      configurable: true
    }
  });

  _extends(ctor.prototype, spec);
}
module.exports = exports["default"];

/***/ }),
/* 1047 */
/***/ (function(module, exports, __webpack_require__) {

var isSymbol = __webpack_require__(181);

/** Used as references for various `Number` constants. */
var INFINITY = 1 / 0;

/**
 * Converts `value` to a string key if it's not a string or symbol.
 *
 * @private
 * @param {*} value The value to inspect.
 * @returns {string|symbol} Returns the key.
 */
function toKey(value) {
  if (typeof value == 'string' || isSymbol(value)) {
    return value;
  }
  var result = (value + '');
  return (result == '0' && (1 / value) == -INFINITY) ? '-0' : result;
}

module.exports = toKey;


/***/ }),
/* 1048 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;

exports.default = function (value) {
  return value == null;
};

module.exports = exports["default"];

/***/ }),
/* 1049 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;

var _propertyExpr = __webpack_require__(1051);

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var validateName = function validateName(d) {
  if (typeof d !== 'string') throw new TypeError('ref\'s must be strings, got: ' + d);
};

var Reference = function () {
  Reference.isRef = function isRef(value) {
    return !!(value && (value.__isYupRef || value instanceof Reference));
  };

  function Reference(key, mapFn) {
    var options = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};

    _classCallCheck(this, Reference);

    validateName(key);
    var prefix = options.contextPrefix || '$';

    if (typeof key === 'function') {
      key = '.';
    }

    this.key = key.trim();
    this.prefix = prefix;
    this.isContext = this.key.indexOf(prefix) === 0;
    this.isSelf = this.key === '.';

    this.path = this.isContext ? this.key.slice(this.prefix.length) : this.key;
    this._get = (0, _propertyExpr.getter)(this.path, true);
    this.map = mapFn || function (value) {
      return value;
    };
  }

  Reference.prototype.resolve = function resolve() {
    return this;
  };

  Reference.prototype.cast = function cast(value, _ref) {
    var parent = _ref.parent,
        context = _ref.context;

    return this.getValue(parent, context);
  };

  Reference.prototype.getValue = function getValue(parent, context) {
    var isContext = this.isContext;
    var value = this._get(isContext ? context : parent || context || {});
    return this.map(value);
  };

  return Reference;
}();

exports.default = Reference;


Reference.prototype.__isYupRef = true;
module.exports = exports['default'];

/***/ }),
/* 1050 */
/***/ (function(module, exports, __webpack_require__) {

var isArray = __webpack_require__(92),
    isKey = __webpack_require__(1053),
    stringToPath = __webpack_require__(1088),
    toString = __webpack_require__(308);

/**
 * Casts `value` to a path array if it's not one.
 *
 * @private
 * @param {*} value The value to inspect.
 * @param {Object} [object] The object to query keys on.
 * @returns {Array} Returns the cast property path array.
 */
function castPath(value, object) {
  if (isArray(value)) {
    return value;
  }
  return isKey(value, object) ? [value] : stringToPath(toString(value));
}

module.exports = castPath;


/***/ }),
/* 1051 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/**
 * @license
 * expr 1.0.0
 * Copyright 2014 Jason Quense
 * Based on Kendo UI Core expression code <https://github.com/telerik/kendo-ui-core#license-information>
 * Copyright :copyright: 2014 Telerik
 * Available under MIT license <https://github.com/theporchrat/expr/blob/master/LICENSE.txt>
 */

var SPLIT_REGEX = /[^.^\]^[]+|(?=\[\]|\.\.)/g,
  DIGIT_REGEX = /^\d+$/,
  LEAD_DIGIT_REGEX = /^\d/,
  SPEC_CHAR_REGEX = /[~`!#$%\^&*+=\-\[\]\\';,/{}|\\":<>\?]/g

var setCache = {},
  getCache = {}

module.exports = {
  expr: expr,

  setter: function(path) {
    return (
      setCache[path] ||
      (setCache[path] = new Function(
        'data, value',
        expr(path, 'data') + ' = value'
      ))
    )
  },

  getter: function(path, safe) {
    var k = path + '_' + safe
    return (
      getCache[k] ||
      (getCache[k] = new Function('data', 'return ' + expr(path, safe, 'data')))
    )
  },

  split: function(path) {
    return path.match(SPLIT_REGEX)
  },

  join: function(segments) {
    return segments.reduce(function(path, part) {
      return (
        path +
        (isQuoted(part) || DIGIT_REGEX.test(part)
          ? '[' + part + ']'
          : (path ? '.' : '') + part)
      )
    }, '')
  },

  forEach: function(path, cb, thisArg) {
    forEach(path.match(SPLIT_REGEX), cb, thisArg)
  }
}

function expr(expression, safe, param) {
  expression = expression || ''

  if (typeof safe === 'string') {
    param = safe
    safe = false
  }

  param = param || 'data'

  if (expression && expression.charAt(0) !== '[') expression = '.' + expression

  return safe ? makeSafe(expression, param) : param + expression
}

function forEach(parts, iter, thisArg) {
  var len = parts.length,
    part,
    idx,
    isArray,
    isBracket

  for (idx = 0; idx < len; idx++) {
    part = parts[idx]

    if (part) {
      if (shouldBeQuoted(part)) {
        part = '"' + part + '"'
      }

      isBracket = isQuoted(part)
      isArray = !isBracket && /^\d+$/.test(part)

      iter.call(thisArg, part, isBracket, isArray, idx, parts)
    }
  }
}

function isQuoted(str) {
  return (
    typeof str === 'string' && str && ["'", '"'].indexOf(str.charAt(0)) !== -1
  )
}

function makeSafe(path, param) {
  var result = param,
    parts = path.match(SPLIT_REGEX),
    isLast

  forEach(parts, function(part, isBracket, isArray, idx, parts) {
    isLast = idx === parts.length - 1

    part = isBracket || isArray ? '[' + part + ']' : '.' + part

    result += part + (!isLast ? ' || {})' : ')')
  })

  return new Array(parts.length + 1).join('(') + result
}

function hasLeadingNumber(part) {
  return part.match(LEAD_DIGIT_REGEX) && !part.match(DIGIT_REGEX)
}

function hasSpecialChars(part) {
  return SPEC_CHAR_REGEX.test(part)
}

function shouldBeQuoted(part) {
  return !isQuoted(part) && (hasLeadingNumber(part) || hasSpecialChars(part))
}


/***/ }),
/* 1052 */
/***/ (function(module, exports) {

exports.__esModule = true;
var ATTRIBUTE_NAMES = exports.ATTRIBUTE_NAMES = {
    BODY: "bodyAttributes",
    HTML: "htmlAttributes",
    TITLE: "titleAttributes"
};

var TAG_NAMES = exports.TAG_NAMES = {
    BASE: "base",
    BODY: "body",
    HEAD: "head",
    HTML: "html",
    LINK: "link",
    META: "meta",
    NOSCRIPT: "noscript",
    SCRIPT: "script",
    STYLE: "style",
    TITLE: "title"
};

var VALID_TAG_NAMES = exports.VALID_TAG_NAMES = Object.keys(TAG_NAMES).map(function (name) {
    return TAG_NAMES[name];
});

var TAG_PROPERTIES = exports.TAG_PROPERTIES = {
    CHARSET: "charset",
    CSS_TEXT: "cssText",
    HREF: "href",
    HTTPEQUIV: "http-equiv",
    INNER_HTML: "innerHTML",
    ITEM_PROP: "itemprop",
    NAME: "name",
    PROPERTY: "property",
    REL: "rel",
    SRC: "src"
};

var REACT_TAG_MAP = exports.REACT_TAG_MAP = {
    accesskey: "accessKey",
    charset: "charSet",
    class: "className",
    contenteditable: "contentEditable",
    contextmenu: "contextMenu",
    "http-equiv": "httpEquiv",
    itemprop: "itemProp",
    tabindex: "tabIndex"
};

var HELMET_PROPS = exports.HELMET_PROPS = {
    DEFAULT_TITLE: "defaultTitle",
    DEFER: "defer",
    ENCODE_SPECIAL_CHARACTERS: "encodeSpecialCharacters",
    ON_CHANGE_CLIENT_STATE: "onChangeClientState",
    TITLE_TEMPLATE: "titleTemplate"
};

var HTML_TAG_MAP = exports.HTML_TAG_MAP = Object.keys(REACT_TAG_MAP).reduce(function (obj, key) {
    obj[REACT_TAG_MAP[key]] = key;
    return obj;
}, {});

var SELF_CLOSING_TAGS = exports.SELF_CLOSING_TAGS = [TAG_NAMES.NOSCRIPT, TAG_NAMES.SCRIPT, TAG_NAMES.STYLE];

var HELMET_ATTRIBUTE = exports.HELMET_ATTRIBUTE = "data-react-helmet";

/***/ }),
/* 1053 */
/***/ (function(module, exports, __webpack_require__) {

var isArray = __webpack_require__(92),
    isSymbol = __webpack_require__(181);

/** Used to match property names within property paths. */
var reIsDeepProp = /\.|\[(?:[^[\]]*|(["'])(?:(?!\1)[^\\]|\\.)*?\1)\]/,
    reIsPlainProp = /^\w*$/;

/**
 * Checks if `value` is a property name and not a property path.
 *
 * @private
 * @param {*} value The value to check.
 * @param {Object} [object] The object to query keys on.
 * @returns {boolean} Returns `true` if `value` is a property name, else `false`.
 */
function isKey(value, object) {
  if (isArray(value)) {
    return false;
  }
  var type = typeof value;
  if (type == 'number' || type == 'symbol' || type == 'boolean' ||
      value == null || isSymbol(value)) {
    return true;
  }
  return reIsPlainProp.test(value) || !reIsDeepProp.test(value) ||
    (object != null && value in Object(object));
}

module.exports = isKey;


/***/ }),
/* 1054 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;

var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };

exports.default = printValue;

var _isFunction = __webpack_require__(183);

var _isFunction2 = _interopRequireDefault(_isFunction);

var _isSymbol = __webpack_require__(181);

var _isSymbol2 = _interopRequireDefault(_isSymbol);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var toString = Object.prototype.toString;
var toISOString = Date.prototype.toISOString;
var errorToString = Error.prototype.toString;
var regExpToString = RegExp.prototype.toString;
var symbolToString = typeof Symbol !== 'undefined' ? Symbol.prototype.toString : function () {
  return '';
};

var SYMBOL_REGEXP = /^Symbol\((.*)\)(.*)$/;

function printNumber(val) {
  if (val != +val) return 'NaN';
  var isNegativeZero = val === 0 && 1 / val < 0;
  return isNegativeZero ? '-0' : '' + val;
}

function printFunction(val) {
  return '[Function ' + (val.name || 'anonymous') + ']';
}

function printSymbol(val) {
  return symbolToString.call(val).replace(SYMBOL_REGEXP, 'Symbol($1)');
}

function printError(val) {
  return '[' + errorToString.call(val) + ']';
}

function printSimpleValue(val) {
  var quoteStrings = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : false;

  if (val === true || val === false) return '' + val;
  if (val === undefined) return 'undefined';
  if (val === null) return 'null';

  var typeOf = typeof val === 'undefined' ? 'undefined' : _typeof(val);

  if (typeOf === 'number') return printNumber(val);
  if (typeOf === 'string') return quoteStrings ? '"' + val + '"' : val;
  if ((0, _isFunction2.default)(val)) return printFunction(val);
  if ((0, _isSymbol2.default)(val)) return printSymbol(val);

  var tag = toString.call(val);
  if (tag === '[object Date]') return isNaN(val.getTime()) ? String(val) : toISOString.call(val);
  if (tag === '[object Error]' || val instanceof Error) return printError(val);
  if (tag === '[object RegExp]') return regExpToString.call(val);

  return null;
}

function printValue(value, quoteStrings) {
  var result = printSimpleValue(value, quoteStrings);
  if (result !== null) return result;

  return JSON.stringify(value, function (key, value) {
    var result = printSimpleValue(this[key], quoteStrings);
    if (result !== null) return result;
    return value;
  }, 2);
}
module.exports = exports['default'];

/***/ }),
/* 1055 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;
exports.propagateErrors = propagateErrors;
exports.settled = settled;
exports.collectErrors = collectErrors;
exports.default = runValidations;

var _synchronousPromise = __webpack_require__(1066);

var _ValidationError = __webpack_require__(1056);

var _ValidationError2 = _interopRequireDefault(_ValidationError);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _objectWithoutProperties(obj, keys) { var target = {}; for (var i in obj) { if (keys.indexOf(i) >= 0) continue; if (!Object.prototype.hasOwnProperty.call(obj, i)) continue; target[i] = obj[i]; } return target; }

var promise = function promise(sync) {
  return sync ? _synchronousPromise.SynchronousPromise : Promise;
};

var unwrapError = function unwrapError() {
  var errors = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : [];
  return errors.inner && errors.inner.length ? errors.inner : [].concat(errors);
};

function scopeToValue(promises, value, sync) {
  //console.log('scopeToValue', promises, value)
  var p = promise(sync).all(promises);

  //console.log('scopeToValue B', p)

  var b = p.catch(function (err) {
    if (err.name === 'ValidationError') err.value = value;
    throw err;
  });
  //console.log('scopeToValue c', b)
  var c = b.then(function () {
    return value;
  });
  //console.log('scopeToValue d', c)
  return c;
}

/**
 * If not failing on the first error, catch the errors
 * and collect them in an array
 */
function propagateErrors(endEarly, errors) {
  return endEarly ? null : function (err) {
    errors.push(err);
    return err.value;
  };
}

function settled(promises, sync) {
  var settle = function settle(promise) {
    return promise.then(function (value) {
      return { fulfilled: true, value: value };
    }, function (value) {
      return { fulfilled: false, value: value };
    });
  };

  return promise(sync).all(promises.map(settle));
}

function collectErrors(_ref) {
  var validations = _ref.validations,
      value = _ref.value,
      path = _ref.path,
      sync = _ref.sync,
      errors = _ref.errors,
      sort = _ref.sort;

  errors = unwrapError(errors);
  return settled(validations, sync).then(function (results) {
    var nestedErrors = results.filter(function (r) {
      return !r.fulfilled;
    }).reduce(function (arr, _ref2) {
      var error = _ref2.value;

      // we are only collecting validation errors
      if (!_ValidationError2.default.isError(error)) {
        throw error;
      }
      return arr.concat(error);
    }, []);

    if (sort) nestedErrors.sort(sort);

    //show parent errors after the nested ones: name.first, name
    errors = nestedErrors.concat(errors);

    if (errors.length) throw new _ValidationError2.default(errors, value, path);

    return value;
  });
}

function runValidations(_ref3) {
  var endEarly = _ref3.endEarly,
      options = _objectWithoutProperties(_ref3, ['endEarly']);

  if (endEarly) return scopeToValue(options.validations, options.value, options.sync);

  return collectErrors(options);
}

/***/ }),
/* 1056 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;
exports.default = ValidationError;

var _printValue = __webpack_require__(1054);

var _printValue2 = _interopRequireDefault(_printValue);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _objectWithoutProperties(obj, keys) { var target = {}; for (var i in obj) { if (keys.indexOf(i) >= 0) continue; if (!Object.prototype.hasOwnProperty.call(obj, i)) continue; target[i] = obj[i]; } return target; }

var strReg = /\$\{\s*(\w+)\s*\}/g;

var replace = function replace(str) {
  return function (params) {
    return str.replace(strReg, function (_, key) {
      return (0, _printValue2.default)(params[key]);
    });
  };
};

function ValidationError(errors, value, field, type) {
  var _this = this;

  this.name = 'ValidationError';
  this.value = value;
  this.path = field;
  this.type = type;
  this.errors = [];
  this.inner = [];

  if (errors) [].concat(errors).forEach(function (err) {
    _this.errors = _this.errors.concat(err.errors || err);

    if (err.inner) _this.inner = _this.inner.concat(err.inner.length ? err.inner : err);
  });

  this.message = this.errors.length > 1 ? this.errors.length + ' errors occurred' : this.errors[0];

  if (Error.captureStackTrace) Error.captureStackTrace(this, ValidationError);
}

ValidationError.prototype = Object.create(Error.prototype);
ValidationError.prototype.constructor = ValidationError;

ValidationError.isError = function (err) {
  return err && err.name === 'ValidationError';
};

ValidationError.formatError = function (message, params) {

  if (typeof message === 'string') message = replace(message);

  var fn = function fn(_ref) {
    var path = _ref.path,
        label = _ref.label,
        params = _objectWithoutProperties(_ref, ['path', 'label']);

    params.path = label || path || 'this';
    return typeof message === 'function' ? message(params) : message;
  };

  return arguments.length === 1 ? fn : fn(params);
};
module.exports = exports['default'];

/***/ }),
/* 1057 */
/***/ (function(module, exports, __webpack_require__) {

var baseFor = __webpack_require__(1103),
    keys = __webpack_require__(120);

/**
 * The base implementation of `_.forOwn` without support for iteratee shorthands.
 *
 * @private
 * @param {Object} object The object to iterate over.
 * @param {Function} iteratee The function invoked per iteration.
 * @returns {Object} Returns `object`.
 */
function baseForOwn(object, iteratee) {
  return object && baseFor(object, iteratee, keys);
}

module.exports = baseForOwn;


/***/ }),
/* 1058 */
/***/ (function(module, exports, __webpack_require__) {

var baseMatches = __webpack_require__(1105),
    baseMatchesProperty = __webpack_require__(1116),
    identity = __webpack_require__(1070),
    isArray = __webpack_require__(92),
    property = __webpack_require__(1120);

/**
 * The base implementation of `_.iteratee`.
 *
 * @private
 * @param {*} [value=_.identity] The value to convert to an iteratee.
 * @returns {Function} Returns the iteratee.
 */
function baseIteratee(value) {
  // Don't store the `typeof` result in a variable to avoid a JIT bug in Safari 9.
  // See https://bugs.webkit.org/show_bug.cgi?id=156034 for more details.
  if (typeof value == 'function') {
    return value;
  }
  if (value == null) {
    return identity;
  }
  if (typeof value == 'object') {
    return isArray(value)
      ? baseMatchesProperty(value[0], value[1])
      : baseMatches(value);
  }
  return property(value);
}

module.exports = baseIteratee;


/***/ }),
/* 1059 */
/***/ (function(module, exports, __webpack_require__) {

var castPath = __webpack_require__(1050),
    toKey = __webpack_require__(1047);

/**
 * The base implementation of `_.get` without support for default values.
 *
 * @private
 * @param {Object} object The object to query.
 * @param {Array|string} path The path of the property to get.
 * @returns {*} Returns the resolved value.
 */
function baseGet(object, path) {
  path = castPath(path, object);

  var index = 0,
      length = path.length;

  while (object != null && index < length) {
    object = object[toKey(path[index++])];
  }
  return (index && index == length) ? object : undefined;
}

module.exports = baseGet;


/***/ }),
/* 1060 */
/***/ (function(module, exports, __webpack_require__) {

var baseIsEqualDeep = __webpack_require__(1107),
    isObjectLike = __webpack_require__(69);

/**
 * The base implementation of `_.isEqual` which supports partial comparisons
 * and tracks traversed objects.
 *
 * @private
 * @param {*} value The value to compare.
 * @param {*} other The other value to compare.
 * @param {boolean} bitmask The bitmask flags.
 *  1 - Unordered comparison
 *  2 - Partial comparison
 * @param {Function} [customizer] The function to customize comparisons.
 * @param {Object} [stack] Tracks traversed `value` and `other` objects.
 * @returns {boolean} Returns `true` if the values are equivalent, else `false`.
 */
function baseIsEqual(value, other, bitmask, customizer, stack) {
  if (value === other) {
    return true;
  }
  if (value == null || other == null || (!isObjectLike(value) && !isObjectLike(other))) {
    return value !== value && other !== other;
  }
  return baseIsEqualDeep(value, other, bitmask, customizer, baseIsEqual, stack);
}

module.exports = baseIsEqual;


/***/ }),
/* 1061 */
/***/ (function(module, exports, __webpack_require__) {

var castPath = __webpack_require__(1050),
    isArguments = __webpack_require__(309),
    isArray = __webpack_require__(92),
    isIndex = __webpack_require__(318),
    isLength = __webpack_require__(189),
    toKey = __webpack_require__(1047);

/**
 * Checks if `path` exists on `object`.
 *
 * @private
 * @param {Object} object The object to query.
 * @param {Array|string} path The path to check.
 * @param {Function} hasFunc The function to check properties.
 * @returns {boolean} Returns `true` if `path` exists, else `false`.
 */
function hasPath(object, path, hasFunc) {
  path = castPath(path, object);

  var index = -1,
      length = path.length,
      result = false;

  while (++index < length) {
    var key = toKey(path[index]);
    if (!(result = object != null && hasFunc(object, key))) {
      break;
    }
    object = object[key];
  }
  if (result || ++index != length) {
    return result;
  }
  length = object == null ? 0 : object.length;
  return !!length && isLength(length) && isIndex(key, length) &&
    (isArray(object) || isArguments(object));
}

module.exports = hasPath;


/***/ }),
/* 1062 */
/***/ (function(module, exports) {

/**
 * Converts `map` to its key-value pairs.
 *
 * @private
 * @param {Object} map The map to convert.
 * @returns {Array} Returns the key-value pairs.
 */
function mapToArray(map) {
  var index = -1,
      result = Array(map.size);

  map.forEach(function(value, key) {
    result[++index] = [key, value];
  });
  return result;
}

module.exports = mapToArray;


/***/ }),
/* 1063 */
/***/ (function(module, exports) {

/**
 * Converts `set` to an array of its values.
 *
 * @private
 * @param {Object} set The set to convert.
 * @returns {Array} Returns the values.
 */
function setToArray(set) {
  var index = -1,
      result = Array(set.size);

  set.forEach(function(value) {
    result[++index] = value;
  });
  return result;
}

module.exports = setToArray;


/***/ }),
/* 1064 */
/***/ (function(module, exports, __webpack_require__) {

var asciiToArray = __webpack_require__(1095),
    hasUnicode = __webpack_require__(1065),
    unicodeToArray = __webpack_require__(1096);

/**
 * Converts `string` to an array.
 *
 * @private
 * @param {string} string The string to convert.
 * @returns {Array} Returns the converted array.
 */
function stringToArray(string) {
  return hasUnicode(string)
    ? unicodeToArray(string)
    : asciiToArray(string);
}

module.exports = stringToArray;


/***/ }),
/* 1065 */
/***/ (function(module, exports) {

/** Used to compose unicode character classes. */
var rsAstralRange = '\\ud800-\\udfff',
    rsComboMarksRange = '\\u0300-\\u036f',
    reComboHalfMarksRange = '\\ufe20-\\ufe2f',
    rsComboSymbolsRange = '\\u20d0-\\u20ff',
    rsComboRange = rsComboMarksRange + reComboHalfMarksRange + rsComboSymbolsRange,
    rsVarRange = '\\ufe0e\\ufe0f';

/** Used to compose unicode capture groups. */
var rsZWJ = '\\u200d';

/** Used to detect strings with [zero-width joiners or code points from the astral planes](http://eev.ee/blog/2015/09/12/dark-corners-of-unicode/). */
var reHasUnicode = RegExp('[' + rsZWJ + rsAstralRange  + rsComboRange + rsVarRange + ']');

/**
 * Checks if `string` contains Unicode symbols.
 *
 * @private
 * @param {string} string The string to inspect.
 * @returns {boolean} Returns `true` if a symbol is found, else `false`.
 */
function hasUnicode(string) {
  return reHasUnicode.test(string);
}

module.exports = hasUnicode;


/***/ }),
/* 1066 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

function argumentsToArray(args) {
  return Array.prototype.slice.apply(args);
}

function looksLikePromise(thing) {
  return thing &&
    thing.then &&
    typeof (thing.then) === "function" &&
    typeof (thing.catch) === "function";
}

function SynchronousPromise(ctorFunction) {
  this.status = "pending";
  this._paused = false;
  this._next = [];
  this._data = [];
  this._runConstructorFunction(ctorFunction);
}

SynchronousPromise.prototype = {
  then: function (next, fail) {
    this._next.push([next, fail]);

    if (this._isPendingResolutionOrRejection()) {
      return this;
    }

    return this._applyNext();
  },
  catch: function (fn) {
    this._next.push([undefined, fn]);

    if (this._isPendingResolutionOrRejection()) {
      return this;
    }

    return this._applyNext();
  },
  pause: function () {
    this._paused = true;
    return this;
  },
  resume: function () {
    this._paused = false;
    return this._applyNext();
  },
  _runConstructorFunction: function (ctorFunction) {
    var self = this;

    this._next.push([
      function (r) { return r; },
      function (err) { throw err; }
    ]);

    var isRun = false;
    ctorFunction(function (result) {
      if (isRun) {
        return;
      }

      isRun = true;
      self._setResolved();
      self._data = [result];
      self._applyNext();
    }, function (err) {
      if (isRun) {
        return;
      }

      isRun = true;
      self._setRejected();
      self._data = [err];
      self._applyNext();
    });
  },
  _setRejected: function () {
    this.status = "rejected";
  },
  _setResolved: function () {
    this.status = "resolved";
  },
  _setPending: function () {
    this.status = "pending";
  },
  _applyNext: function () {
    if (this._next.length === 0 || this._paused) {
      return this;
    }

    var next = this._findNext();
    if (!next) {
      return this;
    }
    return this._applyNextHandler(next);
  },
  _applyNextHandler: function (handler) {
    try {
      var data = handler.apply(null, this._data);

      if (looksLikePromise(data)) {
        this._handleNestedPromise(data);
        return this;
      }

      this._setResolved();
      this._data = [data];
      return this._applyNext();
    } catch (e) {
      this._setRejected();
      this._data = [e];
      return this._applyNext();
    }
  },
  _findNext: function () {
    if (this._isPendingResolutionOrRejection()) {
      return undefined;
    }
    var handler = this.status === "resolved"
          ? this._findFirstResolutionHandler
          : this._findFirstRejectionHandler;
    return handler ? handler.apply(this) : undefined;
  },
  _handleNestedPromise: function (promise) {
    this._setPending();
    var self = this;
    promise.then(function (d) {
      self._setResolved();
      self._data = [d];
      self._applyNext();
    }).catch(function (e) {
      self._setRejected();
      self._data = [e];
      self._applyNext();
    });
  },
  _isPendingResolutionOrRejection: function () {
    return this.status === "pending";
  },
  _findFirstResolutionHandler: function () {
    var next;
    while (!next && this._next.length > 0) {
      next = this._next.shift()[0];
    }

    return next;
  },
  _findFirstRejectionHandler: function () {
    var next;
    while (!next && this._next.length > 0) {
      next = this._next.shift()[1];
    }

    return next;
  }
};
SynchronousPromise.resolve = function (data) {
  if (looksLikePromise(data)) {
    return data;
  }

  return new SynchronousPromise(function (resolve) {
    resolve(data);
  });
};
SynchronousPromise.reject = function (error) {
  if (looksLikePromise(error)) {
    return error;
  }

  return new SynchronousPromise(function (resolve, reject) {
    reject(error);
  });
};
SynchronousPromise.all = function () {
  var args = argumentsToArray(arguments);
  if (Array.isArray(args[0])) {
    args = args[0];
  }
  if (!args.length) {
    return SynchronousPromise.resolve([]);
  }
  return new SynchronousPromise(function (resolve, reject) {
    var
      allData = [],
      numResolved = 0,
      doResolve = function () {
        if (numResolved === args.length) {
          resolve(allData);
        }
      },
      rejected = false,
      doReject = function (err) {
        if (rejected) {
          return;
        }
        rejected = true;
        reject(err);
      };
    args.forEach(function (arg, idx) {
      SynchronousPromise.resolve(arg).then(function (thisResult) {
        allData[idx] = thisResult;
        numResolved += 1;
        doResolve();
      }).catch(function (err) {
        doReject(err);
      });
    });
  });
};
SynchronousPromise.unresolved = function () {
  var stash = {};
  var result = new SynchronousPromise(function (resolve, reject) {
    stash.resolve = resolve;
    stash.reject = reject;
  });
  result.resolve = stash.resolve;
  result.reject = stash.reject;
  return result;
};

module.exports = {
  SynchronousPromise: SynchronousPromise
};



/***/ }),
/* 1067 */
/***/ (function(module, exports, __webpack_require__) {

var SetCache = __webpack_require__(1108),
    arraySome = __webpack_require__(1111),
    cacheHas = __webpack_require__(1112);

/** Used to compose bitmasks for value comparisons. */
var COMPARE_PARTIAL_FLAG = 1,
    COMPARE_UNORDERED_FLAG = 2;

/**
 * A specialized version of `baseIsEqualDeep` for arrays with support for
 * partial deep comparisons.
 *
 * @private
 * @param {Array} array The array to compare.
 * @param {Array} other The other array to compare.
 * @param {number} bitmask The bitmask flags. See `baseIsEqual` for more details.
 * @param {Function} customizer The function to customize comparisons.
 * @param {Function} equalFunc The function to determine equivalents of values.
 * @param {Object} stack Tracks traversed `array` and `other` objects.
 * @returns {boolean} Returns `true` if the arrays are equivalent, else `false`.
 */
function equalArrays(array, other, bitmask, customizer, equalFunc, stack) {
  var isPartial = bitmask & COMPARE_PARTIAL_FLAG,
      arrLength = array.length,
      othLength = other.length;

  if (arrLength != othLength && !(isPartial && othLength > arrLength)) {
    return false;
  }
  // Assume cyclic values are equal.
  var stacked = stack.get(array);
  if (stacked && stack.get(other)) {
    return stacked == other;
  }
  var index = -1,
      result = true,
      seen = (bitmask & COMPARE_UNORDERED_FLAG) ? new SetCache : undefined;

  stack.set(array, other);
  stack.set(other, array);

  // Ignore non-index properties.
  while (++index < arrLength) {
    var arrValue = array[index],
        othValue = other[index];

    if (customizer) {
      var compared = isPartial
        ? customizer(othValue, arrValue, index, other, array, stack)
        : customizer(arrValue, othValue, index, array, other, stack);
    }
    if (compared !== undefined) {
      if (compared) {
        continue;
      }
      result = false;
      break;
    }
    // Recursively compare arrays (susceptible to call stack limits).
    if (seen) {
      if (!arraySome(other, function(othValue, othIndex) {
            if (!cacheHas(seen, othIndex) &&
                (arrValue === othValue || equalFunc(arrValue, othValue, bitmask, customizer, stack))) {
              return seen.push(othIndex);
            }
          })) {
        result = false;
        break;
      }
    } else if (!(
          arrValue === othValue ||
            equalFunc(arrValue, othValue, bitmask, customizer, stack)
        )) {
      result = false;
      break;
    }
  }
  stack['delete'](array);
  stack['delete'](other);
  return result;
}

module.exports = equalArrays;


/***/ }),
/* 1068 */
/***/ (function(module, exports, __webpack_require__) {

var isObject = __webpack_require__(52);

/**
 * Checks if `value` is suitable for strict equality comparisons, i.e. `===`.
 *
 * @private
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` if suitable for strict
 *  equality comparisons, else `false`.
 */
function isStrictComparable(value) {
  return value === value && !isObject(value);
}

module.exports = isStrictComparable;


/***/ }),
/* 1069 */
/***/ (function(module, exports) {

/**
 * A specialized version of `matchesProperty` for source values suitable
 * for strict equality comparisons, i.e. `===`.
 *
 * @private
 * @param {string} key The key of the property to get.
 * @param {*} srcValue The value to match.
 * @returns {Function} Returns the new spec function.
 */
function matchesStrictComparable(key, srcValue) {
  return function(object) {
    if (object == null) {
      return false;
    }
    return object[key] === srcValue &&
      (srcValue !== undefined || (key in Object(object)));
  };
}

module.exports = matchesStrictComparable;


/***/ }),
/* 1070 */
/***/ (function(module, exports) {

/**
 * This method returns the first argument it receives.
 *
 * @static
 * @since 0.1.0
 * @memberOf _
 * @category Util
 * @param {*} value Any value.
 * @returns {*} Returns `value`.
 * @example
 *
 * var object = { 'a': 1 };
 *
 * console.log(_.identity(object) === object);
 * // => true
 */
function identity(value) {
  return value;
}

module.exports = identity;


/***/ }),
/* 1071 */
/***/ (function(module, exports) {

/**
 * The base implementation of `_.slice` without an iteratee call guard.
 *
 * @private
 * @param {Array} array The array to slice.
 * @param {number} [start=0] The start position.
 * @param {number} [end=array.length] The end position.
 * @returns {Array} Returns the slice of `array`.
 */
function baseSlice(array, start, end) {
  var index = -1,
      length = array.length;

  if (start < 0) {
    start = -start > length ? 0 : (length + start);
  }
  end = end > length ? length : end;
  if (end < 0) {
    end += length;
  }
  length = start > end ? 0 : ((end - start) >>> 0);
  start >>>= 0;

  var result = Array(length);
  while (++index < length) {
    result[index] = array[index + start];
  }
  return result;
}

module.exports = baseSlice;


/***/ }),
/* 1072 */
/***/ (function(module, exports, __webpack_require__) {

var arrayReduce = __webpack_require__(1146),
    deburr = __webpack_require__(1147),
    words = __webpack_require__(1150);

/** Used to compose unicode capture groups. */
var rsApos = "['\u2019]";

/** Used to match apostrophes. */
var reApos = RegExp(rsApos, 'g');

/**
 * Creates a function like `_.camelCase`.
 *
 * @private
 * @param {Function} callback The function to combine each word.
 * @returns {Function} Returns the new compounder function.
 */
function createCompounder(callback) {
  return function(string) {
    return arrayReduce(words(deburr(string).replace(reApos, '')), callback, '');
  };
}

module.exports = createCompounder;


/***/ }),
/* 1073 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;
exports.default = makePath;
function makePath(strings) {
  for (var _len = arguments.length, values = Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++) {
    values[_key - 1] = arguments[_key];
  }

  var path = strings.reduce(function (str, next) {
    var value = values.shift();
    return str + (value == null ? '' : value) + next;
  });

  return path.replace(/^\./, '');
}
module.exports = exports['default'];

/***/ }),
/* 1074 */
/***/ (function(module, exports, __webpack_require__) {

var __WEBPACK_AMD_DEFINE_RESULT__;/*!
  Copyright (c) 2015 Jed Watson.
  Based on code that is Copyright 2013-2015, Facebook, Inc.
  All rights reserved.
*/
/* global define */

(function () {
	'use strict';

	var canUseDOM = !!(
		typeof window !== 'undefined' &&
		window.document &&
		window.document.createElement
	);

	var ExecutionEnvironment = {

		canUseDOM: canUseDOM,

		canUseWorkers: typeof Worker !== 'undefined',

		canUseEventListeners:
			canUseDOM && !!(window.addEventListener || window.attachEvent),

		canUseViewport: canUseDOM && !!window.screen

	};

	if (true) {
		!(__WEBPACK_AMD_DEFINE_RESULT__ = function () {
			return ExecutionEnvironment;
		}.call(exports, __webpack_require__, exports, module),
				__WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));
	} else if (typeof module !== 'undefined' && module.exports) {
		module.exports = ExecutionEnvironment;
	} else {
		window.ExecutionEnvironment = ExecutionEnvironment;
	}

}());


/***/ }),
/* 1075 */
/***/ (function(module, exports, __webpack_require__) {

exports.__esModule = true;
exports.Helmet = undefined;

var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _react = __webpack_require__(0);

var _react2 = _interopRequireDefault(_react);

var _propTypes = __webpack_require__(1);

var _propTypes2 = _interopRequireDefault(_propTypes);

var _reactSideEffect = __webpack_require__(1076);

var _reactSideEffect2 = _interopRequireDefault(_reactSideEffect);

var _deepEqual = __webpack_require__(1078);

var _deepEqual2 = _interopRequireDefault(_deepEqual);

var _HelmetUtils = __webpack_require__(1081);

var _HelmetConstants = __webpack_require__(1052);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _objectWithoutProperties(obj, keys) { var target = {}; for (var i in obj) { if (keys.indexOf(i) >= 0) continue; if (!Object.prototype.hasOwnProperty.call(obj, i)) continue; target[i] = obj[i]; } return target; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var Helmet = function Helmet(Component) {
    var _class, _temp;

    return _temp = _class = function (_React$Component) {
        _inherits(HelmetWrapper, _React$Component);

        function HelmetWrapper() {
            _classCallCheck(this, HelmetWrapper);

            return _possibleConstructorReturn(this, _React$Component.apply(this, arguments));
        }

        HelmetWrapper.prototype.shouldComponentUpdate = function shouldComponentUpdate(nextProps) {
            return !(0, _deepEqual2.default)(this.props, nextProps);
        };

        HelmetWrapper.prototype.mapNestedChildrenToProps = function mapNestedChildrenToProps(child, nestedChildren) {
            if (!nestedChildren) {
                return null;
            }

            switch (child.type) {
                case _HelmetConstants.TAG_NAMES.SCRIPT:
                case _HelmetConstants.TAG_NAMES.NOSCRIPT:
                    return {
                        innerHTML: nestedChildren
                    };

                case _HelmetConstants.TAG_NAMES.STYLE:
                    return {
                        cssText: nestedChildren
                    };
            }

            throw new Error("<" + child.type + " /> elements are self-closing and can not contain children. Refer to our API for more information.");
        };

        HelmetWrapper.prototype.flattenArrayTypeChildren = function flattenArrayTypeChildren(_ref) {
            var _extends2;

            var child = _ref.child,
                arrayTypeChildren = _ref.arrayTypeChildren,
                newChildProps = _ref.newChildProps,
                nestedChildren = _ref.nestedChildren;

            return _extends({}, arrayTypeChildren, (_extends2 = {}, _extends2[child.type] = [].concat(arrayTypeChildren[child.type] || [], [_extends({}, newChildProps, this.mapNestedChildrenToProps(child, nestedChildren))]), _extends2));
        };

        HelmetWrapper.prototype.mapObjectTypeChildren = function mapObjectTypeChildren(_ref2) {
            var _extends3, _extends4;

            var child = _ref2.child,
                newProps = _ref2.newProps,
                newChildProps = _ref2.newChildProps,
                nestedChildren = _ref2.nestedChildren;

            switch (child.type) {
                case _HelmetConstants.TAG_NAMES.TITLE:
                    return _extends({}, newProps, (_extends3 = {}, _extends3[child.type] = nestedChildren, _extends3.titleAttributes = _extends({}, newChildProps), _extends3));

                case _HelmetConstants.TAG_NAMES.BODY:
                    return _extends({}, newProps, {
                        bodyAttributes: _extends({}, newChildProps)
                    });

                case _HelmetConstants.TAG_NAMES.HTML:
                    return _extends({}, newProps, {
                        htmlAttributes: _extends({}, newChildProps)
                    });
            }

            return _extends({}, newProps, (_extends4 = {}, _extends4[child.type] = _extends({}, newChildProps), _extends4));
        };

        HelmetWrapper.prototype.mapArrayTypeChildrenToProps = function mapArrayTypeChildrenToProps(arrayTypeChildren, newProps) {
            var newFlattenedProps = _extends({}, newProps);

            Object.keys(arrayTypeChildren).forEach(function (arrayChildName) {
                var _extends5;

                newFlattenedProps = _extends({}, newFlattenedProps, (_extends5 = {}, _extends5[arrayChildName] = arrayTypeChildren[arrayChildName], _extends5));
            });

            return newFlattenedProps;
        };

        HelmetWrapper.prototype.warnOnInvalidChildren = function warnOnInvalidChildren(child, nestedChildren) {
            if (false) {
                if (!_HelmetConstants.VALID_TAG_NAMES.some(function (name) {
                    return child.type === name;
                })) {
                    if (typeof child.type === "function") {
                        return (0, _HelmetUtils.warn)("You may be attempting to nest <Helmet> components within each other, which is not allowed. Refer to our API for more information.");
                    }

                    return (0, _HelmetUtils.warn)("Only elements types " + _HelmetConstants.VALID_TAG_NAMES.join(", ") + " are allowed. Helmet does not support rendering <" + child.type + "> elements. Refer to our API for more information.");
                }

                if (nestedChildren && typeof nestedChildren !== "string" && (!Array.isArray(nestedChildren) || nestedChildren.some(function (nestedChild) {
                    return typeof nestedChild !== "string";
                }))) {
                    throw new Error("Helmet expects a string as a child of <" + child.type + ">. Did you forget to wrap your children in braces? ( <" + child.type + ">{``}</" + child.type + "> ) Refer to our API for more information.");
                }
            }

            return true;
        };

        HelmetWrapper.prototype.mapChildrenToProps = function mapChildrenToProps(children, newProps) {
            var _this2 = this;

            var arrayTypeChildren = {};

            _react2.default.Children.forEach(children, function (child) {
                if (!child || !child.props) {
                    return;
                }

                var _child$props = child.props,
                    nestedChildren = _child$props.children,
                    childProps = _objectWithoutProperties(_child$props, ["children"]);

                var newChildProps = (0, _HelmetUtils.convertReactPropstoHtmlAttributes)(childProps);

                _this2.warnOnInvalidChildren(child, nestedChildren);

                switch (child.type) {
                    case _HelmetConstants.TAG_NAMES.LINK:
                    case _HelmetConstants.TAG_NAMES.META:
                    case _HelmetConstants.TAG_NAMES.NOSCRIPT:
                    case _HelmetConstants.TAG_NAMES.SCRIPT:
                    case _HelmetConstants.TAG_NAMES.STYLE:
                        arrayTypeChildren = _this2.flattenArrayTypeChildren({
                            child: child,
                            arrayTypeChildren: arrayTypeChildren,
                            newChildProps: newChildProps,
                            nestedChildren: nestedChildren
                        });
                        break;

                    default:
                        newProps = _this2.mapObjectTypeChildren({
                            child: child,
                            newProps: newProps,
                            newChildProps: newChildProps,
                            nestedChildren: nestedChildren
                        });
                        break;
                }
            });

            newProps = this.mapArrayTypeChildrenToProps(arrayTypeChildren, newProps);
            return newProps;
        };

        HelmetWrapper.prototype.render = function render() {
            var _props = this.props,
                children = _props.children,
                props = _objectWithoutProperties(_props, ["children"]);

            var newProps = _extends({}, props);

            if (children) {
                newProps = this.mapChildrenToProps(children, newProps);
            }

            return _react2.default.createElement(Component, newProps);
        };

        _createClass(HelmetWrapper, null, [{
            key: "canUseDOM",


            // Component.peek comes from react-side-effect:
            // For testing, you may use a static peek() method available on the returned component.
            // It lets you get the current state without resetting the mounted instance stack.
            // Don’t use it for anything other than testing.

            /**
            * @param {Object} base: {"target": "_blank", "href": "http://mysite.com/"}
            * @param {Object} bodyAttributes: {"className": "root"}
            * @param {String} defaultTitle: "Default Title"
            * @param {Boolean} defer: true
            * @param {Boolean} encodeSpecialCharacters: true
            * @param {Object} htmlAttributes: {"lang": "en", "amp": undefined}
            * @param {Array} link: [{"rel": "canonical", "href": "http://mysite.com/example"}]
            * @param {Array} meta: [{"name": "description", "content": "Test description"}]
            * @param {Array} noscript: [{"innerHTML": "<img src='http://mysite.com/js/test.js'"}]
            * @param {Function} onChangeClientState: "(newState) => console.log(newState)"
            * @param {Array} script: [{"type": "text/javascript", "src": "http://mysite.com/js/test.js"}]
            * @param {Array} style: [{"type": "text/css", "cssText": "div { display: block; color: blue; }"}]
            * @param {String} title: "Title"
            * @param {Object} titleAttributes: {"itemprop": "name"}
            * @param {String} titleTemplate: "MySite.com - %s"
            */
            set: function set(canUseDOM) {
                Component.canUseDOM = canUseDOM;
            }
        }]);

        return HelmetWrapper;
    }(_react2.default.Component), _class.propTypes = {
        base: _propTypes2.default.object,
        bodyAttributes: _propTypes2.default.object,
        children: _propTypes2.default.oneOfType([_propTypes2.default.arrayOf(_propTypes2.default.node), _propTypes2.default.node]),
        defaultTitle: _propTypes2.default.string,
        defer: _propTypes2.default.bool,
        encodeSpecialCharacters: _propTypes2.default.bool,
        htmlAttributes: _propTypes2.default.object,
        link: _propTypes2.default.arrayOf(_propTypes2.default.object),
        meta: _propTypes2.default.arrayOf(_propTypes2.default.object),
        noscript: _propTypes2.default.arrayOf(_propTypes2.default.object),
        onChangeClientState: _propTypes2.default.func,
        script: _propTypes2.default.arrayOf(_propTypes2.default.object),
        style: _propTypes2.default.arrayOf(_propTypes2.default.object),
        title: _propTypes2.default.string,
        titleAttributes: _propTypes2.default.object,
        titleTemplate: _propTypes2.default.string
    }, _class.defaultProps = {
        defer: true,
        encodeSpecialCharacters: true
    }, _class.peek = Component.peek, _class.rewind = function () {
        var mappedState = Component.rewind();
        if (!mappedState) {
            // provide fallback if mappedState is undefined
            mappedState = (0, _HelmetUtils.mapStateOnServer)({
                baseTag: [],
                bodyAttributes: {},
                encodeSpecialCharacters: true,
                htmlAttributes: {},
                linkTags: [],
                metaTags: [],
                noscriptTags: [],
                scriptTags: [],
                styleTags: [],
                title: "",
                titleAttributes: {}
            });
        }

        return mappedState;
    }, _temp;
};

var NullComponent = function NullComponent() {
    return null;
};

var HelmetSideEffects = (0, _reactSideEffect2.default)(_HelmetUtils.reducePropsToState, _HelmetUtils.handleClientStateChange, _HelmetUtils.mapStateOnServer)(NullComponent);

var HelmetExport = Helmet(HelmetSideEffects);
HelmetExport.renderStatic = HelmetExport.rewind;

exports.Helmet = HelmetExport;
exports.default = HelmetExport;

/***/ }),
/* 1076 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


function _interopDefault (ex) { return (ex && (typeof ex === 'object') && 'default' in ex) ? ex['default'] : ex; }

var React = __webpack_require__(0);
var React__default = _interopDefault(React);
var ExecutionEnvironment = _interopDefault(__webpack_require__(1074));
var shallowEqual = _interopDefault(__webpack_require__(1077));

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

function withSideEffect(reducePropsToState, handleStateChangeOnClient, mapStateOnServer) {
  if (typeof reducePropsToState !== 'function') {
    throw new Error('Expected reducePropsToState to be a function.');
  }
  if (typeof handleStateChangeOnClient !== 'function') {
    throw new Error('Expected handleStateChangeOnClient to be a function.');
  }
  if (typeof mapStateOnServer !== 'undefined' && typeof mapStateOnServer !== 'function') {
    throw new Error('Expected mapStateOnServer to either be undefined or a function.');
  }

  function getDisplayName(WrappedComponent) {
    return WrappedComponent.displayName || WrappedComponent.name || 'Component';
  }

  return function wrap(WrappedComponent) {
    if (typeof WrappedComponent !== 'function') {
      throw new Error('Expected WrappedComponent to be a React component.');
    }

    var mountedInstances = [];
    var state = void 0;

    function emitChange() {
      state = reducePropsToState(mountedInstances.map(function (instance) {
        return instance.props;
      }));

      if (SideEffect.canUseDOM) {
        handleStateChangeOnClient(state);
      } else if (mapStateOnServer) {
        state = mapStateOnServer(state);
      }
    }

    var SideEffect = function (_Component) {
      _inherits(SideEffect, _Component);

      function SideEffect() {
        _classCallCheck(this, SideEffect);

        return _possibleConstructorReturn(this, _Component.apply(this, arguments));
      }

      // Try to use displayName of wrapped component
      SideEffect.peek = function peek() {
        return state;
      };

      // Expose canUseDOM so tests can monkeypatch it


      SideEffect.rewind = function rewind() {
        if (SideEffect.canUseDOM) {
          throw new Error('You may only call rewind() on the server. Call peek() to read the current state.');
        }

        var recordedState = state;
        state = undefined;
        mountedInstances = [];
        return recordedState;
      };

      SideEffect.prototype.shouldComponentUpdate = function shouldComponentUpdate(nextProps) {
        return !shallowEqual(nextProps, this.props);
      };

      SideEffect.prototype.componentWillMount = function componentWillMount() {
        mountedInstances.push(this);
        emitChange();
      };

      SideEffect.prototype.componentDidUpdate = function componentDidUpdate() {
        emitChange();
      };

      SideEffect.prototype.componentWillUnmount = function componentWillUnmount() {
        var index = mountedInstances.indexOf(this);
        mountedInstances.splice(index, 1);
        emitChange();
      };

      SideEffect.prototype.render = function render() {
        return React__default.createElement(WrappedComponent, this.props);
      };

      return SideEffect;
    }(React.Component);

    SideEffect.displayName = 'SideEffect(' + getDisplayName(WrappedComponent) + ')';
    SideEffect.canUseDOM = ExecutionEnvironment.canUseDOM;


    return SideEffect;
  };
}

module.exports = withSideEffect;


/***/ }),
/* 1077 */
/***/ (function(module, exports) {

module.exports = function shallowEqual(objA, objB, compare, compareContext) {

    var ret = compare ? compare.call(compareContext, objA, objB) : void 0;

    if(ret !== void 0) {
        return !!ret;
    }

    if(objA === objB) {
        return true;
    }

    if(typeof objA !== 'object' || !objA ||
       typeof objB !== 'object' || !objB) {
        return false;
    }

    var keysA = Object.keys(objA);
    var keysB = Object.keys(objB);

    if(keysA.length !== keysB.length) {
        return false;
    }

    var bHasOwnProperty = Object.prototype.hasOwnProperty.bind(objB);

    // Test for A's keys different from B.
    for(var idx = 0; idx < keysA.length; idx++) {

        var key = keysA[idx];

        if(!bHasOwnProperty(key)) {
            return false;
        }

        var valueA = objA[key];
        var valueB = objB[key];

        ret = compare ? compare.call(compareContext, valueA, valueB, key) : void 0;

        if(ret === false ||
           ret === void 0 && valueA !== valueB) {
            return false;
        }

    }

    return true;

};


/***/ }),
/* 1078 */
/***/ (function(module, exports, __webpack_require__) {

var pSlice = Array.prototype.slice;
var objectKeys = __webpack_require__(1079);
var isArguments = __webpack_require__(1080);

var deepEqual = module.exports = function (actual, expected, opts) {
  if (!opts) opts = {};
  // 7.1. All identical values are equivalent, as determined by ===.
  if (actual === expected) {
    return true;

  } else if (actual instanceof Date && expected instanceof Date) {
    return actual.getTime() === expected.getTime();

  // 7.3. Other pairs that do not both pass typeof value == 'object',
  // equivalence is determined by ==.
  } else if (!actual || !expected || typeof actual != 'object' && typeof expected != 'object') {
    return opts.strict ? actual === expected : actual == expected;

  // 7.4. For all other Object pairs, including Array objects, equivalence is
  // determined by having the same number of owned properties (as verified
  // with Object.prototype.hasOwnProperty.call), the same set of keys
  // (although not necessarily the same order), equivalent values for every
  // corresponding key, and an identical 'prototype' property. Note: this
  // accounts for both named and indexed properties on Arrays.
  } else {
    return objEquiv(actual, expected, opts);
  }
}

function isUndefinedOrNull(value) {
  return value === null || value === undefined;
}

function isBuffer (x) {
  if (!x || typeof x !== 'object' || typeof x.length !== 'number') return false;
  if (typeof x.copy !== 'function' || typeof x.slice !== 'function') {
    return false;
  }
  if (x.length > 0 && typeof x[0] !== 'number') return false;
  return true;
}

function objEquiv(a, b, opts) {
  var i, key;
  if (isUndefinedOrNull(a) || isUndefinedOrNull(b))
    return false;
  // an identical 'prototype' property.
  if (a.prototype !== b.prototype) return false;
  //~~~I've managed to break Object.keys through screwy arguments passing.
  //   Converting to array solves the problem.
  if (isArguments(a)) {
    if (!isArguments(b)) {
      return false;
    }
    a = pSlice.call(a);
    b = pSlice.call(b);
    return deepEqual(a, b, opts);
  }
  if (isBuffer(a)) {
    if (!isBuffer(b)) {
      return false;
    }
    if (a.length !== b.length) return false;
    for (i = 0; i < a.length; i++) {
      if (a[i] !== b[i]) return false;
    }
    return true;
  }
  try {
    var ka = objectKeys(a),
        kb = objectKeys(b);
  } catch (e) {//happens when one is a string literal and the other isn't
    return false;
  }
  // having the same number of owned properties (keys incorporates
  // hasOwnProperty)
  if (ka.length != kb.length)
    return false;
  //the same set of keys (although not necessarily the same order),
  ka.sort();
  kb.sort();
  //~~~cheap key test
  for (i = ka.length - 1; i >= 0; i--) {
    if (ka[i] != kb[i])
      return false;
  }
  //equivalent values for every corresponding key, and
  //~~~possibly expensive deep test
  for (i = ka.length - 1; i >= 0; i--) {
    key = ka[i];
    if (!deepEqual(a[key], b[key], opts)) return false;
  }
  return typeof a === typeof b;
}


/***/ }),
/* 1079 */
/***/ (function(module, exports) {

exports = module.exports = typeof Object.keys === 'function'
  ? Object.keys : shim;

exports.shim = shim;
function shim (obj) {
  var keys = [];
  for (var key in obj) keys.push(key);
  return keys;
}


/***/ }),
/* 1080 */
/***/ (function(module, exports) {

var supportsArgumentsClass = (function(){
  return Object.prototype.toString.call(arguments)
})() == '[object Arguments]';

exports = module.exports = supportsArgumentsClass ? supported : unsupported;

exports.supported = supported;
function supported(object) {
  return Object.prototype.toString.call(object) == '[object Arguments]';
};

exports.unsupported = unsupported;
function unsupported(object){
  return object &&
    typeof object == 'object' &&
    typeof object.length == 'number' &&
    Object.prototype.hasOwnProperty.call(object, 'callee') &&
    !Object.prototype.propertyIsEnumerable.call(object, 'callee') ||
    false;
};


/***/ }),
/* 1081 */
/***/ (function(module, exports, __webpack_require__) {

/* WEBPACK VAR INJECTION */(function(global) {exports.__esModule = true;
exports.warn = exports.requestAnimationFrame = exports.reducePropsToState = exports.mapStateOnServer = exports.handleClientStateChange = exports.convertReactPropstoHtmlAttributes = undefined;

var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };

var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };

var _react = __webpack_require__(0);

var _react2 = _interopRequireDefault(_react);

var _objectAssign = __webpack_require__(123);

var _objectAssign2 = _interopRequireDefault(_objectAssign);

var _HelmetConstants = __webpack_require__(1052);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var encodeSpecialCharacters = function encodeSpecialCharacters(str) {
    var encode = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : true;

    if (encode === false) {
        return String(str);
    }

    return String(str).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#x27;");
};

var getTitleFromPropsList = function getTitleFromPropsList(propsList) {
    var innermostTitle = getInnermostProperty(propsList, _HelmetConstants.TAG_NAMES.TITLE);
    var innermostTemplate = getInnermostProperty(propsList, _HelmetConstants.HELMET_PROPS.TITLE_TEMPLATE);

    if (innermostTemplate && innermostTitle) {
        // use function arg to avoid need to escape $ characters
        return innermostTemplate.replace(/%s/g, function () {
            return innermostTitle;
        });
    }

    var innermostDefaultTitle = getInnermostProperty(propsList, _HelmetConstants.HELMET_PROPS.DEFAULT_TITLE);

    return innermostTitle || innermostDefaultTitle || undefined;
};

var getOnChangeClientState = function getOnChangeClientState(propsList) {
    return getInnermostProperty(propsList, _HelmetConstants.HELMET_PROPS.ON_CHANGE_CLIENT_STATE) || function () {};
};

var getAttributesFromPropsList = function getAttributesFromPropsList(tagType, propsList) {
    return propsList.filter(function (props) {
        return typeof props[tagType] !== "undefined";
    }).map(function (props) {
        return props[tagType];
    }).reduce(function (tagAttrs, current) {
        return _extends({}, tagAttrs, current);
    }, {});
};

var getBaseTagFromPropsList = function getBaseTagFromPropsList(primaryAttributes, propsList) {
    return propsList.filter(function (props) {
        return typeof props[_HelmetConstants.TAG_NAMES.BASE] !== "undefined";
    }).map(function (props) {
        return props[_HelmetConstants.TAG_NAMES.BASE];
    }).reverse().reduce(function (innermostBaseTag, tag) {
        if (!innermostBaseTag.length) {
            var keys = Object.keys(tag);

            for (var i = 0; i < keys.length; i++) {
                var attributeKey = keys[i];
                var lowerCaseAttributeKey = attributeKey.toLowerCase();

                if (primaryAttributes.indexOf(lowerCaseAttributeKey) !== -1 && tag[lowerCaseAttributeKey]) {
                    return innermostBaseTag.concat(tag);
                }
            }
        }

        return innermostBaseTag;
    }, []);
};

var getTagsFromPropsList = function getTagsFromPropsList(tagName, primaryAttributes, propsList) {
    // Calculate list of tags, giving priority innermost component (end of the propslist)
    var approvedSeenTags = {};

    return propsList.filter(function (props) {
        if (Array.isArray(props[tagName])) {
            return true;
        }
        if (typeof props[tagName] !== "undefined") {
            warn("Helmet: " + tagName + " should be of type \"Array\". Instead found type \"" + _typeof(props[tagName]) + "\"");
        }
        return false;
    }).map(function (props) {
        return props[tagName];
    }).reverse().reduce(function (approvedTags, instanceTags) {
        var instanceSeenTags = {};

        instanceTags.filter(function (tag) {
            var primaryAttributeKey = void 0;
            var keys = Object.keys(tag);
            for (var i = 0; i < keys.length; i++) {
                var attributeKey = keys[i];
                var lowerCaseAttributeKey = attributeKey.toLowerCase();

                // Special rule with link tags, since rel and href are both primary tags, rel takes priority
                if (primaryAttributes.indexOf(lowerCaseAttributeKey) !== -1 && !(primaryAttributeKey === _HelmetConstants.TAG_PROPERTIES.REL && tag[primaryAttributeKey].toLowerCase() === "canonical") && !(lowerCaseAttributeKey === _HelmetConstants.TAG_PROPERTIES.REL && tag[lowerCaseAttributeKey].toLowerCase() === "stylesheet")) {
                    primaryAttributeKey = lowerCaseAttributeKey;
                }
                // Special case for innerHTML which doesn't work lowercased
                if (primaryAttributes.indexOf(attributeKey) !== -1 && (attributeKey === _HelmetConstants.TAG_PROPERTIES.INNER_HTML || attributeKey === _HelmetConstants.TAG_PROPERTIES.CSS_TEXT || attributeKey === _HelmetConstants.TAG_PROPERTIES.ITEM_PROP)) {
                    primaryAttributeKey = attributeKey;
                }
            }

            if (!primaryAttributeKey || !tag[primaryAttributeKey]) {
                return false;
            }

            var value = tag[primaryAttributeKey].toLowerCase();

            if (!approvedSeenTags[primaryAttributeKey]) {
                approvedSeenTags[primaryAttributeKey] = {};
            }

            if (!instanceSeenTags[primaryAttributeKey]) {
                instanceSeenTags[primaryAttributeKey] = {};
            }

            if (!approvedSeenTags[primaryAttributeKey][value]) {
                instanceSeenTags[primaryAttributeKey][value] = true;
                return true;
            }

            return false;
        }).reverse().forEach(function (tag) {
            return approvedTags.push(tag);
        });

        // Update seen tags with tags from this instance
        var keys = Object.keys(instanceSeenTags);
        for (var i = 0; i < keys.length; i++) {
            var attributeKey = keys[i];
            var tagUnion = (0, _objectAssign2.default)({}, approvedSeenTags[attributeKey], instanceSeenTags[attributeKey]);

            approvedSeenTags[attributeKey] = tagUnion;
        }

        return approvedTags;
    }, []).reverse();
};

var getInnermostProperty = function getInnermostProperty(propsList, property) {
    for (var i = propsList.length - 1; i >= 0; i--) {
        var props = propsList[i];

        if (props.hasOwnProperty(property)) {
            return props[property];
        }
    }

    return null;
};

var reducePropsToState = function reducePropsToState(propsList) {
    return {
        baseTag: getBaseTagFromPropsList([_HelmetConstants.TAG_PROPERTIES.HREF], propsList),
        bodyAttributes: getAttributesFromPropsList(_HelmetConstants.ATTRIBUTE_NAMES.BODY, propsList),
        defer: getInnermostProperty(propsList, _HelmetConstants.HELMET_PROPS.DEFER),
        encode: getInnermostProperty(propsList, _HelmetConstants.HELMET_PROPS.ENCODE_SPECIAL_CHARACTERS),
        htmlAttributes: getAttributesFromPropsList(_HelmetConstants.ATTRIBUTE_NAMES.HTML, propsList),
        linkTags: getTagsFromPropsList(_HelmetConstants.TAG_NAMES.LINK, [_HelmetConstants.TAG_PROPERTIES.REL, _HelmetConstants.TAG_PROPERTIES.HREF], propsList),
        metaTags: getTagsFromPropsList(_HelmetConstants.TAG_NAMES.META, [_HelmetConstants.TAG_PROPERTIES.NAME, _HelmetConstants.TAG_PROPERTIES.CHARSET, _HelmetConstants.TAG_PROPERTIES.HTTPEQUIV, _HelmetConstants.TAG_PROPERTIES.PROPERTY, _HelmetConstants.TAG_PROPERTIES.ITEM_PROP], propsList),
        noscriptTags: getTagsFromPropsList(_HelmetConstants.TAG_NAMES.NOSCRIPT, [_HelmetConstants.TAG_PROPERTIES.INNER_HTML], propsList),
        onChangeClientState: getOnChangeClientState(propsList),
        scriptTags: getTagsFromPropsList(_HelmetConstants.TAG_NAMES.SCRIPT, [_HelmetConstants.TAG_PROPERTIES.SRC, _HelmetConstants.TAG_PROPERTIES.INNER_HTML], propsList),
        styleTags: getTagsFromPropsList(_HelmetConstants.TAG_NAMES.STYLE, [_HelmetConstants.TAG_PROPERTIES.CSS_TEXT], propsList),
        title: getTitleFromPropsList(propsList),
        titleAttributes: getAttributesFromPropsList(_HelmetConstants.ATTRIBUTE_NAMES.TITLE, propsList)
    };
};

var rafPolyfill = function () {
    var clock = Date.now();

    return function (callback) {
        var currentTime = Date.now();

        if (currentTime - clock > 16) {
            clock = currentTime;
            callback(currentTime);
        } else {
            setTimeout(function () {
                rafPolyfill(callback);
            }, 0);
        }
    };
}();

var cafPolyfill = function cafPolyfill(id) {
    return clearTimeout(id);
};

var requestAnimationFrame = typeof window !== "undefined" ? window.requestAnimationFrame || window.webkitRequestAnimationFrame || window.mozRequestAnimationFrame || rafPolyfill : global.requestAnimationFrame || rafPolyfill;

var cancelAnimationFrame = typeof window !== "undefined" ? window.cancelAnimationFrame || window.webkitCancelAnimationFrame || window.mozCancelAnimationFrame || cafPolyfill : global.cancelAnimationFrame || cafPolyfill;

var warn = function warn(msg) {
    return console && typeof console.warn === "function" && console.warn(msg);
};

var _helmetCallback = null;

var handleClientStateChange = function handleClientStateChange(newState) {
    if (_helmetCallback) {
        cancelAnimationFrame(_helmetCallback);
    }

    if (newState.defer) {
        _helmetCallback = requestAnimationFrame(function () {
            commitTagChanges(newState, function () {
                _helmetCallback = null;
            });
        });
    } else {
        commitTagChanges(newState);
        _helmetCallback = null;
    }
};

var commitTagChanges = function commitTagChanges(newState, cb) {
    var baseTag = newState.baseTag,
        bodyAttributes = newState.bodyAttributes,
        htmlAttributes = newState.htmlAttributes,
        linkTags = newState.linkTags,
        metaTags = newState.metaTags,
        noscriptTags = newState.noscriptTags,
        onChangeClientState = newState.onChangeClientState,
        scriptTags = newState.scriptTags,
        styleTags = newState.styleTags,
        title = newState.title,
        titleAttributes = newState.titleAttributes;

    updateAttributes(_HelmetConstants.TAG_NAMES.BODY, bodyAttributes);
    updateAttributes(_HelmetConstants.TAG_NAMES.HTML, htmlAttributes);

    updateTitle(title, titleAttributes);

    var tagUpdates = {
        baseTag: updateTags(_HelmetConstants.TAG_NAMES.BASE, baseTag),
        linkTags: updateTags(_HelmetConstants.TAG_NAMES.LINK, linkTags),
        metaTags: updateTags(_HelmetConstants.TAG_NAMES.META, metaTags),
        noscriptTags: updateTags(_HelmetConstants.TAG_NAMES.NOSCRIPT, noscriptTags),
        scriptTags: updateTags(_HelmetConstants.TAG_NAMES.SCRIPT, scriptTags),
        styleTags: updateTags(_HelmetConstants.TAG_NAMES.STYLE, styleTags)
    };

    var addedTags = {};
    var removedTags = {};

    Object.keys(tagUpdates).forEach(function (tagType) {
        var _tagUpdates$tagType = tagUpdates[tagType],
            newTags = _tagUpdates$tagType.newTags,
            oldTags = _tagUpdates$tagType.oldTags;


        if (newTags.length) {
            addedTags[tagType] = newTags;
        }
        if (oldTags.length) {
            removedTags[tagType] = tagUpdates[tagType].oldTags;
        }
    });

    cb && cb();

    onChangeClientState(newState, addedTags, removedTags);
};

var flattenArray = function flattenArray(possibleArray) {
    return Array.isArray(possibleArray) ? possibleArray.join("") : possibleArray;
};

var updateTitle = function updateTitle(title, attributes) {
    if (typeof title !== "undefined" && document.title !== title) {
        document.title = flattenArray(title);
    }

    updateAttributes(_HelmetConstants.TAG_NAMES.TITLE, attributes);
};

var updateAttributes = function updateAttributes(tagName, attributes) {
    var elementTag = document.getElementsByTagName(tagName)[0];

    if (!elementTag) {
        return;
    }

    var helmetAttributeString = elementTag.getAttribute(_HelmetConstants.HELMET_ATTRIBUTE);
    var helmetAttributes = helmetAttributeString ? helmetAttributeString.split(",") : [];
    var attributesToRemove = [].concat(helmetAttributes);
    var attributeKeys = Object.keys(attributes);

    for (var i = 0; i < attributeKeys.length; i++) {
        var attribute = attributeKeys[i];
        var value = attributes[attribute] || "";

        if (elementTag.getAttribute(attribute) !== value) {
            elementTag.setAttribute(attribute, value);
        }

        if (helmetAttributes.indexOf(attribute) === -1) {
            helmetAttributes.push(attribute);
        }

        var indexToSave = attributesToRemove.indexOf(attribute);
        if (indexToSave !== -1) {
            attributesToRemove.splice(indexToSave, 1);
        }
    }

    for (var _i = attributesToRemove.length - 1; _i >= 0; _i--) {
        elementTag.removeAttribute(attributesToRemove[_i]);
    }

    if (helmetAttributes.length === attributesToRemove.length) {
        elementTag.removeAttribute(_HelmetConstants.HELMET_ATTRIBUTE);
    } else if (elementTag.getAttribute(_HelmetConstants.HELMET_ATTRIBUTE) !== attributeKeys.join(",")) {
        elementTag.setAttribute(_HelmetConstants.HELMET_ATTRIBUTE, attributeKeys.join(","));
    }
};

var updateTags = function updateTags(type, tags) {
    var headElement = document.head || document.querySelector(_HelmetConstants.TAG_NAMES.HEAD);
    var tagNodes = headElement.querySelectorAll(type + "[" + _HelmetConstants.HELMET_ATTRIBUTE + "]");
    var oldTags = Array.prototype.slice.call(tagNodes);
    var newTags = [];
    var indexToDelete = void 0;

    if (tags && tags.length) {
        tags.forEach(function (tag) {
            var newElement = document.createElement(type);

            for (var attribute in tag) {
                if (tag.hasOwnProperty(attribute)) {
                    if (attribute === _HelmetConstants.TAG_PROPERTIES.INNER_HTML) {
                        newElement.innerHTML = tag.innerHTML;
                    } else if (attribute === _HelmetConstants.TAG_PROPERTIES.CSS_TEXT) {
                        if (newElement.styleSheet) {
                            newElement.styleSheet.cssText = tag.cssText;
                        } else {
                            newElement.appendChild(document.createTextNode(tag.cssText));
                        }
                    } else {
                        var value = typeof tag[attribute] === "undefined" ? "" : tag[attribute];
                        newElement.setAttribute(attribute, value);
                    }
                }
            }

            newElement.setAttribute(_HelmetConstants.HELMET_ATTRIBUTE, "true");

            // Remove a duplicate tag from domTagstoRemove, so it isn't cleared.
            if (oldTags.some(function (existingTag, index) {
                indexToDelete = index;
                return newElement.isEqualNode(existingTag);
            })) {
                oldTags.splice(indexToDelete, 1);
            } else {
                newTags.push(newElement);
            }
        });
    }

    oldTags.forEach(function (tag) {
        return tag.parentNode.removeChild(tag);
    });
    newTags.forEach(function (tag) {
        return headElement.appendChild(tag);
    });

    return {
        oldTags: oldTags,
        newTags: newTags
    };
};

var generateElementAttributesAsString = function generateElementAttributesAsString(attributes) {
    return Object.keys(attributes).reduce(function (str, key) {
        var attr = typeof attributes[key] !== "undefined" ? key + "=\"" + attributes[key] + "\"" : "" + key;
        return str ? str + " " + attr : attr;
    }, "");
};

var generateTitleAsString = function generateTitleAsString(type, title, attributes, encode) {
    var attributeString = generateElementAttributesAsString(attributes);
    var flattenedTitle = flattenArray(title);
    return attributeString ? "<" + type + " " + _HelmetConstants.HELMET_ATTRIBUTE + "=\"true\" " + attributeString + ">" + encodeSpecialCharacters(flattenedTitle, encode) + "</" + type + ">" : "<" + type + " " + _HelmetConstants.HELMET_ATTRIBUTE + "=\"true\">" + encodeSpecialCharacters(flattenedTitle, encode) + "</" + type + ">";
};

var generateTagsAsString = function generateTagsAsString(type, tags, encode) {
    return tags.reduce(function (str, tag) {
        var attributeHtml = Object.keys(tag).filter(function (attribute) {
            return !(attribute === _HelmetConstants.TAG_PROPERTIES.INNER_HTML || attribute === _HelmetConstants.TAG_PROPERTIES.CSS_TEXT);
        }).reduce(function (string, attribute) {
            var attr = typeof tag[attribute] === "undefined" ? attribute : attribute + "=\"" + encodeSpecialCharacters(tag[attribute], encode) + "\"";
            return string ? string + " " + attr : attr;
        }, "");

        var tagContent = tag.innerHTML || tag.cssText || "";

        var isSelfClosing = _HelmetConstants.SELF_CLOSING_TAGS.indexOf(type) === -1;

        return str + "<" + type + " " + _HelmetConstants.HELMET_ATTRIBUTE + "=\"true\" " + attributeHtml + (isSelfClosing ? "/>" : ">" + tagContent + "</" + type + ">");
    }, "");
};

var convertElementAttributestoReactProps = function convertElementAttributestoReactProps(attributes) {
    var initProps = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};

    return Object.keys(attributes).reduce(function (obj, key) {
        obj[_HelmetConstants.REACT_TAG_MAP[key] || key] = attributes[key];
        return obj;
    }, initProps);
};

var convertReactPropstoHtmlAttributes = function convertReactPropstoHtmlAttributes(props) {
    var initAttributes = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};

    return Object.keys(props).reduce(function (obj, key) {
        obj[_HelmetConstants.HTML_TAG_MAP[key] || key] = props[key];
        return obj;
    }, initAttributes);
};

var generateTitleAsReactComponent = function generateTitleAsReactComponent(type, title, attributes) {
    var _initProps;

    // assigning into an array to define toString function on it
    var initProps = (_initProps = {
        key: title
    }, _initProps[_HelmetConstants.HELMET_ATTRIBUTE] = true, _initProps);
    var props = convertElementAttributestoReactProps(attributes, initProps);

    return [_react2.default.createElement(_HelmetConstants.TAG_NAMES.TITLE, props, title)];
};

var generateTagsAsReactComponent = function generateTagsAsReactComponent(type, tags) {
    return tags.map(function (tag, i) {
        var _mappedTag;

        var mappedTag = (_mappedTag = {
            key: i
        }, _mappedTag[_HelmetConstants.HELMET_ATTRIBUTE] = true, _mappedTag);

        Object.keys(tag).forEach(function (attribute) {
            var mappedAttribute = _HelmetConstants.REACT_TAG_MAP[attribute] || attribute;

            if (mappedAttribute === _HelmetConstants.TAG_PROPERTIES.INNER_HTML || mappedAttribute === _HelmetConstants.TAG_PROPERTIES.CSS_TEXT) {
                var content = tag.innerHTML || tag.cssText;
                mappedTag.dangerouslySetInnerHTML = { __html: content };
            } else {
                mappedTag[mappedAttribute] = tag[attribute];
            }
        });

        return _react2.default.createElement(type, mappedTag);
    });
};

var getMethodsForTag = function getMethodsForTag(type, tags, encode) {
    switch (type) {
        case _HelmetConstants.TAG_NAMES.TITLE:
            return {
                toComponent: function toComponent() {
                    return generateTitleAsReactComponent(type, tags.title, tags.titleAttributes, encode);
                },
                toString: function toString() {
                    return generateTitleAsString(type, tags.title, tags.titleAttributes, encode);
                }
            };
        case _HelmetConstants.ATTRIBUTE_NAMES.BODY:
        case _HelmetConstants.ATTRIBUTE_NAMES.HTML:
            return {
                toComponent: function toComponent() {
                    return convertElementAttributestoReactProps(tags);
                },
                toString: function toString() {
                    return generateElementAttributesAsString(tags);
                }
            };
        default:
            return {
                toComponent: function toComponent() {
                    return generateTagsAsReactComponent(type, tags);
                },
                toString: function toString() {
                    return generateTagsAsString(type, tags, encode);
                }
            };
    }
};

var mapStateOnServer = function mapStateOnServer(_ref) {
    var baseTag = _ref.baseTag,
        bodyAttributes = _ref.bodyAttributes,
        encode = _ref.encode,
        htmlAttributes = _ref.htmlAttributes,
        linkTags = _ref.linkTags,
        metaTags = _ref.metaTags,
        noscriptTags = _ref.noscriptTags,
        scriptTags = _ref.scriptTags,
        styleTags = _ref.styleTags,
        _ref$title = _ref.title,
        title = _ref$title === undefined ? "" : _ref$title,
        titleAttributes = _ref.titleAttributes;
    return {
        base: getMethodsForTag(_HelmetConstants.TAG_NAMES.BASE, baseTag, encode),
        bodyAttributes: getMethodsForTag(_HelmetConstants.ATTRIBUTE_NAMES.BODY, bodyAttributes, encode),
        htmlAttributes: getMethodsForTag(_HelmetConstants.ATTRIBUTE_NAMES.HTML, htmlAttributes, encode),
        link: getMethodsForTag(_HelmetConstants.TAG_NAMES.LINK, linkTags, encode),
        meta: getMethodsForTag(_HelmetConstants.TAG_NAMES.META, metaTags, encode),
        noscript: getMethodsForTag(_HelmetConstants.TAG_NAMES.NOSCRIPT, noscriptTags, encode),
        script: getMethodsForTag(_HelmetConstants.TAG_NAMES.SCRIPT, scriptTags, encode),
        style: getMethodsForTag(_HelmetConstants.TAG_NAMES.STYLE, styleTags, encode),
        title: getMethodsForTag(_HelmetConstants.TAG_NAMES.TITLE, { title: title, titleAttributes: titleAttributes }, encode)
    };
};

exports.convertReactPropstoHtmlAttributes = convertReactPropstoHtmlAttributes;
exports.handleClientStateChange = handleClientStateChange;
exports.mapStateOnServer = mapStateOnServer;
exports.reducePropsToState = reducePropsToState;
exports.requestAnimationFrame = requestAnimationFrame;
exports.warn = warn;
/* WEBPACK VAR INJECTION */}.call(exports, __webpack_require__(35)))

/***/ }),
/* 1082 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return ReferralConsentsPropTypes; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "g", function() { return ReferralSummaryPropTypes; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "k", function() { return ReferrerPropTypes; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "i", function() { return ReferrerBankAccountPropTypes; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "l", function() { return ReferrerShippingAddressPropTypes; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "m", function() { return ReferrerW9PropType; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "d", function() { return ReferralGamePropTypes; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "j", function() { return ReferrerProgressPropTypes; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "b", function() { return ReferralContactPropTypes; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "c", function() { return ReferralContactsPropTypes; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "f", function() { return ReferralSelectedContactsPropTypes; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "h", function() { return ReferralTagPropTypes; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "e", function() { return ReferralPropTypes; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_prop_types__ = __webpack_require__(1);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_prop_types___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_prop_types__);
var ReferralConsentsPropTypes=__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.shape({referralConsent:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.bool});var ReferralSummaryPropTypes=__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.shape({isSubscribed:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.bool,registrations:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.number,funded:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.number,earned:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.number,paid:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.number,pending:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.number,eligible:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.bool,unifiedUrl:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string,referralProducts:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.arrayOf(__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.shape({affiliate:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.shape({id:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.number,name:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string,email:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string,type:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string,industry:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string,accountOwner:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string,vendorInternalId:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string,vendorId:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string,startDate:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string,createdDate:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string}),campaign:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.shape({id:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.number,name:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string,target:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string,department:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string,description:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string,redirectUrl:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string,allowsCustomValues:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.bool,affiliateFee:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.number,welcomeBonus:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.number,campaignOwner:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string,category:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string,numberTargeted:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string,createdDate:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string}),customUrl:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string,displayUrl:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string,redirectUrl:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string,daysRetention:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.number,startDate:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string,createdDate:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string})),referralStatistics:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.arrayOf(__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.shape({campaignTarget:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string,registrations:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.number,funded:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.number,paid:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.number,pending:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.number}))});var ReferrerPropTypes=__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.shape({referrerId:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string.isRequired,firstName:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string.isRequired,lastName:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string.isRequired,email:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string.isRequired,mobile:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string.isRequired,partyId:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.number.isRequired,affiliateId:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string.isRequired,eligibility:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.bool.isRequired,memberStartDate:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string.isRequired});var ReferrerBankAccountPropTypes=__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.shape({accountType:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string,accountNo:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string,routingNo:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string,ssn:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string,displaySsn:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.bool});var ReferrerShippingAddressPropTypes=__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.shape({address:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string,apartment:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string,city:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string,state:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string,postalCode:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string});var ReferrerW9PropType=__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.shape({docusignUrl:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string,userId:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.number,w9DocumentId:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string,w9Status:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string});var ReferralGamePropTypes=__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.shape({ruleId:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string.isRequired,giftId:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string.isRequired,giftName:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string.isRequired,giftDescription:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string.isRequired,achievementsRequired:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.number.isRequired,achievementsCompleted:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.number.isRequired,achievementType:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string.isRequired});var ReferrerProgressPropTypes=__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.arrayOf(ReferralGamePropTypes);var ReferralContactPropTypes=__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.shape({firstName:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string,lastName:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string,email:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string});var ReferralContactsPropTypes=__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.shape({authorized:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.bool,contacts:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.arrayOf(ReferralContactPropTypes)});var ReferralSelectedContactsPropTypes=__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.objectOf(ReferralContactPropTypes);var ReferralTagPropTypes=__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.arrayOf(__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string);var ReferralPropTypes=__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.shape({affiliateId:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string,eligibility:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.bool,email:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string,firstName:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string,lastName:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string,memberStartDate:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string,mobile:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string,partyId:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.number,referrerId:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string});

/***/ }),
/* 1083 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;
exports.ValidationError = exports.addMethod = exports.isSchema = exports.reach = exports.lazy = exports.ref = exports.array = exports.object = exports.date = exports.boolean = exports.bool = exports.number = exports.string = exports.mixed = undefined;

var _mixed = __webpack_require__(1042);

var _mixed2 = _interopRequireDefault(_mixed);

var _boolean = __webpack_require__(1123);

var _boolean2 = _interopRequireDefault(_boolean);

var _string = __webpack_require__(1124);

var _string2 = _interopRequireDefault(_string);

var _number = __webpack_require__(1125);

var _number2 = _interopRequireDefault(_number);

var _date = __webpack_require__(1126);

var _date2 = _interopRequireDefault(_date);

var _object = __webpack_require__(1128);

var _object2 = _interopRequireDefault(_object);

var _array = __webpack_require__(1164);

var _array2 = _interopRequireDefault(_array);

var _Reference = __webpack_require__(1049);

var _Reference2 = _interopRequireDefault(_Reference);

var _Lazy = __webpack_require__(1166);

var _Lazy2 = _interopRequireDefault(_Lazy);

var _ValidationError = __webpack_require__(1056);

var _ValidationError2 = _interopRequireDefault(_ValidationError);

var _reach = __webpack_require__(1167);

var _reach2 = _interopRequireDefault(_reach);

var _isSchema = __webpack_require__(1043);

var _isSchema2 = _interopRequireDefault(_isSchema);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var boolean = _boolean2.default;
var ref = function ref(key, options) {
  return new _Reference2.default(key, options);
};

var lazy = function lazy(fn) {
  return new _Lazy2.default(fn);
};

function addMethod(schemaType, name, fn) {
  if (!schemaType || !(0, _isSchema2.default)(schemaType.prototype)) throw new TypeError('You must provide a yup schema constructor function');

  if (typeof name !== 'string') throw new TypeError('A Method name must be provided');
  if (typeof fn !== 'function') throw new TypeError('Method function must be provided');

  schemaType.prototype[name] = fn;
}

exports.mixed = _mixed2.default;
exports.string = _string2.default;
exports.number = _number2.default;
exports.bool = _boolean2.default;
exports.boolean = boolean;
exports.date = _date2.default;
exports.object = _object2.default;
exports.array = _array2.default;
exports.ref = ref;
exports.lazy = lazy;
exports.reach = _reach2.default;
exports.isSchema = _isSchema2.default;
exports.addMethod = addMethod;
exports.ValidationError = _ValidationError2.default;
exports.default = {
  mixed: _mixed2.default,
  string: _string2.default,
  number: _number2.default,
  bool: _boolean2.default,
  boolean: boolean,
  date: _date2.default,
  object: _object2.default,
  array: _array2.default,
  ref: ref,
  lazy: lazy,
  reach: _reach2.default,
  isSchema: _isSchema2.default,
  addMethod: addMethod,
  ValidationError: _ValidationError2.default
};

/***/ }),
/* 1084 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* WEBPACK VAR INJECTION */(function(global) {/* unused harmony export Formik */
/* unused harmony export yupToFormErrors */
/* unused harmony export validateYupSchema */
/* unused harmony export Field */
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return Form; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "b", function() { return withFormik; });
/* unused harmony export move */
/* unused harmony export swap */
/* unused harmony export insert */
/* unused harmony export FieldArray */
/* unused harmony export getIn */
/* unused harmony export setIn */
/* unused harmony export setNestedObjectValues */
/* unused harmony export isReactNative */
/* unused harmony export isFunction */
/* unused harmony export isObject */
/* unused harmony export isInteger */
/* unused harmony export isEmptyChildren */
/* unused harmony export isPromise */
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__(0);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);


/*! *****************************************************************************
Copyright (c) Microsoft Corporation. All rights reserved.
Licensed under the Apache License, Version 2.0 (the "License"); you may not use
this file except in compliance with the License. You may obtain a copy of the
License at http://www.apache.org/licenses/LICENSE-2.0

THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION ANY IMPLIED
WARRANTIES OR CONDITIONS OF TITLE, FITNESS FOR A PARTICULAR PURPOSE,
MERCHANTABLITY OR NON-INFRINGEMENT.

See the Apache Version 2.0 License for specific language governing permissions
and limitations under the License.
***************************************************************************** */
/* global Reflect, Promise */

var extendStatics = Object.setPrototypeOf ||
    ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
    function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };

function __extends(d, b) {
    extendStatics(d, b);
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
}

var __assign = Object.assign || function __assign(t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
        s = arguments[i];
        for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
    }
    return t;
};

function __rest(s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) if (e.indexOf(p[i]) < 0)
            t[p[i]] = s[p[i]];
    return t;
}

var commonjsGlobal = typeof window !== 'undefined' ? window : typeof global !== 'undefined' ? global : typeof self !== 'undefined' ? self : {};





function createCommonjsModule(fn, module) {
	return module = { exports: {} }, fn(module, module.exports), module.exports;
}

/**
 * Copyright (c) 2013-present, Facebook, Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 *
 * 
 */

function makeEmptyFunction(arg) {
  return function () {
    return arg;
  };
}

/**
 * This function accepts and discards inputs; it has no side effects. This is
 * primarily useful idiomatically for overridable function endpoints which
 * always need to be callable, since JS lacks a null-call idiom ala Cocoa.
 */
var emptyFunction = function emptyFunction() {};

emptyFunction.thatReturns = makeEmptyFunction;
emptyFunction.thatReturnsFalse = makeEmptyFunction(false);
emptyFunction.thatReturnsTrue = makeEmptyFunction(true);
emptyFunction.thatReturnsNull = makeEmptyFunction(null);
emptyFunction.thatReturnsThis = function () {
  return this;
};
emptyFunction.thatReturnsArgument = function (arg) {
  return arg;
};

var emptyFunction_1 = emptyFunction;

/**
 * Copyright (c) 2013-present, Facebook, Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 *
 */

/**
 * Use invariant() to assert state which your program assumes to be true.
 *
 * Provide sprintf-style format (only %s is supported) and arguments
 * to provide information about what broke and what you were
 * expecting.
 *
 * The invariant message will be stripped in production, but the invariant
 * will remain to ensure logic does not differ in production.
 */

var validateFormat = function validateFormat(format) {};

if (false) {
  validateFormat = function validateFormat(format) {
    if (format === undefined) {
      throw new Error('invariant requires an error message argument');
    }
  };
}

function invariant(condition, format, a, b, c, d, e, f) {
  validateFormat(format);

  if (!condition) {
    var error;
    if (format === undefined) {
      error = new Error('Minified exception occurred; use the non-minified dev environment ' + 'for the full error message and additional helpful warnings.');
    } else {
      var args = [a, b, c, d, e, f];
      var argIndex = 0;
      error = new Error(format.replace(/%s/g, function () {
        return args[argIndex++];
      }));
      error.name = 'Invariant Violation';
    }

    error.framesToPop = 1; // we don't care about invariant's own frame
    throw error;
  }
}

var invariant_1 = invariant;

/**
 * Similar to invariant but only logs a warning if the condition is not met.
 * This can be used to log issues in development environments in critical
 * paths. Removing the logging code for production environments will keep the
 * same logic and follow the same code paths.
 */

var warning = emptyFunction_1;

if (false) {
  var printWarning = function printWarning(format) {
    for (var _len = arguments.length, args = Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++) {
      args[_key - 1] = arguments[_key];
    }

    var argIndex = 0;
    var message = 'Warning: ' + format.replace(/%s/g, function () {
      return args[argIndex++];
    });
    if (typeof console !== 'undefined') {
      console.error(message);
    }
    try {
      // --- Welcome to debugging React ---
      // This error was thrown as a convenience so that you can use this stack
      // to find the callsite that caused this warning to fire.
      throw new Error(message);
    } catch (x) {}
  };

  warning = function warning(condition, format) {
    if (format === undefined) {
      throw new Error('`warning(condition, format, ...args)` requires a warning ' + 'message argument');
    }

    if (format.indexOf('Failed Composite propType: ') === 0) {
      return; // Ignore CompositeComponent proptype check.
    }

    if (!condition) {
      for (var _len2 = arguments.length, args = Array(_len2 > 2 ? _len2 - 2 : 0), _key2 = 2; _key2 < _len2; _key2++) {
        args[_key2 - 2] = arguments[_key2];
      }

      printWarning.apply(undefined, [format].concat(args));
    }
  };
}

var warning_1 = warning;

/*
object-assign
(c) Sindre Sorhus
@license MIT
*/

/* eslint-disable no-unused-vars */
var getOwnPropertySymbols = Object.getOwnPropertySymbols;
var hasOwnProperty = Object.prototype.hasOwnProperty;
var propIsEnumerable = Object.prototype.propertyIsEnumerable;

function toObject(val) {
	if (val === null || val === undefined) {
		throw new TypeError('Object.assign cannot be called with null or undefined');
	}

	return Object(val);
}

function shouldUseNative() {
	try {
		if (!Object.assign) {
			return false;
		}

		// Detect buggy property enumeration order in older V8 versions.

		// https://bugs.chromium.org/p/v8/issues/detail?id=4118
		var test1 = new String('abc');  // eslint-disable-line no-new-wrappers
		test1[5] = 'de';
		if (Object.getOwnPropertyNames(test1)[0] === '5') {
			return false;
		}

		// https://bugs.chromium.org/p/v8/issues/detail?id=3056
		var test2 = {};
		for (var i = 0; i < 10; i++) {
			test2['_' + String.fromCharCode(i)] = i;
		}
		var order2 = Object.getOwnPropertyNames(test2).map(function (n) {
			return test2[n];
		});
		if (order2.join('') !== '0123456789') {
			return false;
		}

		// https://bugs.chromium.org/p/v8/issues/detail?id=3056
		var test3 = {};
		'abcdefghijklmnopqrst'.split('').forEach(function (letter) {
			test3[letter] = letter;
		});
		if (Object.keys(Object.assign({}, test3)).join('') !==
				'abcdefghijklmnopqrst') {
			return false;
		}

		return true;
	} catch (err) {
		// We don't expect any of the above to throw, but better to be safe.
		return false;
	}
}

var index = shouldUseNative() ? Object.assign : function (target, source) {
	var from;
	var to = toObject(target);
	var symbols;

	for (var s = 1; s < arguments.length; s++) {
		from = Object(arguments[s]);

		for (var key in from) {
			if (hasOwnProperty.call(from, key)) {
				to[key] = from[key];
			}
		}

		if (getOwnPropertySymbols) {
			symbols = getOwnPropertySymbols(from);
			for (var i = 0; i < symbols.length; i++) {
				if (propIsEnumerable.call(from, symbols[i])) {
					to[symbols[i]] = from[symbols[i]];
				}
			}
		}
	}

	return to;
};

/**
 * Copyright (c) 2013-present, Facebook, Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */

var ReactPropTypesSecret = 'SECRET_DO_NOT_PASS_THIS_OR_YOU_WILL_BE_FIRED';

var ReactPropTypesSecret_1 = ReactPropTypesSecret;

if (false) {
  var invariant$2 = invariant_1;
  var warning$1 = warning_1;
  var ReactPropTypesSecret$2 = ReactPropTypesSecret_1;
  var loggedTypeFailures = {};
}

/**
 * Assert that the values match with the type specs.
 * Error messages are memorized and will only be shown once.
 *
 * @param {object} typeSpecs Map of name to a ReactPropType
 * @param {object} values Runtime values that need to be type-checked
 * @param {string} location e.g. "prop", "context", "child context"
 * @param {string} componentName Name of the component for error messages.
 * @param {?Function} getStack Returns the component stack.
 * @private
 */
function checkPropTypes(typeSpecs, values, location, componentName, getStack) {
  if (false) {
    for (var typeSpecName in typeSpecs) {
      if (typeSpecs.hasOwnProperty(typeSpecName)) {
        var error;
        // Prop type validation may throw. In case they do, we don't want to
        // fail the render phase where it didn't fail before. So we log it.
        // After these have been cleaned up, we'll let them throw.
        try {
          // This is intentionally an invariant that gets caught. It's the same
          // behavior as without this statement except with a better message.
          invariant$2(typeof typeSpecs[typeSpecName] === 'function', '%s: %s type `%s` is invalid; it must be a function, usually from ' + 'the `prop-types` package, but received `%s`.', componentName || 'React class', location, typeSpecName, typeof typeSpecs[typeSpecName]);
          error = typeSpecs[typeSpecName](values, typeSpecName, componentName, location, null, ReactPropTypesSecret$2);
        } catch (ex) {
          error = ex;
        }
        warning$1(!error || error instanceof Error, '%s: type specification of %s `%s` is invalid; the type checker ' + 'function must return `null` or an `Error` but returned a %s. ' + 'You may have forgotten to pass an argument to the type checker ' + 'creator (arrayOf, instanceOf, objectOf, oneOf, oneOfType, and ' + 'shape all require an argument).', componentName || 'React class', location, typeSpecName, typeof error);
        if (error instanceof Error && !(error.message in loggedTypeFailures)) {
          // Only monitor this failure once because there tends to be a lot of the
          // same error.
          loggedTypeFailures[error.message] = true;

          var stack = getStack ? getStack() : '';

          warning$1(false, 'Failed %s type: %s%s', location, error.message, stack != null ? stack : '');
        }
      }
    }
  }
}

var checkPropTypes_1 = checkPropTypes;

var factoryWithTypeCheckers = function(isValidElement, throwOnDirectAccess) {
  /* global Symbol */
  var ITERATOR_SYMBOL = typeof Symbol === 'function' && Symbol.iterator;
  var FAUX_ITERATOR_SYMBOL = '@@iterator'; // Before Symbol spec.

  /**
   * Returns the iterator method function contained on the iterable object.
   *
   * Be sure to invoke the function with the iterable as context:
   *
   *     var iteratorFn = getIteratorFn(myIterable);
   *     if (iteratorFn) {
   *       var iterator = iteratorFn.call(myIterable);
   *       ...
   *     }
   *
   * @param {?object} maybeIterable
   * @return {?function}
   */
  function getIteratorFn(maybeIterable) {
    var iteratorFn = maybeIterable && (ITERATOR_SYMBOL && maybeIterable[ITERATOR_SYMBOL] || maybeIterable[FAUX_ITERATOR_SYMBOL]);
    if (typeof iteratorFn === 'function') {
      return iteratorFn;
    }
  }

  /**
   * Collection of methods that allow declaration and validation of props that are
   * supplied to React components. Example usage:
   *
   *   var Props = require('ReactPropTypes');
   *   var MyArticle = React.createClass({
   *     propTypes: {
   *       // An optional string prop named "description".
   *       description: Props.string,
   *
   *       // A required enum prop named "category".
   *       category: Props.oneOf(['News','Photos']).isRequired,
   *
   *       // A prop named "dialog" that requires an instance of Dialog.
   *       dialog: Props.instanceOf(Dialog).isRequired
   *     },
   *     render: function() { ... }
   *   });
   *
   * A more formal specification of how these methods are used:
   *
   *   type := array|bool|func|object|number|string|oneOf([...])|instanceOf(...)
   *   decl := ReactPropTypes.{type}(.isRequired)?
   *
   * Each and every declaration produces a function with the same signature. This
   * allows the creation of custom validation functions. For example:
   *
   *  var MyLink = React.createClass({
   *    propTypes: {
   *      // An optional string or URI prop named "href".
   *      href: function(props, propName, componentName) {
   *        var propValue = props[propName];
   *        if (propValue != null && typeof propValue !== 'string' &&
   *            !(propValue instanceof URI)) {
   *          return new Error(
   *            'Expected a string or an URI for ' + propName + ' in ' +
   *            componentName
   *          );
   *        }
   *      }
   *    },
   *    render: function() {...}
   *  });
   *
   * @internal
   */

  var ANONYMOUS = '<<anonymous>>';

  // Important!
  // Keep this list in sync with production version in `./factoryWithThrowingShims.js`.
  var ReactPropTypes = {
    array: createPrimitiveTypeChecker('array'),
    bool: createPrimitiveTypeChecker('boolean'),
    func: createPrimitiveTypeChecker('function'),
    number: createPrimitiveTypeChecker('number'),
    object: createPrimitiveTypeChecker('object'),
    string: createPrimitiveTypeChecker('string'),
    symbol: createPrimitiveTypeChecker('symbol'),

    any: createAnyTypeChecker(),
    arrayOf: createArrayOfTypeChecker,
    element: createElementTypeChecker(),
    instanceOf: createInstanceTypeChecker,
    node: createNodeChecker(),
    objectOf: createObjectOfTypeChecker,
    oneOf: createEnumTypeChecker,
    oneOfType: createUnionTypeChecker,
    shape: createShapeTypeChecker,
    exact: createStrictShapeTypeChecker,
  };

  /**
   * inlined Object.is polyfill to avoid requiring consumers ship their own
   * https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object/is
   */
  /*eslint-disable no-self-compare*/
  function is(x, y) {
    // SameValue algorithm
    if (x === y) {
      // Steps 1-5, 7-10
      // Steps 6.b-6.e: +0 != -0
      return x !== 0 || 1 / x === 1 / y;
    } else {
      // Step 6.a: NaN == NaN
      return x !== x && y !== y;
    }
  }
  /*eslint-enable no-self-compare*/

  /**
   * We use an Error-like object for backward compatibility as people may call
   * PropTypes directly and inspect their output. However, we don't use real
   * Errors anymore. We don't inspect their stack anyway, and creating them
   * is prohibitively expensive if they are created too often, such as what
   * happens in oneOfType() for any type before the one that matched.
   */
  function PropTypeError(message) {
    this.message = message;
    this.stack = '';
  }
  // Make `instanceof Error` still work for returned errors.
  PropTypeError.prototype = Error.prototype;

  function createChainableTypeChecker(validate) {
    if (false) {
      var manualPropTypeCallCache = {};
      var manualPropTypeWarningCount = 0;
    }
    function checkType(isRequired, props, propName, componentName, location, propFullName, secret) {
      componentName = componentName || ANONYMOUS;
      propFullName = propFullName || propName;

      if (secret !== ReactPropTypesSecret_1) {
        if (throwOnDirectAccess) {
          // New behavior only for users of `prop-types` package
          invariant_1(
            false,
            'Calling PropTypes validators directly is not supported by the `prop-types` package. ' +
            'Use `PropTypes.checkPropTypes()` to call them. ' +
            'Read more at http://fb.me/use-check-prop-types'
          );
        } else if (false) {
          // Old behavior for people using React.PropTypes
          var cacheKey = componentName + ':' + propName;
          if (
            !manualPropTypeCallCache[cacheKey] &&
            // Avoid spamming the console because they are often not actionable except for lib authors
            manualPropTypeWarningCount < 3
          ) {
            warning_1(
              false,
              'You are manually calling a React.PropTypes validation ' +
              'function for the `%s` prop on `%s`. This is deprecated ' +
              'and will throw in the standalone `prop-types` package. ' +
              'You may be seeing this warning due to a third-party PropTypes ' +
              'library. See https://fb.me/react-warning-dont-call-proptypes ' + 'for details.',
              propFullName,
              componentName
            );
            manualPropTypeCallCache[cacheKey] = true;
            manualPropTypeWarningCount++;
          }
        }
      }
      if (props[propName] == null) {
        if (isRequired) {
          if (props[propName] === null) {
            return new PropTypeError('The ' + location + ' `' + propFullName + '` is marked as required ' + ('in `' + componentName + '`, but its value is `null`.'));
          }
          return new PropTypeError('The ' + location + ' `' + propFullName + '` is marked as required in ' + ('`' + componentName + '`, but its value is `undefined`.'));
        }
        return null;
      } else {
        return validate(props, propName, componentName, location, propFullName);
      }
    }

    var chainedCheckType = checkType.bind(null, false);
    chainedCheckType.isRequired = checkType.bind(null, true);

    return chainedCheckType;
  }

  function createPrimitiveTypeChecker(expectedType) {
    function validate(props, propName, componentName, location, propFullName, secret) {
      var propValue = props[propName];
      var propType = getPropType(propValue);
      if (propType !== expectedType) {
        // `propValue` being instance of, say, date/regexp, pass the 'object'
        // check, but we can offer a more precise error message here rather than
        // 'of type `object`'.
        var preciseType = getPreciseType(propValue);

        return new PropTypeError('Invalid ' + location + ' `' + propFullName + '` of type ' + ('`' + preciseType + '` supplied to `' + componentName + '`, expected ') + ('`' + expectedType + '`.'));
      }
      return null;
    }
    return createChainableTypeChecker(validate);
  }

  function createAnyTypeChecker() {
    return createChainableTypeChecker(emptyFunction_1.thatReturnsNull);
  }

  function createArrayOfTypeChecker(typeChecker) {
    function validate(props, propName, componentName, location, propFullName) {
      if (typeof typeChecker !== 'function') {
        return new PropTypeError('Property `' + propFullName + '` of component `' + componentName + '` has invalid PropType notation inside arrayOf.');
      }
      var propValue = props[propName];
      if (!Array.isArray(propValue)) {
        var propType = getPropType(propValue);
        return new PropTypeError('Invalid ' + location + ' `' + propFullName + '` of type ' + ('`' + propType + '` supplied to `' + componentName + '`, expected an array.'));
      }
      for (var i = 0; i < propValue.length; i++) {
        var error = typeChecker(propValue, i, componentName, location, propFullName + '[' + i + ']', ReactPropTypesSecret_1);
        if (error instanceof Error) {
          return error;
        }
      }
      return null;
    }
    return createChainableTypeChecker(validate);
  }

  function createElementTypeChecker() {
    function validate(props, propName, componentName, location, propFullName) {
      var propValue = props[propName];
      if (!isValidElement(propValue)) {
        var propType = getPropType(propValue);
        return new PropTypeError('Invalid ' + location + ' `' + propFullName + '` of type ' + ('`' + propType + '` supplied to `' + componentName + '`, expected a single ReactElement.'));
      }
      return null;
    }
    return createChainableTypeChecker(validate);
  }

  function createInstanceTypeChecker(expectedClass) {
    function validate(props, propName, componentName, location, propFullName) {
      if (!(props[propName] instanceof expectedClass)) {
        var expectedClassName = expectedClass.name || ANONYMOUS;
        var actualClassName = getClassName(props[propName]);
        return new PropTypeError('Invalid ' + location + ' `' + propFullName + '` of type ' + ('`' + actualClassName + '` supplied to `' + componentName + '`, expected ') + ('instance of `' + expectedClassName + '`.'));
      }
      return null;
    }
    return createChainableTypeChecker(validate);
  }

  function createEnumTypeChecker(expectedValues) {
    if (!Array.isArray(expectedValues)) {
       false ? warning_1(false, 'Invalid argument supplied to oneOf, expected an instance of array.') : void 0;
      return emptyFunction_1.thatReturnsNull;
    }

    function validate(props, propName, componentName, location, propFullName) {
      var propValue = props[propName];
      for (var i = 0; i < expectedValues.length; i++) {
        if (is(propValue, expectedValues[i])) {
          return null;
        }
      }

      var valuesString = JSON.stringify(expectedValues);
      return new PropTypeError('Invalid ' + location + ' `' + propFullName + '` of value `' + propValue + '` ' + ('supplied to `' + componentName + '`, expected one of ' + valuesString + '.'));
    }
    return createChainableTypeChecker(validate);
  }

  function createObjectOfTypeChecker(typeChecker) {
    function validate(props, propName, componentName, location, propFullName) {
      if (typeof typeChecker !== 'function') {
        return new PropTypeError('Property `' + propFullName + '` of component `' + componentName + '` has invalid PropType notation inside objectOf.');
      }
      var propValue = props[propName];
      var propType = getPropType(propValue);
      if (propType !== 'object') {
        return new PropTypeError('Invalid ' + location + ' `' + propFullName + '` of type ' + ('`' + propType + '` supplied to `' + componentName + '`, expected an object.'));
      }
      for (var key in propValue) {
        if (propValue.hasOwnProperty(key)) {
          var error = typeChecker(propValue, key, componentName, location, propFullName + '.' + key, ReactPropTypesSecret_1);
          if (error instanceof Error) {
            return error;
          }
        }
      }
      return null;
    }
    return createChainableTypeChecker(validate);
  }

  function createUnionTypeChecker(arrayOfTypeCheckers) {
    if (!Array.isArray(arrayOfTypeCheckers)) {
       false ? warning_1(false, 'Invalid argument supplied to oneOfType, expected an instance of array.') : void 0;
      return emptyFunction_1.thatReturnsNull;
    }

    for (var i = 0; i < arrayOfTypeCheckers.length; i++) {
      var checker = arrayOfTypeCheckers[i];
      if (typeof checker !== 'function') {
        warning_1(
          false,
          'Invalid argument supplied to oneOfType. Expected an array of check functions, but ' +
          'received %s at index %s.',
          getPostfixForTypeWarning(checker),
          i
        );
        return emptyFunction_1.thatReturnsNull;
      }
    }

    function validate(props, propName, componentName, location, propFullName) {
      for (var i = 0; i < arrayOfTypeCheckers.length; i++) {
        var checker = arrayOfTypeCheckers[i];
        if (checker(props, propName, componentName, location, propFullName, ReactPropTypesSecret_1) == null) {
          return null;
        }
      }

      return new PropTypeError('Invalid ' + location + ' `' + propFullName + '` supplied to ' + ('`' + componentName + '`.'));
    }
    return createChainableTypeChecker(validate);
  }

  function createNodeChecker() {
    function validate(props, propName, componentName, location, propFullName) {
      if (!isNode(props[propName])) {
        return new PropTypeError('Invalid ' + location + ' `' + propFullName + '` supplied to ' + ('`' + componentName + '`, expected a ReactNode.'));
      }
      return null;
    }
    return createChainableTypeChecker(validate);
  }

  function createShapeTypeChecker(shapeTypes) {
    function validate(props, propName, componentName, location, propFullName) {
      var propValue = props[propName];
      var propType = getPropType(propValue);
      if (propType !== 'object') {
        return new PropTypeError('Invalid ' + location + ' `' + propFullName + '` of type `' + propType + '` ' + ('supplied to `' + componentName + '`, expected `object`.'));
      }
      for (var key in shapeTypes) {
        var checker = shapeTypes[key];
        if (!checker) {
          continue;
        }
        var error = checker(propValue, key, componentName, location, propFullName + '.' + key, ReactPropTypesSecret_1);
        if (error) {
          return error;
        }
      }
      return null;
    }
    return createChainableTypeChecker(validate);
  }

  function createStrictShapeTypeChecker(shapeTypes) {
    function validate(props, propName, componentName, location, propFullName) {
      var propValue = props[propName];
      var propType = getPropType(propValue);
      if (propType !== 'object') {
        return new PropTypeError('Invalid ' + location + ' `' + propFullName + '` of type `' + propType + '` ' + ('supplied to `' + componentName + '`, expected `object`.'));
      }
      // We need to check all keys in case some are required but missing from
      // props.
      var allKeys = index({}, props[propName], shapeTypes);
      for (var key in allKeys) {
        var checker = shapeTypes[key];
        if (!checker) {
          return new PropTypeError(
            'Invalid ' + location + ' `' + propFullName + '` key `' + key + '` supplied to `' + componentName + '`.' +
            '\nBad object: ' + JSON.stringify(props[propName], null, '  ') +
            '\nValid keys: ' +  JSON.stringify(Object.keys(shapeTypes), null, '  ')
          );
        }
        var error = checker(propValue, key, componentName, location, propFullName + '.' + key, ReactPropTypesSecret_1);
        if (error) {
          return error;
        }
      }
      return null;
    }

    return createChainableTypeChecker(validate);
  }

  function isNode(propValue) {
    switch (typeof propValue) {
      case 'number':
      case 'string':
      case 'undefined':
        return true;
      case 'boolean':
        return !propValue;
      case 'object':
        if (Array.isArray(propValue)) {
          return propValue.every(isNode);
        }
        if (propValue === null || isValidElement(propValue)) {
          return true;
        }

        var iteratorFn = getIteratorFn(propValue);
        if (iteratorFn) {
          var iterator = iteratorFn.call(propValue);
          var step;
          if (iteratorFn !== propValue.entries) {
            while (!(step = iterator.next()).done) {
              if (!isNode(step.value)) {
                return false;
              }
            }
          } else {
            // Iterator will provide entry [k,v] tuples rather than values.
            while (!(step = iterator.next()).done) {
              var entry = step.value;
              if (entry) {
                if (!isNode(entry[1])) {
                  return false;
                }
              }
            }
          }
        } else {
          return false;
        }

        return true;
      default:
        return false;
    }
  }

  function isSymbol(propType, propValue) {
    // Native Symbol.
    if (propType === 'symbol') {
      return true;
    }

    // 19.4.3.5 Symbol.prototype[@@toStringTag] === 'Symbol'
    if (propValue['@@toStringTag'] === 'Symbol') {
      return true;
    }

    // Fallback for non-spec compliant Symbols which are polyfilled.
    if (typeof Symbol === 'function' && propValue instanceof Symbol) {
      return true;
    }

    return false;
  }

  // Equivalent of `typeof` but with special handling for array and regexp.
  function getPropType(propValue) {
    var propType = typeof propValue;
    if (Array.isArray(propValue)) {
      return 'array';
    }
    if (propValue instanceof RegExp) {
      // Old webkits (at least until Android 4.0) return 'function' rather than
      // 'object' for typeof a RegExp. We'll normalize this here so that /bla/
      // passes PropTypes.object.
      return 'object';
    }
    if (isSymbol(propType, propValue)) {
      return 'symbol';
    }
    return propType;
  }

  // This handles more types than `getPropType`. Only used for error messages.
  // See `createPrimitiveTypeChecker`.
  function getPreciseType(propValue) {
    if (typeof propValue === 'undefined' || propValue === null) {
      return '' + propValue;
    }
    var propType = getPropType(propValue);
    if (propType === 'object') {
      if (propValue instanceof Date) {
        return 'date';
      } else if (propValue instanceof RegExp) {
        return 'regexp';
      }
    }
    return propType;
  }

  // Returns a string that is postfixed to a warning about an invalid type.
  // For example, "undefined" or "of type array"
  function getPostfixForTypeWarning(value) {
    var type = getPreciseType(value);
    switch (type) {
      case 'array':
      case 'object':
        return 'an ' + type;
      case 'boolean':
      case 'date':
      case 'regexp':
        return 'a ' + type;
      default:
        return type;
    }
  }

  // Returns class name of the object, if any.
  function getClassName(propValue) {
    if (!propValue.constructor || !propValue.constructor.name) {
      return ANONYMOUS;
    }
    return propValue.constructor.name;
  }

  ReactPropTypes.checkPropTypes = checkPropTypes_1;
  ReactPropTypes.PropTypes = ReactPropTypes;

  return ReactPropTypes;
};

var factoryWithThrowingShims = function() {
  function shim(props, propName, componentName, location, propFullName, secret) {
    if (secret === ReactPropTypesSecret_1) {
      // It is still safe when called from React.
      return;
    }
    invariant_1(
      false,
      'Calling PropTypes validators directly is not supported by the `prop-types` package. ' +
      'Use PropTypes.checkPropTypes() to call them. ' +
      'Read more at http://fb.me/use-check-prop-types'
    );
  }
  shim.isRequired = shim;
  function getShim() {
    return shim;
  }
  // Important!
  // Keep this list in sync with production version in `./factoryWithTypeCheckers.js`.
  var ReactPropTypes = {
    array: shim,
    bool: shim,
    func: shim,
    number: shim,
    object: shim,
    string: shim,
    symbol: shim,

    any: shim,
    arrayOf: getShim,
    element: shim,
    instanceOf: getShim,
    node: shim,
    objectOf: getShim,
    oneOf: getShim,
    oneOfType: getShim,
    shape: getShim,
    exact: getShim
  };

  ReactPropTypes.checkPropTypes = emptyFunction_1;
  ReactPropTypes.PropTypes = ReactPropTypes;

  return ReactPropTypes;
};

var index$2 = createCommonjsModule(function (module) {
/**
 * Copyright (c) 2013-present, Facebook, Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */

if (false) {
  var REACT_ELEMENT_TYPE = (typeof Symbol === 'function' &&
    Symbol.for &&
    Symbol.for('react.element')) ||
    0xeac7;

  var isValidElement = function(object) {
    return typeof object === 'object' &&
      object !== null &&
      object.$$typeof === REACT_ELEMENT_TYPE;
  };

  // By explicitly using `prop-types` you are opting into new development behavior.
  // http://fb.me/prop-types-in-prod
  var throwOnDirectAccess = true;
  module.exports = factoryWithTypeCheckers(isValidElement, throwOnDirectAccess);
} else {
  // By explicitly using `prop-types` you are opting into new production behavior.
  // http://fb.me/prop-types-in-prod
  module.exports = factoryWithThrowingShims();
}
});

var index_1 = index$2.object;
var index_2 = index$2.oneOfType;
var index_3 = index$2.string;
var index_4 = index$2.node;
var index_5 = index$2.func;
var index_6 = index$2.bool;
var index_7 = index$2.element;

var index$4 = createCommonjsModule(function (module, exports) {
/**
 * Lodash (Custom Build) <https://lodash.com/>
 * Build: `lodash modularize exports="npm" -o ./`
 * Copyright JS Foundation and other contributors <https://js.foundation/>
 * Released under MIT license <https://lodash.com/license>
 * Based on Underscore.js 1.8.3 <http://underscorejs.org/LICENSE>
 * Copyright Jeremy Ashkenas, DocumentCloud and Investigative Reporters & Editors
 */

/** Used as the size to enable large array optimizations. */
var LARGE_ARRAY_SIZE = 200;

/** Used to stand-in for `undefined` hash values. */
var HASH_UNDEFINED = '__lodash_hash_undefined__';

/** Used to compose bitmasks for value comparisons. */
var COMPARE_PARTIAL_FLAG = 1,
    COMPARE_UNORDERED_FLAG = 2;

/** Used as references for various `Number` constants. */
var MAX_SAFE_INTEGER = 9007199254740991;

/** `Object#toString` result references. */
var argsTag = '[object Arguments]',
    arrayTag = '[object Array]',
    asyncTag = '[object AsyncFunction]',
    boolTag = '[object Boolean]',
    dateTag = '[object Date]',
    errorTag = '[object Error]',
    funcTag = '[object Function]',
    genTag = '[object GeneratorFunction]',
    mapTag = '[object Map]',
    numberTag = '[object Number]',
    nullTag = '[object Null]',
    objectTag = '[object Object]',
    promiseTag = '[object Promise]',
    proxyTag = '[object Proxy]',
    regexpTag = '[object RegExp]',
    setTag = '[object Set]',
    stringTag = '[object String]',
    symbolTag = '[object Symbol]',
    undefinedTag = '[object Undefined]',
    weakMapTag = '[object WeakMap]';

var arrayBufferTag = '[object ArrayBuffer]',
    dataViewTag = '[object DataView]',
    float32Tag = '[object Float32Array]',
    float64Tag = '[object Float64Array]',
    int8Tag = '[object Int8Array]',
    int16Tag = '[object Int16Array]',
    int32Tag = '[object Int32Array]',
    uint8Tag = '[object Uint8Array]',
    uint8ClampedTag = '[object Uint8ClampedArray]',
    uint16Tag = '[object Uint16Array]',
    uint32Tag = '[object Uint32Array]';

/**
 * Used to match `RegExp`
 * [syntax characters](http://ecma-international.org/ecma-262/7.0/#sec-patterns).
 */
var reRegExpChar = /[\\^$.*+?()[\]{}|]/g;

/** Used to detect host constructors (Safari). */
var reIsHostCtor = /^\[object .+?Constructor\]$/;

/** Used to detect unsigned integer values. */
var reIsUint = /^(?:0|[1-9]\d*)$/;

/** Used to identify `toStringTag` values of typed arrays. */
var typedArrayTags = {};
typedArrayTags[float32Tag] = typedArrayTags[float64Tag] =
typedArrayTags[int8Tag] = typedArrayTags[int16Tag] =
typedArrayTags[int32Tag] = typedArrayTags[uint8Tag] =
typedArrayTags[uint8ClampedTag] = typedArrayTags[uint16Tag] =
typedArrayTags[uint32Tag] = true;
typedArrayTags[argsTag] = typedArrayTags[arrayTag] =
typedArrayTags[arrayBufferTag] = typedArrayTags[boolTag] =
typedArrayTags[dataViewTag] = typedArrayTags[dateTag] =
typedArrayTags[errorTag] = typedArrayTags[funcTag] =
typedArrayTags[mapTag] = typedArrayTags[numberTag] =
typedArrayTags[objectTag] = typedArrayTags[regexpTag] =
typedArrayTags[setTag] = typedArrayTags[stringTag] =
typedArrayTags[weakMapTag] = false;

/** Detect free variable `global` from Node.js. */
var freeGlobal = typeof commonjsGlobal == 'object' && commonjsGlobal && commonjsGlobal.Object === Object && commonjsGlobal;

/** Detect free variable `self`. */
var freeSelf = typeof self == 'object' && self && self.Object === Object && self;

/** Used as a reference to the global object. */
var root = freeGlobal || freeSelf || Function('return this')();

/** Detect free variable `exports`. */
var freeExports = 'object' == 'object' && exports && !exports.nodeType && exports;

/** Detect free variable `module`. */
var freeModule = freeExports && 'object' == 'object' && module && !module.nodeType && module;

/** Detect the popular CommonJS extension `module.exports`. */
var moduleExports = freeModule && freeModule.exports === freeExports;

/** Detect free variable `process` from Node.js. */
var freeProcess = moduleExports && freeGlobal.process;

/** Used to access faster Node.js helpers. */
var nodeUtil = (function() {
  try {
    return freeProcess && freeProcess.binding && freeProcess.binding('util');
  } catch (e) {}
}());

/* Node.js helper references. */
var nodeIsTypedArray = nodeUtil && nodeUtil.isTypedArray;

/**
 * A specialized version of `_.filter` for arrays without support for
 * iteratee shorthands.
 *
 * @private
 * @param {Array} [array] The array to iterate over.
 * @param {Function} predicate The function invoked per iteration.
 * @returns {Array} Returns the new filtered array.
 */
function arrayFilter(array, predicate) {
  var index = -1,
      length = array == null ? 0 : array.length,
      resIndex = 0,
      result = [];

  while (++index < length) {
    var value = array[index];
    if (predicate(value, index, array)) {
      result[resIndex++] = value;
    }
  }
  return result;
}

/**
 * Appends the elements of `values` to `array`.
 *
 * @private
 * @param {Array} array The array to modify.
 * @param {Array} values The values to append.
 * @returns {Array} Returns `array`.
 */
function arrayPush(array, values) {
  var index = -1,
      length = values.length,
      offset = array.length;

  while (++index < length) {
    array[offset + index] = values[index];
  }
  return array;
}

/**
 * A specialized version of `_.some` for arrays without support for iteratee
 * shorthands.
 *
 * @private
 * @param {Array} [array] The array to iterate over.
 * @param {Function} predicate The function invoked per iteration.
 * @returns {boolean} Returns `true` if any element passes the predicate check,
 *  else `false`.
 */
function arraySome(array, predicate) {
  var index = -1,
      length = array == null ? 0 : array.length;

  while (++index < length) {
    if (predicate(array[index], index, array)) {
      return true;
    }
  }
  return false;
}

/**
 * The base implementation of `_.times` without support for iteratee shorthands
 * or max array length checks.
 *
 * @private
 * @param {number} n The number of times to invoke `iteratee`.
 * @param {Function} iteratee The function invoked per iteration.
 * @returns {Array} Returns the array of results.
 */
function baseTimes(n, iteratee) {
  var index = -1,
      result = Array(n);

  while (++index < n) {
    result[index] = iteratee(index);
  }
  return result;
}

/**
 * The base implementation of `_.unary` without support for storing metadata.
 *
 * @private
 * @param {Function} func The function to cap arguments for.
 * @returns {Function} Returns the new capped function.
 */
function baseUnary(func) {
  return function(value) {
    return func(value);
  };
}

/**
 * Checks if a `cache` value for `key` exists.
 *
 * @private
 * @param {Object} cache The cache to query.
 * @param {string} key The key of the entry to check.
 * @returns {boolean} Returns `true` if an entry for `key` exists, else `false`.
 */
function cacheHas(cache, key) {
  return cache.has(key);
}

/**
 * Gets the value at `key` of `object`.
 *
 * @private
 * @param {Object} [object] The object to query.
 * @param {string} key The key of the property to get.
 * @returns {*} Returns the property value.
 */
function getValue(object, key) {
  return object == null ? undefined : object[key];
}

/**
 * Converts `map` to its key-value pairs.
 *
 * @private
 * @param {Object} map The map to convert.
 * @returns {Array} Returns the key-value pairs.
 */
function mapToArray(map) {
  var index = -1,
      result = Array(map.size);

  map.forEach(function(value, key) {
    result[++index] = [key, value];
  });
  return result;
}

/**
 * Creates a unary function that invokes `func` with its argument transformed.
 *
 * @private
 * @param {Function} func The function to wrap.
 * @param {Function} transform The argument transform.
 * @returns {Function} Returns the new function.
 */
function overArg(func, transform) {
  return function(arg) {
    return func(transform(arg));
  };
}

/**
 * Converts `set` to an array of its values.
 *
 * @private
 * @param {Object} set The set to convert.
 * @returns {Array} Returns the values.
 */
function setToArray(set) {
  var index = -1,
      result = Array(set.size);

  set.forEach(function(value) {
    result[++index] = value;
  });
  return result;
}

/** Used for built-in method references. */
var arrayProto = Array.prototype,
    funcProto = Function.prototype,
    objectProto = Object.prototype;

/** Used to detect overreaching core-js shims. */
var coreJsData = root['__core-js_shared__'];

/** Used to resolve the decompiled source of functions. */
var funcToString = funcProto.toString;

/** Used to check objects for own properties. */
var hasOwnProperty = objectProto.hasOwnProperty;

/** Used to detect methods masquerading as native. */
var maskSrcKey = (function() {
  var uid = /[^.]+$/.exec(coreJsData && coreJsData.keys && coreJsData.keys.IE_PROTO || '');
  return uid ? ('Symbol(src)_1.' + uid) : '';
}());

/**
 * Used to resolve the
 * [`toStringTag`](http://ecma-international.org/ecma-262/7.0/#sec-object.prototype.tostring)
 * of values.
 */
var nativeObjectToString = objectProto.toString;

/** Used to detect if a method is native. */
var reIsNative = RegExp('^' +
  funcToString.call(hasOwnProperty).replace(reRegExpChar, '\\$&')
  .replace(/hasOwnProperty|(function).*?(?=\\\()| for .+?(?=\\\])/g, '$1.*?') + '$'
);

/** Built-in value references. */
var Buffer = moduleExports ? root.Buffer : undefined,
    Symbol = root.Symbol,
    Uint8Array = root.Uint8Array,
    propertyIsEnumerable = objectProto.propertyIsEnumerable,
    splice = arrayProto.splice,
    symToStringTag = Symbol ? Symbol.toStringTag : undefined;

/* Built-in method references for those with the same name as other `lodash` methods. */
var nativeGetSymbols = Object.getOwnPropertySymbols,
    nativeIsBuffer = Buffer ? Buffer.isBuffer : undefined,
    nativeKeys = overArg(Object.keys, Object);

/* Built-in method references that are verified to be native. */
var DataView = getNative(root, 'DataView'),
    Map = getNative(root, 'Map'),
    Promise = getNative(root, 'Promise'),
    Set = getNative(root, 'Set'),
    WeakMap = getNative(root, 'WeakMap'),
    nativeCreate = getNative(Object, 'create');

/** Used to detect maps, sets, and weakmaps. */
var dataViewCtorString = toSource(DataView),
    mapCtorString = toSource(Map),
    promiseCtorString = toSource(Promise),
    setCtorString = toSource(Set),
    weakMapCtorString = toSource(WeakMap);

/** Used to convert symbols to primitives and strings. */
var symbolProto = Symbol ? Symbol.prototype : undefined,
    symbolValueOf = symbolProto ? symbolProto.valueOf : undefined;

/**
 * Creates a hash object.
 *
 * @private
 * @constructor
 * @param {Array} [entries] The key-value pairs to cache.
 */
function Hash(entries) {
  var index = -1,
      length = entries == null ? 0 : entries.length;

  this.clear();
  while (++index < length) {
    var entry = entries[index];
    this.set(entry[0], entry[1]);
  }
}

/**
 * Removes all key-value entries from the hash.
 *
 * @private
 * @name clear
 * @memberOf Hash
 */
function hashClear() {
  this.__data__ = nativeCreate ? nativeCreate(null) : {};
  this.size = 0;
}

/**
 * Removes `key` and its value from the hash.
 *
 * @private
 * @name delete
 * @memberOf Hash
 * @param {Object} hash The hash to modify.
 * @param {string} key The key of the value to remove.
 * @returns {boolean} Returns `true` if the entry was removed, else `false`.
 */
function hashDelete(key) {
  var result = this.has(key) && delete this.__data__[key];
  this.size -= result ? 1 : 0;
  return result;
}

/**
 * Gets the hash value for `key`.
 *
 * @private
 * @name get
 * @memberOf Hash
 * @param {string} key The key of the value to get.
 * @returns {*} Returns the entry value.
 */
function hashGet(key) {
  var data = this.__data__;
  if (nativeCreate) {
    var result = data[key];
    return result === HASH_UNDEFINED ? undefined : result;
  }
  return hasOwnProperty.call(data, key) ? data[key] : undefined;
}

/**
 * Checks if a hash value for `key` exists.
 *
 * @private
 * @name has
 * @memberOf Hash
 * @param {string} key The key of the entry to check.
 * @returns {boolean} Returns `true` if an entry for `key` exists, else `false`.
 */
function hashHas(key) {
  var data = this.__data__;
  return nativeCreate ? (data[key] !== undefined) : hasOwnProperty.call(data, key);
}

/**
 * Sets the hash `key` to `value`.
 *
 * @private
 * @name set
 * @memberOf Hash
 * @param {string} key The key of the value to set.
 * @param {*} value The value to set.
 * @returns {Object} Returns the hash instance.
 */
function hashSet(key, value) {
  var data = this.__data__;
  this.size += this.has(key) ? 0 : 1;
  data[key] = (nativeCreate && value === undefined) ? HASH_UNDEFINED : value;
  return this;
}

// Add methods to `Hash`.
Hash.prototype.clear = hashClear;
Hash.prototype['delete'] = hashDelete;
Hash.prototype.get = hashGet;
Hash.prototype.has = hashHas;
Hash.prototype.set = hashSet;

/**
 * Creates an list cache object.
 *
 * @private
 * @constructor
 * @param {Array} [entries] The key-value pairs to cache.
 */
function ListCache(entries) {
  var index = -1,
      length = entries == null ? 0 : entries.length;

  this.clear();
  while (++index < length) {
    var entry = entries[index];
    this.set(entry[0], entry[1]);
  }
}

/**
 * Removes all key-value entries from the list cache.
 *
 * @private
 * @name clear
 * @memberOf ListCache
 */
function listCacheClear() {
  this.__data__ = [];
  this.size = 0;
}

/**
 * Removes `key` and its value from the list cache.
 *
 * @private
 * @name delete
 * @memberOf ListCache
 * @param {string} key The key of the value to remove.
 * @returns {boolean} Returns `true` if the entry was removed, else `false`.
 */
function listCacheDelete(key) {
  var data = this.__data__,
      index = assocIndexOf(data, key);

  if (index < 0) {
    return false;
  }
  var lastIndex = data.length - 1;
  if (index == lastIndex) {
    data.pop();
  } else {
    splice.call(data, index, 1);
  }
  --this.size;
  return true;
}

/**
 * Gets the list cache value for `key`.
 *
 * @private
 * @name get
 * @memberOf ListCache
 * @param {string} key The key of the value to get.
 * @returns {*} Returns the entry value.
 */
function listCacheGet(key) {
  var data = this.__data__,
      index = assocIndexOf(data, key);

  return index < 0 ? undefined : data[index][1];
}

/**
 * Checks if a list cache value for `key` exists.
 *
 * @private
 * @name has
 * @memberOf ListCache
 * @param {string} key The key of the entry to check.
 * @returns {boolean} Returns `true` if an entry for `key` exists, else `false`.
 */
function listCacheHas(key) {
  return assocIndexOf(this.__data__, key) > -1;
}

/**
 * Sets the list cache `key` to `value`.
 *
 * @private
 * @name set
 * @memberOf ListCache
 * @param {string} key The key of the value to set.
 * @param {*} value The value to set.
 * @returns {Object} Returns the list cache instance.
 */
function listCacheSet(key, value) {
  var data = this.__data__,
      index = assocIndexOf(data, key);

  if (index < 0) {
    ++this.size;
    data.push([key, value]);
  } else {
    data[index][1] = value;
  }
  return this;
}

// Add methods to `ListCache`.
ListCache.prototype.clear = listCacheClear;
ListCache.prototype['delete'] = listCacheDelete;
ListCache.prototype.get = listCacheGet;
ListCache.prototype.has = listCacheHas;
ListCache.prototype.set = listCacheSet;

/**
 * Creates a map cache object to store key-value pairs.
 *
 * @private
 * @constructor
 * @param {Array} [entries] The key-value pairs to cache.
 */
function MapCache(entries) {
  var index = -1,
      length = entries == null ? 0 : entries.length;

  this.clear();
  while (++index < length) {
    var entry = entries[index];
    this.set(entry[0], entry[1]);
  }
}

/**
 * Removes all key-value entries from the map.
 *
 * @private
 * @name clear
 * @memberOf MapCache
 */
function mapCacheClear() {
  this.size = 0;
  this.__data__ = {
    'hash': new Hash,
    'map': new (Map || ListCache),
    'string': new Hash
  };
}

/**
 * Removes `key` and its value from the map.
 *
 * @private
 * @name delete
 * @memberOf MapCache
 * @param {string} key The key of the value to remove.
 * @returns {boolean} Returns `true` if the entry was removed, else `false`.
 */
function mapCacheDelete(key) {
  var result = getMapData(this, key)['delete'](key);
  this.size -= result ? 1 : 0;
  return result;
}

/**
 * Gets the map value for `key`.
 *
 * @private
 * @name get
 * @memberOf MapCache
 * @param {string} key The key of the value to get.
 * @returns {*} Returns the entry value.
 */
function mapCacheGet(key) {
  return getMapData(this, key).get(key);
}

/**
 * Checks if a map value for `key` exists.
 *
 * @private
 * @name has
 * @memberOf MapCache
 * @param {string} key The key of the entry to check.
 * @returns {boolean} Returns `true` if an entry for `key` exists, else `false`.
 */
function mapCacheHas(key) {
  return getMapData(this, key).has(key);
}

/**
 * Sets the map `key` to `value`.
 *
 * @private
 * @name set
 * @memberOf MapCache
 * @param {string} key The key of the value to set.
 * @param {*} value The value to set.
 * @returns {Object} Returns the map cache instance.
 */
function mapCacheSet(key, value) {
  var data = getMapData(this, key),
      size = data.size;

  data.set(key, value);
  this.size += data.size == size ? 0 : 1;
  return this;
}

// Add methods to `MapCache`.
MapCache.prototype.clear = mapCacheClear;
MapCache.prototype['delete'] = mapCacheDelete;
MapCache.prototype.get = mapCacheGet;
MapCache.prototype.has = mapCacheHas;
MapCache.prototype.set = mapCacheSet;

/**
 *
 * Creates an array cache object to store unique values.
 *
 * @private
 * @constructor
 * @param {Array} [values] The values to cache.
 */
function SetCache(values) {
  var index = -1,
      length = values == null ? 0 : values.length;

  this.__data__ = new MapCache;
  while (++index < length) {
    this.add(values[index]);
  }
}

/**
 * Adds `value` to the array cache.
 *
 * @private
 * @name add
 * @memberOf SetCache
 * @alias push
 * @param {*} value The value to cache.
 * @returns {Object} Returns the cache instance.
 */
function setCacheAdd(value) {
  this.__data__.set(value, HASH_UNDEFINED);
  return this;
}

/**
 * Checks if `value` is in the array cache.
 *
 * @private
 * @name has
 * @memberOf SetCache
 * @param {*} value The value to search for.
 * @returns {number} Returns `true` if `value` is found, else `false`.
 */
function setCacheHas(value) {
  return this.__data__.has(value);
}

// Add methods to `SetCache`.
SetCache.prototype.add = SetCache.prototype.push = setCacheAdd;
SetCache.prototype.has = setCacheHas;

/**
 * Creates a stack cache object to store key-value pairs.
 *
 * @private
 * @constructor
 * @param {Array} [entries] The key-value pairs to cache.
 */
function Stack(entries) {
  var data = this.__data__ = new ListCache(entries);
  this.size = data.size;
}

/**
 * Removes all key-value entries from the stack.
 *
 * @private
 * @name clear
 * @memberOf Stack
 */
function stackClear() {
  this.__data__ = new ListCache;
  this.size = 0;
}

/**
 * Removes `key` and its value from the stack.
 *
 * @private
 * @name delete
 * @memberOf Stack
 * @param {string} key The key of the value to remove.
 * @returns {boolean} Returns `true` if the entry was removed, else `false`.
 */
function stackDelete(key) {
  var data = this.__data__,
      result = data['delete'](key);

  this.size = data.size;
  return result;
}

/**
 * Gets the stack value for `key`.
 *
 * @private
 * @name get
 * @memberOf Stack
 * @param {string} key The key of the value to get.
 * @returns {*} Returns the entry value.
 */
function stackGet(key) {
  return this.__data__.get(key);
}

/**
 * Checks if a stack value for `key` exists.
 *
 * @private
 * @name has
 * @memberOf Stack
 * @param {string} key The key of the entry to check.
 * @returns {boolean} Returns `true` if an entry for `key` exists, else `false`.
 */
function stackHas(key) {
  return this.__data__.has(key);
}

/**
 * Sets the stack `key` to `value`.
 *
 * @private
 * @name set
 * @memberOf Stack
 * @param {string} key The key of the value to set.
 * @param {*} value The value to set.
 * @returns {Object} Returns the stack cache instance.
 */
function stackSet(key, value) {
  var data = this.__data__;
  if (data instanceof ListCache) {
    var pairs = data.__data__;
    if (!Map || (pairs.length < LARGE_ARRAY_SIZE - 1)) {
      pairs.push([key, value]);
      this.size = ++data.size;
      return this;
    }
    data = this.__data__ = new MapCache(pairs);
  }
  data.set(key, value);
  this.size = data.size;
  return this;
}

// Add methods to `Stack`.
Stack.prototype.clear = stackClear;
Stack.prototype['delete'] = stackDelete;
Stack.prototype.get = stackGet;
Stack.prototype.has = stackHas;
Stack.prototype.set = stackSet;

/**
 * Creates an array of the enumerable property names of the array-like `value`.
 *
 * @private
 * @param {*} value The value to query.
 * @param {boolean} inherited Specify returning inherited property names.
 * @returns {Array} Returns the array of property names.
 */
function arrayLikeKeys(value, inherited) {
  var isArr = isArray(value),
      isArg = !isArr && isArguments(value),
      isBuff = !isArr && !isArg && isBuffer(value),
      isType = !isArr && !isArg && !isBuff && isTypedArray(value),
      skipIndexes = isArr || isArg || isBuff || isType,
      result = skipIndexes ? baseTimes(value.length, String) : [],
      length = result.length;

  for (var key in value) {
    if ((inherited || hasOwnProperty.call(value, key)) &&
        !(skipIndexes && (
           // Safari 9 has enumerable `arguments.length` in strict mode.
           key == 'length' ||
           // Node.js 0.10 has enumerable non-index properties on buffers.
           (isBuff && (key == 'offset' || key == 'parent')) ||
           // PhantomJS 2 has enumerable non-index properties on typed arrays.
           (isType && (key == 'buffer' || key == 'byteLength' || key == 'byteOffset')) ||
           // Skip index properties.
           isIndex(key, length)
        ))) {
      result.push(key);
    }
  }
  return result;
}

/**
 * Gets the index at which the `key` is found in `array` of key-value pairs.
 *
 * @private
 * @param {Array} array The array to inspect.
 * @param {*} key The key to search for.
 * @returns {number} Returns the index of the matched value, else `-1`.
 */
function assocIndexOf(array, key) {
  var length = array.length;
  while (length--) {
    if (eq(array[length][0], key)) {
      return length;
    }
  }
  return -1;
}

/**
 * The base implementation of `getAllKeys` and `getAllKeysIn` which uses
 * `keysFunc` and `symbolsFunc` to get the enumerable property names and
 * symbols of `object`.
 *
 * @private
 * @param {Object} object The object to query.
 * @param {Function} keysFunc The function to get the keys of `object`.
 * @param {Function} symbolsFunc The function to get the symbols of `object`.
 * @returns {Array} Returns the array of property names and symbols.
 */
function baseGetAllKeys(object, keysFunc, symbolsFunc) {
  var result = keysFunc(object);
  return isArray(object) ? result : arrayPush(result, symbolsFunc(object));
}

/**
 * The base implementation of `getTag` without fallbacks for buggy environments.
 *
 * @private
 * @param {*} value The value to query.
 * @returns {string} Returns the `toStringTag`.
 */
function baseGetTag(value) {
  if (value == null) {
    return value === undefined ? undefinedTag : nullTag;
  }
  return (symToStringTag && symToStringTag in Object(value))
    ? getRawTag(value)
    : objectToString(value);
}

/**
 * The base implementation of `_.isArguments`.
 *
 * @private
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is an `arguments` object,
 */
function baseIsArguments(value) {
  return isObjectLike(value) && baseGetTag(value) == argsTag;
}

/**
 * The base implementation of `_.isEqual` which supports partial comparisons
 * and tracks traversed objects.
 *
 * @private
 * @param {*} value The value to compare.
 * @param {*} other The other value to compare.
 * @param {boolean} bitmask The bitmask flags.
 *  1 - Unordered comparison
 *  2 - Partial comparison
 * @param {Function} [customizer] The function to customize comparisons.
 * @param {Object} [stack] Tracks traversed `value` and `other` objects.
 * @returns {boolean} Returns `true` if the values are equivalent, else `false`.
 */
function baseIsEqual(value, other, bitmask, customizer, stack) {
  if (value === other) {
    return true;
  }
  if (value == null || other == null || (!isObjectLike(value) && !isObjectLike(other))) {
    return value !== value && other !== other;
  }
  return baseIsEqualDeep(value, other, bitmask, customizer, baseIsEqual, stack);
}

/**
 * A specialized version of `baseIsEqual` for arrays and objects which performs
 * deep comparisons and tracks traversed objects enabling objects with circular
 * references to be compared.
 *
 * @private
 * @param {Object} object The object to compare.
 * @param {Object} other The other object to compare.
 * @param {number} bitmask The bitmask flags. See `baseIsEqual` for more details.
 * @param {Function} customizer The function to customize comparisons.
 * @param {Function} equalFunc The function to determine equivalents of values.
 * @param {Object} [stack] Tracks traversed `object` and `other` objects.
 * @returns {boolean} Returns `true` if the objects are equivalent, else `false`.
 */
function baseIsEqualDeep(object, other, bitmask, customizer, equalFunc, stack) {
  var objIsArr = isArray(object),
      othIsArr = isArray(other),
      objTag = objIsArr ? arrayTag : getTag(object),
      othTag = othIsArr ? arrayTag : getTag(other);

  objTag = objTag == argsTag ? objectTag : objTag;
  othTag = othTag == argsTag ? objectTag : othTag;

  var objIsObj = objTag == objectTag,
      othIsObj = othTag == objectTag,
      isSameTag = objTag == othTag;

  if (isSameTag && isBuffer(object)) {
    if (!isBuffer(other)) {
      return false;
    }
    objIsArr = true;
    objIsObj = false;
  }
  if (isSameTag && !objIsObj) {
    stack || (stack = new Stack);
    return (objIsArr || isTypedArray(object))
      ? equalArrays(object, other, bitmask, customizer, equalFunc, stack)
      : equalByTag(object, other, objTag, bitmask, customizer, equalFunc, stack);
  }
  if (!(bitmask & COMPARE_PARTIAL_FLAG)) {
    var objIsWrapped = objIsObj && hasOwnProperty.call(object, '__wrapped__'),
        othIsWrapped = othIsObj && hasOwnProperty.call(other, '__wrapped__');

    if (objIsWrapped || othIsWrapped) {
      var objUnwrapped = objIsWrapped ? object.value() : object,
          othUnwrapped = othIsWrapped ? other.value() : other;

      stack || (stack = new Stack);
      return equalFunc(objUnwrapped, othUnwrapped, bitmask, customizer, stack);
    }
  }
  if (!isSameTag) {
    return false;
  }
  stack || (stack = new Stack);
  return equalObjects(object, other, bitmask, customizer, equalFunc, stack);
}

/**
 * The base implementation of `_.isNative` without bad shim checks.
 *
 * @private
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is a native function,
 *  else `false`.
 */
function baseIsNative(value) {
  if (!isObject(value) || isMasked(value)) {
    return false;
  }
  var pattern = isFunction(value) ? reIsNative : reIsHostCtor;
  return pattern.test(toSource(value));
}

/**
 * The base implementation of `_.isTypedArray` without Node.js optimizations.
 *
 * @private
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is a typed array, else `false`.
 */
function baseIsTypedArray(value) {
  return isObjectLike(value) &&
    isLength(value.length) && !!typedArrayTags[baseGetTag(value)];
}

/**
 * The base implementation of `_.keys` which doesn't treat sparse arrays as dense.
 *
 * @private
 * @param {Object} object The object to query.
 * @returns {Array} Returns the array of property names.
 */
function baseKeys(object) {
  if (!isPrototype(object)) {
    return nativeKeys(object);
  }
  var result = [];
  for (var key in Object(object)) {
    if (hasOwnProperty.call(object, key) && key != 'constructor') {
      result.push(key);
    }
  }
  return result;
}

/**
 * A specialized version of `baseIsEqualDeep` for arrays with support for
 * partial deep comparisons.
 *
 * @private
 * @param {Array} array The array to compare.
 * @param {Array} other The other array to compare.
 * @param {number} bitmask The bitmask flags. See `baseIsEqual` for more details.
 * @param {Function} customizer The function to customize comparisons.
 * @param {Function} equalFunc The function to determine equivalents of values.
 * @param {Object} stack Tracks traversed `array` and `other` objects.
 * @returns {boolean} Returns `true` if the arrays are equivalent, else `false`.
 */
function equalArrays(array, other, bitmask, customizer, equalFunc, stack) {
  var isPartial = bitmask & COMPARE_PARTIAL_FLAG,
      arrLength = array.length,
      othLength = other.length;

  if (arrLength != othLength && !(isPartial && othLength > arrLength)) {
    return false;
  }
  // Assume cyclic values are equal.
  var stacked = stack.get(array);
  if (stacked && stack.get(other)) {
    return stacked == other;
  }
  var index = -1,
      result = true,
      seen = (bitmask & COMPARE_UNORDERED_FLAG) ? new SetCache : undefined;

  stack.set(array, other);
  stack.set(other, array);

  // Ignore non-index properties.
  while (++index < arrLength) {
    var arrValue = array[index],
        othValue = other[index];

    if (customizer) {
      var compared = isPartial
        ? customizer(othValue, arrValue, index, other, array, stack)
        : customizer(arrValue, othValue, index, array, other, stack);
    }
    if (compared !== undefined) {
      if (compared) {
        continue;
      }
      result = false;
      break;
    }
    // Recursively compare arrays (susceptible to call stack limits).
    if (seen) {
      if (!arraySome(other, function(othValue, othIndex) {
            if (!cacheHas(seen, othIndex) &&
                (arrValue === othValue || equalFunc(arrValue, othValue, bitmask, customizer, stack))) {
              return seen.push(othIndex);
            }
          })) {
        result = false;
        break;
      }
    } else if (!(
          arrValue === othValue ||
            equalFunc(arrValue, othValue, bitmask, customizer, stack)
        )) {
      result = false;
      break;
    }
  }
  stack['delete'](array);
  stack['delete'](other);
  return result;
}

/**
 * A specialized version of `baseIsEqualDeep` for comparing objects of
 * the same `toStringTag`.
 *
 * **Note:** This function only supports comparing values with tags of
 * `Boolean`, `Date`, `Error`, `Number`, `RegExp`, or `String`.
 *
 * @private
 * @param {Object} object The object to compare.
 * @param {Object} other The other object to compare.
 * @param {string} tag The `toStringTag` of the objects to compare.
 * @param {number} bitmask The bitmask flags. See `baseIsEqual` for more details.
 * @param {Function} customizer The function to customize comparisons.
 * @param {Function} equalFunc The function to determine equivalents of values.
 * @param {Object} stack Tracks traversed `object` and `other` objects.
 * @returns {boolean} Returns `true` if the objects are equivalent, else `false`.
 */
function equalByTag(object, other, tag, bitmask, customizer, equalFunc, stack) {
  switch (tag) {
    case dataViewTag:
      if ((object.byteLength != other.byteLength) ||
          (object.byteOffset != other.byteOffset)) {
        return false;
      }
      object = object.buffer;
      other = other.buffer;

    case arrayBufferTag:
      if ((object.byteLength != other.byteLength) ||
          !equalFunc(new Uint8Array(object), new Uint8Array(other))) {
        return false;
      }
      return true;

    case boolTag:
    case dateTag:
    case numberTag:
      // Coerce booleans to `1` or `0` and dates to milliseconds.
      // Invalid dates are coerced to `NaN`.
      return eq(+object, +other);

    case errorTag:
      return object.name == other.name && object.message == other.message;

    case regexpTag:
    case stringTag:
      // Coerce regexes to strings and treat strings, primitives and objects,
      // as equal. See http://www.ecma-international.org/ecma-262/7.0/#sec-regexp.prototype.tostring
      // for more details.
      return object == (other + '');

    case mapTag:
      var convert = mapToArray;

    case setTag:
      var isPartial = bitmask & COMPARE_PARTIAL_FLAG;
      convert || (convert = setToArray);

      if (object.size != other.size && !isPartial) {
        return false;
      }
      // Assume cyclic values are equal.
      var stacked = stack.get(object);
      if (stacked) {
        return stacked == other;
      }
      bitmask |= COMPARE_UNORDERED_FLAG;

      // Recursively compare objects (susceptible to call stack limits).
      stack.set(object, other);
      var result = equalArrays(convert(object), convert(other), bitmask, customizer, equalFunc, stack);
      stack['delete'](object);
      return result;

    case symbolTag:
      if (symbolValueOf) {
        return symbolValueOf.call(object) == symbolValueOf.call(other);
      }
  }
  return false;
}

/**
 * A specialized version of `baseIsEqualDeep` for objects with support for
 * partial deep comparisons.
 *
 * @private
 * @param {Object} object The object to compare.
 * @param {Object} other The other object to compare.
 * @param {number} bitmask The bitmask flags. See `baseIsEqual` for more details.
 * @param {Function} customizer The function to customize comparisons.
 * @param {Function} equalFunc The function to determine equivalents of values.
 * @param {Object} stack Tracks traversed `object` and `other` objects.
 * @returns {boolean} Returns `true` if the objects are equivalent, else `false`.
 */
function equalObjects(object, other, bitmask, customizer, equalFunc, stack) {
  var isPartial = bitmask & COMPARE_PARTIAL_FLAG,
      objProps = getAllKeys(object),
      objLength = objProps.length,
      othProps = getAllKeys(other),
      othLength = othProps.length;

  if (objLength != othLength && !isPartial) {
    return false;
  }
  var index = objLength;
  while (index--) {
    var key = objProps[index];
    if (!(isPartial ? key in other : hasOwnProperty.call(other, key))) {
      return false;
    }
  }
  // Assume cyclic values are equal.
  var stacked = stack.get(object);
  if (stacked && stack.get(other)) {
    return stacked == other;
  }
  var result = true;
  stack.set(object, other);
  stack.set(other, object);

  var skipCtor = isPartial;
  while (++index < objLength) {
    key = objProps[index];
    var objValue = object[key],
        othValue = other[key];

    if (customizer) {
      var compared = isPartial
        ? customizer(othValue, objValue, key, other, object, stack)
        : customizer(objValue, othValue, key, object, other, stack);
    }
    // Recursively compare objects (susceptible to call stack limits).
    if (!(compared === undefined
          ? (objValue === othValue || equalFunc(objValue, othValue, bitmask, customizer, stack))
          : compared
        )) {
      result = false;
      break;
    }
    skipCtor || (skipCtor = key == 'constructor');
  }
  if (result && !skipCtor) {
    var objCtor = object.constructor,
        othCtor = other.constructor;

    // Non `Object` object instances with different constructors are not equal.
    if (objCtor != othCtor &&
        ('constructor' in object && 'constructor' in other) &&
        !(typeof objCtor == 'function' && objCtor instanceof objCtor &&
          typeof othCtor == 'function' && othCtor instanceof othCtor)) {
      result = false;
    }
  }
  stack['delete'](object);
  stack['delete'](other);
  return result;
}

/**
 * Creates an array of own enumerable property names and symbols of `object`.
 *
 * @private
 * @param {Object} object The object to query.
 * @returns {Array} Returns the array of property names and symbols.
 */
function getAllKeys(object) {
  return baseGetAllKeys(object, keys, getSymbols);
}

/**
 * Gets the data for `map`.
 *
 * @private
 * @param {Object} map The map to query.
 * @param {string} key The reference key.
 * @returns {*} Returns the map data.
 */
function getMapData(map, key) {
  var data = map.__data__;
  return isKeyable(key)
    ? data[typeof key == 'string' ? 'string' : 'hash']
    : data.map;
}

/**
 * Gets the native function at `key` of `object`.
 *
 * @private
 * @param {Object} object The object to query.
 * @param {string} key The key of the method to get.
 * @returns {*} Returns the function if it's native, else `undefined`.
 */
function getNative(object, key) {
  var value = getValue(object, key);
  return baseIsNative(value) ? value : undefined;
}

/**
 * A specialized version of `baseGetTag` which ignores `Symbol.toStringTag` values.
 *
 * @private
 * @param {*} value The value to query.
 * @returns {string} Returns the raw `toStringTag`.
 */
function getRawTag(value) {
  var isOwn = hasOwnProperty.call(value, symToStringTag),
      tag = value[symToStringTag];

  try {
    value[symToStringTag] = undefined;
    var unmasked = true;
  } catch (e) {}

  var result = nativeObjectToString.call(value);
  if (unmasked) {
    if (isOwn) {
      value[symToStringTag] = tag;
    } else {
      delete value[symToStringTag];
    }
  }
  return result;
}

/**
 * Creates an array of the own enumerable symbols of `object`.
 *
 * @private
 * @param {Object} object The object to query.
 * @returns {Array} Returns the array of symbols.
 */
var getSymbols = !nativeGetSymbols ? stubArray : function(object) {
  if (object == null) {
    return [];
  }
  object = Object(object);
  return arrayFilter(nativeGetSymbols(object), function(symbol) {
    return propertyIsEnumerable.call(object, symbol);
  });
};

/**
 * Gets the `toStringTag` of `value`.
 *
 * @private
 * @param {*} value The value to query.
 * @returns {string} Returns the `toStringTag`.
 */
var getTag = baseGetTag;

// Fallback for data views, maps, sets, and weak maps in IE 11 and promises in Node.js < 6.
if ((DataView && getTag(new DataView(new ArrayBuffer(1))) != dataViewTag) ||
    (Map && getTag(new Map) != mapTag) ||
    (Promise && getTag(Promise.resolve()) != promiseTag) ||
    (Set && getTag(new Set) != setTag) ||
    (WeakMap && getTag(new WeakMap) != weakMapTag)) {
  getTag = function(value) {
    var result = baseGetTag(value),
        Ctor = result == objectTag ? value.constructor : undefined,
        ctorString = Ctor ? toSource(Ctor) : '';

    if (ctorString) {
      switch (ctorString) {
        case dataViewCtorString: return dataViewTag;
        case mapCtorString: return mapTag;
        case promiseCtorString: return promiseTag;
        case setCtorString: return setTag;
        case weakMapCtorString: return weakMapTag;
      }
    }
    return result;
  };
}

/**
 * Checks if `value` is a valid array-like index.
 *
 * @private
 * @param {*} value The value to check.
 * @param {number} [length=MAX_SAFE_INTEGER] The upper bounds of a valid index.
 * @returns {boolean} Returns `true` if `value` is a valid index, else `false`.
 */
function isIndex(value, length) {
  length = length == null ? MAX_SAFE_INTEGER : length;
  return !!length &&
    (typeof value == 'number' || reIsUint.test(value)) &&
    (value > -1 && value % 1 == 0 && value < length);
}

/**
 * Checks if `value` is suitable for use as unique object key.
 *
 * @private
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is suitable, else `false`.
 */
function isKeyable(value) {
  var type = typeof value;
  return (type == 'string' || type == 'number' || type == 'symbol' || type == 'boolean')
    ? (value !== '__proto__')
    : (value === null);
}

/**
 * Checks if `func` has its source masked.
 *
 * @private
 * @param {Function} func The function to check.
 * @returns {boolean} Returns `true` if `func` is masked, else `false`.
 */
function isMasked(func) {
  return !!maskSrcKey && (maskSrcKey in func);
}

/**
 * Checks if `value` is likely a prototype object.
 *
 * @private
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is a prototype, else `false`.
 */
function isPrototype(value) {
  var Ctor = value && value.constructor,
      proto = (typeof Ctor == 'function' && Ctor.prototype) || objectProto;

  return value === proto;
}

/**
 * Converts `value` to a string using `Object.prototype.toString`.
 *
 * @private
 * @param {*} value The value to convert.
 * @returns {string} Returns the converted string.
 */
function objectToString(value) {
  return nativeObjectToString.call(value);
}

/**
 * Converts `func` to its source code.
 *
 * @private
 * @param {Function} func The function to convert.
 * @returns {string} Returns the source code.
 */
function toSource(func) {
  if (func != null) {
    try {
      return funcToString.call(func);
    } catch (e) {}
    try {
      return (func + '');
    } catch (e) {}
  }
  return '';
}

/**
 * Performs a
 * [`SameValueZero`](http://ecma-international.org/ecma-262/7.0/#sec-samevaluezero)
 * comparison between two values to determine if they are equivalent.
 *
 * @static
 * @memberOf _
 * @since 4.0.0
 * @category Lang
 * @param {*} value The value to compare.
 * @param {*} other The other value to compare.
 * @returns {boolean} Returns `true` if the values are equivalent, else `false`.
 * @example
 *
 * var object = { 'a': 1 };
 * var other = { 'a': 1 };
 *
 * _.eq(object, object);
 * // => true
 *
 * _.eq(object, other);
 * // => false
 *
 * _.eq('a', 'a');
 * // => true
 *
 * _.eq('a', Object('a'));
 * // => false
 *
 * _.eq(NaN, NaN);
 * // => true
 */
function eq(value, other) {
  return value === other || (value !== value && other !== other);
}

/**
 * Checks if `value` is likely an `arguments` object.
 *
 * @static
 * @memberOf _
 * @since 0.1.0
 * @category Lang
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is an `arguments` object,
 *  else `false`.
 * @example
 *
 * _.isArguments(function() { return arguments; }());
 * // => true
 *
 * _.isArguments([1, 2, 3]);
 * // => false
 */
var isArguments = baseIsArguments(function() { return arguments; }()) ? baseIsArguments : function(value) {
  return isObjectLike(value) && hasOwnProperty.call(value, 'callee') &&
    !propertyIsEnumerable.call(value, 'callee');
};

/**
 * Checks if `value` is classified as an `Array` object.
 *
 * @static
 * @memberOf _
 * @since 0.1.0
 * @category Lang
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is an array, else `false`.
 * @example
 *
 * _.isArray([1, 2, 3]);
 * // => true
 *
 * _.isArray(document.body.children);
 * // => false
 *
 * _.isArray('abc');
 * // => false
 *
 * _.isArray(_.noop);
 * // => false
 */
var isArray = Array.isArray;

/**
 * Checks if `value` is array-like. A value is considered array-like if it's
 * not a function and has a `value.length` that's an integer greater than or
 * equal to `0` and less than or equal to `Number.MAX_SAFE_INTEGER`.
 *
 * @static
 * @memberOf _
 * @since 4.0.0
 * @category Lang
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is array-like, else `false`.
 * @example
 *
 * _.isArrayLike([1, 2, 3]);
 * // => true
 *
 * _.isArrayLike(document.body.children);
 * // => true
 *
 * _.isArrayLike('abc');
 * // => true
 *
 * _.isArrayLike(_.noop);
 * // => false
 */
function isArrayLike(value) {
  return value != null && isLength(value.length) && !isFunction(value);
}

/**
 * Checks if `value` is a buffer.
 *
 * @static
 * @memberOf _
 * @since 4.3.0
 * @category Lang
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is a buffer, else `false`.
 * @example
 *
 * _.isBuffer(new Buffer(2));
 * // => true
 *
 * _.isBuffer(new Uint8Array(2));
 * // => false
 */
var isBuffer = nativeIsBuffer || stubFalse;

/**
 * Performs a deep comparison between two values to determine if they are
 * equivalent.
 *
 * **Note:** This method supports comparing arrays, array buffers, booleans,
 * date objects, error objects, maps, numbers, `Object` objects, regexes,
 * sets, strings, symbols, and typed arrays. `Object` objects are compared
 * by their own, not inherited, enumerable properties. Functions and DOM
 * nodes are compared by strict equality, i.e. `===`.
 *
 * @static
 * @memberOf _
 * @since 0.1.0
 * @category Lang
 * @param {*} value The value to compare.
 * @param {*} other The other value to compare.
 * @returns {boolean} Returns `true` if the values are equivalent, else `false`.
 * @example
 *
 * var object = { 'a': 1 };
 * var other = { 'a': 1 };
 *
 * _.isEqual(object, other);
 * // => true
 *
 * object === other;
 * // => false
 */
function isEqual(value, other) {
  return baseIsEqual(value, other);
}

/**
 * Checks if `value` is classified as a `Function` object.
 *
 * @static
 * @memberOf _
 * @since 0.1.0
 * @category Lang
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is a function, else `false`.
 * @example
 *
 * _.isFunction(_);
 * // => true
 *
 * _.isFunction(/abc/);
 * // => false
 */
function isFunction(value) {
  if (!isObject(value)) {
    return false;
  }
  // The use of `Object#toString` avoids issues with the `typeof` operator
  // in Safari 9 which returns 'object' for typed arrays and other constructors.
  var tag = baseGetTag(value);
  return tag == funcTag || tag == genTag || tag == asyncTag || tag == proxyTag;
}

/**
 * Checks if `value` is a valid array-like length.
 *
 * **Note:** This method is loosely based on
 * [`ToLength`](http://ecma-international.org/ecma-262/7.0/#sec-tolength).
 *
 * @static
 * @memberOf _
 * @since 4.0.0
 * @category Lang
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is a valid length, else `false`.
 * @example
 *
 * _.isLength(3);
 * // => true
 *
 * _.isLength(Number.MIN_VALUE);
 * // => false
 *
 * _.isLength(Infinity);
 * // => false
 *
 * _.isLength('3');
 * // => false
 */
function isLength(value) {
  return typeof value == 'number' &&
    value > -1 && value % 1 == 0 && value <= MAX_SAFE_INTEGER;
}

/**
 * Checks if `value` is the
 * [language type](http://www.ecma-international.org/ecma-262/7.0/#sec-ecmascript-language-types)
 * of `Object`. (e.g. arrays, functions, objects, regexes, `new Number(0)`, and `new String('')`)
 *
 * @static
 * @memberOf _
 * @since 0.1.0
 * @category Lang
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is an object, else `false`.
 * @example
 *
 * _.isObject({});
 * // => true
 *
 * _.isObject([1, 2, 3]);
 * // => true
 *
 * _.isObject(_.noop);
 * // => true
 *
 * _.isObject(null);
 * // => false
 */
function isObject(value) {
  var type = typeof value;
  return value != null && (type == 'object' || type == 'function');
}

/**
 * Checks if `value` is object-like. A value is object-like if it's not `null`
 * and has a `typeof` result of "object".
 *
 * @static
 * @memberOf _
 * @since 4.0.0
 * @category Lang
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is object-like, else `false`.
 * @example
 *
 * _.isObjectLike({});
 * // => true
 *
 * _.isObjectLike([1, 2, 3]);
 * // => true
 *
 * _.isObjectLike(_.noop);
 * // => false
 *
 * _.isObjectLike(null);
 * // => false
 */
function isObjectLike(value) {
  return value != null && typeof value == 'object';
}

/**
 * Checks if `value` is classified as a typed array.
 *
 * @static
 * @memberOf _
 * @since 3.0.0
 * @category Lang
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is a typed array, else `false`.
 * @example
 *
 * _.isTypedArray(new Uint8Array);
 * // => true
 *
 * _.isTypedArray([]);
 * // => false
 */
var isTypedArray = nodeIsTypedArray ? baseUnary(nodeIsTypedArray) : baseIsTypedArray;

/**
 * Creates an array of the own enumerable property names of `object`.
 *
 * **Note:** Non-object values are coerced to objects. See the
 * [ES spec](http://ecma-international.org/ecma-262/7.0/#sec-object.keys)
 * for more details.
 *
 * @static
 * @since 0.1.0
 * @memberOf _
 * @category Object
 * @param {Object} object The object to query.
 * @returns {Array} Returns the array of property names.
 * @example
 *
 * function Foo() {
 *   this.a = 1;
 *   this.b = 2;
 * }
 *
 * Foo.prototype.c = 3;
 *
 * _.keys(new Foo);
 * // => ['a', 'b'] (iteration order is not guaranteed)
 *
 * _.keys('hi');
 * // => ['0', '1']
 */
function keys(object) {
  return isArrayLike(object) ? arrayLikeKeys(object) : baseKeys(object);
}

/**
 * This method returns a new empty array.
 *
 * @static
 * @memberOf _
 * @since 4.13.0
 * @category Util
 * @returns {Array} Returns the new empty array.
 * @example
 *
 * var arrays = _.times(2, _.stubArray);
 *
 * console.log(arrays);
 * // => [[], []]
 *
 * console.log(arrays[0] === arrays[1]);
 * // => false
 */
function stubArray() {
  return [];
}

/**
 * This method returns `false`.
 *
 * @static
 * @memberOf _
 * @since 4.13.0
 * @category Util
 * @returns {boolean} Returns `false`.
 * @example
 *
 * _.times(2, _.stubFalse);
 * // => [false, false]
 */
function stubFalse() {
  return false;
}

module.exports = isEqual;
});

/**
 * Copyright 2014-2015, Facebook, Inc.
 * All rights reserved.
 *
 * This source code is licensed under the BSD-style license found in the
 * LICENSE file in the root directory of this source tree. An additional grant
 * of patent rights can be found in the PATENTS file in the same directory.
 */

/**
 * Similar to invariant but only logs a warning if the condition is not met.
 * This can be used to log issues in development environments in critical
 * paths. Removing the logging code for production environments will keep the
 * same logic and follow the same code paths.
 */

var __DEV__ = "production" !== 'production';

var warning$2 = function() {};

if (__DEV__) {
  warning$2 = function(condition, format, args) {
    var len = arguments.length;
    args = new Array(len > 2 ? len - 2 : 0);
    for (var key = 2; key < len; key++) {
      args[key - 2] = arguments[key];
    }
    if (format === undefined) {
      throw new Error(
        '`warning(condition, format, ...args)` requires a warning ' +
        'message argument'
      );
    }

    if (format.length < 10 || (/^[s\W]*$/).test(format)) {
      throw new Error(
        'The warning format should be able to uniquely identify this ' +
        'warning. Please, use a more descriptive format than: ' + format
      );
    }

    if (!condition) {
      var argIndex = 0;
      var message = 'Warning: ' +
        format.replace(/%s/g, function() {
          return args[argIndex++];
        });
      if (typeof console !== 'undefined') {
        console.error(message);
      }
      try {
        // This error was thrown as a convenience so that you can use this stack
        // to find the callsite that caused this warning to fire.
        throw new Error(message);
      } catch(x) {}
    }
  };
}

var warning_1$2 = warning$2;

/**
 * lodash (Custom Build) <https://lodash.com/>
 * Build: `lodash modularize exports="npm" -o ./`
 * Copyright jQuery Foundation and other contributors <https://jquery.org/>
 * Released under MIT license <https://lodash.com/license>
 * Based on Underscore.js 1.8.3 <http://underscorejs.org/LICENSE>
 * Copyright Jeremy Ashkenas, DocumentCloud and Investigative Reporters & Editors
 */

/** Used as the `TypeError` message for "Functions" methods. */
var FUNC_ERROR_TEXT = 'Expected a function';

/** Used to stand-in for `undefined` hash values. */
var HASH_UNDEFINED = '__lodash_hash_undefined__';

/** Used as references for various `Number` constants. */
var INFINITY = 1 / 0;

/** `Object#toString` result references. */
var funcTag = '[object Function]';
var genTag = '[object GeneratorFunction]';
var symbolTag = '[object Symbol]';

/** Used to match property names within property paths. */
var reLeadingDot = /^\./;
var rePropName = /[^.[\]]+|\[(?:(-?\d+(?:\.\d+)?)|(["'])((?:(?!\2)[^\\]|\\.)*?)\2)\]|(?=(?:\.|\[\])(?:\.|\[\]|$))/g;

/**
 * Used to match `RegExp`
 * [syntax characters](http://ecma-international.org/ecma-262/7.0/#sec-patterns).
 */
var reRegExpChar = /[\\^$.*+?()[\]{}|]/g;

/** Used to match backslashes in property paths. */
var reEscapeChar = /\\(\\)?/g;

/** Used to detect host constructors (Safari). */
var reIsHostCtor = /^\[object .+?Constructor\]$/;

/** Detect free variable `global` from Node.js. */
var freeGlobal = typeof commonjsGlobal == 'object' && commonjsGlobal && commonjsGlobal.Object === Object && commonjsGlobal;

/** Detect free variable `self`. */
var freeSelf = typeof self == 'object' && self && self.Object === Object && self;

/** Used as a reference to the global object. */
var root = freeGlobal || freeSelf || Function('return this')();

/**
 * A specialized version of `_.map` for arrays without support for iteratee
 * shorthands.
 *
 * @private
 * @param {Array} [array] The array to iterate over.
 * @param {Function} iteratee The function invoked per iteration.
 * @returns {Array} Returns the new mapped array.
 */
function arrayMap(array, iteratee) {
  var index = -1,
      length = array ? array.length : 0,
      result = Array(length);

  while (++index < length) {
    result[index] = iteratee(array[index], index, array);
  }
  return result;
}

/**
 * Gets the value at `key` of `object`.
 *
 * @private
 * @param {Object} [object] The object to query.
 * @param {string} key The key of the property to get.
 * @returns {*} Returns the property value.
 */
function getValue(object, key) {
  return object == null ? undefined : object[key];
}

/**
 * Checks if `value` is a host object in IE < 9.
 *
 * @private
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is a host object, else `false`.
 */
function isHostObject(value) {
  // Many host objects are `Object` objects that can coerce to strings
  // despite having improperly defined `toString` methods.
  var result = false;
  if (value != null && typeof value.toString != 'function') {
    try {
      result = !!(value + '');
    } catch (e) {}
  }
  return result;
}

/** Used for built-in method references. */
var arrayProto = Array.prototype;
var funcProto = Function.prototype;
var objectProto = Object.prototype;

/** Used to detect overreaching core-js shims. */
var coreJsData = root['__core-js_shared__'];

/** Used to detect methods masquerading as native. */
var maskSrcKey = (function() {
  var uid = /[^.]+$/.exec(coreJsData && coreJsData.keys && coreJsData.keys.IE_PROTO || '');
  return uid ? ('Symbol(src)_1.' + uid) : '';
}());

/** Used to resolve the decompiled source of functions. */
var funcToString = funcProto.toString;

/** Used to check objects for own properties. */
var hasOwnProperty$1 = objectProto.hasOwnProperty;

/**
 * Used to resolve the
 * [`toStringTag`](http://ecma-international.org/ecma-262/7.0/#sec-object.prototype.tostring)
 * of values.
 */
var objectToString = objectProto.toString;

/** Used to detect if a method is native. */
var reIsNative = RegExp('^' +
  funcToString.call(hasOwnProperty$1).replace(reRegExpChar, '\\$&')
  .replace(/hasOwnProperty|(function).*?(?=\\\()| for .+?(?=\\\])/g, '$1.*?') + '$'
);

/** Built-in value references. */
var Symbol$1 = root.Symbol;
var splice = arrayProto.splice;

/* Built-in method references that are verified to be native. */
var Map = getNative(root, 'Map');
var nativeCreate = getNative(Object, 'create');

/** Used to convert symbols to primitives and strings. */
var symbolProto = Symbol$1 ? Symbol$1.prototype : undefined;
var symbolToString = symbolProto ? symbolProto.toString : undefined;

/**
 * Creates a hash object.
 *
 * @private
 * @constructor
 * @param {Array} [entries] The key-value pairs to cache.
 */
function Hash(entries) {
  var index = -1,
      length = entries ? entries.length : 0;

  this.clear();
  while (++index < length) {
    var entry = entries[index];
    this.set(entry[0], entry[1]);
  }
}

/**
 * Removes all key-value entries from the hash.
 *
 * @private
 * @name clear
 * @memberOf Hash
 */
function hashClear() {
  this.__data__ = nativeCreate ? nativeCreate(null) : {};
}

/**
 * Removes `key` and its value from the hash.
 *
 * @private
 * @name delete
 * @memberOf Hash
 * @param {Object} hash The hash to modify.
 * @param {string} key The key of the value to remove.
 * @returns {boolean} Returns `true` if the entry was removed, else `false`.
 */
function hashDelete(key) {
  return this.has(key) && delete this.__data__[key];
}

/**
 * Gets the hash value for `key`.
 *
 * @private
 * @name get
 * @memberOf Hash
 * @param {string} key The key of the value to get.
 * @returns {*} Returns the entry value.
 */
function hashGet(key) {
  var data = this.__data__;
  if (nativeCreate) {
    var result = data[key];
    return result === HASH_UNDEFINED ? undefined : result;
  }
  return hasOwnProperty$1.call(data, key) ? data[key] : undefined;
}

/**
 * Checks if a hash value for `key` exists.
 *
 * @private
 * @name has
 * @memberOf Hash
 * @param {string} key The key of the entry to check.
 * @returns {boolean} Returns `true` if an entry for `key` exists, else `false`.
 */
function hashHas(key) {
  var data = this.__data__;
  return nativeCreate ? data[key] !== undefined : hasOwnProperty$1.call(data, key);
}

/**
 * Sets the hash `key` to `value`.
 *
 * @private
 * @name set
 * @memberOf Hash
 * @param {string} key The key of the value to set.
 * @param {*} value The value to set.
 * @returns {Object} Returns the hash instance.
 */
function hashSet(key, value) {
  var data = this.__data__;
  data[key] = (nativeCreate && value === undefined) ? HASH_UNDEFINED : value;
  return this;
}

// Add methods to `Hash`.
Hash.prototype.clear = hashClear;
Hash.prototype['delete'] = hashDelete;
Hash.prototype.get = hashGet;
Hash.prototype.has = hashHas;
Hash.prototype.set = hashSet;

/**
 * Creates an list cache object.
 *
 * @private
 * @constructor
 * @param {Array} [entries] The key-value pairs to cache.
 */
function ListCache(entries) {
  var index = -1,
      length = entries ? entries.length : 0;

  this.clear();
  while (++index < length) {
    var entry = entries[index];
    this.set(entry[0], entry[1]);
  }
}

/**
 * Removes all key-value entries from the list cache.
 *
 * @private
 * @name clear
 * @memberOf ListCache
 */
function listCacheClear() {
  this.__data__ = [];
}

/**
 * Removes `key` and its value from the list cache.
 *
 * @private
 * @name delete
 * @memberOf ListCache
 * @param {string} key The key of the value to remove.
 * @returns {boolean} Returns `true` if the entry was removed, else `false`.
 */
function listCacheDelete(key) {
  var data = this.__data__,
      index = assocIndexOf(data, key);

  if (index < 0) {
    return false;
  }
  var lastIndex = data.length - 1;
  if (index == lastIndex) {
    data.pop();
  } else {
    splice.call(data, index, 1);
  }
  return true;
}

/**
 * Gets the list cache value for `key`.
 *
 * @private
 * @name get
 * @memberOf ListCache
 * @param {string} key The key of the value to get.
 * @returns {*} Returns the entry value.
 */
function listCacheGet(key) {
  var data = this.__data__,
      index = assocIndexOf(data, key);

  return index < 0 ? undefined : data[index][1];
}

/**
 * Checks if a list cache value for `key` exists.
 *
 * @private
 * @name has
 * @memberOf ListCache
 * @param {string} key The key of the entry to check.
 * @returns {boolean} Returns `true` if an entry for `key` exists, else `false`.
 */
function listCacheHas(key) {
  return assocIndexOf(this.__data__, key) > -1;
}

/**
 * Sets the list cache `key` to `value`.
 *
 * @private
 * @name set
 * @memberOf ListCache
 * @param {string} key The key of the value to set.
 * @param {*} value The value to set.
 * @returns {Object} Returns the list cache instance.
 */
function listCacheSet(key, value) {
  var data = this.__data__,
      index = assocIndexOf(data, key);

  if (index < 0) {
    data.push([key, value]);
  } else {
    data[index][1] = value;
  }
  return this;
}

// Add methods to `ListCache`.
ListCache.prototype.clear = listCacheClear;
ListCache.prototype['delete'] = listCacheDelete;
ListCache.prototype.get = listCacheGet;
ListCache.prototype.has = listCacheHas;
ListCache.prototype.set = listCacheSet;

/**
 * Creates a map cache object to store key-value pairs.
 *
 * @private
 * @constructor
 * @param {Array} [entries] The key-value pairs to cache.
 */
function MapCache(entries) {
  var index = -1,
      length = entries ? entries.length : 0;

  this.clear();
  while (++index < length) {
    var entry = entries[index];
    this.set(entry[0], entry[1]);
  }
}

/**
 * Removes all key-value entries from the map.
 *
 * @private
 * @name clear
 * @memberOf MapCache
 */
function mapCacheClear() {
  this.__data__ = {
    'hash': new Hash,
    'map': new (Map || ListCache),
    'string': new Hash
  };
}

/**
 * Removes `key` and its value from the map.
 *
 * @private
 * @name delete
 * @memberOf MapCache
 * @param {string} key The key of the value to remove.
 * @returns {boolean} Returns `true` if the entry was removed, else `false`.
 */
function mapCacheDelete(key) {
  return getMapData(this, key)['delete'](key);
}

/**
 * Gets the map value for `key`.
 *
 * @private
 * @name get
 * @memberOf MapCache
 * @param {string} key The key of the value to get.
 * @returns {*} Returns the entry value.
 */
function mapCacheGet(key) {
  return getMapData(this, key).get(key);
}

/**
 * Checks if a map value for `key` exists.
 *
 * @private
 * @name has
 * @memberOf MapCache
 * @param {string} key The key of the entry to check.
 * @returns {boolean} Returns `true` if an entry for `key` exists, else `false`.
 */
function mapCacheHas(key) {
  return getMapData(this, key).has(key);
}

/**
 * Sets the map `key` to `value`.
 *
 * @private
 * @name set
 * @memberOf MapCache
 * @param {string} key The key of the value to set.
 * @param {*} value The value to set.
 * @returns {Object} Returns the map cache instance.
 */
function mapCacheSet(key, value) {
  getMapData(this, key).set(key, value);
  return this;
}

// Add methods to `MapCache`.
MapCache.prototype.clear = mapCacheClear;
MapCache.prototype['delete'] = mapCacheDelete;
MapCache.prototype.get = mapCacheGet;
MapCache.prototype.has = mapCacheHas;
MapCache.prototype.set = mapCacheSet;

/**
 * Gets the index at which the `key` is found in `array` of key-value pairs.
 *
 * @private
 * @param {Array} array The array to inspect.
 * @param {*} key The key to search for.
 * @returns {number} Returns the index of the matched value, else `-1`.
 */
function assocIndexOf(array, key) {
  var length = array.length;
  while (length--) {
    if (eq(array[length][0], key)) {
      return length;
    }
  }
  return -1;
}

/**
 * The base implementation of `_.isNative` without bad shim checks.
 *
 * @private
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is a native function,
 *  else `false`.
 */
function baseIsNative(value) {
  if (!isObject(value) || isMasked(value)) {
    return false;
  }
  var pattern = (isFunction(value) || isHostObject(value)) ? reIsNative : reIsHostCtor;
  return pattern.test(toSource(value));
}

/**
 * The base implementation of `_.toString` which doesn't convert nullish
 * values to empty strings.
 *
 * @private
 * @param {*} value The value to process.
 * @returns {string} Returns the string.
 */
function baseToString(value) {
  // Exit early for strings to avoid a performance hit in some environments.
  if (typeof value == 'string') {
    return value;
  }
  if (isSymbol(value)) {
    return symbolToString ? symbolToString.call(value) : '';
  }
  var result = (value + '');
  return (result == '0' && (1 / value) == -INFINITY) ? '-0' : result;
}

/**
 * Copies the values of `source` to `array`.
 *
 * @private
 * @param {Array} source The array to copy values from.
 * @param {Array} [array=[]] The array to copy values to.
 * @returns {Array} Returns `array`.
 */
function copyArray(source, array) {
  var index = -1,
      length = source.length;

  array || (array = Array(length));
  while (++index < length) {
    array[index] = source[index];
  }
  return array;
}

/**
 * Gets the data for `map`.
 *
 * @private
 * @param {Object} map The map to query.
 * @param {string} key The reference key.
 * @returns {*} Returns the map data.
 */
function getMapData(map, key) {
  var data = map.__data__;
  return isKeyable(key)
    ? data[typeof key == 'string' ? 'string' : 'hash']
    : data.map;
}

/**
 * Gets the native function at `key` of `object`.
 *
 * @private
 * @param {Object} object The object to query.
 * @param {string} key The key of the method to get.
 * @returns {*} Returns the function if it's native, else `undefined`.
 */
function getNative(object, key) {
  var value = getValue(object, key);
  return baseIsNative(value) ? value : undefined;
}

/**
 * Checks if `value` is suitable for use as unique object key.
 *
 * @private
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is suitable, else `false`.
 */
function isKeyable(value) {
  var type = typeof value;
  return (type == 'string' || type == 'number' || type == 'symbol' || type == 'boolean')
    ? (value !== '__proto__')
    : (value === null);
}

/**
 * Checks if `func` has its source masked.
 *
 * @private
 * @param {Function} func The function to check.
 * @returns {boolean} Returns `true` if `func` is masked, else `false`.
 */
function isMasked(func) {
  return !!maskSrcKey && (maskSrcKey in func);
}

/**
 * Converts `string` to a property path array.
 *
 * @private
 * @param {string} string The string to convert.
 * @returns {Array} Returns the property path array.
 */
var stringToPath = memoize(function(string) {
  string = toString(string);

  var result = [];
  if (reLeadingDot.test(string)) {
    result.push('');
  }
  string.replace(rePropName, function(match, number, quote, string) {
    result.push(quote ? string.replace(reEscapeChar, '$1') : (number || match));
  });
  return result;
});

/**
 * Converts `value` to a string key if it's not a string or symbol.
 *
 * @private
 * @param {*} value The value to inspect.
 * @returns {string|symbol} Returns the key.
 */
function toKey(value) {
  if (typeof value == 'string' || isSymbol(value)) {
    return value;
  }
  var result = (value + '');
  return (result == '0' && (1 / value) == -INFINITY) ? '-0' : result;
}

/**
 * Converts `func` to its source code.
 *
 * @private
 * @param {Function} func The function to process.
 * @returns {string} Returns the source code.
 */
function toSource(func) {
  if (func != null) {
    try {
      return funcToString.call(func);
    } catch (e) {}
    try {
      return (func + '');
    } catch (e) {}
  }
  return '';
}

/**
 * Creates a function that memoizes the result of `func`. If `resolver` is
 * provided, it determines the cache key for storing the result based on the
 * arguments provided to the memoized function. By default, the first argument
 * provided to the memoized function is used as the map cache key. The `func`
 * is invoked with the `this` binding of the memoized function.
 *
 * **Note:** The cache is exposed as the `cache` property on the memoized
 * function. Its creation may be customized by replacing the `_.memoize.Cache`
 * constructor with one whose instances implement the
 * [`Map`](http://ecma-international.org/ecma-262/7.0/#sec-properties-of-the-map-prototype-object)
 * method interface of `delete`, `get`, `has`, and `set`.
 *
 * @static
 * @memberOf _
 * @since 0.1.0
 * @category Function
 * @param {Function} func The function to have its output memoized.
 * @param {Function} [resolver] The function to resolve the cache key.
 * @returns {Function} Returns the new memoized function.
 * @example
 *
 * var object = { 'a': 1, 'b': 2 };
 * var other = { 'c': 3, 'd': 4 };
 *
 * var values = _.memoize(_.values);
 * values(object);
 * // => [1, 2]
 *
 * values(other);
 * // => [3, 4]
 *
 * object.a = 2;
 * values(object);
 * // => [1, 2]
 *
 * // Modify the result cache.
 * values.cache.set(object, ['a', 'b']);
 * values(object);
 * // => ['a', 'b']
 *
 * // Replace `_.memoize.Cache`.
 * _.memoize.Cache = WeakMap;
 */
function memoize(func, resolver) {
  if (typeof func != 'function' || (resolver && typeof resolver != 'function')) {
    throw new TypeError(FUNC_ERROR_TEXT);
  }
  var memoized = function() {
    var args = arguments,
        key = resolver ? resolver.apply(this, args) : args[0],
        cache = memoized.cache;

    if (cache.has(key)) {
      return cache.get(key);
    }
    var result = func.apply(this, args);
    memoized.cache = cache.set(key, result);
    return result;
  };
  memoized.cache = new (memoize.Cache || MapCache);
  return memoized;
}

// Assign cache to `_.memoize`.
memoize.Cache = MapCache;

/**
 * Performs a
 * [`SameValueZero`](http://ecma-international.org/ecma-262/7.0/#sec-samevaluezero)
 * comparison between two values to determine if they are equivalent.
 *
 * @static
 * @memberOf _
 * @since 4.0.0
 * @category Lang
 * @param {*} value The value to compare.
 * @param {*} other The other value to compare.
 * @returns {boolean} Returns `true` if the values are equivalent, else `false`.
 * @example
 *
 * var object = { 'a': 1 };
 * var other = { 'a': 1 };
 *
 * _.eq(object, object);
 * // => true
 *
 * _.eq(object, other);
 * // => false
 *
 * _.eq('a', 'a');
 * // => true
 *
 * _.eq('a', Object('a'));
 * // => false
 *
 * _.eq(NaN, NaN);
 * // => true
 */
function eq(value, other) {
  return value === other || (value !== value && other !== other);
}

/**
 * Checks if `value` is classified as an `Array` object.
 *
 * @static
 * @memberOf _
 * @since 0.1.0
 * @category Lang
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is an array, else `false`.
 * @example
 *
 * _.isArray([1, 2, 3]);
 * // => true
 *
 * _.isArray(document.body.children);
 * // => false
 *
 * _.isArray('abc');
 * // => false
 *
 * _.isArray(_.noop);
 * // => false
 */
var isArray = Array.isArray;

/**
 * Checks if `value` is classified as a `Function` object.
 *
 * @static
 * @memberOf _
 * @since 0.1.0
 * @category Lang
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is a function, else `false`.
 * @example
 *
 * _.isFunction(_);
 * // => true
 *
 * _.isFunction(/abc/);
 * // => false
 */
function isFunction(value) {
  // The use of `Object#toString` avoids issues with the `typeof` operator
  // in Safari 8-9 which returns 'object' for typed array and other constructors.
  var tag = isObject(value) ? objectToString.call(value) : '';
  return tag == funcTag || tag == genTag;
}

/**
 * Checks if `value` is the
 * [language type](http://www.ecma-international.org/ecma-262/7.0/#sec-ecmascript-language-types)
 * of `Object`. (e.g. arrays, functions, objects, regexes, `new Number(0)`, and `new String('')`)
 *
 * @static
 * @memberOf _
 * @since 0.1.0
 * @category Lang
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is an object, else `false`.
 * @example
 *
 * _.isObject({});
 * // => true
 *
 * _.isObject([1, 2, 3]);
 * // => true
 *
 * _.isObject(_.noop);
 * // => true
 *
 * _.isObject(null);
 * // => false
 */
function isObject(value) {
  var type = typeof value;
  return !!value && (type == 'object' || type == 'function');
}

/**
 * Checks if `value` is object-like. A value is object-like if it's not `null`
 * and has a `typeof` result of "object".
 *
 * @static
 * @memberOf _
 * @since 4.0.0
 * @category Lang
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is object-like, else `false`.
 * @example
 *
 * _.isObjectLike({});
 * // => true
 *
 * _.isObjectLike([1, 2, 3]);
 * // => true
 *
 * _.isObjectLike(_.noop);
 * // => false
 *
 * _.isObjectLike(null);
 * // => false
 */
function isObjectLike(value) {
  return !!value && typeof value == 'object';
}

/**
 * Checks if `value` is classified as a `Symbol` primitive or object.
 *
 * @static
 * @memberOf _
 * @since 4.0.0
 * @category Lang
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is a symbol, else `false`.
 * @example
 *
 * _.isSymbol(Symbol.iterator);
 * // => true
 *
 * _.isSymbol('abc');
 * // => false
 */
function isSymbol(value) {
  return typeof value == 'symbol' ||
    (isObjectLike(value) && objectToString.call(value) == symbolTag);
}

/**
 * Converts `value` to a string. An empty string is returned for `null`
 * and `undefined` values. The sign of `-0` is preserved.
 *
 * @static
 * @memberOf _
 * @since 4.0.0
 * @category Lang
 * @param {*} value The value to process.
 * @returns {string} Returns the string.
 * @example
 *
 * _.toString(null);
 * // => ''
 *
 * _.toString(-0);
 * // => '-0'
 *
 * _.toString([1, 2, 3]);
 * // => '1,2,3'
 */
function toString(value) {
  return value == null ? '' : baseToString(value);
}

/**
 * Converts `value` to a property path array.
 *
 * @static
 * @memberOf _
 * @since 4.0.0
 * @category Util
 * @param {*} value The value to convert.
 * @returns {Array} Returns the new property path array.
 * @example
 *
 * _.toPath('a.b.c');
 * // => ['a', 'b', 'c']
 *
 * _.toPath('a[0].b.c');
 * // => ['a', '0', 'b', 'c']
 */
function toPath(value) {
  if (isArray(value)) {
    return arrayMap(value, toKey);
  }
  return isSymbol(value) ? [value] : copyArray(stringToPath(value));
}

var index$5 = toPath;

var index$6 = createCommonjsModule(function (module, exports) {
/**
 * lodash (Custom Build) <https://lodash.com/>
 * Build: `lodash modularize exports="npm" -o ./`
 * Copyright jQuery Foundation and other contributors <https://jquery.org/>
 * Released under MIT license <https://lodash.com/license>
 * Based on Underscore.js 1.8.3 <http://underscorejs.org/LICENSE>
 * Copyright Jeremy Ashkenas, DocumentCloud and Investigative Reporters & Editors
 */

/** Used as the size to enable large array optimizations. */
var LARGE_ARRAY_SIZE = 200;

/** Used to stand-in for `undefined` hash values. */
var HASH_UNDEFINED = '__lodash_hash_undefined__';

/** Used as references for various `Number` constants. */
var MAX_SAFE_INTEGER = 9007199254740991;

/** `Object#toString` result references. */
var argsTag = '[object Arguments]',
    arrayTag = '[object Array]',
    boolTag = '[object Boolean]',
    dateTag = '[object Date]',
    errorTag = '[object Error]',
    funcTag = '[object Function]',
    genTag = '[object GeneratorFunction]',
    mapTag = '[object Map]',
    numberTag = '[object Number]',
    objectTag = '[object Object]',
    promiseTag = '[object Promise]',
    regexpTag = '[object RegExp]',
    setTag = '[object Set]',
    stringTag = '[object String]',
    symbolTag = '[object Symbol]',
    weakMapTag = '[object WeakMap]';

var arrayBufferTag = '[object ArrayBuffer]',
    dataViewTag = '[object DataView]',
    float32Tag = '[object Float32Array]',
    float64Tag = '[object Float64Array]',
    int8Tag = '[object Int8Array]',
    int16Tag = '[object Int16Array]',
    int32Tag = '[object Int32Array]',
    uint8Tag = '[object Uint8Array]',
    uint8ClampedTag = '[object Uint8ClampedArray]',
    uint16Tag = '[object Uint16Array]',
    uint32Tag = '[object Uint32Array]';

/**
 * Used to match `RegExp`
 * [syntax characters](http://ecma-international.org/ecma-262/7.0/#sec-patterns).
 */
var reRegExpChar = /[\\^$.*+?()[\]{}|]/g;

/** Used to match `RegExp` flags from their coerced string values. */
var reFlags = /\w*$/;

/** Used to detect host constructors (Safari). */
var reIsHostCtor = /^\[object .+?Constructor\]$/;

/** Used to detect unsigned integer values. */
var reIsUint = /^(?:0|[1-9]\d*)$/;

/** Used to identify `toStringTag` values supported by `_.clone`. */
var cloneableTags = {};
cloneableTags[argsTag] = cloneableTags[arrayTag] =
cloneableTags[arrayBufferTag] = cloneableTags[dataViewTag] =
cloneableTags[boolTag] = cloneableTags[dateTag] =
cloneableTags[float32Tag] = cloneableTags[float64Tag] =
cloneableTags[int8Tag] = cloneableTags[int16Tag] =
cloneableTags[int32Tag] = cloneableTags[mapTag] =
cloneableTags[numberTag] = cloneableTags[objectTag] =
cloneableTags[regexpTag] = cloneableTags[setTag] =
cloneableTags[stringTag] = cloneableTags[symbolTag] =
cloneableTags[uint8Tag] = cloneableTags[uint8ClampedTag] =
cloneableTags[uint16Tag] = cloneableTags[uint32Tag] = true;
cloneableTags[errorTag] = cloneableTags[funcTag] =
cloneableTags[weakMapTag] = false;

/** Detect free variable `global` from Node.js. */
var freeGlobal = typeof commonjsGlobal == 'object' && commonjsGlobal && commonjsGlobal.Object === Object && commonjsGlobal;

/** Detect free variable `self`. */
var freeSelf = typeof self == 'object' && self && self.Object === Object && self;

/** Used as a reference to the global object. */
var root = freeGlobal || freeSelf || Function('return this')();

/** Detect free variable `exports`. */
var freeExports = 'object' == 'object' && exports && !exports.nodeType && exports;

/** Detect free variable `module`. */
var freeModule = freeExports && 'object' == 'object' && module && !module.nodeType && module;

/** Detect the popular CommonJS extension `module.exports`. */
var moduleExports = freeModule && freeModule.exports === freeExports;

/**
 * Adds the key-value `pair` to `map`.
 *
 * @private
 * @param {Object} map The map to modify.
 * @param {Array} pair The key-value pair to add.
 * @returns {Object} Returns `map`.
 */
function addMapEntry(map, pair) {
  // Don't return `map.set` because it's not chainable in IE 11.
  map.set(pair[0], pair[1]);
  return map;
}

/**
 * Adds `value` to `set`.
 *
 * @private
 * @param {Object} set The set to modify.
 * @param {*} value The value to add.
 * @returns {Object} Returns `set`.
 */
function addSetEntry(set, value) {
  // Don't return `set.add` because it's not chainable in IE 11.
  set.add(value);
  return set;
}

/**
 * A specialized version of `_.forEach` for arrays without support for
 * iteratee shorthands.
 *
 * @private
 * @param {Array} [array] The array to iterate over.
 * @param {Function} iteratee The function invoked per iteration.
 * @returns {Array} Returns `array`.
 */
function arrayEach(array, iteratee) {
  var index = -1,
      length = array ? array.length : 0;

  while (++index < length) {
    if (iteratee(array[index], index, array) === false) {
      break;
    }
  }
  return array;
}

/**
 * Appends the elements of `values` to `array`.
 *
 * @private
 * @param {Array} array The array to modify.
 * @param {Array} values The values to append.
 * @returns {Array} Returns `array`.
 */
function arrayPush(array, values) {
  var index = -1,
      length = values.length,
      offset = array.length;

  while (++index < length) {
    array[offset + index] = values[index];
  }
  return array;
}

/**
 * A specialized version of `_.reduce` for arrays without support for
 * iteratee shorthands.
 *
 * @private
 * @param {Array} [array] The array to iterate over.
 * @param {Function} iteratee The function invoked per iteration.
 * @param {*} [accumulator] The initial value.
 * @param {boolean} [initAccum] Specify using the first element of `array` as
 *  the initial value.
 * @returns {*} Returns the accumulated value.
 */
function arrayReduce(array, iteratee, accumulator, initAccum) {
  var index = -1,
      length = array ? array.length : 0;

  if (initAccum && length) {
    accumulator = array[++index];
  }
  while (++index < length) {
    accumulator = iteratee(accumulator, array[index], index, array);
  }
  return accumulator;
}

/**
 * The base implementation of `_.times` without support for iteratee shorthands
 * or max array length checks.
 *
 * @private
 * @param {number} n The number of times to invoke `iteratee`.
 * @param {Function} iteratee The function invoked per iteration.
 * @returns {Array} Returns the array of results.
 */
function baseTimes(n, iteratee) {
  var index = -1,
      result = Array(n);

  while (++index < n) {
    result[index] = iteratee(index);
  }
  return result;
}

/**
 * Gets the value at `key` of `object`.
 *
 * @private
 * @param {Object} [object] The object to query.
 * @param {string} key The key of the property to get.
 * @returns {*} Returns the property value.
 */
function getValue(object, key) {
  return object == null ? undefined : object[key];
}

/**
 * Checks if `value` is a host object in IE < 9.
 *
 * @private
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is a host object, else `false`.
 */
function isHostObject(value) {
  // Many host objects are `Object` objects that can coerce to strings
  // despite having improperly defined `toString` methods.
  var result = false;
  if (value != null && typeof value.toString != 'function') {
    try {
      result = !!(value + '');
    } catch (e) {}
  }
  return result;
}

/**
 * Converts `map` to its key-value pairs.
 *
 * @private
 * @param {Object} map The map to convert.
 * @returns {Array} Returns the key-value pairs.
 */
function mapToArray(map) {
  var index = -1,
      result = Array(map.size);

  map.forEach(function(value, key) {
    result[++index] = [key, value];
  });
  return result;
}

/**
 * Creates a unary function that invokes `func` with its argument transformed.
 *
 * @private
 * @param {Function} func The function to wrap.
 * @param {Function} transform The argument transform.
 * @returns {Function} Returns the new function.
 */
function overArg(func, transform) {
  return function(arg) {
    return func(transform(arg));
  };
}

/**
 * Converts `set` to an array of its values.
 *
 * @private
 * @param {Object} set The set to convert.
 * @returns {Array} Returns the values.
 */
function setToArray(set) {
  var index = -1,
      result = Array(set.size);

  set.forEach(function(value) {
    result[++index] = value;
  });
  return result;
}

/** Used for built-in method references. */
var arrayProto = Array.prototype,
    funcProto = Function.prototype,
    objectProto = Object.prototype;

/** Used to detect overreaching core-js shims. */
var coreJsData = root['__core-js_shared__'];

/** Used to detect methods masquerading as native. */
var maskSrcKey = (function() {
  var uid = /[^.]+$/.exec(coreJsData && coreJsData.keys && coreJsData.keys.IE_PROTO || '');
  return uid ? ('Symbol(src)_1.' + uid) : '';
}());

/** Used to resolve the decompiled source of functions. */
var funcToString = funcProto.toString;

/** Used to check objects for own properties. */
var hasOwnProperty = objectProto.hasOwnProperty;

/**
 * Used to resolve the
 * [`toStringTag`](http://ecma-international.org/ecma-262/7.0/#sec-object.prototype.tostring)
 * of values.
 */
var objectToString = objectProto.toString;

/** Used to detect if a method is native. */
var reIsNative = RegExp('^' +
  funcToString.call(hasOwnProperty).replace(reRegExpChar, '\\$&')
  .replace(/hasOwnProperty|(function).*?(?=\\\()| for .+?(?=\\\])/g, '$1.*?') + '$'
);

/** Built-in value references. */
var Buffer = moduleExports ? root.Buffer : undefined,
    Symbol = root.Symbol,
    Uint8Array = root.Uint8Array,
    getPrototype = overArg(Object.getPrototypeOf, Object),
    objectCreate = Object.create,
    propertyIsEnumerable = objectProto.propertyIsEnumerable,
    splice = arrayProto.splice;

/* Built-in method references for those with the same name as other `lodash` methods. */
var nativeGetSymbols = Object.getOwnPropertySymbols,
    nativeIsBuffer = Buffer ? Buffer.isBuffer : undefined,
    nativeKeys = overArg(Object.keys, Object);

/* Built-in method references that are verified to be native. */
var DataView = getNative(root, 'DataView'),
    Map = getNative(root, 'Map'),
    Promise = getNative(root, 'Promise'),
    Set = getNative(root, 'Set'),
    WeakMap = getNative(root, 'WeakMap'),
    nativeCreate = getNative(Object, 'create');

/** Used to detect maps, sets, and weakmaps. */
var dataViewCtorString = toSource(DataView),
    mapCtorString = toSource(Map),
    promiseCtorString = toSource(Promise),
    setCtorString = toSource(Set),
    weakMapCtorString = toSource(WeakMap);

/** Used to convert symbols to primitives and strings. */
var symbolProto = Symbol ? Symbol.prototype : undefined,
    symbolValueOf = symbolProto ? symbolProto.valueOf : undefined;

/**
 * Creates a hash object.
 *
 * @private
 * @constructor
 * @param {Array} [entries] The key-value pairs to cache.
 */
function Hash(entries) {
  var index = -1,
      length = entries ? entries.length : 0;

  this.clear();
  while (++index < length) {
    var entry = entries[index];
    this.set(entry[0], entry[1]);
  }
}

/**
 * Removes all key-value entries from the hash.
 *
 * @private
 * @name clear
 * @memberOf Hash
 */
function hashClear() {
  this.__data__ = nativeCreate ? nativeCreate(null) : {};
}

/**
 * Removes `key` and its value from the hash.
 *
 * @private
 * @name delete
 * @memberOf Hash
 * @param {Object} hash The hash to modify.
 * @param {string} key The key of the value to remove.
 * @returns {boolean} Returns `true` if the entry was removed, else `false`.
 */
function hashDelete(key) {
  return this.has(key) && delete this.__data__[key];
}

/**
 * Gets the hash value for `key`.
 *
 * @private
 * @name get
 * @memberOf Hash
 * @param {string} key The key of the value to get.
 * @returns {*} Returns the entry value.
 */
function hashGet(key) {
  var data = this.__data__;
  if (nativeCreate) {
    var result = data[key];
    return result === HASH_UNDEFINED ? undefined : result;
  }
  return hasOwnProperty.call(data, key) ? data[key] : undefined;
}

/**
 * Checks if a hash value for `key` exists.
 *
 * @private
 * @name has
 * @memberOf Hash
 * @param {string} key The key of the entry to check.
 * @returns {boolean} Returns `true` if an entry for `key` exists, else `false`.
 */
function hashHas(key) {
  var data = this.__data__;
  return nativeCreate ? data[key] !== undefined : hasOwnProperty.call(data, key);
}

/**
 * Sets the hash `key` to `value`.
 *
 * @private
 * @name set
 * @memberOf Hash
 * @param {string} key The key of the value to set.
 * @param {*} value The value to set.
 * @returns {Object} Returns the hash instance.
 */
function hashSet(key, value) {
  var data = this.__data__;
  data[key] = (nativeCreate && value === undefined) ? HASH_UNDEFINED : value;
  return this;
}

// Add methods to `Hash`.
Hash.prototype.clear = hashClear;
Hash.prototype['delete'] = hashDelete;
Hash.prototype.get = hashGet;
Hash.prototype.has = hashHas;
Hash.prototype.set = hashSet;

/**
 * Creates an list cache object.
 *
 * @private
 * @constructor
 * @param {Array} [entries] The key-value pairs to cache.
 */
function ListCache(entries) {
  var index = -1,
      length = entries ? entries.length : 0;

  this.clear();
  while (++index < length) {
    var entry = entries[index];
    this.set(entry[0], entry[1]);
  }
}

/**
 * Removes all key-value entries from the list cache.
 *
 * @private
 * @name clear
 * @memberOf ListCache
 */
function listCacheClear() {
  this.__data__ = [];
}

/**
 * Removes `key` and its value from the list cache.
 *
 * @private
 * @name delete
 * @memberOf ListCache
 * @param {string} key The key of the value to remove.
 * @returns {boolean} Returns `true` if the entry was removed, else `false`.
 */
function listCacheDelete(key) {
  var data = this.__data__,
      index = assocIndexOf(data, key);

  if (index < 0) {
    return false;
  }
  var lastIndex = data.length - 1;
  if (index == lastIndex) {
    data.pop();
  } else {
    splice.call(data, index, 1);
  }
  return true;
}

/**
 * Gets the list cache value for `key`.
 *
 * @private
 * @name get
 * @memberOf ListCache
 * @param {string} key The key of the value to get.
 * @returns {*} Returns the entry value.
 */
function listCacheGet(key) {
  var data = this.__data__,
      index = assocIndexOf(data, key);

  return index < 0 ? undefined : data[index][1];
}

/**
 * Checks if a list cache value for `key` exists.
 *
 * @private
 * @name has
 * @memberOf ListCache
 * @param {string} key The key of the entry to check.
 * @returns {boolean} Returns `true` if an entry for `key` exists, else `false`.
 */
function listCacheHas(key) {
  return assocIndexOf(this.__data__, key) > -1;
}

/**
 * Sets the list cache `key` to `value`.
 *
 * @private
 * @name set
 * @memberOf ListCache
 * @param {string} key The key of the value to set.
 * @param {*} value The value to set.
 * @returns {Object} Returns the list cache instance.
 */
function listCacheSet(key, value) {
  var data = this.__data__,
      index = assocIndexOf(data, key);

  if (index < 0) {
    data.push([key, value]);
  } else {
    data[index][1] = value;
  }
  return this;
}

// Add methods to `ListCache`.
ListCache.prototype.clear = listCacheClear;
ListCache.prototype['delete'] = listCacheDelete;
ListCache.prototype.get = listCacheGet;
ListCache.prototype.has = listCacheHas;
ListCache.prototype.set = listCacheSet;

/**
 * Creates a map cache object to store key-value pairs.
 *
 * @private
 * @constructor
 * @param {Array} [entries] The key-value pairs to cache.
 */
function MapCache(entries) {
  var index = -1,
      length = entries ? entries.length : 0;

  this.clear();
  while (++index < length) {
    var entry = entries[index];
    this.set(entry[0], entry[1]);
  }
}

/**
 * Removes all key-value entries from the map.
 *
 * @private
 * @name clear
 * @memberOf MapCache
 */
function mapCacheClear() {
  this.__data__ = {
    'hash': new Hash,
    'map': new (Map || ListCache),
    'string': new Hash
  };
}

/**
 * Removes `key` and its value from the map.
 *
 * @private
 * @name delete
 * @memberOf MapCache
 * @param {string} key The key of the value to remove.
 * @returns {boolean} Returns `true` if the entry was removed, else `false`.
 */
function mapCacheDelete(key) {
  return getMapData(this, key)['delete'](key);
}

/**
 * Gets the map value for `key`.
 *
 * @private
 * @name get
 * @memberOf MapCache
 * @param {string} key The key of the value to get.
 * @returns {*} Returns the entry value.
 */
function mapCacheGet(key) {
  return getMapData(this, key).get(key);
}

/**
 * Checks if a map value for `key` exists.
 *
 * @private
 * @name has
 * @memberOf MapCache
 * @param {string} key The key of the entry to check.
 * @returns {boolean} Returns `true` if an entry for `key` exists, else `false`.
 */
function mapCacheHas(key) {
  return getMapData(this, key).has(key);
}

/**
 * Sets the map `key` to `value`.
 *
 * @private
 * @name set
 * @memberOf MapCache
 * @param {string} key The key of the value to set.
 * @param {*} value The value to set.
 * @returns {Object} Returns the map cache instance.
 */
function mapCacheSet(key, value) {
  getMapData(this, key).set(key, value);
  return this;
}

// Add methods to `MapCache`.
MapCache.prototype.clear = mapCacheClear;
MapCache.prototype['delete'] = mapCacheDelete;
MapCache.prototype.get = mapCacheGet;
MapCache.prototype.has = mapCacheHas;
MapCache.prototype.set = mapCacheSet;

/**
 * Creates a stack cache object to store key-value pairs.
 *
 * @private
 * @constructor
 * @param {Array} [entries] The key-value pairs to cache.
 */
function Stack(entries) {
  this.__data__ = new ListCache(entries);
}

/**
 * Removes all key-value entries from the stack.
 *
 * @private
 * @name clear
 * @memberOf Stack
 */
function stackClear() {
  this.__data__ = new ListCache;
}

/**
 * Removes `key` and its value from the stack.
 *
 * @private
 * @name delete
 * @memberOf Stack
 * @param {string} key The key of the value to remove.
 * @returns {boolean} Returns `true` if the entry was removed, else `false`.
 */
function stackDelete(key) {
  return this.__data__['delete'](key);
}

/**
 * Gets the stack value for `key`.
 *
 * @private
 * @name get
 * @memberOf Stack
 * @param {string} key The key of the value to get.
 * @returns {*} Returns the entry value.
 */
function stackGet(key) {
  return this.__data__.get(key);
}

/**
 * Checks if a stack value for `key` exists.
 *
 * @private
 * @name has
 * @memberOf Stack
 * @param {string} key The key of the entry to check.
 * @returns {boolean} Returns `true` if an entry for `key` exists, else `false`.
 */
function stackHas(key) {
  return this.__data__.has(key);
}

/**
 * Sets the stack `key` to `value`.
 *
 * @private
 * @name set
 * @memberOf Stack
 * @param {string} key The key of the value to set.
 * @param {*} value The value to set.
 * @returns {Object} Returns the stack cache instance.
 */
function stackSet(key, value) {
  var cache = this.__data__;
  if (cache instanceof ListCache) {
    var pairs = cache.__data__;
    if (!Map || (pairs.length < LARGE_ARRAY_SIZE - 1)) {
      pairs.push([key, value]);
      return this;
    }
    cache = this.__data__ = new MapCache(pairs);
  }
  cache.set(key, value);
  return this;
}

// Add methods to `Stack`.
Stack.prototype.clear = stackClear;
Stack.prototype['delete'] = stackDelete;
Stack.prototype.get = stackGet;
Stack.prototype.has = stackHas;
Stack.prototype.set = stackSet;

/**
 * Creates an array of the enumerable property names of the array-like `value`.
 *
 * @private
 * @param {*} value The value to query.
 * @param {boolean} inherited Specify returning inherited property names.
 * @returns {Array} Returns the array of property names.
 */
function arrayLikeKeys(value, inherited) {
  // Safari 8.1 makes `arguments.callee` enumerable in strict mode.
  // Safari 9 makes `arguments.length` enumerable in strict mode.
  var result = (isArray(value) || isArguments(value))
    ? baseTimes(value.length, String)
    : [];

  var length = result.length,
      skipIndexes = !!length;

  for (var key in value) {
    if ((inherited || hasOwnProperty.call(value, key)) &&
        !(skipIndexes && (key == 'length' || isIndex(key, length)))) {
      result.push(key);
    }
  }
  return result;
}

/**
 * Assigns `value` to `key` of `object` if the existing value is not equivalent
 * using [`SameValueZero`](http://ecma-international.org/ecma-262/7.0/#sec-samevaluezero)
 * for equality comparisons.
 *
 * @private
 * @param {Object} object The object to modify.
 * @param {string} key The key of the property to assign.
 * @param {*} value The value to assign.
 */
function assignValue(object, key, value) {
  var objValue = object[key];
  if (!(hasOwnProperty.call(object, key) && eq(objValue, value)) ||
      (value === undefined && !(key in object))) {
    object[key] = value;
  }
}

/**
 * Gets the index at which the `key` is found in `array` of key-value pairs.
 *
 * @private
 * @param {Array} array The array to inspect.
 * @param {*} key The key to search for.
 * @returns {number} Returns the index of the matched value, else `-1`.
 */
function assocIndexOf(array, key) {
  var length = array.length;
  while (length--) {
    if (eq(array[length][0], key)) {
      return length;
    }
  }
  return -1;
}

/**
 * The base implementation of `_.assign` without support for multiple sources
 * or `customizer` functions.
 *
 * @private
 * @param {Object} object The destination object.
 * @param {Object} source The source object.
 * @returns {Object} Returns `object`.
 */
function baseAssign(object, source) {
  return object && copyObject(source, keys(source), object);
}

/**
 * The base implementation of `_.clone` and `_.cloneDeep` which tracks
 * traversed objects.
 *
 * @private
 * @param {*} value The value to clone.
 * @param {boolean} [isDeep] Specify a deep clone.
 * @param {boolean} [isFull] Specify a clone including symbols.
 * @param {Function} [customizer] The function to customize cloning.
 * @param {string} [key] The key of `value`.
 * @param {Object} [object] The parent object of `value`.
 * @param {Object} [stack] Tracks traversed objects and their clone counterparts.
 * @returns {*} Returns the cloned value.
 */
function baseClone(value, isDeep, isFull, customizer, key, object, stack) {
  var result;
  if (customizer) {
    result = object ? customizer(value, key, object, stack) : customizer(value);
  }
  if (result !== undefined) {
    return result;
  }
  if (!isObject(value)) {
    return value;
  }
  var isArr = isArray(value);
  if (isArr) {
    result = initCloneArray(value);
    if (!isDeep) {
      return copyArray(value, result);
    }
  } else {
    var tag = getTag(value),
        isFunc = tag == funcTag || tag == genTag;

    if (isBuffer(value)) {
      return cloneBuffer(value, isDeep);
    }
    if (tag == objectTag || tag == argsTag || (isFunc && !object)) {
      if (isHostObject(value)) {
        return object ? value : {};
      }
      result = initCloneObject(isFunc ? {} : value);
      if (!isDeep) {
        return copySymbols(value, baseAssign(result, value));
      }
    } else {
      if (!cloneableTags[tag]) {
        return object ? value : {};
      }
      result = initCloneByTag(value, tag, baseClone, isDeep);
    }
  }
  // Check for circular references and return its corresponding clone.
  stack || (stack = new Stack);
  var stacked = stack.get(value);
  if (stacked) {
    return stacked;
  }
  stack.set(value, result);

  if (!isArr) {
    var props = isFull ? getAllKeys(value) : keys(value);
  }
  arrayEach(props || value, function(subValue, key) {
    if (props) {
      key = subValue;
      subValue = value[key];
    }
    // Recursively populate clone (susceptible to call stack limits).
    assignValue(result, key, baseClone(subValue, isDeep, isFull, customizer, key, value, stack));
  });
  return result;
}

/**
 * The base implementation of `_.create` without support for assigning
 * properties to the created object.
 *
 * @private
 * @param {Object} prototype The object to inherit from.
 * @returns {Object} Returns the new object.
 */
function baseCreate(proto) {
  return isObject(proto) ? objectCreate(proto) : {};
}

/**
 * The base implementation of `getAllKeys` and `getAllKeysIn` which uses
 * `keysFunc` and `symbolsFunc` to get the enumerable property names and
 * symbols of `object`.
 *
 * @private
 * @param {Object} object The object to query.
 * @param {Function} keysFunc The function to get the keys of `object`.
 * @param {Function} symbolsFunc The function to get the symbols of `object`.
 * @returns {Array} Returns the array of property names and symbols.
 */
function baseGetAllKeys(object, keysFunc, symbolsFunc) {
  var result = keysFunc(object);
  return isArray(object) ? result : arrayPush(result, symbolsFunc(object));
}

/**
 * The base implementation of `getTag`.
 *
 * @private
 * @param {*} value The value to query.
 * @returns {string} Returns the `toStringTag`.
 */
function baseGetTag(value) {
  return objectToString.call(value);
}

/**
 * The base implementation of `_.isNative` without bad shim checks.
 *
 * @private
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is a native function,
 *  else `false`.
 */
function baseIsNative(value) {
  if (!isObject(value) || isMasked(value)) {
    return false;
  }
  var pattern = (isFunction(value) || isHostObject(value)) ? reIsNative : reIsHostCtor;
  return pattern.test(toSource(value));
}

/**
 * The base implementation of `_.keys` which doesn't treat sparse arrays as dense.
 *
 * @private
 * @param {Object} object The object to query.
 * @returns {Array} Returns the array of property names.
 */
function baseKeys(object) {
  if (!isPrototype(object)) {
    return nativeKeys(object);
  }
  var result = [];
  for (var key in Object(object)) {
    if (hasOwnProperty.call(object, key) && key != 'constructor') {
      result.push(key);
    }
  }
  return result;
}

/**
 * Creates a clone of  `buffer`.
 *
 * @private
 * @param {Buffer} buffer The buffer to clone.
 * @param {boolean} [isDeep] Specify a deep clone.
 * @returns {Buffer} Returns the cloned buffer.
 */
function cloneBuffer(buffer, isDeep) {
  if (isDeep) {
    return buffer.slice();
  }
  var result = new buffer.constructor(buffer.length);
  buffer.copy(result);
  return result;
}

/**
 * Creates a clone of `arrayBuffer`.
 *
 * @private
 * @param {ArrayBuffer} arrayBuffer The array buffer to clone.
 * @returns {ArrayBuffer} Returns the cloned array buffer.
 */
function cloneArrayBuffer(arrayBuffer) {
  var result = new arrayBuffer.constructor(arrayBuffer.byteLength);
  new Uint8Array(result).set(new Uint8Array(arrayBuffer));
  return result;
}

/**
 * Creates a clone of `dataView`.
 *
 * @private
 * @param {Object} dataView The data view to clone.
 * @param {boolean} [isDeep] Specify a deep clone.
 * @returns {Object} Returns the cloned data view.
 */
function cloneDataView(dataView, isDeep) {
  var buffer = isDeep ? cloneArrayBuffer(dataView.buffer) : dataView.buffer;
  return new dataView.constructor(buffer, dataView.byteOffset, dataView.byteLength);
}

/**
 * Creates a clone of `map`.
 *
 * @private
 * @param {Object} map The map to clone.
 * @param {Function} cloneFunc The function to clone values.
 * @param {boolean} [isDeep] Specify a deep clone.
 * @returns {Object} Returns the cloned map.
 */
function cloneMap(map, isDeep, cloneFunc) {
  var array = isDeep ? cloneFunc(mapToArray(map), true) : mapToArray(map);
  return arrayReduce(array, addMapEntry, new map.constructor);
}

/**
 * Creates a clone of `regexp`.
 *
 * @private
 * @param {Object} regexp The regexp to clone.
 * @returns {Object} Returns the cloned regexp.
 */
function cloneRegExp(regexp) {
  var result = new regexp.constructor(regexp.source, reFlags.exec(regexp));
  result.lastIndex = regexp.lastIndex;
  return result;
}

/**
 * Creates a clone of `set`.
 *
 * @private
 * @param {Object} set The set to clone.
 * @param {Function} cloneFunc The function to clone values.
 * @param {boolean} [isDeep] Specify a deep clone.
 * @returns {Object} Returns the cloned set.
 */
function cloneSet(set, isDeep, cloneFunc) {
  var array = isDeep ? cloneFunc(setToArray(set), true) : setToArray(set);
  return arrayReduce(array, addSetEntry, new set.constructor);
}

/**
 * Creates a clone of the `symbol` object.
 *
 * @private
 * @param {Object} symbol The symbol object to clone.
 * @returns {Object} Returns the cloned symbol object.
 */
function cloneSymbol(symbol) {
  return symbolValueOf ? Object(symbolValueOf.call(symbol)) : {};
}

/**
 * Creates a clone of `typedArray`.
 *
 * @private
 * @param {Object} typedArray The typed array to clone.
 * @param {boolean} [isDeep] Specify a deep clone.
 * @returns {Object} Returns the cloned typed array.
 */
function cloneTypedArray(typedArray, isDeep) {
  var buffer = isDeep ? cloneArrayBuffer(typedArray.buffer) : typedArray.buffer;
  return new typedArray.constructor(buffer, typedArray.byteOffset, typedArray.length);
}

/**
 * Copies the values of `source` to `array`.
 *
 * @private
 * @param {Array} source The array to copy values from.
 * @param {Array} [array=[]] The array to copy values to.
 * @returns {Array} Returns `array`.
 */
function copyArray(source, array) {
  var index = -1,
      length = source.length;

  array || (array = Array(length));
  while (++index < length) {
    array[index] = source[index];
  }
  return array;
}

/**
 * Copies properties of `source` to `object`.
 *
 * @private
 * @param {Object} source The object to copy properties from.
 * @param {Array} props The property identifiers to copy.
 * @param {Object} [object={}] The object to copy properties to.
 * @param {Function} [customizer] The function to customize copied values.
 * @returns {Object} Returns `object`.
 */
function copyObject(source, props, object, customizer) {
  object || (object = {});

  var index = -1,
      length = props.length;

  while (++index < length) {
    var key = props[index];

    var newValue = customizer
      ? customizer(object[key], source[key], key, object, source)
      : undefined;

    assignValue(object, key, newValue === undefined ? source[key] : newValue);
  }
  return object;
}

/**
 * Copies own symbol properties of `source` to `object`.
 *
 * @private
 * @param {Object} source The object to copy symbols from.
 * @param {Object} [object={}] The object to copy symbols to.
 * @returns {Object} Returns `object`.
 */
function copySymbols(source, object) {
  return copyObject(source, getSymbols(source), object);
}

/**
 * Creates an array of own enumerable property names and symbols of `object`.
 *
 * @private
 * @param {Object} object The object to query.
 * @returns {Array} Returns the array of property names and symbols.
 */
function getAllKeys(object) {
  return baseGetAllKeys(object, keys, getSymbols);
}

/**
 * Gets the data for `map`.
 *
 * @private
 * @param {Object} map The map to query.
 * @param {string} key The reference key.
 * @returns {*} Returns the map data.
 */
function getMapData(map, key) {
  var data = map.__data__;
  return isKeyable(key)
    ? data[typeof key == 'string' ? 'string' : 'hash']
    : data.map;
}

/**
 * Gets the native function at `key` of `object`.
 *
 * @private
 * @param {Object} object The object to query.
 * @param {string} key The key of the method to get.
 * @returns {*} Returns the function if it's native, else `undefined`.
 */
function getNative(object, key) {
  var value = getValue(object, key);
  return baseIsNative(value) ? value : undefined;
}

/**
 * Creates an array of the own enumerable symbol properties of `object`.
 *
 * @private
 * @param {Object} object The object to query.
 * @returns {Array} Returns the array of symbols.
 */
var getSymbols = nativeGetSymbols ? overArg(nativeGetSymbols, Object) : stubArray;

/**
 * Gets the `toStringTag` of `value`.
 *
 * @private
 * @param {*} value The value to query.
 * @returns {string} Returns the `toStringTag`.
 */
var getTag = baseGetTag;

// Fallback for data views, maps, sets, and weak maps in IE 11,
// for data views in Edge < 14, and promises in Node.js.
if ((DataView && getTag(new DataView(new ArrayBuffer(1))) != dataViewTag) ||
    (Map && getTag(new Map) != mapTag) ||
    (Promise && getTag(Promise.resolve()) != promiseTag) ||
    (Set && getTag(new Set) != setTag) ||
    (WeakMap && getTag(new WeakMap) != weakMapTag)) {
  getTag = function(value) {
    var result = objectToString.call(value),
        Ctor = result == objectTag ? value.constructor : undefined,
        ctorString = Ctor ? toSource(Ctor) : undefined;

    if (ctorString) {
      switch (ctorString) {
        case dataViewCtorString: return dataViewTag;
        case mapCtorString: return mapTag;
        case promiseCtorString: return promiseTag;
        case setCtorString: return setTag;
        case weakMapCtorString: return weakMapTag;
      }
    }
    return result;
  };
}

/**
 * Initializes an array clone.
 *
 * @private
 * @param {Array} array The array to clone.
 * @returns {Array} Returns the initialized clone.
 */
function initCloneArray(array) {
  var length = array.length,
      result = array.constructor(length);

  // Add properties assigned by `RegExp#exec`.
  if (length && typeof array[0] == 'string' && hasOwnProperty.call(array, 'index')) {
    result.index = array.index;
    result.input = array.input;
  }
  return result;
}

/**
 * Initializes an object clone.
 *
 * @private
 * @param {Object} object The object to clone.
 * @returns {Object} Returns the initialized clone.
 */
function initCloneObject(object) {
  return (typeof object.constructor == 'function' && !isPrototype(object))
    ? baseCreate(getPrototype(object))
    : {};
}

/**
 * Initializes an object clone based on its `toStringTag`.
 *
 * **Note:** This function only supports cloning values with tags of
 * `Boolean`, `Date`, `Error`, `Number`, `RegExp`, or `String`.
 *
 * @private
 * @param {Object} object The object to clone.
 * @param {string} tag The `toStringTag` of the object to clone.
 * @param {Function} cloneFunc The function to clone values.
 * @param {boolean} [isDeep] Specify a deep clone.
 * @returns {Object} Returns the initialized clone.
 */
function initCloneByTag(object, tag, cloneFunc, isDeep) {
  var Ctor = object.constructor;
  switch (tag) {
    case arrayBufferTag:
      return cloneArrayBuffer(object);

    case boolTag:
    case dateTag:
      return new Ctor(+object);

    case dataViewTag:
      return cloneDataView(object, isDeep);

    case float32Tag: case float64Tag:
    case int8Tag: case int16Tag: case int32Tag:
    case uint8Tag: case uint8ClampedTag: case uint16Tag: case uint32Tag:
      return cloneTypedArray(object, isDeep);

    case mapTag:
      return cloneMap(object, isDeep, cloneFunc);

    case numberTag:
    case stringTag:
      return new Ctor(object);

    case regexpTag:
      return cloneRegExp(object);

    case setTag:
      return cloneSet(object, isDeep, cloneFunc);

    case symbolTag:
      return cloneSymbol(object);
  }
}

/**
 * Checks if `value` is a valid array-like index.
 *
 * @private
 * @param {*} value The value to check.
 * @param {number} [length=MAX_SAFE_INTEGER] The upper bounds of a valid index.
 * @returns {boolean} Returns `true` if `value` is a valid index, else `false`.
 */
function isIndex(value, length) {
  length = length == null ? MAX_SAFE_INTEGER : length;
  return !!length &&
    (typeof value == 'number' || reIsUint.test(value)) &&
    (value > -1 && value % 1 == 0 && value < length);
}

/**
 * Checks if `value` is suitable for use as unique object key.
 *
 * @private
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is suitable, else `false`.
 */
function isKeyable(value) {
  var type = typeof value;
  return (type == 'string' || type == 'number' || type == 'symbol' || type == 'boolean')
    ? (value !== '__proto__')
    : (value === null);
}

/**
 * Checks if `func` has its source masked.
 *
 * @private
 * @param {Function} func The function to check.
 * @returns {boolean} Returns `true` if `func` is masked, else `false`.
 */
function isMasked(func) {
  return !!maskSrcKey && (maskSrcKey in func);
}

/**
 * Checks if `value` is likely a prototype object.
 *
 * @private
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is a prototype, else `false`.
 */
function isPrototype(value) {
  var Ctor = value && value.constructor,
      proto = (typeof Ctor == 'function' && Ctor.prototype) || objectProto;

  return value === proto;
}

/**
 * Converts `func` to its source code.
 *
 * @private
 * @param {Function} func The function to process.
 * @returns {string} Returns the source code.
 */
function toSource(func) {
  if (func != null) {
    try {
      return funcToString.call(func);
    } catch (e) {}
    try {
      return (func + '');
    } catch (e) {}
  }
  return '';
}

/**
 * This method is like `_.clone` except that it recursively clones `value`.
 *
 * @static
 * @memberOf _
 * @since 1.0.0
 * @category Lang
 * @param {*} value The value to recursively clone.
 * @returns {*} Returns the deep cloned value.
 * @see _.clone
 * @example
 *
 * var objects = [{ 'a': 1 }, { 'b': 2 }];
 *
 * var deep = _.cloneDeep(objects);
 * console.log(deep[0] === objects[0]);
 * // => false
 */
function cloneDeep(value) {
  return baseClone(value, true, true);
}

/**
 * Performs a
 * [`SameValueZero`](http://ecma-international.org/ecma-262/7.0/#sec-samevaluezero)
 * comparison between two values to determine if they are equivalent.
 *
 * @static
 * @memberOf _
 * @since 4.0.0
 * @category Lang
 * @param {*} value The value to compare.
 * @param {*} other The other value to compare.
 * @returns {boolean} Returns `true` if the values are equivalent, else `false`.
 * @example
 *
 * var object = { 'a': 1 };
 * var other = { 'a': 1 };
 *
 * _.eq(object, object);
 * // => true
 *
 * _.eq(object, other);
 * // => false
 *
 * _.eq('a', 'a');
 * // => true
 *
 * _.eq('a', Object('a'));
 * // => false
 *
 * _.eq(NaN, NaN);
 * // => true
 */
function eq(value, other) {
  return value === other || (value !== value && other !== other);
}

/**
 * Checks if `value` is likely an `arguments` object.
 *
 * @static
 * @memberOf _
 * @since 0.1.0
 * @category Lang
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is an `arguments` object,
 *  else `false`.
 * @example
 *
 * _.isArguments(function() { return arguments; }());
 * // => true
 *
 * _.isArguments([1, 2, 3]);
 * // => false
 */
function isArguments(value) {
  // Safari 8.1 makes `arguments.callee` enumerable in strict mode.
  return isArrayLikeObject(value) && hasOwnProperty.call(value, 'callee') &&
    (!propertyIsEnumerable.call(value, 'callee') || objectToString.call(value) == argsTag);
}

/**
 * Checks if `value` is classified as an `Array` object.
 *
 * @static
 * @memberOf _
 * @since 0.1.0
 * @category Lang
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is an array, else `false`.
 * @example
 *
 * _.isArray([1, 2, 3]);
 * // => true
 *
 * _.isArray(document.body.children);
 * // => false
 *
 * _.isArray('abc');
 * // => false
 *
 * _.isArray(_.noop);
 * // => false
 */
var isArray = Array.isArray;

/**
 * Checks if `value` is array-like. A value is considered array-like if it's
 * not a function and has a `value.length` that's an integer greater than or
 * equal to `0` and less than or equal to `Number.MAX_SAFE_INTEGER`.
 *
 * @static
 * @memberOf _
 * @since 4.0.0
 * @category Lang
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is array-like, else `false`.
 * @example
 *
 * _.isArrayLike([1, 2, 3]);
 * // => true
 *
 * _.isArrayLike(document.body.children);
 * // => true
 *
 * _.isArrayLike('abc');
 * // => true
 *
 * _.isArrayLike(_.noop);
 * // => false
 */
function isArrayLike(value) {
  return value != null && isLength(value.length) && !isFunction(value);
}

/**
 * This method is like `_.isArrayLike` except that it also checks if `value`
 * is an object.
 *
 * @static
 * @memberOf _
 * @since 4.0.0
 * @category Lang
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is an array-like object,
 *  else `false`.
 * @example
 *
 * _.isArrayLikeObject([1, 2, 3]);
 * // => true
 *
 * _.isArrayLikeObject(document.body.children);
 * // => true
 *
 * _.isArrayLikeObject('abc');
 * // => false
 *
 * _.isArrayLikeObject(_.noop);
 * // => false
 */
function isArrayLikeObject(value) {
  return isObjectLike(value) && isArrayLike(value);
}

/**
 * Checks if `value` is a buffer.
 *
 * @static
 * @memberOf _
 * @since 4.3.0
 * @category Lang
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is a buffer, else `false`.
 * @example
 *
 * _.isBuffer(new Buffer(2));
 * // => true
 *
 * _.isBuffer(new Uint8Array(2));
 * // => false
 */
var isBuffer = nativeIsBuffer || stubFalse;

/**
 * Checks if `value` is classified as a `Function` object.
 *
 * @static
 * @memberOf _
 * @since 0.1.0
 * @category Lang
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is a function, else `false`.
 * @example
 *
 * _.isFunction(_);
 * // => true
 *
 * _.isFunction(/abc/);
 * // => false
 */
function isFunction(value) {
  // The use of `Object#toString` avoids issues with the `typeof` operator
  // in Safari 8-9 which returns 'object' for typed array and other constructors.
  var tag = isObject(value) ? objectToString.call(value) : '';
  return tag == funcTag || tag == genTag;
}

/**
 * Checks if `value` is a valid array-like length.
 *
 * **Note:** This method is loosely based on
 * [`ToLength`](http://ecma-international.org/ecma-262/7.0/#sec-tolength).
 *
 * @static
 * @memberOf _
 * @since 4.0.0
 * @category Lang
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is a valid length, else `false`.
 * @example
 *
 * _.isLength(3);
 * // => true
 *
 * _.isLength(Number.MIN_VALUE);
 * // => false
 *
 * _.isLength(Infinity);
 * // => false
 *
 * _.isLength('3');
 * // => false
 */
function isLength(value) {
  return typeof value == 'number' &&
    value > -1 && value % 1 == 0 && value <= MAX_SAFE_INTEGER;
}

/**
 * Checks if `value` is the
 * [language type](http://www.ecma-international.org/ecma-262/7.0/#sec-ecmascript-language-types)
 * of `Object`. (e.g. arrays, functions, objects, regexes, `new Number(0)`, and `new String('')`)
 *
 * @static
 * @memberOf _
 * @since 0.1.0
 * @category Lang
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is an object, else `false`.
 * @example
 *
 * _.isObject({});
 * // => true
 *
 * _.isObject([1, 2, 3]);
 * // => true
 *
 * _.isObject(_.noop);
 * // => true
 *
 * _.isObject(null);
 * // => false
 */
function isObject(value) {
  var type = typeof value;
  return !!value && (type == 'object' || type == 'function');
}

/**
 * Checks if `value` is object-like. A value is object-like if it's not `null`
 * and has a `typeof` result of "object".
 *
 * @static
 * @memberOf _
 * @since 4.0.0
 * @category Lang
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is object-like, else `false`.
 * @example
 *
 * _.isObjectLike({});
 * // => true
 *
 * _.isObjectLike([1, 2, 3]);
 * // => true
 *
 * _.isObjectLike(_.noop);
 * // => false
 *
 * _.isObjectLike(null);
 * // => false
 */
function isObjectLike(value) {
  return !!value && typeof value == 'object';
}

/**
 * Creates an array of the own enumerable property names of `object`.
 *
 * **Note:** Non-object values are coerced to objects. See the
 * [ES spec](http://ecma-international.org/ecma-262/7.0/#sec-object.keys)
 * for more details.
 *
 * @static
 * @since 0.1.0
 * @memberOf _
 * @category Object
 * @param {Object} object The object to query.
 * @returns {Array} Returns the array of property names.
 * @example
 *
 * function Foo() {
 *   this.a = 1;
 *   this.b = 2;
 * }
 *
 * Foo.prototype.c = 3;
 *
 * _.keys(new Foo);
 * // => ['a', 'b'] (iteration order is not guaranteed)
 *
 * _.keys('hi');
 * // => ['0', '1']
 */
function keys(object) {
  return isArrayLike(object) ? arrayLikeKeys(object) : baseKeys(object);
}

/**
 * This method returns a new empty array.
 *
 * @static
 * @memberOf _
 * @since 4.13.0
 * @category Util
 * @returns {Array} Returns the new empty array.
 * @example
 *
 * var arrays = _.times(2, _.stubArray);
 *
 * console.log(arrays);
 * // => [[], []]
 *
 * console.log(arrays[0] === arrays[1]);
 * // => false
 */
function stubArray() {
  return [];
}

/**
 * This method returns `false`.
 *
 * @static
 * @memberOf _
 * @since 4.13.0
 * @category Util
 * @returns {boolean} Returns `false`.
 * @example
 *
 * _.times(2, _.stubFalse);
 * // => [false, false]
 */
function stubFalse() {
  return false;
}

module.exports = cloneDeep;
});

function getIn(obj, key, def, p) {
    if (p === void 0) { p = 0; }
    var path = index$5(key);
    while (obj && p < path.length) {
        obj = obj[path[p++]];
    }
    return obj === undefined ? def : obj;
}
function setIn(obj, path, value) {
    var res = {};
    var resVal = res;
    var i = 0;
    var pathArray = index$5(path);
    for (; i < pathArray.length - 1; i++) {
        var currentPath = pathArray[i];
        var currentObj = obj[currentPath];
        if (resVal[currentPath]) {
            resVal = resVal[currentPath];
        }
        else if (currentObj) {
            resVal = resVal[currentPath] = index$6(currentObj);
        }
        else {
            var nextPath = pathArray[i + 1];
            resVal = resVal[currentPath] =
                isInteger(nextPath) && Number(nextPath) >= 0 ? [] : {};
        }
    }
    resVal[pathArray[i]] = value;
    return __assign({}, obj, res);
}
function setNestedObjectValues(object, value, visited, response) {
    if (visited === void 0) { visited = new WeakMap(); }
    if (response === void 0) { response = {}; }
    for (var _i = 0, _a = Object.keys(object); _i < _a.length; _i++) {
        var k = _a[_i];
        var val = object[k];
        if (isObject$1(val)) {
            if (!visited.get(val)) {
                visited.set(val, true);
                response[k] = Array.isArray(val) ? [] : {};
                setNestedObjectValues(val, value, visited, response[k]);
            }
        }
        else {
            response[k] = value;
        }
    }
    return response;
}
var isReactNative = typeof window !== 'undefined' &&
    window.navigator &&
    window.navigator.product &&
    window.navigator.product === 'ReactNative';
var isFunction$1 = function (obj) { return 'function' === typeof obj; };
var isObject$1 = function (obj) { return obj !== null && typeof obj === 'object'; };
var isInteger = function (obj) { return String(Math.floor(Number(obj))) === obj; };
var isEmptyChildren = function (children) {
    return __WEBPACK_IMPORTED_MODULE_0_react__["Children"].count(children) === 0;
};
function isPromise(value) {
    if (value !== null && typeof value === 'object') {
        return value && typeof value.then === 'function';
    }
    return false;
}

var Field = (function (_super) {
    __extends(Field, _super);
    function Field() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.handleChange = function (e) {
            var _a = _this.context.formik, handleChange = _a.handleChange, validateOnChange = _a.validateOnChange;
            handleChange(e);
            if (!!validateOnChange && !!_this.props.validate) {
                _this.runFieldValidations(e.target.value);
            }
        };
        _this.handleBlur = function (e) {
            var _a = _this.context.formik, handleBlur = _a.handleBlur, validateOnBlur = _a.validateOnBlur;
            handleBlur(e);
            if (validateOnBlur && _this.props.validate) {
                _this.runFieldValidations(e.target.value);
            }
        };
        _this.runFieldValidations = function (value) {
            var setFieldError = _this.context.formik.setFieldError;
            var _a = _this.props, name = _a.name, validate = _a.validate;
            var maybePromise = validate(value);
            if (isPromise(maybePromise)) {
                maybePromise.then(function () { return setFieldError(name, undefined); }, function (error) { return setFieldError(name, error); });
            }
            else {
                setFieldError(name, maybePromise);
            }
        };
        return _this;
    }
    Field.prototype.componentWillMount = function () {
        var _a = this.props, render = _a.render, children = _a.children, component = _a.component;
        warning_1$2(!(component && render), 'You should not use <Field component> and <Field render> in the same <Field> component; <Field component> will be ignored');
        warning_1$2(!(this.props.component && children && isFunction$1(children)), 'You should not use <Field component> and <Field children> as a function in the same <Field> component; <Field component> will be ignored.');
        warning_1$2(!(render && children && !isEmptyChildren(children)), 'You should not use <Field render> and <Field children> in the same <Field> component; <Field children> will be ignored');
    };
    Field.prototype.render = function () {
        var _a = this.props, validate = _a.validate, name = _a.name, render = _a.render, children = _a.children, _b = _a.component, component = _b === void 0 ? 'input' : _b, props = __rest(_a, ["validate", "name", "render", "children", "component"]);
        var formik = this.context.formik;
        var field = {
            value: props.type === 'radio' || props.type === 'checkbox'
                ? props.value
                : getIn(formik.values, name),
            name: name,
            onChange: validate ? this.handleChange : formik.handleChange,
            onBlur: validate ? this.handleBlur : formik.handleBlur,
        };
        var bag = { field: field, form: formik };
        if (render) {
            return render(bag);
        }
        if (isFunction$1(children)) {
            return children(bag);
        }
        if (typeof component === 'string') {
            return Object(__WEBPACK_IMPORTED_MODULE_0_react__["createElement"])(component, __assign({}, field, props, { children: children }));
        }
        return Object(__WEBPACK_IMPORTED_MODULE_0_react__["createElement"])(component, __assign({}, bag, props, { children: children }));
    };
    Field.contextTypes = {
        formik: index_1,
    };
    Field.propTypes = {
        name: index_3.isRequired,
        component: index_2([index_3, index_5]),
        render: index_5,
        children: index_2([index_5, index_4]),
        validate: index_5,
    };
    return Field;
}(__WEBPACK_IMPORTED_MODULE_0_react__["Component"]));

var Form = function (props, context) { return (Object(__WEBPACK_IMPORTED_MODULE_0_react__["createElement"])("form", __assign({ onSubmit: context.formik.handleSubmit }, props))); };
Form.contextTypes = {
    formik: index_1,
};

var REACT_STATICS = {
    childContextTypes: true,
    contextTypes: true,
    defaultProps: true,
    displayName: true,
    getDefaultProps: true,
    mixins: true,
    propTypes: true,
    type: true,
};
var KNOWN_STATICS = {
    name: true,
    length: true,
    prototype: true,
    caller: true,
    callee: true,
    arguments: true,
    arity: true,
};
var getOwnPropertySymbols$1 = Object.getOwnPropertySymbols;
var propIsEnumerable$1 = Object.prototype.propertyIsEnumerable;
var getPrototypeOf = Object.getPrototypeOf;
var objectPrototype = getPrototypeOf && getPrototypeOf(Object);
var getOwnPropertyNames = Object.getOwnPropertyNames;
function hoistNonReactStatics(targetComponent, sourceComponent, blacklist) {
    if (typeof sourceComponent !== 'string') {
        if (objectPrototype) {
            var inheritedComponent = getPrototypeOf(sourceComponent);
            if (inheritedComponent && inheritedComponent !== objectPrototype) {
                hoistNonReactStatics(targetComponent, inheritedComponent, blacklist);
            }
        }
        var keys = getOwnPropertyNames(sourceComponent);
        if (getOwnPropertySymbols$1) {
            keys = keys.concat(getOwnPropertySymbols$1(sourceComponent));
        }
        for (var i = 0; i < keys.length; ++i) {
            var key = keys[i];
            if (!REACT_STATICS[key] &&
                !KNOWN_STATICS[key] &&
                (!blacklist || !blacklist[key])) {
                if (propIsEnumerable$1.call(sourceComponent, key) ||
                    typeof sourceComponent[key] === 'function') {
                    try {
                        targetComponent[key] = sourceComponent[key];
                    }
                    catch (e) { }
                }
            }
        }
        return targetComponent;
    }
    return targetComponent;
}

function withFormik(_a) {
    var _b = _a.mapPropsToValues, mapPropsToValues = _b === void 0 ? function (vanillaProps) {
        var val = {};
        for (var k in vanillaProps) {
            if (vanillaProps.hasOwnProperty(k) &&
                typeof vanillaProps[k] !== 'function') {
                val[k] = vanillaProps[k];
            }
        }
        return val;
    } : _b, config = __rest(_a, ["mapPropsToValues"]);
    return function createFormik(Component$$1) {
        var C = (function (_super) {
            __extends(C, _super);
            function C() {
                var _this = _super !== null && _super.apply(this, arguments) || this;
                _this.validate = function (values) {
                    return config.validate(values, _this.props);
                };
                _this.validationSchema = function () {
                    return isFunction$1(config.validationSchema)
                        ? config.validationSchema(_this.props)
                        : config.validationSchema;
                };
                _this.handleSubmit = function (values, actions) {
                    return config.handleSubmit(values, __assign({}, actions, { props: _this.props }));
                };
                _this.renderFormComponent = function (formikProps) {
                    return Object(__WEBPACK_IMPORTED_MODULE_0_react__["createElement"])(Component$$1, __assign({}, _this.props, formikProps));
                };
                return _this;
            }
            C.prototype.render = function () {
                return (Object(__WEBPACK_IMPORTED_MODULE_0_react__["createElement"])(Formik, __assign({}, this.props, config, { validate: config.validate && this.validate, validationSchema: config.validationSchema && this.validationSchema, initialValues: mapPropsToValues(this.props), onSubmit: this.handleSubmit, render: this.renderFormComponent })));
            };
            return C;
        }(__WEBPACK_IMPORTED_MODULE_0_react__["Component"]));
        return hoistNonReactStatics(C, Component$$1);
    };
}

var move = function (array, from, to) {
    var copy = (array || []).slice();
    var value = copy[from];
    copy.splice(from, 1);
    copy.splice(to, 0, value);
    return copy;
};
var swap = function (array, indexA, indexB) {
    var copy = (array || []).slice();
    var a = copy[indexA];
    copy[indexA] = copy[indexB];
    copy[indexB] = a;
    return copy;
};
var insert = function (array, index, value) {
    var copy = (array || []).slice();
    copy.splice(index, 0, value);
    return copy;
};
var FieldArray = (function (_super) {
    __extends(FieldArray, _super);
    function FieldArray(props) {
        var _this = _super.call(this, props) || this;
        _this.updateArrayField = function (fn, alterTouched, alterErrors) {
            var _a = _this.context.formik, setFormikState = _a.setFormikState, validateForm = _a.validateForm, values = _a.values, touched = _a.touched, errors = _a.errors;
            var _b = _this.props, name = _b.name, validateOnChange = _b.validateOnChange;
            setFormikState(function (prevState) { return (__assign({}, prevState, { values: setIn(prevState.values, name, fn(getIn(values, name))), errors: alterErrors
                    ? setIn(prevState.errors, name, fn(getIn(errors, name)))
                    : prevState.errors, touched: alterTouched
                    ? setIn(prevState.touched, name, fn(getIn(touched, name)))
                    : prevState.touched })); }, function () {
                if (validateOnChange) {
                    validateForm();
                }
            });
        };
        _this.push = function (value) {
            return _this.updateArrayField(function (array) { return (array || []).concat([value]); }, false, false);
        };
        _this.swap = function (indexA, indexB) {
            return _this.updateArrayField(function (array) { return swap(array, indexA, indexB); }, false, false);
        };
        _this.move = function (from, to) {
            return _this.updateArrayField(function (array) { return move(array, from, to); }, false, false);
        };
        _this.insert = function (index, value) {
            return _this.updateArrayField(function (array) { return insert(array, index, value); }, false, false);
        };
        _this.unshift = function (value) {
            var arr = [];
            _this.updateArrayField(function (array) {
                arr = array ? [value].concat(array) : [value];
                return arr;
            }, false, false);
            return arr.length;
        };
        _this.remove = _this.remove.bind(_this);
        _this.pop = _this.pop.bind(_this);
        return _this;
    }
    FieldArray.prototype.remove = function (index) {
        var result;
        this.updateArrayField(function (array) {
            var copy = array ? array.slice() : [];
            if (!result) {
                result = copy[index];
            }
            if (isFunction$1(copy.splice)) {
                copy.splice(index, 1);
            }
            return copy;
        }, true, true);
        return result;
    };
    FieldArray.prototype.pop = function () {
        var result;
        this.updateArrayField(function (array) {
            var tmp = array;
            if (!result) {
                result = tmp && tmp.pop && tmp.pop();
            }
            return tmp;
        }, true, true);
        return result;
    };
    FieldArray.prototype.render = function () {
        var arrayHelpers = {
            push: this.push,
            pop: this.pop,
            swap: this.swap,
            move: this.move,
            insert: this.insert,
            unshift: this.unshift,
            remove: this.remove,
        };
        var _a = this.props, component = _a.component, render = _a.render, children = _a.children, name = _a.name;
        var props = __assign({}, arrayHelpers, { form: this.context.formik, name: name });
        return component
            ? Object(__WEBPACK_IMPORTED_MODULE_0_react__["createElement"])(component, props)
            : render
                ? render(props)
                : children
                    ? typeof children === 'function'
                        ? children(props)
                        : !isEmptyChildren(children) ? __WEBPACK_IMPORTED_MODULE_0_react__["Children"].only(children) : null
                    : null;
    };
    FieldArray.defaultProps = {
        validateOnChange: true,
    };
    FieldArray.contextTypes = {
        formik: index_1,
    };
    return FieldArray;
}(__WEBPACK_IMPORTED_MODULE_0_react__["Component"]));

var Formik = (function (_super) {
    __extends(Formik, _super);
    function Formik(props) {
        var _this = _super.call(this, props) || this;
        _this.setErrors = function (errors) {
            _this.setState({ errors: errors });
        };
        _this.setTouched = function (touched) {
            _this.setState({ touched: touched }, function () {
                if (_this.props.validateOnBlur) {
                    _this.runValidations(_this.state.values);
                }
            });
        };
        _this.setValues = function (values) {
            _this.setState({ values: values }, function () {
                if (_this.props.validateOnChange) {
                    _this.runValidations(values);
                }
            });
        };
        _this.setStatus = function (status) {
            _this.setState({ status: status });
        };
        _this.setError = function (error) {
            if (false) {
                console.warn("Warning: Formik's setError(error) is deprecated and may be removed in future releases. Please use Formik's setStatus(status) instead. It works identically. For more info see https://github.com/jaredpalmer/formik#setstatus-status-any--void");
            }
            _this.setState({ error: error });
        };
        _this.setSubmitting = function (isSubmitting) {
            _this.setState({ isSubmitting: isSubmitting });
        };
        _this.runValidationSchema = function (values, onSuccess) {
            var validationSchema = _this.props.validationSchema;
            var schema = isFunction$1(validationSchema)
                ? validationSchema()
                : validationSchema;
            validateYupSchema(values, schema).then(function () {
                _this.setState({ errors: {} });
                if (onSuccess) {
                    onSuccess();
                }
            }, function (err) {
                return _this.setState({ errors: yupToFormErrors(err), isSubmitting: false });
            });
        };
        _this.runValidations = function (values) {
            if (values === void 0) { values = _this.state.values; }
            if (_this.props.validationSchema) {
                _this.runValidationSchema(values);
            }
            if (_this.props.validate) {
                var maybePromisedErrors = _this.props.validate(values);
                if (isPromise(maybePromisedErrors)) {
                    maybePromisedErrors.then(function () {
                        _this.setState({ errors: {} });
                    }, function (errors) { return _this.setState({ errors: errors, isSubmitting: false }); });
                }
                else {
                    _this.setErrors(maybePromisedErrors);
                }
            }
        };
        _this.handleChange = function (e) {
            if (isReactNative) {
                if (false) {
                    console.error("Warning: Formik's handleChange does not work with React Native. Use setFieldValue and within a callback instead. For more info see https://github.com/jaredpalmer/formik#react-native");
                }
                return;
            }
            e.persist();
            var _a = e.target, type = _a.type, name = _a.name, id = _a.id, value = _a.value, checked = _a.checked, outerHTML = _a.outerHTML;
            var field = name ? name : id;
            var parsed;
            var val = /number|range/.test(type)
                ? (parsed = parseFloat(value), Number.isNaN(parsed) ? '' : parsed)
                : /checkbox/.test(type) ? checked : value;
            if (!field && "production" !== 'production') {
                warnAboutMissingIdentifier({
                    htmlContent: outerHTML,
                    documentationAnchorLink: 'handlechange-e-reactchangeeventany--void',
                    handlerName: 'handleChange',
                });
            }
            _this.setState(function (prevState) { return (__assign({}, prevState, { values: setIn(prevState.values, field, val) })); });
            if (_this.props.validateOnChange) {
                _this.runValidations(setIn(_this.state.values, field, val));
            }
        };
        _this.setFieldValue = function (field, value, shouldValidate) {
            if (shouldValidate === void 0) { shouldValidate = true; }
            _this.setState(function (prevState) { return (__assign({}, prevState, { values: setIn(prevState.values, field, value) })); }, function () {
                if (_this.props.validateOnChange && shouldValidate) {
                    _this.runValidations(_this.state.values);
                }
            });
        };
        _this.handleSubmit = function (e) {
            e.preventDefault();
            _this.submitForm();
        };
        _this.submitForm = function () {
            _this.setState({
                touched: setNestedObjectValues(_this.state.values, true),
                isSubmitting: true,
            });
            if (_this.props.validate) {
                var maybePromisedErrors = _this.props.validate(_this.state.values) || {};
                if (isPromise(maybePromisedErrors)) {
                    maybePromisedErrors.then(function () {
                        _this.setState({ errors: {} });
                        _this.executeSubmit();
                    }, function (errors) { return _this.setState({ errors: errors, isSubmitting: false }); });
                    return;
                }
                else {
                    var isValid = Object.keys(maybePromisedErrors).length === 0;
                    _this.setState({
                        errors: maybePromisedErrors,
                        isSubmitting: isValid,
                    });
                    if (isValid) {
                        _this.executeSubmit();
                    }
                }
            }
            else if (_this.props.validationSchema) {
                _this.runValidationSchema(_this.state.values, _this.executeSubmit);
            }
            else {
                _this.executeSubmit();
            }
        };
        _this.executeSubmit = function () {
            _this.props.onSubmit(_this.state.values, _this.getFormikActions());
        };
        _this.handleBlur = function (e) {
            if (isReactNative) {
                if (false) {
                    console.error("Warning: Formik's handleBlur does not work with React Native. Use setFieldTouched(field, isTouched) within a callback instead. For more info see https://github.com/jaredpalmer/formik#setfieldtouched-field-string-istouched-boolean--void");
                }
                return;
            }
            e.persist();
            var _a = e.target, name = _a.name, id = _a.id, outerHTML = _a.outerHTML;
            var field = name ? name : id;
            if (!field && "production" !== 'production') {
                warnAboutMissingIdentifier({
                    htmlContent: outerHTML,
                    documentationAnchorLink: 'handleblur-e-any--void',
                    handlerName: 'handleBlur',
                });
            }
            _this.setState(function (prevState) { return ({
                touched: setIn(prevState.touched, field, true),
            }); });
            if (_this.props.validateOnBlur) {
                _this.runValidations(_this.state.values);
            }
        };
        _this.setFieldTouched = function (field, touched, shouldValidate) {
            if (touched === void 0) { touched = true; }
            if (shouldValidate === void 0) { shouldValidate = true; }
            _this.setState(function (prevState) { return (__assign({}, prevState, { touched: setIn(prevState.touched, field, touched) })); }, function () {
                if (_this.props.validateOnBlur && shouldValidate) {
                    _this.runValidations(_this.state.values);
                }
            });
        };
        _this.setFieldError = function (field, message) {
            _this.setState(function (prevState) { return (__assign({}, prevState, { errors: setIn(prevState.errors, field, message) })); });
        };
        _this.resetForm = function (nextValues) {
            var values = nextValues ? nextValues : _this.props.initialValues;
            _this.initialValues = values;
            _this.setState({
                isSubmitting: false,
                errors: {},
                touched: {},
                error: undefined,
                status: undefined,
                values: values,
            });
        };
        _this.handleReset = function () {
            if (_this.props.onReset) {
                var maybePromisedOnReset = _this.props.onReset(_this.state.values, _this.getFormikActions());
                if (isPromise(maybePromisedOnReset)) {
                    maybePromisedOnReset.then(_this.resetForm);
                }
                else {
                    _this.resetForm();
                }
            }
            else {
                _this.resetForm();
            }
        };
        _this.setFormikState = function (s, callback) {
            return _this.setState(s, callback);
        };
        _this.getFormikActions = function () {
            return {
                resetForm: _this.resetForm,
                submitForm: _this.submitForm,
                validateForm: _this.runValidations,
                setError: _this.setError,
                setErrors: _this.setErrors,
                setFieldError: _this.setFieldError,
                setFieldTouched: _this.setFieldTouched,
                setFieldValue: _this.setFieldValue,
                setStatus: _this.setStatus,
                setSubmitting: _this.setSubmitting,
                setTouched: _this.setTouched,
                setValues: _this.setValues,
                setFormikState: _this.setFormikState,
            };
        };
        _this.getFormikComputedProps = function () {
            var isInitialValid = _this.props.isInitialValid;
            var dirty = !index$4(_this.initialValues, _this.state.values);
            return {
                dirty: dirty,
                isValid: dirty
                    ? _this.state.errors && Object.keys(_this.state.errors).length === 0
                    : isInitialValid !== false && isFunction$1(isInitialValid)
                        ? isInitialValid(_this.props)
                        : isInitialValid,
                initialValues: _this.initialValues,
            };
        };
        _this.getFormikBag = function () {
            return __assign({}, _this.state, _this.getFormikActions(), _this.getFormikComputedProps(), { handleBlur: _this.handleBlur, handleChange: _this.handleChange, handleReset: _this.handleReset, handleSubmit: _this.handleSubmit, validateOnChange: _this.props.validateOnChange, validateOnBlur: _this.props.validateOnBlur });
        };
        _this.state = {
            values: props.initialValues || {},
            errors: {},
            touched: {},
            isSubmitting: false,
        };
        _this.initialValues = props.initialValues || {};
        return _this;
    }
    Formik.prototype.getChildContext = function () {
        return {
            formik: this.getFormikBag(),
        };
    };
    Formik.prototype.componentWillReceiveProps = function (nextProps) {
        if (this.props.enableReinitialize &&
            !index$4(nextProps.initialValues, this.props.initialValues)) {
            this.initialValues = nextProps.initialValues;
            this.resetForm(nextProps.initialValues);
        }
    };
    Formik.prototype.componentWillMount = function () {
        warning_1$2(!(this.props.component && this.props.render), 'You should not use <Formik component> and <Formik render> in the same <Formik> component; <Formik render> will be ignored');
        warning_1$2(!(this.props.component &&
            this.props.children &&
            !isEmptyChildren(this.props.children)), 'You should not use <Formik component> and <Formik children> in the same <Formik> component; <Formik children> will be ignored');
        warning_1$2(!(this.props.render &&
            this.props.children &&
            !isEmptyChildren(this.props.children)), 'You should not use <Formik render> and <Formik children> in the same <Formik> component; <Formik children> will be ignored');
    };
    Formik.prototype.render = function () {
        var _a = this.props, component = _a.component, render = _a.render, children = _a.children;
        var props = this.getFormikBag();
        return component
            ? Object(__WEBPACK_IMPORTED_MODULE_0_react__["createElement"])(component, props)
            : render
                ? render(props)
                : children
                    ? typeof children === 'function'
                        ? children(props)
                        : !isEmptyChildren(children) ? __WEBPACK_IMPORTED_MODULE_0_react__["Children"].only(children) : null
                    : null;
    };
    Formik.defaultProps = {
        validateOnChange: true,
        validateOnBlur: true,
        isInitialValid: false,
        enableReinitialize: false,
    };
    Formik.propTypes = {
        validateOnChange: index_6,
        validateOnBlur: index_6,
        isInitialValid: index_2([index_5, index_6]),
        initialValues: index_1,
        onReset: index_5,
        onSubmit: index_5.isRequired,
        validationSchema: index_2([index_5, index_1]),
        validate: index_5,
        component: index_5,
        render: index_5,
        children: index_2([index_5, index_4]),
        enableReinitialize: index_6,
    };
    Formik.childContextTypes = {
        formik: index_1,
    };
    return Formik;
}(__WEBPACK_IMPORTED_MODULE_0_react__["Component"]));
function warnAboutMissingIdentifier(_a) {
    var htmlContent = _a.htmlContent, documentationAnchorLink = _a.documentationAnchorLink, handlerName = _a.handlerName;
    console.error("Warning: `" + handlerName + "` has triggered and you forgot to pass an `id` or `name` attribute to your input:\n\n    " + htmlContent + "\n\n    Formik cannot determine which value to update. For more info see https://github.com/jaredpalmer/formik#" + documentationAnchorLink + "\n  ");
}
function yupToFormErrors(yupError) {
    var errors = {};
    for (var _i = 0, _a = yupError.inner; _i < _a.length; _i++) {
        var err = _a[_i];
        if (!errors[err.path]) {
            errors = setIn(errors, err.path, err.message);
        }
    }
    return errors;
}
function validateYupSchema(data, schema, context) {
    if (context === void 0) { context = {}; }
    var validateData = {};
    for (var k in data) {
        if (data.hasOwnProperty(k)) {
            var key = String(k);
            validateData[key] =
                data[key] !== '' ? data[key] : undefined;
        }
    }
    return schema.validate(validateData, { abortEarly: false, context: context });
}


//# sourceMappingURL=formik.es6.js.map

/* WEBPACK VAR INJECTION */}.call(__webpack_exports__, __webpack_require__(35)))

/***/ }),
/* 1085 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__error_boundary__ = __webpack_require__(1086);
/* harmony reexport (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return __WEBPACK_IMPORTED_MODULE_0__error_boundary__["a"]; });


/***/ }),
/* 1086 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__(0);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_prop_types__ = __webpack_require__(1);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_prop_types___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_prop_types__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_scuid_x__ = __webpack_require__(14);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_scuid_x___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_scuid_x__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_styled_components__ = __webpack_require__(3);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__utilities_error_handling__ = __webpack_require__(187);
var _createClass=function(){function defineProperties(target,props){for(var i=0;i<props.length;i++){var descriptor=props[i];descriptor.enumerable=descriptor.enumerable||false;descriptor.configurable=true;if("value"in descriptor)descriptor.writable=true;Object.defineProperty(target,descriptor.key,descriptor);}}return function(Constructor,protoProps,staticProps){if(protoProps)defineProperties(Constructor.prototype,protoProps);if(staticProps)defineProperties(Constructor,staticProps);return Constructor;};}();var _templateObject=_taggedTemplateLiteral(['\n  max-width: 1240px;\n  margin: 0px auto;\n  padding: 20px;\n'],['\n  max-width: 1240px;\n  margin: 0px auto;\n  padding: 20px;\n']),_templateObject2=_taggedTemplateLiteral(['\n  margin-bottom: 0px;\n  header {\n    box-shadow: none;\n    padding: 0px;\n    margin-bottom: 0px;\n    &:focus {\n      outline: none;\n    }\n  }\n'],['\n  margin-bottom: 0px;\n  header {\n    box-shadow: none;\n    padding: 0px;\n    margin-bottom: 0px;\n    &:focus {\n      outline: none;\n    }\n  }\n']);function _classCallCheck(instance,Constructor){if(!(instance instanceof Constructor)){throw new TypeError("Cannot call a class as a function");}}function _possibleConstructorReturn(self,call){if(!self){throw new ReferenceError("this hasn't been initialised - super() hasn't been called");}return call&&(typeof call==="object"||typeof call==="function")?call:self;}function _inherits(subClass,superClass){if(typeof superClass!=="function"&&superClass!==null){throw new TypeError("Super expression must either be null or a function, not "+typeof superClass);}subClass.prototype=Object.create(superClass&&superClass.prototype,{constructor:{value:subClass,enumerable:false,writable:true,configurable:true}});if(superClass)Object.setPrototypeOf?Object.setPrototypeOf(subClass,superClass):subClass.__proto__=superClass;}function _taggedTemplateLiteral(strings,raw){return Object.freeze(Object.defineProperties(strings,{raw:{value:Object.freeze(raw)}}));}/**
 * Styled components
 */var Container=__WEBPACK_IMPORTED_MODULE_3_styled_components__["default"].div(_templateObject);var CustomAccordion=Object(__WEBPACK_IMPORTED_MODULE_3_styled_components__["default"])(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["AccordionMultiTitle"])(_templateObject2);var ErrorBoundary=function(_Component){_inherits(ErrorBoundary,_Component);function ErrorBoundary(){var _ref;var _temp,_this,_ret;_classCallCheck(this,ErrorBoundary);for(var _len=arguments.length,args=Array(_len),_key=0;_key<_len;_key++){args[_key]=arguments[_key];}return _ret=(_temp=(_this=_possibleConstructorReturn(this,(_ref=ErrorBoundary.__proto__||Object.getPrototypeOf(ErrorBoundary)).call.apply(_ref,[this].concat(args))),_this),_this.state={error:null,info:null},_temp),_possibleConstructorReturn(_this,_ret);}_createClass(ErrorBoundary,[{key:'componentDidCatch',value:function componentDidCatch(error,info){this.setState({error:error,info:info});// Log error to error reporting service
Object(__WEBPACK_IMPORTED_MODULE_4__utilities_error_handling__["b" /* errorLogger */])(error);}},{key:'render',value:function render(){var children=this.props.children;var _state=this.state,error=_state.error,info=_state.info;if(info&&"production"==='development'){console.log('---->',info);// eslint-disable-line no-console
}if(error){return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(Container,null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["NotificationBar"],{warning:true},__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(CustomAccordion,{title:'Something went wrong. Please refresh the page and try again.',subTitle:'',iconTitle:'Details'},__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["Paragraph"],null,error.message))));}return children;}}]);return ErrorBoundary;}(__WEBPACK_IMPORTED_MODULE_0_react__["Component"]);ErrorBoundary.propTypes={children:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.node.isRequired};/* harmony default export */ __webpack_exports__["a"] = (ErrorBoundary);

/***/ }),
/* 1087 */
/***/ (function(module, exports) {

/** Used for built-in method references. */
var objectProto = Object.prototype;

/** Used to check objects for own properties. */
var hasOwnProperty = objectProto.hasOwnProperty;

/**
 * The base implementation of `_.has` without support for deep paths.
 *
 * @private
 * @param {Object} [object] The object to query.
 * @param {Array|string} key The key to check.
 * @returns {boolean} Returns `true` if `key` exists, else `false`.
 */
function baseHas(object, key) {
  return object != null && hasOwnProperty.call(object, key);
}

module.exports = baseHas;


/***/ }),
/* 1088 */
/***/ (function(module, exports, __webpack_require__) {

var memoizeCapped = __webpack_require__(1089);

/** Used to match property names within property paths. */
var rePropName = /[^.[\]]+|\[(?:(-?\d+(?:\.\d+)?)|(["'])((?:(?!\2)[^\\]|\\.)*?)\2)\]|(?=(?:\.|\[\])(?:\.|\[\]|$))/g;

/** Used to match backslashes in property paths. */
var reEscapeChar = /\\(\\)?/g;

/**
 * Converts `string` to a property path array.
 *
 * @private
 * @param {string} string The string to convert.
 * @returns {Array} Returns the property path array.
 */
var stringToPath = memoizeCapped(function(string) {
  var result = [];
  if (string.charCodeAt(0) === 46 /* . */) {
    result.push('');
  }
  string.replace(rePropName, function(match, number, quote, subString) {
    result.push(quote ? subString.replace(reEscapeChar, '$1') : (number || match));
  });
  return result;
});

module.exports = stringToPath;


/***/ }),
/* 1089 */
/***/ (function(module, exports, __webpack_require__) {

var memoize = __webpack_require__(1090);

/** Used as the maximum memoize cache size. */
var MAX_MEMOIZE_SIZE = 500;

/**
 * A specialized version of `_.memoize` which clears the memoized function's
 * cache when it exceeds `MAX_MEMOIZE_SIZE`.
 *
 * @private
 * @param {Function} func The function to have its output memoized.
 * @returns {Function} Returns the new memoized function.
 */
function memoizeCapped(func) {
  var result = memoize(func, function(key) {
    if (cache.size === MAX_MEMOIZE_SIZE) {
      cache.clear();
    }
    return key;
  });

  var cache = result.cache;
  return result;
}

module.exports = memoizeCapped;


/***/ }),
/* 1090 */
/***/ (function(module, exports, __webpack_require__) {

var MapCache = __webpack_require__(312);

/** Error message constants. */
var FUNC_ERROR_TEXT = 'Expected a function';

/**
 * Creates a function that memoizes the result of `func`. If `resolver` is
 * provided, it determines the cache key for storing the result based on the
 * arguments provided to the memoized function. By default, the first argument
 * provided to the memoized function is used as the map cache key. The `func`
 * is invoked with the `this` binding of the memoized function.
 *
 * **Note:** The cache is exposed as the `cache` property on the memoized
 * function. Its creation may be customized by replacing the `_.memoize.Cache`
 * constructor with one whose instances implement the
 * [`Map`](http://ecma-international.org/ecma-262/7.0/#sec-properties-of-the-map-prototype-object)
 * method interface of `clear`, `delete`, `get`, `has`, and `set`.
 *
 * @static
 * @memberOf _
 * @since 0.1.0
 * @category Function
 * @param {Function} func The function to have its output memoized.
 * @param {Function} [resolver] The function to resolve the cache key.
 * @returns {Function} Returns the new memoized function.
 * @example
 *
 * var object = { 'a': 1, 'b': 2 };
 * var other = { 'c': 3, 'd': 4 };
 *
 * var values = _.memoize(_.values);
 * values(object);
 * // => [1, 2]
 *
 * values(other);
 * // => [3, 4]
 *
 * object.a = 2;
 * values(object);
 * // => [1, 2]
 *
 * // Modify the result cache.
 * values.cache.set(object, ['a', 'b']);
 * values(object);
 * // => ['a', 'b']
 *
 * // Replace `_.memoize.Cache`.
 * _.memoize.Cache = WeakMap;
 */
function memoize(func, resolver) {
  if (typeof func != 'function' || (resolver != null && typeof resolver != 'function')) {
    throw new TypeError(FUNC_ERROR_TEXT);
  }
  var memoized = function() {
    var args = arguments,
        key = resolver ? resolver.apply(this, args) : args[0],
        cache = memoized.cache;

    if (cache.has(key)) {
      return cache.get(key);
    }
    var result = func.apply(this, args);
    memoized.cache = cache.set(key, result) || cache;
    return result;
  };
  memoized.cache = new (memoize.Cache || MapCache);
  return memoized;
}

// Expose `MapCache`.
memoize.Cache = MapCache;

module.exports = memoize;


/***/ }),
/* 1091 */
/***/ (function(module, exports, __webpack_require__) {

var baseClone = __webpack_require__(313);

/** Used to compose bitmasks for cloning. */
var CLONE_DEEP_FLAG = 1,
    CLONE_SYMBOLS_FLAG = 4;

/**
 * This method is like `_.cloneWith` except that it recursively clones `value`.
 *
 * @static
 * @memberOf _
 * @since 4.0.0
 * @category Lang
 * @param {*} value The value to recursively clone.
 * @param {Function} [customizer] The function to customize cloning.
 * @returns {*} Returns the deep cloned value.
 * @see _.cloneWith
 * @example
 *
 * function customizer(value) {
 *   if (_.isElement(value)) {
 *     return value.cloneNode(true);
 *   }
 * }
 *
 * var el = _.cloneDeepWith(document.body, customizer);
 *
 * console.log(el === document.body);
 * // => false
 * console.log(el.nodeName);
 * // => 'BODY'
 * console.log(el.childNodes.length);
 * // => 20
 */
function cloneDeepWith(value, customizer) {
  customizer = typeof customizer == 'function' ? customizer : undefined;
  return baseClone(value, CLONE_DEEP_FLAG | CLONE_SYMBOLS_FLAG, customizer);
}

module.exports = cloneDeepWith;


/***/ }),
/* 1092 */
/***/ (function(module, exports, __webpack_require__) {

var Symbol = __webpack_require__(94),
    copyArray = __webpack_require__(321),
    getTag = __webpack_require__(121),
    isArrayLike = __webpack_require__(186),
    isString = __webpack_require__(1093),
    iteratorToArray = __webpack_require__(1094),
    mapToArray = __webpack_require__(1062),
    setToArray = __webpack_require__(1063),
    stringToArray = __webpack_require__(1064),
    values = __webpack_require__(1097);

/** `Object#toString` result references. */
var mapTag = '[object Map]',
    setTag = '[object Set]';

/** Built-in value references. */
var symIterator = Symbol ? Symbol.iterator : undefined;

/**
 * Converts `value` to an array.
 *
 * @static
 * @since 0.1.0
 * @memberOf _
 * @category Lang
 * @param {*} value The value to convert.
 * @returns {Array} Returns the converted array.
 * @example
 *
 * _.toArray({ 'a': 1, 'b': 2 });
 * // => [1, 2]
 *
 * _.toArray('abc');
 * // => ['a', 'b', 'c']
 *
 * _.toArray(1);
 * // => []
 *
 * _.toArray(null);
 * // => []
 */
function toArray(value) {
  if (!value) {
    return [];
  }
  if (isArrayLike(value)) {
    return isString(value) ? stringToArray(value) : copyArray(value);
  }
  if (symIterator && value[symIterator]) {
    return iteratorToArray(value[symIterator]());
  }
  var tag = getTag(value),
      func = tag == mapTag ? mapToArray : (tag == setTag ? setToArray : values);

  return func(value);
}

module.exports = toArray;


/***/ }),
/* 1093 */
/***/ (function(module, exports, __webpack_require__) {

var baseGetTag = __webpack_require__(81),
    isArray = __webpack_require__(92),
    isObjectLike = __webpack_require__(69);

/** `Object#toString` result references. */
var stringTag = '[object String]';

/**
 * Checks if `value` is classified as a `String` primitive or object.
 *
 * @static
 * @since 0.1.0
 * @memberOf _
 * @category Lang
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is a string, else `false`.
 * @example
 *
 * _.isString('abc');
 * // => true
 *
 * _.isString(1);
 * // => false
 */
function isString(value) {
  return typeof value == 'string' ||
    (!isArray(value) && isObjectLike(value) && baseGetTag(value) == stringTag);
}

module.exports = isString;


/***/ }),
/* 1094 */
/***/ (function(module, exports) {

/**
 * Converts `iterator` to an array.
 *
 * @private
 * @param {Object} iterator The iterator to convert.
 * @returns {Array} Returns the converted array.
 */
function iteratorToArray(iterator) {
  var data,
      result = [];

  while (!(data = iterator.next()).done) {
    result.push(data.value);
  }
  return result;
}

module.exports = iteratorToArray;


/***/ }),
/* 1095 */
/***/ (function(module, exports) {

/**
 * Converts an ASCII `string` to an array.
 *
 * @private
 * @param {string} string The string to convert.
 * @returns {Array} Returns the converted array.
 */
function asciiToArray(string) {
  return string.split('');
}

module.exports = asciiToArray;


/***/ }),
/* 1096 */
/***/ (function(module, exports) {

/** Used to compose unicode character classes. */
var rsAstralRange = '\\ud800-\\udfff',
    rsComboMarksRange = '\\u0300-\\u036f',
    reComboHalfMarksRange = '\\ufe20-\\ufe2f',
    rsComboSymbolsRange = '\\u20d0-\\u20ff',
    rsComboRange = rsComboMarksRange + reComboHalfMarksRange + rsComboSymbolsRange,
    rsVarRange = '\\ufe0e\\ufe0f';

/** Used to compose unicode capture groups. */
var rsAstral = '[' + rsAstralRange + ']',
    rsCombo = '[' + rsComboRange + ']',
    rsFitz = '\\ud83c[\\udffb-\\udfff]',
    rsModifier = '(?:' + rsCombo + '|' + rsFitz + ')',
    rsNonAstral = '[^' + rsAstralRange + ']',
    rsRegional = '(?:\\ud83c[\\udde6-\\uddff]){2}',
    rsSurrPair = '[\\ud800-\\udbff][\\udc00-\\udfff]',
    rsZWJ = '\\u200d';

/** Used to compose unicode regexes. */
var reOptMod = rsModifier + '?',
    rsOptVar = '[' + rsVarRange + ']?',
    rsOptJoin = '(?:' + rsZWJ + '(?:' + [rsNonAstral, rsRegional, rsSurrPair].join('|') + ')' + rsOptVar + reOptMod + ')*',
    rsSeq = rsOptVar + reOptMod + rsOptJoin,
    rsSymbol = '(?:' + [rsNonAstral + rsCombo + '?', rsCombo, rsRegional, rsSurrPair, rsAstral].join('|') + ')';

/** Used to match [string symbols](https://mathiasbynens.be/notes/javascript-unicode). */
var reUnicode = RegExp(rsFitz + '(?=' + rsFitz + ')|' + rsSymbol + rsSeq, 'g');

/**
 * Converts a Unicode `string` to an array.
 *
 * @private
 * @param {string} string The string to convert.
 * @returns {Array} Returns the converted array.
 */
function unicodeToArray(string) {
  return string.match(reUnicode) || [];
}

module.exports = unicodeToArray;


/***/ }),
/* 1097 */
/***/ (function(module, exports, __webpack_require__) {

var baseValues = __webpack_require__(1098),
    keys = __webpack_require__(120);

/**
 * Creates an array of the own enumerable string keyed property values of `object`.
 *
 * **Note:** Non-object values are coerced to objects.
 *
 * @static
 * @since 0.1.0
 * @memberOf _
 * @category Object
 * @param {Object} object The object to query.
 * @returns {Array} Returns the array of property values.
 * @example
 *
 * function Foo() {
 *   this.a = 1;
 *   this.b = 2;
 * }
 *
 * Foo.prototype.c = 3;
 *
 * _.values(new Foo);
 * // => [1, 2] (iteration order is not guaranteed)
 *
 * _.values('hi');
 * // => ['h', 'i']
 */
function values(object) {
  return object == null ? [] : baseValues(object, keys(object));
}

module.exports = values;


/***/ }),
/* 1098 */
/***/ (function(module, exports, __webpack_require__) {

var arrayMap = __webpack_require__(311);

/**
 * The base implementation of `_.values` and `_.valuesIn` which creates an
 * array of `object` property values corresponding to the property names
 * of `props`.
 *
 * @private
 * @param {Object} object The object to query.
 * @param {Array} props The property names to get values for.
 * @returns {Object} Returns the array of property values.
 */
function baseValues(object, props) {
  return arrayMap(props, function(key) {
    return object[key];
  });
}

module.exports = baseValues;


/***/ }),
/* 1099 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;

var _has = __webpack_require__(1044);

var _has2 = _interopRequireDefault(_has);

var _isSchema = __webpack_require__(1043);

var _isSchema2 = _interopRequireDefault(_isSchema);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function callOrConcat(schema) {
  if (typeof schema === 'function') return schema;

  return function (base) {
    return base.concat(schema);
  };
}

var Conditional = function () {
  function Conditional(refs, options) {
    _classCallCheck(this, Conditional);

    var is = options.is,
        then = options.then,
        otherwise = options.otherwise;


    this.refs = [].concat(refs);

    then = callOrConcat(then);
    otherwise = callOrConcat(otherwise);

    if (typeof options === 'function') this.fn = options;else {
      if (!(0, _has2.default)(options, 'is')) throw new TypeError('`is:` is required for `when()` conditions');

      if (!options.then && !options.otherwise) throw new TypeError('either `then:` or `otherwise:` is required for `when()` conditions');

      var isFn = typeof is === 'function' ? is : function () {
        for (var _len = arguments.length, values = Array(_len), _key = 0; _key < _len; _key++) {
          values[_key] = arguments[_key];
        }

        return values.every(function (value) {
          return value === is;
        });
      };

      this.fn = function () {
        for (var _len2 = arguments.length, values = Array(_len2), _key2 = 0; _key2 < _len2; _key2++) {
          values[_key2] = arguments[_key2];
        }

        var currentSchema = values.pop();
        var option = isFn.apply(undefined, values) ? then : otherwise;

        return option(currentSchema);
      };
    }
  }

  Conditional.prototype.getValue = function getValue(parent, context) {
    var values = this.refs.map(function (r) {
      return r.getValue(parent, context);
    });

    return values;
  };

  Conditional.prototype.resolve = function resolve(ctx, values) {
    var schema = this.fn.apply(ctx, values.concat(ctx));

    if (schema !== undefined && !(0, _isSchema2.default)(schema)) throw new TypeError('conditions must return a schema object');

    return schema || ctx;
  };

  return Conditional;
}();

exports.default = Conditional;
module.exports = exports['default'];

/***/ }),
/* 1100 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;
exports.default = merge;

var _has = __webpack_require__(1044);

var _has2 = _interopRequireDefault(_has);

var _isSchema = __webpack_require__(1043);

var _isSchema2 = _interopRequireDefault(_isSchema);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var isObject = function isObject(obj) {
  return Object.prototype.toString.call(obj) === '[object Object]';
};

function merge(target, source) {
  for (var key in source) {
    if ((0, _has2.default)(source, key)) {
      var targetVal = target[key],
          sourceVal = source[key];

      if (sourceVal === undefined) continue;

      if ((0, _isSchema2.default)(sourceVal)) {
        target[key] = (0, _isSchema2.default)(targetVal) ? targetVal.concat(sourceVal) : sourceVal;
      } else if (isObject(sourceVal)) {
        target[key] = isObject(targetVal) ? merge(targetVal, sourceVal) : sourceVal;
      } else if (Array.isArray(sourceVal)) {
        target[key] = Array.isArray(targetVal) ? targetVal.concat(sourceVal) : sourceVal;
      } else target[key] = source[key];
    }
  }return target;
}
module.exports = exports['default'];

/***/ }),
/* 1101 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;

var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };

exports.default = createValidation;

var _mapValues = __webpack_require__(1102);

var _mapValues2 = _interopRequireDefault(_mapValues);

var _ValidationError = __webpack_require__(1056);

var _ValidationError2 = _interopRequireDefault(_ValidationError);

var _Reference = __webpack_require__(1049);

var _Reference2 = _interopRequireDefault(_Reference);

var _synchronousPromise = __webpack_require__(1066);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _objectWithoutProperties(obj, keys) { var target = {}; for (var i in obj) { if (keys.indexOf(i) >= 0) continue; if (!Object.prototype.hasOwnProperty.call(obj, i)) continue; target[i] = obj[i]; } return target; }

var formatError = _ValidationError2.default.formatError;

var thenable = function thenable(p) {
  return p && typeof p.then === 'function' && typeof p.catch === 'function';
};

function runTest(testFn, ctx, value, sync) {
  var result = testFn.call(ctx, value);
  if (!sync) return Promise.resolve(result);

  if (thenable(result)) {
    throw new Error('Validation test of type: "' + ctx.type + '" returned a Promise during a synchronous validate. ' + 'This test will finish after the validate call has returned');
  }
  return _synchronousPromise.SynchronousPromise.resolve(result);
}

function resolveParams(oldParams, newParams, resolve) {
  return (0, _mapValues2.default)(_extends({}, oldParams, newParams), resolve);
}

function createErrorFactory(_ref) {
  var value = _ref.value,
      label = _ref.label,
      resolve = _ref.resolve,
      originalValue = _ref.originalValue,
      opts = _objectWithoutProperties(_ref, ['value', 'label', 'resolve', 'originalValue']);

  return function createError() {
    var _ref2 = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {},
        _ref2$path = _ref2.path,
        path = _ref2$path === undefined ? opts.path : _ref2$path,
        _ref2$message = _ref2.message,
        message = _ref2$message === undefined ? opts.message : _ref2$message,
        _ref2$type = _ref2.type,
        type = _ref2$type === undefined ? opts.name : _ref2$type,
        params = _ref2.params;

    params = _extends({
      path: path,
      value: value,
      originalValue: originalValue,
      label: label
    }, resolveParams(opts.params, params, resolve));

    return _extends(new _ValidationError2.default(formatError(message, params), value, path, type), { params: params });
  };
}

function createValidation(options) {
  var name = options.name,
      message = options.message,
      test = options.test,
      params = options.params;


  function validate(_ref3) {
    var value = _ref3.value,
        path = _ref3.path,
        label = _ref3.label,
        options = _ref3.options,
        originalValue = _ref3.originalValue,
        sync = _ref3.sync,
        rest = _objectWithoutProperties(_ref3, ['value', 'path', 'label', 'options', 'originalValue', 'sync']);

    var parent = options.parent;
    var resolve = function resolve(value) {
      return _Reference2.default.isRef(value) ? value.getValue(parent, options.context) : value;
    };

    var createError = createErrorFactory({
      message: message, path: path, value: value, originalValue: originalValue, params: params,
      label: label, resolve: resolve, name: name
    });

    var ctx = _extends({ path: path, parent: parent, type: name, createError: createError, resolve: resolve, options: options }, rest);

    return runTest(test, ctx, value, sync).then(function (validOrError) {
      if (_ValidationError2.default.isError(validOrError)) throw validOrError;else if (!validOrError) throw createError();
    });
  }

  validate.TEST_NAME = name;
  validate.TEST_FN = test;
  validate.TEST = options;

  return validate;
}

module.exports.createErrorFactory = createErrorFactory;
module.exports = exports['default'];

/***/ }),
/* 1102 */
/***/ (function(module, exports, __webpack_require__) {

var baseAssignValue = __webpack_require__(184),
    baseForOwn = __webpack_require__(1057),
    baseIteratee = __webpack_require__(1058);

/**
 * Creates an object with the same keys as `object` and values generated
 * by running each own enumerable string keyed property of `object` thru
 * `iteratee`. The iteratee is invoked with three arguments:
 * (value, key, object).
 *
 * @static
 * @memberOf _
 * @since 2.4.0
 * @category Object
 * @param {Object} object The object to iterate over.
 * @param {Function} [iteratee=_.identity] The function invoked per iteration.
 * @returns {Object} Returns the new mapped object.
 * @see _.mapKeys
 * @example
 *
 * var users = {
 *   'fred':    { 'user': 'fred',    'age': 40 },
 *   'pebbles': { 'user': 'pebbles', 'age': 1 }
 * };
 *
 * _.mapValues(users, function(o) { return o.age; });
 * // => { 'fred': 40, 'pebbles': 1 } (iteration order is not guaranteed)
 *
 * // The `_.property` iteratee shorthand.
 * _.mapValues(users, 'age');
 * // => { 'fred': 40, 'pebbles': 1 } (iteration order is not guaranteed)
 */
function mapValues(object, iteratee) {
  var result = {};
  iteratee = baseIteratee(iteratee, 3);

  baseForOwn(object, function(value, key, object) {
    baseAssignValue(result, key, iteratee(value, key, object));
  });
  return result;
}

module.exports = mapValues;


/***/ }),
/* 1103 */
/***/ (function(module, exports, __webpack_require__) {

var createBaseFor = __webpack_require__(1104);

/**
 * The base implementation of `baseForOwn` which iterates over `object`
 * properties returned by `keysFunc` and invokes `iteratee` for each property.
 * Iteratee functions may exit iteration early by explicitly returning `false`.
 *
 * @private
 * @param {Object} object The object to iterate over.
 * @param {Function} iteratee The function invoked per iteration.
 * @param {Function} keysFunc The function to get the keys of `object`.
 * @returns {Object} Returns `object`.
 */
var baseFor = createBaseFor();

module.exports = baseFor;


/***/ }),
/* 1104 */
/***/ (function(module, exports) {

/**
 * Creates a base function for methods like `_.forIn` and `_.forOwn`.
 *
 * @private
 * @param {boolean} [fromRight] Specify iterating from right to left.
 * @returns {Function} Returns the new base function.
 */
function createBaseFor(fromRight) {
  return function(object, iteratee, keysFunc) {
    var index = -1,
        iterable = Object(object),
        props = keysFunc(object),
        length = props.length;

    while (length--) {
      var key = props[fromRight ? length : ++index];
      if (iteratee(iterable[key], key, iterable) === false) {
        break;
      }
    }
    return object;
  };
}

module.exports = createBaseFor;


/***/ }),
/* 1105 */
/***/ (function(module, exports, __webpack_require__) {

var baseIsMatch = __webpack_require__(1106),
    getMatchData = __webpack_require__(1115),
    matchesStrictComparable = __webpack_require__(1069);

/**
 * The base implementation of `_.matches` which doesn't clone `source`.
 *
 * @private
 * @param {Object} source The object of property values to match.
 * @returns {Function} Returns the new spec function.
 */
function baseMatches(source) {
  var matchData = getMatchData(source);
  if (matchData.length == 1 && matchData[0][2]) {
    return matchesStrictComparable(matchData[0][0], matchData[0][1]);
  }
  return function(object) {
    return object === source || baseIsMatch(object, source, matchData);
  };
}

module.exports = baseMatches;


/***/ }),
/* 1106 */
/***/ (function(module, exports, __webpack_require__) {

var Stack = __webpack_require__(314),
    baseIsEqual = __webpack_require__(1060);

/** Used to compose bitmasks for value comparisons. */
var COMPARE_PARTIAL_FLAG = 1,
    COMPARE_UNORDERED_FLAG = 2;

/**
 * The base implementation of `_.isMatch` without support for iteratee shorthands.
 *
 * @private
 * @param {Object} object The object to inspect.
 * @param {Object} source The object of property values to match.
 * @param {Array} matchData The property names, values, and compare flags to match.
 * @param {Function} [customizer] The function to customize comparisons.
 * @returns {boolean} Returns `true` if `object` is a match, else `false`.
 */
function baseIsMatch(object, source, matchData, customizer) {
  var index = matchData.length,
      length = index,
      noCustomizer = !customizer;

  if (object == null) {
    return !length;
  }
  object = Object(object);
  while (index--) {
    var data = matchData[index];
    if ((noCustomizer && data[2])
          ? data[1] !== object[data[0]]
          : !(data[0] in object)
        ) {
      return false;
    }
  }
  while (++index < length) {
    data = matchData[index];
    var key = data[0],
        objValue = object[key],
        srcValue = data[1];

    if (noCustomizer && data[2]) {
      if (objValue === undefined && !(key in object)) {
        return false;
      }
    } else {
      var stack = new Stack;
      if (customizer) {
        var result = customizer(objValue, srcValue, key, object, source, stack);
      }
      if (!(result === undefined
            ? baseIsEqual(srcValue, objValue, COMPARE_PARTIAL_FLAG | COMPARE_UNORDERED_FLAG, customizer, stack)
            : result
          )) {
        return false;
      }
    }
  }
  return true;
}

module.exports = baseIsMatch;


/***/ }),
/* 1107 */
/***/ (function(module, exports, __webpack_require__) {

var Stack = __webpack_require__(314),
    equalArrays = __webpack_require__(1067),
    equalByTag = __webpack_require__(1113),
    equalObjects = __webpack_require__(1114),
    getTag = __webpack_require__(121),
    isArray = __webpack_require__(92),
    isBuffer = __webpack_require__(182),
    isTypedArray = __webpack_require__(310);

/** Used to compose bitmasks for value comparisons. */
var COMPARE_PARTIAL_FLAG = 1;

/** `Object#toString` result references. */
var argsTag = '[object Arguments]',
    arrayTag = '[object Array]',
    objectTag = '[object Object]';

/** Used for built-in method references. */
var objectProto = Object.prototype;

/** Used to check objects for own properties. */
var hasOwnProperty = objectProto.hasOwnProperty;

/**
 * A specialized version of `baseIsEqual` for arrays and objects which performs
 * deep comparisons and tracks traversed objects enabling objects with circular
 * references to be compared.
 *
 * @private
 * @param {Object} object The object to compare.
 * @param {Object} other The other object to compare.
 * @param {number} bitmask The bitmask flags. See `baseIsEqual` for more details.
 * @param {Function} customizer The function to customize comparisons.
 * @param {Function} equalFunc The function to determine equivalents of values.
 * @param {Object} [stack] Tracks traversed `object` and `other` objects.
 * @returns {boolean} Returns `true` if the objects are equivalent, else `false`.
 */
function baseIsEqualDeep(object, other, bitmask, customizer, equalFunc, stack) {
  var objIsArr = isArray(object),
      othIsArr = isArray(other),
      objTag = objIsArr ? arrayTag : getTag(object),
      othTag = othIsArr ? arrayTag : getTag(other);

  objTag = objTag == argsTag ? objectTag : objTag;
  othTag = othTag == argsTag ? objectTag : othTag;

  var objIsObj = objTag == objectTag,
      othIsObj = othTag == objectTag,
      isSameTag = objTag == othTag;

  if (isSameTag && isBuffer(object)) {
    if (!isBuffer(other)) {
      return false;
    }
    objIsArr = true;
    objIsObj = false;
  }
  if (isSameTag && !objIsObj) {
    stack || (stack = new Stack);
    return (objIsArr || isTypedArray(object))
      ? equalArrays(object, other, bitmask, customizer, equalFunc, stack)
      : equalByTag(object, other, objTag, bitmask, customizer, equalFunc, stack);
  }
  if (!(bitmask & COMPARE_PARTIAL_FLAG)) {
    var objIsWrapped = objIsObj && hasOwnProperty.call(object, '__wrapped__'),
        othIsWrapped = othIsObj && hasOwnProperty.call(other, '__wrapped__');

    if (objIsWrapped || othIsWrapped) {
      var objUnwrapped = objIsWrapped ? object.value() : object,
          othUnwrapped = othIsWrapped ? other.value() : other;

      stack || (stack = new Stack);
      return equalFunc(objUnwrapped, othUnwrapped, bitmask, customizer, stack);
    }
  }
  if (!isSameTag) {
    return false;
  }
  stack || (stack = new Stack);
  return equalObjects(object, other, bitmask, customizer, equalFunc, stack);
}

module.exports = baseIsEqualDeep;


/***/ }),
/* 1108 */
/***/ (function(module, exports, __webpack_require__) {

var MapCache = __webpack_require__(312),
    setCacheAdd = __webpack_require__(1109),
    setCacheHas = __webpack_require__(1110);

/**
 *
 * Creates an array cache object to store unique values.
 *
 * @private
 * @constructor
 * @param {Array} [values] The values to cache.
 */
function SetCache(values) {
  var index = -1,
      length = values == null ? 0 : values.length;

  this.__data__ = new MapCache;
  while (++index < length) {
    this.add(values[index]);
  }
}

// Add methods to `SetCache`.
SetCache.prototype.add = SetCache.prototype.push = setCacheAdd;
SetCache.prototype.has = setCacheHas;

module.exports = SetCache;


/***/ }),
/* 1109 */
/***/ (function(module, exports) {

/** Used to stand-in for `undefined` hash values. */
var HASH_UNDEFINED = '__lodash_hash_undefined__';

/**
 * Adds `value` to the array cache.
 *
 * @private
 * @name add
 * @memberOf SetCache
 * @alias push
 * @param {*} value The value to cache.
 * @returns {Object} Returns the cache instance.
 */
function setCacheAdd(value) {
  this.__data__.set(value, HASH_UNDEFINED);
  return this;
}

module.exports = setCacheAdd;


/***/ }),
/* 1110 */
/***/ (function(module, exports) {

/**
 * Checks if `value` is in the array cache.
 *
 * @private
 * @name has
 * @memberOf SetCache
 * @param {*} value The value to search for.
 * @returns {number} Returns `true` if `value` is found, else `false`.
 */
function setCacheHas(value) {
  return this.__data__.has(value);
}

module.exports = setCacheHas;


/***/ }),
/* 1111 */
/***/ (function(module, exports) {

/**
 * A specialized version of `_.some` for arrays without support for iteratee
 * shorthands.
 *
 * @private
 * @param {Array} [array] The array to iterate over.
 * @param {Function} predicate The function invoked per iteration.
 * @returns {boolean} Returns `true` if any element passes the predicate check,
 *  else `false`.
 */
function arraySome(array, predicate) {
  var index = -1,
      length = array == null ? 0 : array.length;

  while (++index < length) {
    if (predicate(array[index], index, array)) {
      return true;
    }
  }
  return false;
}

module.exports = arraySome;


/***/ }),
/* 1112 */
/***/ (function(module, exports) {

/**
 * Checks if a `cache` value for `key` exists.
 *
 * @private
 * @param {Object} cache The cache to query.
 * @param {string} key The key of the entry to check.
 * @returns {boolean} Returns `true` if an entry for `key` exists, else `false`.
 */
function cacheHas(cache, key) {
  return cache.has(key);
}

module.exports = cacheHas;


/***/ }),
/* 1113 */
/***/ (function(module, exports, __webpack_require__) {

var Symbol = __webpack_require__(94),
    Uint8Array = __webpack_require__(324),
    eq = __webpack_require__(190),
    equalArrays = __webpack_require__(1067),
    mapToArray = __webpack_require__(1062),
    setToArray = __webpack_require__(1063);

/** Used to compose bitmasks for value comparisons. */
var COMPARE_PARTIAL_FLAG = 1,
    COMPARE_UNORDERED_FLAG = 2;

/** `Object#toString` result references. */
var boolTag = '[object Boolean]',
    dateTag = '[object Date]',
    errorTag = '[object Error]',
    mapTag = '[object Map]',
    numberTag = '[object Number]',
    regexpTag = '[object RegExp]',
    setTag = '[object Set]',
    stringTag = '[object String]',
    symbolTag = '[object Symbol]';

var arrayBufferTag = '[object ArrayBuffer]',
    dataViewTag = '[object DataView]';

/** Used to convert symbols to primitives and strings. */
var symbolProto = Symbol ? Symbol.prototype : undefined,
    symbolValueOf = symbolProto ? symbolProto.valueOf : undefined;

/**
 * A specialized version of `baseIsEqualDeep` for comparing objects of
 * the same `toStringTag`.
 *
 * **Note:** This function only supports comparing values with tags of
 * `Boolean`, `Date`, `Error`, `Number`, `RegExp`, or `String`.
 *
 * @private
 * @param {Object} object The object to compare.
 * @param {Object} other The other object to compare.
 * @param {string} tag The `toStringTag` of the objects to compare.
 * @param {number} bitmask The bitmask flags. See `baseIsEqual` for more details.
 * @param {Function} customizer The function to customize comparisons.
 * @param {Function} equalFunc The function to determine equivalents of values.
 * @param {Object} stack Tracks traversed `object` and `other` objects.
 * @returns {boolean} Returns `true` if the objects are equivalent, else `false`.
 */
function equalByTag(object, other, tag, bitmask, customizer, equalFunc, stack) {
  switch (tag) {
    case dataViewTag:
      if ((object.byteLength != other.byteLength) ||
          (object.byteOffset != other.byteOffset)) {
        return false;
      }
      object = object.buffer;
      other = other.buffer;

    case arrayBufferTag:
      if ((object.byteLength != other.byteLength) ||
          !equalFunc(new Uint8Array(object), new Uint8Array(other))) {
        return false;
      }
      return true;

    case boolTag:
    case dateTag:
    case numberTag:
      // Coerce booleans to `1` or `0` and dates to milliseconds.
      // Invalid dates are coerced to `NaN`.
      return eq(+object, +other);

    case errorTag:
      return object.name == other.name && object.message == other.message;

    case regexpTag:
    case stringTag:
      // Coerce regexes to strings and treat strings, primitives and objects,
      // as equal. See http://www.ecma-international.org/ecma-262/7.0/#sec-regexp.prototype.tostring
      // for more details.
      return object == (other + '');

    case mapTag:
      var convert = mapToArray;

    case setTag:
      var isPartial = bitmask & COMPARE_PARTIAL_FLAG;
      convert || (convert = setToArray);

      if (object.size != other.size && !isPartial) {
        return false;
      }
      // Assume cyclic values are equal.
      var stacked = stack.get(object);
      if (stacked) {
        return stacked == other;
      }
      bitmask |= COMPARE_UNORDERED_FLAG;

      // Recursively compare objects (susceptible to call stack limits).
      stack.set(object, other);
      var result = equalArrays(convert(object), convert(other), bitmask, customizer, equalFunc, stack);
      stack['delete'](object);
      return result;

    case symbolTag:
      if (symbolValueOf) {
        return symbolValueOf.call(object) == symbolValueOf.call(other);
      }
  }
  return false;
}

module.exports = equalByTag;


/***/ }),
/* 1114 */
/***/ (function(module, exports, __webpack_require__) {

var getAllKeys = __webpack_require__(322);

/** Used to compose bitmasks for value comparisons. */
var COMPARE_PARTIAL_FLAG = 1;

/** Used for built-in method references. */
var objectProto = Object.prototype;

/** Used to check objects for own properties. */
var hasOwnProperty = objectProto.hasOwnProperty;

/**
 * A specialized version of `baseIsEqualDeep` for objects with support for
 * partial deep comparisons.
 *
 * @private
 * @param {Object} object The object to compare.
 * @param {Object} other The other object to compare.
 * @param {number} bitmask The bitmask flags. See `baseIsEqual` for more details.
 * @param {Function} customizer The function to customize comparisons.
 * @param {Function} equalFunc The function to determine equivalents of values.
 * @param {Object} stack Tracks traversed `object` and `other` objects.
 * @returns {boolean} Returns `true` if the objects are equivalent, else `false`.
 */
function equalObjects(object, other, bitmask, customizer, equalFunc, stack) {
  var isPartial = bitmask & COMPARE_PARTIAL_FLAG,
      objProps = getAllKeys(object),
      objLength = objProps.length,
      othProps = getAllKeys(other),
      othLength = othProps.length;

  if (objLength != othLength && !isPartial) {
    return false;
  }
  var index = objLength;
  while (index--) {
    var key = objProps[index];
    if (!(isPartial ? key in other : hasOwnProperty.call(other, key))) {
      return false;
    }
  }
  // Assume cyclic values are equal.
  var stacked = stack.get(object);
  if (stacked && stack.get(other)) {
    return stacked == other;
  }
  var result = true;
  stack.set(object, other);
  stack.set(other, object);

  var skipCtor = isPartial;
  while (++index < objLength) {
    key = objProps[index];
    var objValue = object[key],
        othValue = other[key];

    if (customizer) {
      var compared = isPartial
        ? customizer(othValue, objValue, key, other, object, stack)
        : customizer(objValue, othValue, key, object, other, stack);
    }
    // Recursively compare objects (susceptible to call stack limits).
    if (!(compared === undefined
          ? (objValue === othValue || equalFunc(objValue, othValue, bitmask, customizer, stack))
          : compared
        )) {
      result = false;
      break;
    }
    skipCtor || (skipCtor = key == 'constructor');
  }
  if (result && !skipCtor) {
    var objCtor = object.constructor,
        othCtor = other.constructor;

    // Non `Object` object instances with different constructors are not equal.
    if (objCtor != othCtor &&
        ('constructor' in object && 'constructor' in other) &&
        !(typeof objCtor == 'function' && objCtor instanceof objCtor &&
          typeof othCtor == 'function' && othCtor instanceof othCtor)) {
      result = false;
    }
  }
  stack['delete'](object);
  stack['delete'](other);
  return result;
}

module.exports = equalObjects;


/***/ }),
/* 1115 */
/***/ (function(module, exports, __webpack_require__) {

var isStrictComparable = __webpack_require__(1068),
    keys = __webpack_require__(120);

/**
 * Gets the property names, values, and compare flags of `object`.
 *
 * @private
 * @param {Object} object The object to query.
 * @returns {Array} Returns the match data of `object`.
 */
function getMatchData(object) {
  var result = keys(object),
      length = result.length;

  while (length--) {
    var key = result[length],
        value = object[key];

    result[length] = [key, value, isStrictComparable(value)];
  }
  return result;
}

module.exports = getMatchData;


/***/ }),
/* 1116 */
/***/ (function(module, exports, __webpack_require__) {

var baseIsEqual = __webpack_require__(1060),
    get = __webpack_require__(1117),
    hasIn = __webpack_require__(1118),
    isKey = __webpack_require__(1053),
    isStrictComparable = __webpack_require__(1068),
    matchesStrictComparable = __webpack_require__(1069),
    toKey = __webpack_require__(1047);

/** Used to compose bitmasks for value comparisons. */
var COMPARE_PARTIAL_FLAG = 1,
    COMPARE_UNORDERED_FLAG = 2;

/**
 * The base implementation of `_.matchesProperty` which doesn't clone `srcValue`.
 *
 * @private
 * @param {string} path The path of the property to get.
 * @param {*} srcValue The value to match.
 * @returns {Function} Returns the new spec function.
 */
function baseMatchesProperty(path, srcValue) {
  if (isKey(path) && isStrictComparable(srcValue)) {
    return matchesStrictComparable(toKey(path), srcValue);
  }
  return function(object) {
    var objValue = get(object, path);
    return (objValue === undefined && objValue === srcValue)
      ? hasIn(object, path)
      : baseIsEqual(srcValue, objValue, COMPARE_PARTIAL_FLAG | COMPARE_UNORDERED_FLAG);
  };
}

module.exports = baseMatchesProperty;


/***/ }),
/* 1117 */
/***/ (function(module, exports, __webpack_require__) {

var baseGet = __webpack_require__(1059);

/**
 * Gets the value at `path` of `object`. If the resolved value is
 * `undefined`, the `defaultValue` is returned in its place.
 *
 * @static
 * @memberOf _
 * @since 3.7.0
 * @category Object
 * @param {Object} object The object to query.
 * @param {Array|string} path The path of the property to get.
 * @param {*} [defaultValue] The value returned for `undefined` resolved values.
 * @returns {*} Returns the resolved value.
 * @example
 *
 * var object = { 'a': [{ 'b': { 'c': 3 } }] };
 *
 * _.get(object, 'a[0].b.c');
 * // => 3
 *
 * _.get(object, ['a', '0', 'b', 'c']);
 * // => 3
 *
 * _.get(object, 'a.b.c', 'default');
 * // => 'default'
 */
function get(object, path, defaultValue) {
  var result = object == null ? undefined : baseGet(object, path);
  return result === undefined ? defaultValue : result;
}

module.exports = get;


/***/ }),
/* 1118 */
/***/ (function(module, exports, __webpack_require__) {

var baseHasIn = __webpack_require__(1119),
    hasPath = __webpack_require__(1061);

/**
 * Checks if `path` is a direct or inherited property of `object`.
 *
 * @static
 * @memberOf _
 * @since 4.0.0
 * @category Object
 * @param {Object} object The object to query.
 * @param {Array|string} path The path to check.
 * @returns {boolean} Returns `true` if `path` exists, else `false`.
 * @example
 *
 * var object = _.create({ 'a': _.create({ 'b': 2 }) });
 *
 * _.hasIn(object, 'a');
 * // => true
 *
 * _.hasIn(object, 'a.b');
 * // => true
 *
 * _.hasIn(object, ['a', 'b']);
 * // => true
 *
 * _.hasIn(object, 'b');
 * // => false
 */
function hasIn(object, path) {
  return object != null && hasPath(object, path, baseHasIn);
}

module.exports = hasIn;


/***/ }),
/* 1119 */
/***/ (function(module, exports) {

/**
 * The base implementation of `_.hasIn` without support for deep paths.
 *
 * @private
 * @param {Object} [object] The object to query.
 * @param {Array|string} key The key to check.
 * @returns {boolean} Returns `true` if `key` exists, else `false`.
 */
function baseHasIn(object, key) {
  return object != null && key in Object(object);
}

module.exports = baseHasIn;


/***/ }),
/* 1120 */
/***/ (function(module, exports, __webpack_require__) {

var baseProperty = __webpack_require__(1121),
    basePropertyDeep = __webpack_require__(1122),
    isKey = __webpack_require__(1053),
    toKey = __webpack_require__(1047);

/**
 * Creates a function that returns the value at `path` of a given object.
 *
 * @static
 * @memberOf _
 * @since 2.4.0
 * @category Util
 * @param {Array|string} path The path of the property to get.
 * @returns {Function} Returns the new accessor function.
 * @example
 *
 * var objects = [
 *   { 'a': { 'b': 2 } },
 *   { 'a': { 'b': 1 } }
 * ];
 *
 * _.map(objects, _.property('a.b'));
 * // => [2, 1]
 *
 * _.map(_.sortBy(objects, _.property(['a', 'b'])), 'a.b');
 * // => [1, 2]
 */
function property(path) {
  return isKey(path) ? baseProperty(toKey(path)) : basePropertyDeep(path);
}

module.exports = property;


/***/ }),
/* 1121 */
/***/ (function(module, exports) {

/**
 * The base implementation of `_.property` without support for deep paths.
 *
 * @private
 * @param {string} key The key of the property to get.
 * @returns {Function} Returns the new accessor function.
 */
function baseProperty(key) {
  return function(object) {
    return object == null ? undefined : object[key];
  };
}

module.exports = baseProperty;


/***/ }),
/* 1122 */
/***/ (function(module, exports, __webpack_require__) {

var baseGet = __webpack_require__(1059);

/**
 * A specialized version of `baseProperty` which supports deep paths.
 *
 * @private
 * @param {Array|string} path The path of the property to get.
 * @returns {Function} Returns the new accessor function.
 */
function basePropertyDeep(path) {
  return function(object) {
    return baseGet(object, path);
  };
}

module.exports = basePropertyDeep;


/***/ }),
/* 1123 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;

var _inherits = __webpack_require__(1046);

var _inherits2 = _interopRequireDefault(_inherits);

var _mixed = __webpack_require__(1042);

var _mixed2 = _interopRequireDefault(_mixed);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = BooleanSchema;


function BooleanSchema() {
  var _this = this;

  if (!(this instanceof BooleanSchema)) return new BooleanSchema();

  _mixed2.default.call(this, { type: 'boolean' });

  this.withMutation(function () {
    _this.transform(function (value) {
      if (!this.isType(value)) {
        if (/^(true|1)$/i.test(value)) return true;
        if (/^(false|0)$/i.test(value)) return false;
      }
      return value;
    });
  });
}

(0, _inherits2.default)(BooleanSchema, _mixed2.default, {
  _typeCheck: function _typeCheck(v) {
    if (v instanceof Boolean) v = v.valueOf();

    return typeof v === 'boolean';
  }
});
module.exports = exports['default'];

/***/ }),
/* 1124 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;
exports.default = StringSchema;

var _inherits = __webpack_require__(1046);

var _inherits2 = _interopRequireDefault(_inherits);

var _mixed = __webpack_require__(1042);

var _mixed2 = _interopRequireDefault(_mixed);

var _locale = __webpack_require__(1045);

var _isAbsent = __webpack_require__(1048);

var _isAbsent2 = _interopRequireDefault(_isAbsent);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var rEmail = /^((([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+(\.([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+)*)|((\x22)((((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(([\x01-\x08\x0b\x0c\x0e-\x1f\x7f]|\x21|[\x23-\x5b]|[\x5d-\x7e]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(\\([\x01-\x09\x0b\x0c\x0d-\x7f]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]))))*(((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(\x22)))@((([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.)+(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))$/i;
var rUrl = /^(https?|ftp):\/\/(((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:)*@)?(((\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5]))|((([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.)+(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.?)(:\d*)?)(\/((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)+(\/(([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)*)*)?)?(\?((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)|[\uE000-\uF8FF]|\/|\?)*)?(\#((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)|\/|\?)*)?$/i;

var hasLength = function hasLength(value) {
  return (0, _isAbsent2.default)(value) || value.length > 0;
};
var isTrimmed = function isTrimmed(value) {
  return (0, _isAbsent2.default)(value) || value === value.trim();
};

function StringSchema() {
  var _this = this;

  if (!(this instanceof StringSchema)) return new StringSchema();

  _mixed2.default.call(this, { type: 'string' });

  this.withMutation(function () {
    _this.transform(function (value) {
      if (this.isType(value)) return value;
      return value != null && value.toString ? value.toString() : value;
    });
  });
}

(0, _inherits2.default)(StringSchema, _mixed2.default, {
  _typeCheck: function _typeCheck(value) {
    if (value instanceof String) value = value.valueOf();

    return typeof value === 'string';
  },
  required: function required(msg) {
    var next = _mixed2.default.prototype.required.call(this, msg || _locale.mixed.required);

    return next.test('required', msg || _locale.mixed.required, hasLength);
  },
  length: function length(_length, msg) {
    return this.test({
      name: 'length',
      exclusive: true,
      message: msg || _locale.string.length,
      params: { length: _length },
      test: function test(value) {
        return (0, _isAbsent2.default)(value) || value.length === this.resolve(_length);
      }
    });
  },
  min: function min(_min, msg) {
    return this.test({
      name: 'min',
      exclusive: true,
      message: msg || _locale.string.min,
      params: { min: _min },
      test: function test(value) {
        return (0, _isAbsent2.default)(value) || value.length >= this.resolve(_min);
      }
    });
  },
  max: function max(_max, msg) {
    return this.test({
      name: 'max',
      exclusive: true,
      message: msg || _locale.string.max,
      params: { max: _max },
      test: function test(value) {
        return (0, _isAbsent2.default)(value) || value.length <= this.resolve(_max);
      }
    });
  },
  matches: function matches(regex) {
    var options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};

    var excludeEmptyString = false,
        message = void 0;

    if (options.message || options.hasOwnProperty('excludeEmptyString')) {
      excludeEmptyString = options.excludeEmptyString;
      message = options.message;
    } else message = options;

    return this.test({
      message: message || _locale.string.matches,
      params: { regex: regex },
      test: function test(value) {
        return (0, _isAbsent2.default)(value) || value === '' && excludeEmptyString || regex.test(value);
      }
    });
  },
  email: function email(msg) {
    return this.matches(rEmail, {
      message: msg || _locale.string.email,
      excludeEmptyString: true
    });
  },
  url: function url(msg) {
    return this.matches(rUrl, {
      message: msg || _locale.string.url,
      excludeEmptyString: true
    });
  },


  //-- transforms --
  ensure: function ensure() {
    return this.default('').transform(function (val) {
      return val === null ? '' : val;
    });
  },
  trim: function trim(msg) {
    msg = msg || _locale.string.trim;

    return this.transform(function (val) {
      return val != null ? val.trim() : val;
    }).test('trim', msg, isTrimmed);
  },
  lowercase: function lowercase(msg) {
    return this.transform(function (value) {
      return !(0, _isAbsent2.default)(value) ? value.toLowerCase() : value;
    }).test({
      name: 'string_case',
      exclusive: true,
      message: msg || _locale.string.lowercase,
      test: function test(value) {
        return (0, _isAbsent2.default)(value) || value === value.toLowerCase();
      }
    });
  },
  uppercase: function uppercase(msg) {
    return this.transform(function (value) {
      return !(0, _isAbsent2.default)(value) ? value.toUpperCase() : value;
    }).test({
      name: 'string_case',
      exclusive: true,
      message: msg || _locale.string.uppercase,
      test: function test(value) {
        return (0, _isAbsent2.default)(value) || value === value.toUpperCase();
      }
    });
  }
});
module.exports = exports['default'];

/***/ }),
/* 1125 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;
exports.default = NumberSchema;

var _inherits = __webpack_require__(1046);

var _inherits2 = _interopRequireDefault(_inherits);

var _mixed = __webpack_require__(1042);

var _mixed2 = _interopRequireDefault(_mixed);

var _locale = __webpack_require__(1045);

var _isAbsent = __webpack_require__(1048);

var _isAbsent2 = _interopRequireDefault(_isAbsent);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var isNaN = function isNaN(value) {
  return value != +value;
};

var isInteger = function isInteger(val) {
  return (0, _isAbsent2.default)(val) || val === (val | 0);
};

function NumberSchema() {
  var _this = this;

  if (!(this instanceof NumberSchema)) return new NumberSchema();

  _mixed2.default.call(this, { type: 'number' });

  this.withMutation(function () {
    _this.transform(function (value) {
      if (this.isType(value)) return value;

      var parsed = parseFloat(value);
      if (this.isType(parsed)) return parsed;

      return NaN;
    });
  });
}

(0, _inherits2.default)(NumberSchema, _mixed2.default, {
  _typeCheck: function _typeCheck(value) {
    if (value instanceof Number) value = value.valueOf();

    return typeof value === 'number' && !isNaN(value);
  },
  min: function min(_min, msg) {
    return this.test({
      name: 'min',
      exclusive: true,
      params: { min: _min },
      message: msg || _locale.number.min,
      test: function test(value) {
        return (0, _isAbsent2.default)(value) || value >= this.resolve(_min);
      }
    });
  },
  max: function max(_max, msg) {
    return this.test({
      name: 'max',
      exclusive: true,
      params: { max: _max },
      message: msg || _locale.number.max,
      test: function test(value) {
        return (0, _isAbsent2.default)(value) || value <= this.resolve(_max);
      }
    });
  },
  positive: function positive(msg) {
    return this.min(0, msg || _locale.number.positive);
  },
  negative: function negative(msg) {
    return this.max(0, msg || _locale.number.negative);
  },
  integer: function integer(msg) {
    msg = msg || _locale.number.integer;

    return this.test('integer', msg, isInteger);
  },
  truncate: function truncate() {
    return this.transform(function (value) {
      return !(0, _isAbsent2.default)(value) ? value | 0 : value;
    });
  },
  round: function round(method) {
    var avail = ['ceil', 'floor', 'round', 'trunc'];
    method = method && method.toLowerCase() || 'round';

    // this exists for symemtry with the new Math.trunc
    if (method === 'trunc') return this.truncate();

    if (avail.indexOf(method.toLowerCase()) === -1) throw new TypeError('Only valid options for round() are: ' + avail.join(', '));

    return this.transform(function (value) {
      return !(0, _isAbsent2.default)(value) ? Math[method](value) : value;
    });
  }
});
module.exports = exports['default'];

/***/ }),
/* 1126 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;

var _mixed = __webpack_require__(1042);

var _mixed2 = _interopRequireDefault(_mixed);

var _inherits = __webpack_require__(1046);

var _inherits2 = _interopRequireDefault(_inherits);

var _isodate = __webpack_require__(1127);

var _isodate2 = _interopRequireDefault(_isodate);

var _locale = __webpack_require__(1045);

var _isAbsent = __webpack_require__(1048);

var _isAbsent2 = _interopRequireDefault(_isAbsent);

var _Reference = __webpack_require__(1049);

var _Reference2 = _interopRequireDefault(_Reference);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var invalidDate = new Date('');

var isDate = function isDate(obj) {
  return Object.prototype.toString.call(obj) === '[object Date]';
};

exports.default = DateSchema;


function DateSchema() {
  var _this = this;

  if (!(this instanceof DateSchema)) return new DateSchema();

  _mixed2.default.call(this, { type: 'date' });

  this.withMutation(function () {
    _this.transform(function (value) {
      if (this.isType(value)) return isDate(value) ? new Date(value) : value;

      value = (0, _isodate2.default)(value);
      return value ? new Date(value) : invalidDate;
    });
  });
}

(0, _inherits2.default)(DateSchema, _mixed2.default, {
  _typeCheck: function _typeCheck(v) {
    return isDate(v) && !isNaN(v.getTime());
  },
  min: function min(_min, msg) {
    var limit = _min;

    if (!_Reference2.default.isRef(limit)) {
      limit = this.cast(_min);
      if (!this._typeCheck(limit)) throw new TypeError('`min` must be a Date or a value that can be `cast()` to a Date');
    }

    return this.test({
      name: 'min',
      exclusive: true,
      message: msg || _locale.date.min,
      params: { min: _min },
      test: function test(value) {
        return (0, _isAbsent2.default)(value) || value >= this.resolve(limit);
      }
    });
  },
  max: function max(_max, msg) {
    var limit = _max;

    if (!_Reference2.default.isRef(limit)) {
      limit = this.cast(_max);
      if (!this._typeCheck(limit)) throw new TypeError('`max` must be a Date or a value that can be `cast()` to a Date');
    }

    return this.test({
      name: 'max',
      exclusive: true,
      message: msg || _locale.date.max,
      params: { max: _max },
      test: function test(value) {
        return (0, _isAbsent2.default)(value) || value <= this.resolve(limit);
      }
    });
  }
});
module.exports = exports['default'];

/***/ }),
/* 1127 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;
exports.default = parseIsoDate;
/**
 * Date.parse with progressive enhancement for ISO 8601 <https://github.com/csnover/js-iso8601>
 * NON-CONFORMANT EDITION.
 * © 2011 Colin Snover <http://zetafleet.com>
 * Released under MIT license.
 */
//              1 YYYY                 2 MM        3 DD              4 HH     5 mm        6 ss            7 msec         8 Z 9 ±    10 tzHH    11 tzmm
var isoReg = /^(\d{4}|[+\-]\d{6})(?:-?(\d{2})(?:-?(\d{2}))?)?(?:[ T]?(\d{2}):?(\d{2})(?::?(\d{2})(?:[,\.](\d{1,}))?)?(?:(Z)|([+\-])(\d{2})(?::?(\d{2}))?)?)?$/;

function parseIsoDate(date) {
  var numericKeys = [1, 4, 5, 6, 7, 10, 11],
      minutesOffset = 0,
      timestamp,
      struct;

  if (struct = isoReg.exec(date)) {
    // avoid NaN timestamps caused by “undefined” values being passed to Date.UTC
    for (var i = 0, k; k = numericKeys[i]; ++i) {
      struct[k] = +struct[k] || 0;
    } // allow undefined days and months
    struct[2] = (+struct[2] || 1) - 1;
    struct[3] = +struct[3] || 1;

    // allow arbitrary sub-second precision beyond milliseconds
    struct[7] = struct[7] ? String(struct[7]).substr(0, 3) : 0;

    // timestamps without timezone identifiers should be considered local time
    if ((struct[8] === undefined || struct[8] === '') && (struct[9] === undefined || struct[9] === '')) timestamp = +new Date(struct[1], struct[2], struct[3], struct[4], struct[5], struct[6], struct[7]);else {
      if (struct[8] !== 'Z' && struct[9] !== undefined) {
        minutesOffset = struct[10] * 60 + struct[11];

        if (struct[9] === '+') minutesOffset = 0 - minutesOffset;
      }

      timestamp = Date.UTC(struct[1], struct[2], struct[3], struct[4], struct[5] + minutesOffset, struct[6], struct[7]);
    }
  } else timestamp = Date.parse ? Date.parse(date) : NaN;

  return timestamp;
}
module.exports = exports['default'];

/***/ }),
/* 1128 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;

var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };

var _templateObject = _taggedTemplateLiteralLoose(['', '.', ''], ['', '.', '']);

exports.default = ObjectSchema;

var _has = __webpack_require__(1044);

var _has2 = _interopRequireDefault(_has);

var _omit = __webpack_require__(1129);

var _omit2 = _interopRequireDefault(_omit);

var _snakeCase2 = __webpack_require__(1145);

var _snakeCase3 = _interopRequireDefault(_snakeCase2);

var _camelCase2 = __webpack_require__(1154);

var _camelCase3 = _interopRequireDefault(_camelCase2);

var _mapKeys = __webpack_require__(1159);

var _mapKeys2 = _interopRequireDefault(_mapKeys);

var _transform = __webpack_require__(1160);

var _transform2 = _interopRequireDefault(_transform);

var _propertyExpr = __webpack_require__(1051);

var _mixed = __webpack_require__(1042);

var _mixed2 = _interopRequireDefault(_mixed);

var _locale = __webpack_require__(1045);

var _sortFields = __webpack_require__(1161);

var _sortFields2 = _interopRequireDefault(_sortFields);

var _sortByKeyOrder = __webpack_require__(1163);

var _sortByKeyOrder2 = _interopRequireDefault(_sortByKeyOrder);

var _inherits = __webpack_require__(1046);

var _inherits2 = _interopRequireDefault(_inherits);

var _makePath = __webpack_require__(1073);

var _makePath2 = _interopRequireDefault(_makePath);

var _runValidations = __webpack_require__(1055);

var _runValidations2 = _interopRequireDefault(_runValidations);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _taggedTemplateLiteralLoose(strings, raw) { strings.raw = raw; return strings; }

var isObject = function isObject(obj) {
  return Object.prototype.toString.call(obj) === '[object Object]';
};

function unknown(ctx, value) {
  var known = Object.keys(ctx.fields);
  return Object.keys(value).filter(function (key) {
    return known.indexOf(key) === -1;
  });
}

function ObjectSchema(spec) {
  var _this2 = this;

  if (!(this instanceof ObjectSchema)) return new ObjectSchema(spec);

  _mixed2.default.call(this, { type: 'object', default: function _default() {
      var _this = this;

      var dft = (0, _transform2.default)(this._nodes, function (obj, key) {
        obj[key] = _this.fields[key].default ? _this.fields[key].default() : undefined;
      }, {});

      return Object.keys(dft).length === 0 ? undefined : dft;
    }
  });

  this.fields = Object.create(null);
  this._nodes = [];
  this._excludedEdges = [];

  this.withMutation(function () {
    _this2.transform(function coerce(value) {
      if (typeof value === 'string') {
        try {
          value = JSON.parse(value);
        } catch (err) {
          value = null;
        }
      }
      if (this.isType(value)) return value;
      return null;
    });

    if (spec) {
      _this2.shape(spec);
    }
  });
}

(0, _inherits2.default)(ObjectSchema, _mixed2.default, {
  _typeCheck: function _typeCheck(value) {
    return isObject(value) || typeof value === 'function';
  },
  _cast: function _cast(_value) {
    var _this3 = this;

    var options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};

    var value = _mixed2.default.prototype._cast.call(this, _value, options);

    //should ignore nulls here
    if (value === undefined) return this.default();

    if (!this._typeCheck(value)) return value;

    var fields = this.fields,
        strip = this._option('stripUnknown', options) === true,
        extra = Object.keys(value).filter(function (v) {
      return _this3._nodes.indexOf(v) === -1;
    }),
        props = this._nodes.concat(extra);

    var innerOptions = _extends({}, options, {
      parent: {}, // is filled during the transform below
      __validating: false
    });

    value = (0, _transform2.default)(props, function (obj, prop) {
      var field = fields[prop];
      var exists = (0, _has2.default)(value, prop);

      if (field) {
        var fieldValue = void 0;
        var strict = field._options && field._options.strict;

        // safe to mutate since this is fired in sequence
        innerOptions.path = (0, _makePath2.default)(_templateObject, options.path, prop);
        innerOptions.value = value[prop];

        field = field.resolve(innerOptions);

        if (field._strip === true) return;

        fieldValue = !options.__validating || !strict ? field.cast(value[prop], innerOptions) : value[prop];

        if (fieldValue !== undefined) obj[prop] = fieldValue;
      } else if (exists && !strip) obj[prop] = value[prop];
    }, innerOptions.parent);

    return value;
  },
  _validate: function _validate(_value) {
    var _this4 = this;

    var opts = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};

    var endEarly = void 0,
        recursive = void 0;
    var sync = opts.sync;
    var errors = [];
    var originalValue = opts.originalValue != null ? opts.originalValue : _value;

    endEarly = this._option('abortEarly', opts);
    recursive = this._option('recursive', opts);

    opts = _extends({}, opts, { __validating: true, originalValue: originalValue });

    return _mixed2.default.prototype._validate.call(this, _value, opts).catch((0, _runValidations.propagateErrors)(endEarly, errors)).then(function (value) {
      if (!recursive || !isObject(value)) {
        // only iterate though actual objects
        if (errors.length) throw errors[0];
        return value;
      }

      originalValue = originalValue || value;

      var validations = _this4._nodes.map(function (key) {
        var path = (0, _makePath2.default)(_templateObject, opts.path, key);
        var field = _this4.fields[key];

        var innerOptions = _extends({}, opts, {
          path: path,
          parent: value,
          originalValue: originalValue[key]
        });

        if (field) {
          // inner fields are always strict:
          // 1. this isn't strict so the casting will also have cast inner values
          // 2. this is strict in which case the nested values weren't cast either
          innerOptions.strict = true;

          if (field.validate) return field.validate(value[key], innerOptions);
        }

        return true;
      });

      return (0, _runValidations2.default)({
        sync: sync,
        validations: validations,
        value: value,
        errors: errors,
        endEarly: endEarly,
        path: opts.path,
        sort: (0, _sortByKeyOrder2.default)(_this4.fields)
      });
    });
  },
  concat: function concat(schema) {
    var next = _mixed2.default.prototype.concat.call(this, schema);

    next._nodes = (0, _sortFields2.default)(next.fields, next._excludedEdges);

    return next;
  },
  shape: function shape(schema) {
    var excludes = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : [];

    var next = this.clone(),
        fields = _extends(next.fields, schema);

    next.fields = fields;

    if (excludes.length) {
      if (!Array.isArray(excludes[0])) excludes = [excludes];

      var keys = excludes.map(function (_ref) {
        var first = _ref[0],
            second = _ref[1];
        return first + '-' + second;
      });

      next._excludedEdges = next._excludedEdges.concat(keys);
    }

    next._nodes = (0, _sortFields2.default)(fields, next._excludedEdges);

    return next;
  },
  from: function from(_from, to, alias) {
    var fromGetter = (0, _propertyExpr.getter)(_from, true);

    return this.transform(function (obj) {
      var newObj = obj;

      if (obj == null) return obj;

      if ((0, _has2.default)(obj, _from)) {
        newObj = alias ? _extends({}, obj) : (0, _omit2.default)(obj, _from);
        newObj[to] = fromGetter(obj);
      }

      return newObj;
    });
  },
  noUnknown: function noUnknown() {
    var noAllow = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : true;
    var message = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : _locale.object.noUnknown;

    if (typeof noAllow === 'string') {
      message = noAllow;
      noAllow = true;
    }

    var next = this.test({
      name: 'noUnknown',
      exclusive: true,
      message: message,
      test: function test(value) {
        return value == null || !noAllow || unknown(this.schema, value).length === 0;
      }
    });

    if (noAllow) next._options.stripUnknown = true;

    return next;
  },
  transformKeys: function transformKeys(fn) {
    return this.transform(function (obj) {
      return obj && (0, _mapKeys2.default)(obj, function (_, key) {
        return fn(key);
      });
    });
  },
  camelCase: function camelCase() {
    return this.transformKeys(_camelCase3.default);
  },
  snakeCase: function snakeCase() {
    return this.transformKeys(_snakeCase3.default);
  },
  constantCase: function constantCase() {
    return this.transformKeys(function (key) {
      return (0, _snakeCase3.default)(key).toUpperCase();
    });
  }
});
module.exports = exports['default'];

/***/ }),
/* 1129 */
/***/ (function(module, exports, __webpack_require__) {

var arrayMap = __webpack_require__(311),
    baseClone = __webpack_require__(313),
    baseUnset = __webpack_require__(1130),
    castPath = __webpack_require__(1050),
    copyObject = __webpack_require__(96),
    customOmitClone = __webpack_require__(1133),
    flatRest = __webpack_require__(1135),
    getAllKeysIn = __webpack_require__(323);

/** Used to compose bitmasks for cloning. */
var CLONE_DEEP_FLAG = 1,
    CLONE_FLAT_FLAG = 2,
    CLONE_SYMBOLS_FLAG = 4;

/**
 * The opposite of `_.pick`; this method creates an object composed of the
 * own and inherited enumerable property paths of `object` that are not omitted.
 *
 * **Note:** This method is considerably slower than `_.pick`.
 *
 * @static
 * @since 0.1.0
 * @memberOf _
 * @category Object
 * @param {Object} object The source object.
 * @param {...(string|string[])} [paths] The property paths to omit.
 * @returns {Object} Returns the new object.
 * @example
 *
 * var object = { 'a': 1, 'b': '2', 'c': 3 };
 *
 * _.omit(object, ['a', 'c']);
 * // => { 'b': '2' }
 */
var omit = flatRest(function(object, paths) {
  var result = {};
  if (object == null) {
    return result;
  }
  var isDeep = false;
  paths = arrayMap(paths, function(path) {
    path = castPath(path, object);
    isDeep || (isDeep = path.length > 1);
    return path;
  });
  copyObject(object, getAllKeysIn(object), result);
  if (isDeep) {
    result = baseClone(result, CLONE_DEEP_FLAG | CLONE_FLAT_FLAG | CLONE_SYMBOLS_FLAG, customOmitClone);
  }
  var length = paths.length;
  while (length--) {
    baseUnset(result, paths[length]);
  }
  return result;
});

module.exports = omit;


/***/ }),
/* 1130 */
/***/ (function(module, exports, __webpack_require__) {

var castPath = __webpack_require__(1050),
    last = __webpack_require__(1131),
    parent = __webpack_require__(1132),
    toKey = __webpack_require__(1047);

/**
 * The base implementation of `_.unset`.
 *
 * @private
 * @param {Object} object The object to modify.
 * @param {Array|string} path The property path to unset.
 * @returns {boolean} Returns `true` if the property is deleted, else `false`.
 */
function baseUnset(object, path) {
  path = castPath(path, object);
  object = parent(object, path);
  return object == null || delete object[toKey(last(path))];
}

module.exports = baseUnset;


/***/ }),
/* 1131 */
/***/ (function(module, exports) {

/**
 * Gets the last element of `array`.
 *
 * @static
 * @memberOf _
 * @since 0.1.0
 * @category Array
 * @param {Array} array The array to query.
 * @returns {*} Returns the last element of `array`.
 * @example
 *
 * _.last([1, 2, 3]);
 * // => 3
 */
function last(array) {
  var length = array == null ? 0 : array.length;
  return length ? array[length - 1] : undefined;
}

module.exports = last;


/***/ }),
/* 1132 */
/***/ (function(module, exports, __webpack_require__) {

var baseGet = __webpack_require__(1059),
    baseSlice = __webpack_require__(1071);

/**
 * Gets the parent value at `path` of `object`.
 *
 * @private
 * @param {Object} object The object to query.
 * @param {Array} path The path to get the parent value of.
 * @returns {*} Returns the parent value.
 */
function parent(object, path) {
  return path.length < 2 ? object : baseGet(object, baseSlice(path, 0, -1));
}

module.exports = parent;


/***/ }),
/* 1133 */
/***/ (function(module, exports, __webpack_require__) {

var isPlainObject = __webpack_require__(1134);

/**
 * Used by `_.omit` to customize its `_.cloneDeep` use to only clone plain
 * objects.
 *
 * @private
 * @param {*} value The value to inspect.
 * @param {string} key The key of the property to inspect.
 * @returns {*} Returns the uncloned value or `undefined` to defer cloning to `_.cloneDeep`.
 */
function customOmitClone(value) {
  return isPlainObject(value) ? undefined : value;
}

module.exports = customOmitClone;


/***/ }),
/* 1134 */
/***/ (function(module, exports, __webpack_require__) {

var baseGetTag = __webpack_require__(81),
    getPrototype = __webpack_require__(185),
    isObjectLike = __webpack_require__(69);

/** `Object#toString` result references. */
var objectTag = '[object Object]';

/** Used for built-in method references. */
var funcProto = Function.prototype,
    objectProto = Object.prototype;

/** Used to resolve the decompiled source of functions. */
var funcToString = funcProto.toString;

/** Used to check objects for own properties. */
var hasOwnProperty = objectProto.hasOwnProperty;

/** Used to infer the `Object` constructor. */
var objectCtorString = funcToString.call(Object);

/**
 * Checks if `value` is a plain object, that is, an object created by the
 * `Object` constructor or one with a `[[Prototype]]` of `null`.
 *
 * @static
 * @memberOf _
 * @since 0.8.0
 * @category Lang
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is a plain object, else `false`.
 * @example
 *
 * function Foo() {
 *   this.a = 1;
 * }
 *
 * _.isPlainObject(new Foo);
 * // => false
 *
 * _.isPlainObject([1, 2, 3]);
 * // => false
 *
 * _.isPlainObject({ 'x': 0, 'y': 0 });
 * // => true
 *
 * _.isPlainObject(Object.create(null));
 * // => true
 */
function isPlainObject(value) {
  if (!isObjectLike(value) || baseGetTag(value) != objectTag) {
    return false;
  }
  var proto = getPrototype(value);
  if (proto === null) {
    return true;
  }
  var Ctor = hasOwnProperty.call(proto, 'constructor') && proto.constructor;
  return typeof Ctor == 'function' && Ctor instanceof Ctor &&
    funcToString.call(Ctor) == objectCtorString;
}

module.exports = isPlainObject;


/***/ }),
/* 1135 */
/***/ (function(module, exports, __webpack_require__) {

var flatten = __webpack_require__(1136),
    overRest = __webpack_require__(1139),
    setToString = __webpack_require__(1141);

/**
 * A specialized version of `baseRest` which flattens the rest array.
 *
 * @private
 * @param {Function} func The function to apply a rest parameter to.
 * @returns {Function} Returns the new function.
 */
function flatRest(func) {
  return setToString(overRest(func, undefined, flatten), func + '');
}

module.exports = flatRest;


/***/ }),
/* 1136 */
/***/ (function(module, exports, __webpack_require__) {

var baseFlatten = __webpack_require__(1137);

/**
 * Flattens `array` a single level deep.
 *
 * @static
 * @memberOf _
 * @since 0.1.0
 * @category Array
 * @param {Array} array The array to flatten.
 * @returns {Array} Returns the new flattened array.
 * @example
 *
 * _.flatten([1, [2, [3, [4]], 5]]);
 * // => [1, 2, [3, [4]], 5]
 */
function flatten(array) {
  var length = array == null ? 0 : array.length;
  return length ? baseFlatten(array, 1) : [];
}

module.exports = flatten;


/***/ }),
/* 1137 */
/***/ (function(module, exports, __webpack_require__) {

var arrayPush = __webpack_require__(191),
    isFlattenable = __webpack_require__(1138);

/**
 * The base implementation of `_.flatten` with support for restricting flattening.
 *
 * @private
 * @param {Array} array The array to flatten.
 * @param {number} depth The maximum recursion depth.
 * @param {boolean} [predicate=isFlattenable] The function invoked per iteration.
 * @param {boolean} [isStrict] Restrict to values that pass `predicate` checks.
 * @param {Array} [result=[]] The initial result value.
 * @returns {Array} Returns the new flattened array.
 */
function baseFlatten(array, depth, predicate, isStrict, result) {
  var index = -1,
      length = array.length;

  predicate || (predicate = isFlattenable);
  result || (result = []);

  while (++index < length) {
    var value = array[index];
    if (depth > 0 && predicate(value)) {
      if (depth > 1) {
        // Recursively flatten arrays (susceptible to call stack limits).
        baseFlatten(value, depth - 1, predicate, isStrict, result);
      } else {
        arrayPush(result, value);
      }
    } else if (!isStrict) {
      result[result.length] = value;
    }
  }
  return result;
}

module.exports = baseFlatten;


/***/ }),
/* 1138 */
/***/ (function(module, exports, __webpack_require__) {

var Symbol = __webpack_require__(94),
    isArguments = __webpack_require__(309),
    isArray = __webpack_require__(92);

/** Built-in value references. */
var spreadableSymbol = Symbol ? Symbol.isConcatSpreadable : undefined;

/**
 * Checks if `value` is a flattenable `arguments` object or array.
 *
 * @private
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is flattenable, else `false`.
 */
function isFlattenable(value) {
  return isArray(value) || isArguments(value) ||
    !!(spreadableSymbol && value && value[spreadableSymbol]);
}

module.exports = isFlattenable;


/***/ }),
/* 1139 */
/***/ (function(module, exports, __webpack_require__) {

var apply = __webpack_require__(1140);

/* Built-in method references for those with the same name as other `lodash` methods. */
var nativeMax = Math.max;

/**
 * A specialized version of `baseRest` which transforms the rest array.
 *
 * @private
 * @param {Function} func The function to apply a rest parameter to.
 * @param {number} [start=func.length-1] The start position of the rest parameter.
 * @param {Function} transform The rest array transform.
 * @returns {Function} Returns the new function.
 */
function overRest(func, start, transform) {
  start = nativeMax(start === undefined ? (func.length - 1) : start, 0);
  return function() {
    var args = arguments,
        index = -1,
        length = nativeMax(args.length - start, 0),
        array = Array(length);

    while (++index < length) {
      array[index] = args[start + index];
    }
    index = -1;
    var otherArgs = Array(start + 1);
    while (++index < start) {
      otherArgs[index] = args[index];
    }
    otherArgs[start] = transform(array);
    return apply(func, this, otherArgs);
  };
}

module.exports = overRest;


/***/ }),
/* 1140 */
/***/ (function(module, exports) {

/**
 * A faster alternative to `Function#apply`, this function invokes `func`
 * with the `this` binding of `thisArg` and the arguments of `args`.
 *
 * @private
 * @param {Function} func The function to invoke.
 * @param {*} thisArg The `this` binding of `func`.
 * @param {Array} args The arguments to invoke `func` with.
 * @returns {*} Returns the result of `func`.
 */
function apply(func, thisArg, args) {
  switch (args.length) {
    case 0: return func.call(thisArg);
    case 1: return func.call(thisArg, args[0]);
    case 2: return func.call(thisArg, args[0], args[1]);
    case 3: return func.call(thisArg, args[0], args[1], args[2]);
  }
  return func.apply(thisArg, args);
}

module.exports = apply;


/***/ }),
/* 1141 */
/***/ (function(module, exports, __webpack_require__) {

var baseSetToString = __webpack_require__(1142),
    shortOut = __webpack_require__(1144);

/**
 * Sets the `toString` method of `func` to return `string`.
 *
 * @private
 * @param {Function} func The function to modify.
 * @param {Function} string The `toString` result.
 * @returns {Function} Returns `func`.
 */
var setToString = shortOut(baseSetToString);

module.exports = setToString;


/***/ }),
/* 1142 */
/***/ (function(module, exports, __webpack_require__) {

var constant = __webpack_require__(1143),
    defineProperty = __webpack_require__(320),
    identity = __webpack_require__(1070);

/**
 * The base implementation of `setToString` without support for hot loop shorting.
 *
 * @private
 * @param {Function} func The function to modify.
 * @param {Function} string The `toString` result.
 * @returns {Function} Returns `func`.
 */
var baseSetToString = !defineProperty ? identity : function(func, string) {
  return defineProperty(func, 'toString', {
    'configurable': true,
    'enumerable': false,
    'value': constant(string),
    'writable': true
  });
};

module.exports = baseSetToString;


/***/ }),
/* 1143 */
/***/ (function(module, exports) {

/**
 * Creates a function that returns `value`.
 *
 * @static
 * @memberOf _
 * @since 2.4.0
 * @category Util
 * @param {*} value The value to return from the new function.
 * @returns {Function} Returns the new constant function.
 * @example
 *
 * var objects = _.times(2, _.constant({ 'a': 1 }));
 *
 * console.log(objects);
 * // => [{ 'a': 1 }, { 'a': 1 }]
 *
 * console.log(objects[0] === objects[1]);
 * // => true
 */
function constant(value) {
  return function() {
    return value;
  };
}

module.exports = constant;


/***/ }),
/* 1144 */
/***/ (function(module, exports) {

/** Used to detect hot functions by number of calls within a span of milliseconds. */
var HOT_COUNT = 800,
    HOT_SPAN = 16;

/* Built-in method references for those with the same name as other `lodash` methods. */
var nativeNow = Date.now;

/**
 * Creates a function that'll short out and invoke `identity` instead
 * of `func` when it's called `HOT_COUNT` or more times in `HOT_SPAN`
 * milliseconds.
 *
 * @private
 * @param {Function} func The function to restrict.
 * @returns {Function} Returns the new shortable function.
 */
function shortOut(func) {
  var count = 0,
      lastCalled = 0;

  return function() {
    var stamp = nativeNow(),
        remaining = HOT_SPAN - (stamp - lastCalled);

    lastCalled = stamp;
    if (remaining > 0) {
      if (++count >= HOT_COUNT) {
        return arguments[0];
      }
    } else {
      count = 0;
    }
    return func.apply(undefined, arguments);
  };
}

module.exports = shortOut;


/***/ }),
/* 1145 */
/***/ (function(module, exports, __webpack_require__) {

var createCompounder = __webpack_require__(1072);

/**
 * Converts `string` to
 * [snake case](https://en.wikipedia.org/wiki/Snake_case).
 *
 * @static
 * @memberOf _
 * @since 3.0.0
 * @category String
 * @param {string} [string=''] The string to convert.
 * @returns {string} Returns the snake cased string.
 * @example
 *
 * _.snakeCase('Foo Bar');
 * // => 'foo_bar'
 *
 * _.snakeCase('fooBar');
 * // => 'foo_bar'
 *
 * _.snakeCase('--FOO-BAR--');
 * // => 'foo_bar'
 */
var snakeCase = createCompounder(function(result, word, index) {
  return result + (index ? '_' : '') + word.toLowerCase();
});

module.exports = snakeCase;


/***/ }),
/* 1146 */
/***/ (function(module, exports) {

/**
 * A specialized version of `_.reduce` for arrays without support for
 * iteratee shorthands.
 *
 * @private
 * @param {Array} [array] The array to iterate over.
 * @param {Function} iteratee The function invoked per iteration.
 * @param {*} [accumulator] The initial value.
 * @param {boolean} [initAccum] Specify using the first element of `array` as
 *  the initial value.
 * @returns {*} Returns the accumulated value.
 */
function arrayReduce(array, iteratee, accumulator, initAccum) {
  var index = -1,
      length = array == null ? 0 : array.length;

  if (initAccum && length) {
    accumulator = array[++index];
  }
  while (++index < length) {
    accumulator = iteratee(accumulator, array[index], index, array);
  }
  return accumulator;
}

module.exports = arrayReduce;


/***/ }),
/* 1147 */
/***/ (function(module, exports, __webpack_require__) {

var deburrLetter = __webpack_require__(1148),
    toString = __webpack_require__(308);

/** Used to match Latin Unicode letters (excluding mathematical operators). */
var reLatin = /[\xc0-\xd6\xd8-\xf6\xf8-\xff\u0100-\u017f]/g;

/** Used to compose unicode character classes. */
var rsComboMarksRange = '\\u0300-\\u036f',
    reComboHalfMarksRange = '\\ufe20-\\ufe2f',
    rsComboSymbolsRange = '\\u20d0-\\u20ff',
    rsComboRange = rsComboMarksRange + reComboHalfMarksRange + rsComboSymbolsRange;

/** Used to compose unicode capture groups. */
var rsCombo = '[' + rsComboRange + ']';

/**
 * Used to match [combining diacritical marks](https://en.wikipedia.org/wiki/Combining_Diacritical_Marks) and
 * [combining diacritical marks for symbols](https://en.wikipedia.org/wiki/Combining_Diacritical_Marks_for_Symbols).
 */
var reComboMark = RegExp(rsCombo, 'g');

/**
 * Deburrs `string` by converting
 * [Latin-1 Supplement](https://en.wikipedia.org/wiki/Latin-1_Supplement_(Unicode_block)#Character_table)
 * and [Latin Extended-A](https://en.wikipedia.org/wiki/Latin_Extended-A)
 * letters to basic Latin letters and removing
 * [combining diacritical marks](https://en.wikipedia.org/wiki/Combining_Diacritical_Marks).
 *
 * @static
 * @memberOf _
 * @since 3.0.0
 * @category String
 * @param {string} [string=''] The string to deburr.
 * @returns {string} Returns the deburred string.
 * @example
 *
 * _.deburr('déjà vu');
 * // => 'deja vu'
 */
function deburr(string) {
  string = toString(string);
  return string && string.replace(reLatin, deburrLetter).replace(reComboMark, '');
}

module.exports = deburr;


/***/ }),
/* 1148 */
/***/ (function(module, exports, __webpack_require__) {

var basePropertyOf = __webpack_require__(1149);

/** Used to map Latin Unicode letters to basic Latin letters. */
var deburredLetters = {
  // Latin-1 Supplement block.
  '\xc0': 'A',  '\xc1': 'A', '\xc2': 'A', '\xc3': 'A', '\xc4': 'A', '\xc5': 'A',
  '\xe0': 'a',  '\xe1': 'a', '\xe2': 'a', '\xe3': 'a', '\xe4': 'a', '\xe5': 'a',
  '\xc7': 'C',  '\xe7': 'c',
  '\xd0': 'D',  '\xf0': 'd',
  '\xc8': 'E',  '\xc9': 'E', '\xca': 'E', '\xcb': 'E',
  '\xe8': 'e',  '\xe9': 'e', '\xea': 'e', '\xeb': 'e',
  '\xcc': 'I',  '\xcd': 'I', '\xce': 'I', '\xcf': 'I',
  '\xec': 'i',  '\xed': 'i', '\xee': 'i', '\xef': 'i',
  '\xd1': 'N',  '\xf1': 'n',
  '\xd2': 'O',  '\xd3': 'O', '\xd4': 'O', '\xd5': 'O', '\xd6': 'O', '\xd8': 'O',
  '\xf2': 'o',  '\xf3': 'o', '\xf4': 'o', '\xf5': 'o', '\xf6': 'o', '\xf8': 'o',
  '\xd9': 'U',  '\xda': 'U', '\xdb': 'U', '\xdc': 'U',
  '\xf9': 'u',  '\xfa': 'u', '\xfb': 'u', '\xfc': 'u',
  '\xdd': 'Y',  '\xfd': 'y', '\xff': 'y',
  '\xc6': 'Ae', '\xe6': 'ae',
  '\xde': 'Th', '\xfe': 'th',
  '\xdf': 'ss',
  // Latin Extended-A block.
  '\u0100': 'A',  '\u0102': 'A', '\u0104': 'A',
  '\u0101': 'a',  '\u0103': 'a', '\u0105': 'a',
  '\u0106': 'C',  '\u0108': 'C', '\u010a': 'C', '\u010c': 'C',
  '\u0107': 'c',  '\u0109': 'c', '\u010b': 'c', '\u010d': 'c',
  '\u010e': 'D',  '\u0110': 'D', '\u010f': 'd', '\u0111': 'd',
  '\u0112': 'E',  '\u0114': 'E', '\u0116': 'E', '\u0118': 'E', '\u011a': 'E',
  '\u0113': 'e',  '\u0115': 'e', '\u0117': 'e', '\u0119': 'e', '\u011b': 'e',
  '\u011c': 'G',  '\u011e': 'G', '\u0120': 'G', '\u0122': 'G',
  '\u011d': 'g',  '\u011f': 'g', '\u0121': 'g', '\u0123': 'g',
  '\u0124': 'H',  '\u0126': 'H', '\u0125': 'h', '\u0127': 'h',
  '\u0128': 'I',  '\u012a': 'I', '\u012c': 'I', '\u012e': 'I', '\u0130': 'I',
  '\u0129': 'i',  '\u012b': 'i', '\u012d': 'i', '\u012f': 'i', '\u0131': 'i',
  '\u0134': 'J',  '\u0135': 'j',
  '\u0136': 'K',  '\u0137': 'k', '\u0138': 'k',
  '\u0139': 'L',  '\u013b': 'L', '\u013d': 'L', '\u013f': 'L', '\u0141': 'L',
  '\u013a': 'l',  '\u013c': 'l', '\u013e': 'l', '\u0140': 'l', '\u0142': 'l',
  '\u0143': 'N',  '\u0145': 'N', '\u0147': 'N', '\u014a': 'N',
  '\u0144': 'n',  '\u0146': 'n', '\u0148': 'n', '\u014b': 'n',
  '\u014c': 'O',  '\u014e': 'O', '\u0150': 'O',
  '\u014d': 'o',  '\u014f': 'o', '\u0151': 'o',
  '\u0154': 'R',  '\u0156': 'R', '\u0158': 'R',
  '\u0155': 'r',  '\u0157': 'r', '\u0159': 'r',
  '\u015a': 'S',  '\u015c': 'S', '\u015e': 'S', '\u0160': 'S',
  '\u015b': 's',  '\u015d': 's', '\u015f': 's', '\u0161': 's',
  '\u0162': 'T',  '\u0164': 'T', '\u0166': 'T',
  '\u0163': 't',  '\u0165': 't', '\u0167': 't',
  '\u0168': 'U',  '\u016a': 'U', '\u016c': 'U', '\u016e': 'U', '\u0170': 'U', '\u0172': 'U',
  '\u0169': 'u',  '\u016b': 'u', '\u016d': 'u', '\u016f': 'u', '\u0171': 'u', '\u0173': 'u',
  '\u0174': 'W',  '\u0175': 'w',
  '\u0176': 'Y',  '\u0177': 'y', '\u0178': 'Y',
  '\u0179': 'Z',  '\u017b': 'Z', '\u017d': 'Z',
  '\u017a': 'z',  '\u017c': 'z', '\u017e': 'z',
  '\u0132': 'IJ', '\u0133': 'ij',
  '\u0152': 'Oe', '\u0153': 'oe',
  '\u0149': "'n", '\u017f': 's'
};

/**
 * Used by `_.deburr` to convert Latin-1 Supplement and Latin Extended-A
 * letters to basic Latin letters.
 *
 * @private
 * @param {string} letter The matched letter to deburr.
 * @returns {string} Returns the deburred letter.
 */
var deburrLetter = basePropertyOf(deburredLetters);

module.exports = deburrLetter;


/***/ }),
/* 1149 */
/***/ (function(module, exports) {

/**
 * The base implementation of `_.propertyOf` without support for deep paths.
 *
 * @private
 * @param {Object} object The object to query.
 * @returns {Function} Returns the new accessor function.
 */
function basePropertyOf(object) {
  return function(key) {
    return object == null ? undefined : object[key];
  };
}

module.exports = basePropertyOf;


/***/ }),
/* 1150 */
/***/ (function(module, exports, __webpack_require__) {

var asciiWords = __webpack_require__(1151),
    hasUnicodeWord = __webpack_require__(1152),
    toString = __webpack_require__(308),
    unicodeWords = __webpack_require__(1153);

/**
 * Splits `string` into an array of its words.
 *
 * @static
 * @memberOf _
 * @since 3.0.0
 * @category String
 * @param {string} [string=''] The string to inspect.
 * @param {RegExp|string} [pattern] The pattern to match words.
 * @param- {Object} [guard] Enables use as an iteratee for methods like `_.map`.
 * @returns {Array} Returns the words of `string`.
 * @example
 *
 * _.words('fred, barney, & pebbles');
 * // => ['fred', 'barney', 'pebbles']
 *
 * _.words('fred, barney, & pebbles', /[^, ]+/g);
 * // => ['fred', 'barney', '&', 'pebbles']
 */
function words(string, pattern, guard) {
  string = toString(string);
  pattern = guard ? undefined : pattern;

  if (pattern === undefined) {
    return hasUnicodeWord(string) ? unicodeWords(string) : asciiWords(string);
  }
  return string.match(pattern) || [];
}

module.exports = words;


/***/ }),
/* 1151 */
/***/ (function(module, exports) {

/** Used to match words composed of alphanumeric characters. */
var reAsciiWord = /[^\x00-\x2f\x3a-\x40\x5b-\x60\x7b-\x7f]+/g;

/**
 * Splits an ASCII `string` into an array of its words.
 *
 * @private
 * @param {string} The string to inspect.
 * @returns {Array} Returns the words of `string`.
 */
function asciiWords(string) {
  return string.match(reAsciiWord) || [];
}

module.exports = asciiWords;


/***/ }),
/* 1152 */
/***/ (function(module, exports) {

/** Used to detect strings that need a more robust regexp to match words. */
var reHasUnicodeWord = /[a-z][A-Z]|[A-Z]{2,}[a-z]|[0-9][a-zA-Z]|[a-zA-Z][0-9]|[^a-zA-Z0-9 ]/;

/**
 * Checks if `string` contains a word composed of Unicode symbols.
 *
 * @private
 * @param {string} string The string to inspect.
 * @returns {boolean} Returns `true` if a word is found, else `false`.
 */
function hasUnicodeWord(string) {
  return reHasUnicodeWord.test(string);
}

module.exports = hasUnicodeWord;


/***/ }),
/* 1153 */
/***/ (function(module, exports) {

/** Used to compose unicode character classes. */
var rsAstralRange = '\\ud800-\\udfff',
    rsComboMarksRange = '\\u0300-\\u036f',
    reComboHalfMarksRange = '\\ufe20-\\ufe2f',
    rsComboSymbolsRange = '\\u20d0-\\u20ff',
    rsComboRange = rsComboMarksRange + reComboHalfMarksRange + rsComboSymbolsRange,
    rsDingbatRange = '\\u2700-\\u27bf',
    rsLowerRange = 'a-z\\xdf-\\xf6\\xf8-\\xff',
    rsMathOpRange = '\\xac\\xb1\\xd7\\xf7',
    rsNonCharRange = '\\x00-\\x2f\\x3a-\\x40\\x5b-\\x60\\x7b-\\xbf',
    rsPunctuationRange = '\\u2000-\\u206f',
    rsSpaceRange = ' \\t\\x0b\\f\\xa0\\ufeff\\n\\r\\u2028\\u2029\\u1680\\u180e\\u2000\\u2001\\u2002\\u2003\\u2004\\u2005\\u2006\\u2007\\u2008\\u2009\\u200a\\u202f\\u205f\\u3000',
    rsUpperRange = 'A-Z\\xc0-\\xd6\\xd8-\\xde',
    rsVarRange = '\\ufe0e\\ufe0f',
    rsBreakRange = rsMathOpRange + rsNonCharRange + rsPunctuationRange + rsSpaceRange;

/** Used to compose unicode capture groups. */
var rsApos = "['\u2019]",
    rsBreak = '[' + rsBreakRange + ']',
    rsCombo = '[' + rsComboRange + ']',
    rsDigits = '\\d+',
    rsDingbat = '[' + rsDingbatRange + ']',
    rsLower = '[' + rsLowerRange + ']',
    rsMisc = '[^' + rsAstralRange + rsBreakRange + rsDigits + rsDingbatRange + rsLowerRange + rsUpperRange + ']',
    rsFitz = '\\ud83c[\\udffb-\\udfff]',
    rsModifier = '(?:' + rsCombo + '|' + rsFitz + ')',
    rsNonAstral = '[^' + rsAstralRange + ']',
    rsRegional = '(?:\\ud83c[\\udde6-\\uddff]){2}',
    rsSurrPair = '[\\ud800-\\udbff][\\udc00-\\udfff]',
    rsUpper = '[' + rsUpperRange + ']',
    rsZWJ = '\\u200d';

/** Used to compose unicode regexes. */
var rsMiscLower = '(?:' + rsLower + '|' + rsMisc + ')',
    rsMiscUpper = '(?:' + rsUpper + '|' + rsMisc + ')',
    rsOptContrLower = '(?:' + rsApos + '(?:d|ll|m|re|s|t|ve))?',
    rsOptContrUpper = '(?:' + rsApos + '(?:D|LL|M|RE|S|T|VE))?',
    reOptMod = rsModifier + '?',
    rsOptVar = '[' + rsVarRange + ']?',
    rsOptJoin = '(?:' + rsZWJ + '(?:' + [rsNonAstral, rsRegional, rsSurrPair].join('|') + ')' + rsOptVar + reOptMod + ')*',
    rsOrdLower = '\\d*(?:1st|2nd|3rd|(?![123])\\dth)(?=\\b|[A-Z_])',
    rsOrdUpper = '\\d*(?:1ST|2ND|3RD|(?![123])\\dTH)(?=\\b|[a-z_])',
    rsSeq = rsOptVar + reOptMod + rsOptJoin,
    rsEmoji = '(?:' + [rsDingbat, rsRegional, rsSurrPair].join('|') + ')' + rsSeq;

/** Used to match complex or compound words. */
var reUnicodeWord = RegExp([
  rsUpper + '?' + rsLower + '+' + rsOptContrLower + '(?=' + [rsBreak, rsUpper, '$'].join('|') + ')',
  rsMiscUpper + '+' + rsOptContrUpper + '(?=' + [rsBreak, rsUpper + rsMiscLower, '$'].join('|') + ')',
  rsUpper + '?' + rsMiscLower + '+' + rsOptContrLower,
  rsUpper + '+' + rsOptContrUpper,
  rsOrdUpper,
  rsOrdLower,
  rsDigits,
  rsEmoji
].join('|'), 'g');

/**
 * Splits a Unicode `string` into an array of its words.
 *
 * @private
 * @param {string} The string to inspect.
 * @returns {Array} Returns the words of `string`.
 */
function unicodeWords(string) {
  return string.match(reUnicodeWord) || [];
}

module.exports = unicodeWords;


/***/ }),
/* 1154 */
/***/ (function(module, exports, __webpack_require__) {

var capitalize = __webpack_require__(1155),
    createCompounder = __webpack_require__(1072);

/**
 * Converts `string` to [camel case](https://en.wikipedia.org/wiki/CamelCase).
 *
 * @static
 * @memberOf _
 * @since 3.0.0
 * @category String
 * @param {string} [string=''] The string to convert.
 * @returns {string} Returns the camel cased string.
 * @example
 *
 * _.camelCase('Foo Bar');
 * // => 'fooBar'
 *
 * _.camelCase('--foo-bar--');
 * // => 'fooBar'
 *
 * _.camelCase('__FOO_BAR__');
 * // => 'fooBar'
 */
var camelCase = createCompounder(function(result, word, index) {
  word = word.toLowerCase();
  return result + (index ? capitalize(word) : word);
});

module.exports = camelCase;


/***/ }),
/* 1155 */
/***/ (function(module, exports, __webpack_require__) {

var toString = __webpack_require__(308),
    upperFirst = __webpack_require__(1156);

/**
 * Converts the first character of `string` to upper case and the remaining
 * to lower case.
 *
 * @static
 * @memberOf _
 * @since 3.0.0
 * @category String
 * @param {string} [string=''] The string to capitalize.
 * @returns {string} Returns the capitalized string.
 * @example
 *
 * _.capitalize('FRED');
 * // => 'Fred'
 */
function capitalize(string) {
  return upperFirst(toString(string).toLowerCase());
}

module.exports = capitalize;


/***/ }),
/* 1156 */
/***/ (function(module, exports, __webpack_require__) {

var createCaseFirst = __webpack_require__(1157);

/**
 * Converts the first character of `string` to upper case.
 *
 * @static
 * @memberOf _
 * @since 4.0.0
 * @category String
 * @param {string} [string=''] The string to convert.
 * @returns {string} Returns the converted string.
 * @example
 *
 * _.upperFirst('fred');
 * // => 'Fred'
 *
 * _.upperFirst('FRED');
 * // => 'FRED'
 */
var upperFirst = createCaseFirst('toUpperCase');

module.exports = upperFirst;


/***/ }),
/* 1157 */
/***/ (function(module, exports, __webpack_require__) {

var castSlice = __webpack_require__(1158),
    hasUnicode = __webpack_require__(1065),
    stringToArray = __webpack_require__(1064),
    toString = __webpack_require__(308);

/**
 * Creates a function like `_.lowerFirst`.
 *
 * @private
 * @param {string} methodName The name of the `String` case method to use.
 * @returns {Function} Returns the new case function.
 */
function createCaseFirst(methodName) {
  return function(string) {
    string = toString(string);

    var strSymbols = hasUnicode(string)
      ? stringToArray(string)
      : undefined;

    var chr = strSymbols
      ? strSymbols[0]
      : string.charAt(0);

    var trailing = strSymbols
      ? castSlice(strSymbols, 1).join('')
      : string.slice(1);

    return chr[methodName]() + trailing;
  };
}

module.exports = createCaseFirst;


/***/ }),
/* 1158 */
/***/ (function(module, exports, __webpack_require__) {

var baseSlice = __webpack_require__(1071);

/**
 * Casts `array` to a slice if it's needed.
 *
 * @private
 * @param {Array} array The array to inspect.
 * @param {number} start The start position.
 * @param {number} [end=array.length] The end position.
 * @returns {Array} Returns the cast slice.
 */
function castSlice(array, start, end) {
  var length = array.length;
  end = end === undefined ? length : end;
  return (!start && end >= length) ? array : baseSlice(array, start, end);
}

module.exports = castSlice;


/***/ }),
/* 1159 */
/***/ (function(module, exports, __webpack_require__) {

var baseAssignValue = __webpack_require__(184),
    baseForOwn = __webpack_require__(1057),
    baseIteratee = __webpack_require__(1058);

/**
 * The opposite of `_.mapValues`; this method creates an object with the
 * same values as `object` and keys generated by running each own enumerable
 * string keyed property of `object` thru `iteratee`. The iteratee is invoked
 * with three arguments: (value, key, object).
 *
 * @static
 * @memberOf _
 * @since 3.8.0
 * @category Object
 * @param {Object} object The object to iterate over.
 * @param {Function} [iteratee=_.identity] The function invoked per iteration.
 * @returns {Object} Returns the new mapped object.
 * @see _.mapValues
 * @example
 *
 * _.mapKeys({ 'a': 1, 'b': 2 }, function(value, key) {
 *   return key + value;
 * });
 * // => { 'a1': 1, 'b2': 2 }
 */
function mapKeys(object, iteratee) {
  var result = {};
  iteratee = baseIteratee(iteratee, 3);

  baseForOwn(object, function(value, key, object) {
    baseAssignValue(result, iteratee(value, key, object), value);
  });
  return result;
}

module.exports = mapKeys;


/***/ }),
/* 1160 */
/***/ (function(module, exports, __webpack_require__) {

var arrayEach = __webpack_require__(319),
    baseCreate = __webpack_require__(325),
    baseForOwn = __webpack_require__(1057),
    baseIteratee = __webpack_require__(1058),
    getPrototype = __webpack_require__(185),
    isArray = __webpack_require__(92),
    isBuffer = __webpack_require__(182),
    isFunction = __webpack_require__(183),
    isObject = __webpack_require__(52),
    isTypedArray = __webpack_require__(310);

/**
 * An alternative to `_.reduce`; this method transforms `object` to a new
 * `accumulator` object which is the result of running each of its own
 * enumerable string keyed properties thru `iteratee`, with each invocation
 * potentially mutating the `accumulator` object. If `accumulator` is not
 * provided, a new object with the same `[[Prototype]]` will be used. The
 * iteratee is invoked with four arguments: (accumulator, value, key, object).
 * Iteratee functions may exit iteration early by explicitly returning `false`.
 *
 * @static
 * @memberOf _
 * @since 1.3.0
 * @category Object
 * @param {Object} object The object to iterate over.
 * @param {Function} [iteratee=_.identity] The function invoked per iteration.
 * @param {*} [accumulator] The custom accumulator value.
 * @returns {*} Returns the accumulated value.
 * @example
 *
 * _.transform([2, 3, 4], function(result, n) {
 *   result.push(n *= n);
 *   return n % 2 == 0;
 * }, []);
 * // => [4, 9]
 *
 * _.transform({ 'a': 1, 'b': 2, 'c': 1 }, function(result, value, key) {
 *   (result[value] || (result[value] = [])).push(key);
 * }, {});
 * // => { '1': ['a', 'c'], '2': ['b'] }
 */
function transform(object, iteratee, accumulator) {
  var isArr = isArray(object),
      isArrLike = isArr || isBuffer(object) || isTypedArray(object);

  iteratee = baseIteratee(iteratee, 4);
  if (accumulator == null) {
    var Ctor = object && object.constructor;
    if (isArrLike) {
      accumulator = isArr ? new Ctor : [];
    }
    else if (isObject(object)) {
      accumulator = isFunction(Ctor) ? baseCreate(getPrototype(object)) : {};
    }
    else {
      accumulator = {};
    }
  }
  (isArrLike ? arrayEach : baseForOwn)(object, function(value, index, object) {
    return iteratee(accumulator, value, index, object);
  });
  return accumulator;
}

module.exports = transform;


/***/ }),
/* 1161 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;
exports.default = sortFields;

var _has = __webpack_require__(1044);

var _has2 = _interopRequireDefault(_has);

var _toposort = __webpack_require__(1162);

var _toposort2 = _interopRequireDefault(_toposort);

var _propertyExpr = __webpack_require__(1051);

var _Reference = __webpack_require__(1049);

var _Reference2 = _interopRequireDefault(_Reference);

var _isSchema = __webpack_require__(1043);

var _isSchema2 = _interopRequireDefault(_isSchema);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function sortFields(fields) {
  var excludes = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : [];

  var edges = [],
      nodes = [];

  function addNode(depPath, key) {
    var node = (0, _propertyExpr.split)(depPath)[0];

    if (!~nodes.indexOf(node)) nodes.push(node);

    if (!~excludes.indexOf(key + '-' + node)) edges.push([key, node]);
  }

  for (var key in fields) {
    if ((0, _has2.default)(fields, key)) {
      var value = fields[key];

      if (!~nodes.indexOf(key)) nodes.push(key);

      if (_Reference2.default.isRef(value) && !value.isContext) addNode(value.path, key);else if ((0, _isSchema2.default)(value) && value._deps) value._deps.forEach(function (path) {
        return addNode(path, key);
      });
    }
  }return _toposort2.default.array(nodes, edges).reverse();
}
module.exports = exports['default'];

/***/ }),
/* 1162 */
/***/ (function(module, exports) {


/**
 * Topological sorting function
 *
 * @param {Array} edges
 * @returns {Array}
 */

module.exports = exports = function(edges){
  return toposort(uniqueNodes(edges), edges)
}

exports.array = toposort

function toposort(nodes, edges) {
  var cursor = nodes.length
    , sorted = new Array(cursor)
    , visited = {}
    , i = cursor

  while (i--) {
    if (!visited[i]) visit(nodes[i], i, [])
  }

  return sorted

  function visit(node, i, predecessors) {
    if(predecessors.indexOf(node) >= 0) {
      throw new Error('Cyclic dependency: '+JSON.stringify(node))
    }

    if (visited[i]) return;
    visited[i] = true

    // outgoing edges
    var outgoing = edges.filter(function(edge){
      return edge[0] === node
    })
    if (i = outgoing.length) {
      var preds = predecessors.concat(node)
      do {
        var child = outgoing[--i][1]
        visit(child, nodes.indexOf(child), preds)
      } while (i)
    }

    sorted[--cursor] = node
  }
}

function uniqueNodes(arr){
  var res = []
  for (var i = 0, len = arr.length; i < len; i++) {
    var edge = arr[i]
    if (res.indexOf(edge[0]) < 0) res.push(edge[0])
    if (res.indexOf(edge[1]) < 0) res.push(edge[1])
  }
  return res
}


/***/ }),
/* 1163 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;
exports.default = sortByKeyOrder;

function findIndex(arr, err) {
  var idx = Infinity;
  arr.some(function (key, ii) {
    if (err.path.indexOf(key) !== -1) {
      idx = ii;
      return true;
    }
  });

  return idx;
}

function sortByKeyOrder(fields) {
  var keys = Object.keys(fields);
  return function (a, b) {
    return findIndex(keys, a) - findIndex(keys, b);
  };
}
module.exports = exports["default"];

/***/ }),
/* 1164 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;

var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };

var _templateObject = _taggedTemplateLiteralLoose(['', '[', ']'], ['', '[', ']']);

var _typeName = __webpack_require__(1165);

var _typeName2 = _interopRequireDefault(_typeName);

var _inherits = __webpack_require__(1046);

var _inherits2 = _interopRequireDefault(_inherits);

var _isAbsent = __webpack_require__(1048);

var _isAbsent2 = _interopRequireDefault(_isAbsent);

var _isSchema = __webpack_require__(1043);

var _isSchema2 = _interopRequireDefault(_isSchema);

var _makePath = __webpack_require__(1073);

var _makePath2 = _interopRequireDefault(_makePath);

var _mixed = __webpack_require__(1042);

var _mixed2 = _interopRequireDefault(_mixed);

var _locale = __webpack_require__(1045);

var _runValidations = __webpack_require__(1055);

var _runValidations2 = _interopRequireDefault(_runValidations);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _taggedTemplateLiteralLoose(strings, raw) { strings.raw = raw; return strings; }

var hasLength = function hasLength(value) {
  return !(0, _isAbsent2.default)(value) && value.length > 0;
};

exports.default = ArraySchema;


function ArraySchema(type) {
  var _this = this;

  if (!(this instanceof ArraySchema)) return new ArraySchema(type);

  _mixed2.default.call(this, { type: 'array' });

  // `undefined` specifically means uninitialized, as opposed to
  // "no subtype"
  this._subType = undefined;

  this.withMutation(function () {
    _this.transform(function (values) {
      if (typeof values === 'string') try {
        values = JSON.parse(values);
      } catch (err) {
        values = null;
      }

      return this.isType(values) ? values : null;
    });

    if (type) _this.of(type);
  });
}

(0, _inherits2.default)(ArraySchema, _mixed2.default, {
  _typeCheck: function _typeCheck(v) {
    return Array.isArray(v);
  },
  _cast: function _cast(_value, _opts) {
    var _this2 = this;

    var value = _mixed2.default.prototype._cast.call(this, _value, _opts);

    //should ignore nulls here
    if (!this._typeCheck(value) || !this._subType) return value;

    return value.map(function (v) {
      return _this2._subType.cast(v, _opts);
    });
  },
  _validate: function _validate(_value) {
    var _this3 = this;

    var options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};

    var errors = [];
    var sync = options.sync;
    var path = options.path;
    var subType = this._subType;
    var endEarly = this._option('abortEarly', options);
    var recursive = this._option('recursive', options);

    var originalValue = options.originalValue != null ? options.originalValue : _value;

    return _mixed2.default.prototype._validate.call(this, _value, options).catch((0, _runValidations.propagateErrors)(endEarly, errors)).then(function (value) {
      if (!recursive || !subType || !_this3._typeCheck(value)) {
        if (errors.length) throw errors[0];
        return value;
      }

      originalValue = originalValue || value;

      var validations = value.map(function (item, idx) {
        var path = (0, _makePath2.default)(_templateObject, options.path, idx);

        // object._validate note for isStrict explanation
        var innerOptions = _extends({}, options, {
          path: path,
          strict: true,
          parent: value,
          originalValue: originalValue[idx]
        });

        if (subType.validate) return subType.validate(item, innerOptions);

        return true;
      });

      return (0, _runValidations2.default)({
        sync: sync,
        path: path,
        value: value,
        errors: errors,
        endEarly: endEarly,
        validations: validations
      });
    });
  },
  of: function of(schema) {
    var next = this.clone();

    if (schema !== false && !(0, _isSchema2.default)(schema)) throw new TypeError('`array.of()` sub-schema must be a valid yup schema, or `false` to negate a current sub-schema. ' + 'not: ' + (0, _typeName2.default)(schema));

    next._subType = schema;

    return next;
  },
  required: function required(msg) {
    var next = _mixed2.default.prototype.required.call(this, msg || _locale.mixed.required);

    return next.test('required', msg || _locale.mixed.required, hasLength);
  },
  min: function min(_min, message) {
    message = message || _locale.array.min;

    return this.test({
      message: message,
      name: 'min',
      exclusive: true,
      params: { min: _min },
      test: function test(value) {
        return (0, _isAbsent2.default)(value) || value.length >= this.resolve(_min);
      }
    });
  },
  max: function max(_max, message) {
    message = message || _locale.array.max;
    return this.test({
      message: message,
      name: 'max',
      exclusive: true,
      params: { max: _max },
      test: function test(value) {
        return (0, _isAbsent2.default)(value) || value.length <= this.resolve(_max);
      }
    });
  },
  ensure: function ensure() {
    return this.default(function () {
      return [];
    }).transform(function (val) {
      return val === null ? [] : [].concat(val);
    });
  },
  compact: function compact(rejector) {
    var reject = !rejector ? function (v) {
      return !!v;
    } : function (v, i, a) {
      return !rejector(v, i, a);
    };

    return this.transform(function (values) {
      return values != null ? values.filter(reject) : values;
    });
  }
});
module.exports = exports['default'];

/***/ }),
/* 1165 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/**
 * type-name - Just a reasonable typeof
 *
 * https://github.com/twada/type-name
 *
 * Copyright (c) 2014-2016 Takuto Wada
 * Licensed under the MIT license.
 *   https://github.com/twada/type-name/blob/master/LICENSE
 */


var toStr = Object.prototype.toString;

function funcName (f) {
    if (f.name) {
        return f.name;
    }
    var match = /^\s*function\s*([^\(]*)/im.exec(f.toString());
    return match ? match[1] : '';
}

function ctorName (obj) {
    var strName = toStr.call(obj).slice(8, -1);
    if ((strName === 'Object' || strName === 'Error') && obj.constructor) {
        return funcName(obj.constructor);
    }
    return strName;
}

function typeName (val) {
    var type;
    if (val === null) {
        return 'null';
    }
    type = typeof val;
    if (type === 'object') {
        return ctorName(val);
    }
    return type;
}

module.exports = typeName;


/***/ }),
/* 1166 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;

var _isSchema = __webpack_require__(1043);

var _isSchema2 = _interopRequireDefault(_isSchema);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _objectWithoutProperties(obj, keys) { var target = {}; for (var i in obj) { if (keys.indexOf(i) >= 0) continue; if (!Object.prototype.hasOwnProperty.call(obj, i)) continue; target[i] = obj[i]; } return target; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var Lazy = function () {
  function Lazy(mapFn) {
    _classCallCheck(this, Lazy);

    this._resolve = function () {
      var schema = mapFn.apply(undefined, arguments);
      if (!(0, _isSchema2.default)(schema)) throw new TypeError('lazy() functions must return a valid schema');

      return schema;
    };
  }

  Lazy.prototype.resolve = function resolve(_ref) {
    var value = _ref.value,
        rest = _objectWithoutProperties(_ref, ['value']);

    return this._resolve(value, rest);
  };

  Lazy.prototype.cast = function cast(value, options) {
    return this._resolve(value, options).cast(value, options);
  };

  Lazy.prototype.validate = function validate(value, options) {
    return this._resolve(value, options).validate(value, options);
  };

  return Lazy;
}();

Lazy.prototype.__isYupSchema__ = true;

exports.default = Lazy;
module.exports = exports['default'];

/***/ }),
/* 1167 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;
exports.default = reach;

var _propertyExpr = __webpack_require__(1051);

var _has = __webpack_require__(1044);

var _has2 = _interopRequireDefault(_has);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var trim = function trim(part) {
  return part.substr(0, part.length - 1).substr(1);
};

function reach(obj, path, value, context) {
  var parent = void 0,
      lastPart = void 0;

  // if only one "value" arg then use it for both
  context = context || value;

  (0, _propertyExpr.forEach)(path, function (_part, isBracket, isArray) {
    var part = isBracket ? trim(_part) : _part;

    if (isArray || (0, _has2.default)(obj, '_subType')) {
      // we skipped an array: foo[].bar
      var idx = isArray ? parseInt(part, 10) : 0;

      obj = obj.resolve({ context: context, parent: parent, value: value })._subType;

      if (value) {
        if (isArray && idx >= value.length) {
          throw new Error('Yup.reach cannot resolve an array item at index: ' + _part + ', in the path: ' + path + '. ' + 'because there is no value at that index. ');
        }

        value = value[idx];
      }
    }

    if (!isArray) {
      obj = obj.resolve({ context: context, parent: parent, value: value });

      if (!(0, _has2.default)(obj, 'fields') || !(0, _has2.default)(obj.fields, part)) throw new Error('The schema does not contain the path: ' + path + '. ' + ('(failed at: ' + lastPart + ' which is a type: "' + obj._type + '") '));

      obj = obj.fields[part];

      parent = value;
      value = value && value[part];
      lastPart = isBracket ? '[' + _part + ']' : '.' + _part;
    }
  });

  if (obj) {
    obj = obj.resolve({ context: context, parent: parent, value: value });
  }

  return obj;
}
module.exports = exports['default'];

/***/ }),
/* 1168 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "b", function() { return DeclinesPropTypes; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return ApplicationPropType; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "c", function() { return MortgageSsoPropType; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "d", function() { return ServicingPropTypes; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_prop_types__ = __webpack_require__(1);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_prop_types___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_prop_types__);
var DeclinesPropTypes=__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.shape({avantDecline:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.bool,code:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string,declineDocUrl:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string,description:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string,ficoReasons:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.arrayOf(__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string),icon:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string,title:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string});var ApplicationPropType=__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.shape({id:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.number.isRequired,type:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string.isRequired,amount:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.number,currentRate:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.number,status:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string.isRequired,statusDesc:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string.isRequired,servicingAccess:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string,servicing:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.shape({accountId:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.number,statusDesc:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string,status:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string}),continueUrl:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string.isRequired,docs:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.arrayOf(__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.shape({type:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string.isRequired,url:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string.isRequired})),welcomeBonusAmount:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.number,welcomeBonusStatus:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string,welcomeBonusUrl:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string,primaryApplicantName:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string,declines:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.arrayOf(__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.arrayOf(DeclinesPropTypes)),rateLockDate:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string,active:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.bool.isRequired,role:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string,otherApplicant:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string,esigned:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.bool.isRequired,productDesc:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string.isRequired});var MortgageSsoPropType=__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.shape({id:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string});var ServicingPropTypes=__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.shape({accessUrl:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string});

/***/ }),
/* 1169 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "b", function() { return AlertNotification; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return AlertContent; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "c", function() { return AlertParagraph; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_styled_components__ = __webpack_require__(3);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_scuid_x__ = __webpack_require__(14);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_scuid_x___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_scuid_x__);
var _templateObject=_taggedTemplateLiteral(['\n  margin-bottom: 10px;\n  padding-left: 0px;\n  padding-right: 0px;\n  .close {\n    margin: -6px auto 0;\n    max-width: 1230px;\n    text-align: right;\n    height: 6px;\n    position: relative;\n  }\n'],['\n  margin-bottom: 10px;\n  padding-left: 0px;\n  padding-right: 0px;\n  .close {\n    margin: -6px auto 0;\n    max-width: 1230px;\n    text-align: right;\n    height: 6px;\n    position: relative;\n  }\n']),_templateObject2=_taggedTemplateLiteral(['\n  max-width: 1200px;\n  margin: 0 auto;\n  padding-right: 70px;\n  display: flex;\n  flex-direction: column;\n  justify-content: space-between;\n  font-size: 14px;\n  @media (max-width: 1250px) {\n    padding-left: 20px;\n  }\n  @media (min-width: 992px) {\n    flex-direction: row;\n    span {\n      max-width: 85%;\n    }\n    a {\n      text-align: right;\n    }\n  }\n  a {\n    cursor: pointer;\n    text-decoration: none;\n    font-weight: 500;\n  }\n'],['\n  max-width: 1200px;\n  margin: 0 auto;\n  padding-right: 70px;\n  display: flex;\n  flex-direction: column;\n  justify-content: space-between;\n  font-size: 14px;\n  @media (max-width: 1250px) {\n    padding-left: 20px;\n  }\n  @media (min-width: 992px) {\n    flex-direction: row;\n    span {\n      max-width: 85%;\n    }\n    a {\n      text-align: right;\n    }\n  }\n  a {\n    cursor: pointer;\n    text-decoration: none;\n    font-weight: 500;\n  }\n']),_templateObject3=_taggedTemplateLiteral(['\n  padding: 0;\n  font-size: 14px;\n'],['\n  padding: 0;\n  font-size: 14px;\n']);function _taggedTemplateLiteral(strings,raw){return Object.freeze(Object.defineProperties(strings,{raw:{value:Object.freeze(raw)}}));}var AlertNotification=Object(__WEBPACK_IMPORTED_MODULE_0_styled_components__["default"])(__WEBPACK_IMPORTED_MODULE_1_scuid_x__["NotificationBar"])(_templateObject);var AlertContent=__WEBPACK_IMPORTED_MODULE_0_styled_components__["default"].div(_templateObject2);var AlertParagraph=Object(__WEBPACK_IMPORTED_MODULE_0_styled_components__["default"])(__WEBPACK_IMPORTED_MODULE_1_scuid_x__["Paragraph"])(_templateObject3);

/***/ }),
/* 1170 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return StatesPropTypes; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_prop_types__ = __webpack_require__(1);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_prop_types___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_prop_types__);
// Alpha2 and name is what comes back from API, but we need value and label for Scuid Dropdown
var StatesPropTypes=__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.arrayOf(__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.shape({label:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string,value:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string,alpha2:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string,name:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string}));

/***/ }),
/* 1171 */
/***/ (function(module, exports, __webpack_require__) {

var baseKeys = __webpack_require__(329),
    getTag = __webpack_require__(121),
    isArguments = __webpack_require__(309),
    isArray = __webpack_require__(92),
    isArrayLike = __webpack_require__(186),
    isBuffer = __webpack_require__(182),
    isPrototype = __webpack_require__(125),
    isTypedArray = __webpack_require__(310);

/** `Object#toString` result references. */
var mapTag = '[object Map]',
    setTag = '[object Set]';

/** Used for built-in method references. */
var objectProto = Object.prototype;

/** Used to check objects for own properties. */
var hasOwnProperty = objectProto.hasOwnProperty;

/**
 * Checks if `value` is an empty object, collection, map, or set.
 *
 * Objects are considered empty if they have no own enumerable string keyed
 * properties.
 *
 * Array-like values such as `arguments` objects, arrays, buffers, strings, or
 * jQuery-like collections are considered empty if they have a `length` of `0`.
 * Similarly, maps and sets are considered empty if they have a `size` of `0`.
 *
 * @static
 * @memberOf _
 * @since 0.1.0
 * @category Lang
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is empty, else `false`.
 * @example
 *
 * _.isEmpty(null);
 * // => true
 *
 * _.isEmpty(true);
 * // => true
 *
 * _.isEmpty(1);
 * // => true
 *
 * _.isEmpty([1, 2, 3]);
 * // => false
 *
 * _.isEmpty({ 'a': 1 });
 * // => false
 */
function isEmpty(value) {
  if (value == null) {
    return true;
  }
  if (isArrayLike(value) &&
      (isArray(value) || typeof value == 'string' || typeof value.splice == 'function' ||
        isBuffer(value) || isTypedArray(value) || isArguments(value))) {
    return !value.length;
  }
  var tag = getTag(value);
  if (tag == mapTag || tag == setTag) {
    return !value.size;
  }
  if (isPrototype(value)) {
    return !baseKeys(value).length;
  }
  for (var key in value) {
    if (hasOwnProperty.call(value, key)) {
      return false;
    }
  }
  return true;
}

module.exports = isEmpty;


/***/ }),
/* 1172 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "e", function() { return getReferralSummary; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "d", function() { return getReferralConsents; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "n", function() { return updateReferralConsent; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "g", function() { return getReferrer; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "k", function() { return postCreateReferrer; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "h", function() { return getReferrerProgress; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "j", function() { return getWaterBottleModalStatus; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return getBackpackModalStatus; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "p", function() { return updateRewardModalVisibility; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "b", function() { return getContacts; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "l", function() { return postReferralContacts; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "c", function() { return getReferralBankAccount; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "m", function() { return updateReferralBankAccount; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "f", function() { return getReferralW9; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "o", function() { return updateReferralW9; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "i", function() { return getReferrerals; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_babel_runtime_regenerator__ = __webpack_require__(122);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_babel_runtime_regenerator___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_babel_runtime_regenerator__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__utilities_api_action_helpers__ = __webpack_require__(93);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__constants__ = __webpack_require__(79);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__constants_referral_constants__ = __webpack_require__(315);
var _this=this;function _asyncToGenerator(fn){return function(){var gen=fn.apply(this,arguments);return new Promise(function(resolve,reject){function step(key,arg){try{var info=gen[key](arg);var value=info.value;}catch(error){reject(error);return;}if(info.done){resolve(value);}else{return Promise.resolve(value).then(function(value){step("next",value);},function(err){step("throw",err);});}}return step("next");});};}var getReferralSummary=function getReferralSummary(){return function(dispatch){return Object(__WEBPACK_IMPORTED_MODULE_1__utilities_api_action_helpers__["b" /* performGet */])(dispatch,__WEBPACK_IMPORTED_MODULE_2__constants__["a" /* API_URL */]+'/affiliate/referral/summary',{},__WEBPACK_IMPORTED_MODULE_3__constants_referral_constants__["l" /* GET_REFERRAL_SUMMARY */],true);};};var getReferralConsents=function getReferralConsents(){return function(dispatch){Object(__WEBPACK_IMPORTED_MODULE_1__utilities_api_action_helpers__["b" /* performGet */])(dispatch,__WEBPACK_IMPORTED_MODULE_2__constants__["a" /* API_URL */]+'/affiliate/referral/consents',{},__WEBPACK_IMPORTED_MODULE_3__constants_referral_constants__["j" /* GET_REFERRAL_CONSENTS */]);};};var updateReferralConsent=function updateReferralConsent(referralConsent,setErrors){return function(dispatch){return Object(__WEBPACK_IMPORTED_MODULE_1__utilities_api_action_helpers__["c" /* performPost */])(dispatch,__WEBPACK_IMPORTED_MODULE_2__constants__["a" /* API_URL */]+'/affiliate/referral/consents',{},referralConsent,__WEBPACK_IMPORTED_MODULE_3__constants_referral_constants__["u" /* POST_REFERRAL_CONSENTS */],setErrors);};};var getReferrer=function getReferrer(){return function(dispatch){Object(__WEBPACK_IMPORTED_MODULE_1__utilities_api_action_helpers__["b" /* performGet */])(dispatch,__WEBPACK_IMPORTED_MODULE_2__constants__["d" /* REFERRAL_URL */]+'/referrer',{},__WEBPACK_IMPORTED_MODULE_3__constants_referral_constants__["m" /* GET_REFERRER */]);};};var postCreateReferrer=function postCreateReferrer(createReferrer){return function(dispatch){Object(__WEBPACK_IMPORTED_MODULE_1__utilities_api_action_helpers__["c" /* performPost */])(dispatch,__WEBPACK_IMPORTED_MODULE_2__constants__["d" /* REFERRAL_URL */]+'/referrer',{},createReferrer,__WEBPACK_IMPORTED_MODULE_3__constants_referral_constants__["t" /* POST_CREATE_REFERRER */]);};};var getReferrerProgress=function getReferrerProgress(){return function(dispatch){Object(__WEBPACK_IMPORTED_MODULE_1__utilities_api_action_helpers__["b" /* performGet */])(dispatch,__WEBPACK_IMPORTED_MODULE_2__constants__["d" /* REFERRAL_URL */]+'/referrer/progress',{},__WEBPACK_IMPORTED_MODULE_3__constants_referral_constants__["n" /* GET_REFERRER_PROGRESS */]);};};var getWaterBottleModalStatus=function getWaterBottleModalStatus(){return function(dispatch){Object(__WEBPACK_IMPORTED_MODULE_1__utilities_api_action_helpers__["b" /* performGet */])(dispatch,__WEBPACK_IMPORTED_MODULE_2__constants__["e" /* REFERRER_URL */]+'/referral-modal/REFERRAL',{},__WEBPACK_IMPORTED_MODULE_3__constants_referral_constants__["p" /* GET_WATER_BOTTLE_MODAL_STATUS */]);};};var getBackpackModalStatus=function getBackpackModalStatus(){return function(dispatch){Object(__WEBPACK_IMPORTED_MODULE_1__utilities_api_action_helpers__["b" /* performGet */])(dispatch,__WEBPACK_IMPORTED_MODULE_2__constants__["e" /* REFERRER_URL */]+'/referral-modal/APP_CREATED',{},__WEBPACK_IMPORTED_MODULE_3__constants_referral_constants__["g" /* GET_BACKPACK_MODAL_STATUS */]);};};var updateRewardModalVisibility=function updateRewardModalVisibility(type,setErrors){return function(dispatch){Object(__WEBPACK_IMPORTED_MODULE_1__utilities_api_action_helpers__["d" /* performPut */])(dispatch,__WEBPACK_IMPORTED_MODULE_2__constants__["e" /* REFERRER_URL */]+'/referral-modal/'+type,{},__WEBPACK_IMPORTED_MODULE_3__constants_referral_constants__["B" /* UPDATE_REWARD_MODAL_VISIBILITY */],setErrors);};};var getContacts=function getContacts(){return function(){var _ref=_asyncToGenerator(/*#__PURE__*/__WEBPACK_IMPORTED_MODULE_0_babel_runtime_regenerator___default.a.mark(function _callee(dispatch){return __WEBPACK_IMPORTED_MODULE_0_babel_runtime_regenerator___default.a.wrap(function _callee$(_context){while(1){switch(_context.prev=_context.next){case 0:Object(__WEBPACK_IMPORTED_MODULE_1__utilities_api_action_helpers__["b" /* performGet */])(dispatch,__WEBPACK_IMPORTED_MODULE_2__constants__["d" /* REFERRAL_URL */]+'/contacts/google',{},__WEBPACK_IMPORTED_MODULE_3__constants_referral_constants__["k" /* GET_REFERRAL_CONTACTS */]);case 1:case'end':return _context.stop();}}},_callee,_this);}));return function(_x){return _ref.apply(this,arguments);};}();};// eslint-disable-next-line arrow-body-style
var postReferralContacts=function postReferralContacts(postBody){return function(dispatch){return Object(__WEBPACK_IMPORTED_MODULE_1__utilities_api_action_helpers__["c" /* performPost */])(dispatch,__WEBPACK_IMPORTED_MODULE_2__constants__["d" /* REFERRAL_URL */]+'/referrer/referrals',{},postBody,__WEBPACK_IMPORTED_MODULE_3__constants_referral_constants__["v" /* POST_REFERRAL_CONTACTS */]);};};var getReferralBankAccount=function getReferralBankAccount(){return function(dispatch){Object(__WEBPACK_IMPORTED_MODULE_1__utilities_api_action_helpers__["b" /* performGet */])(dispatch,__WEBPACK_IMPORTED_MODULE_2__constants__["a" /* API_URL */]+'/affiliate/referral/ach',{},__WEBPACK_IMPORTED_MODULE_3__constants_referral_constants__["h" /* GET_BANK_ACCOUNT */]);};};var updateReferralBankAccount=function updateReferralBankAccount(accountInfo,setErrors){return function(dispatch){Object(__WEBPACK_IMPORTED_MODULE_1__utilities_api_action_helpers__["c" /* performPost */])(dispatch,__WEBPACK_IMPORTED_MODULE_2__constants__["a" /* API_URL */]+'/affiliate/referral/ach',{},accountInfo,__WEBPACK_IMPORTED_MODULE_3__constants_referral_constants__["A" /* UPDATE_BANK_ACCOUNT */],setErrors);};};var REFERRAL_W9_INFO=__WEBPACK_IMPORTED_MODULE_2__constants__["a" /* API_URL */]+'/affiliate/referral/w9/info';var getReferralW9=function getReferralW9(){return function(dispatch){Object(__WEBPACK_IMPORTED_MODULE_1__utilities_api_action_helpers__["b" /* performGet */])(dispatch,REFERRAL_W9_INFO,{},__WEBPACK_IMPORTED_MODULE_3__constants_referral_constants__["o" /* GET_W9_INFO */],true);};};var updateReferralW9=function updateReferralW9(setErrors){return function(dispatch){Object(__WEBPACK_IMPORTED_MODULE_1__utilities_api_action_helpers__["c" /* performPost */])(dispatch,REFERRAL_W9_INFO,{},null,__WEBPACK_IMPORTED_MODULE_3__constants_referral_constants__["w" /* POST_W9_INFO */],setErrors);};};var getReferrerals=function getReferrerals(){return function(dispatch){Object(__WEBPACK_IMPORTED_MODULE_1__utilities_api_action_helpers__["b" /* performGet */])(dispatch,__WEBPACK_IMPORTED_MODULE_2__constants__["d" /* REFERRAL_URL */]+'/referrer/referrals',{},__WEBPACK_IMPORTED_MODULE_3__constants_referral_constants__["i" /* GET_REFERRALS */]);};};

/***/ }),
/* 1173 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return Attention; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "f", function() { return LoanBody; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "j", function() { return LoanSummary; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "c", function() { return LoanAction; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "e", function() { return LoanAmount; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "h", function() { return LoanButton; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "d", function() { return LoanAdditionalInfo; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "i", function() { return LoanDescription; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "b", function() { return DropdownContainer; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "g", function() { return LoanBottomBorder; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_styled_components__ = __webpack_require__(3);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_scuid_x__ = __webpack_require__(14);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_scuid_x___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_scuid_x__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__themes__ = __webpack_require__(1178);
var _templateObject=_taggedTemplateLiteral(['\n  color: ',';\n'],['\n  color: ',';\n']),_templateObject2=_taggedTemplateLiteral(['\n  @media (max-width: 767px) {\n    flex-direction: column;\n    margin-top: 0.5rem;\n  }\n'],['\n  @media (max-width: 767px) {\n    flex-direction: column;\n    margin-top: 0.5rem;\n  }\n']),_templateObject3=_taggedTemplateLiteral(['\n  display: flex;\n  align-items: flex-end;\n  color: ',';\n  font-size: 1.6rem;\n  span {\n    display: block;\n    color: ',';\n    font-size: 0.9rem;\n  }\n  @media (max-width: 767px) {\n    justify-content: space-between;\n    flex-direction: column;\n    align-items: flex-start;\n  }\n'],['\n  display: flex;\n  align-items: flex-end;\n  color: ',';\n  font-size: 1.6rem;\n  span {\n    display: block;\n    color: ',';\n    font-size: 0.9rem;\n  }\n  @media (max-width: 767px) {\n    justify-content: space-between;\n    flex-direction: column;\n    align-items: flex-start;\n  }\n']),_templateObject4=_taggedTemplateLiteral(['\n  display: flex;\n  flex-direction: column;\n  &:only-child {\n    width: 100%;\n    text-align: right;\n  }\n  @media (max-width: 767px) {\n    flex-direction: row;\n    align-items: center;\n    margin-top: 1rem;\n  }\n'],['\n  display: flex;\n  flex-direction: column;\n  &:only-child {\n    width: 100%;\n    text-align: right;\n  }\n  @media (max-width: 767px) {\n    flex-direction: row;\n    align-items: center;\n    margin-top: 1rem;\n  }\n']),_templateObject5=_taggedTemplateLiteral(['\n  @media (min-width: 992px) {\n    width: 20rem;\n    font-size: 1.88rem;\n  }\n  @media (max-width: 991px) and (min-width: 768px) {\n    width: 15rem;\n    font-size: 1.5rem;\n  }\n'],['\n  @media (min-width: 992px) {\n    width: 20rem;\n    font-size: 1.88rem;\n  }\n  @media (max-width: 991px) and (min-width: 768px) {\n    width: 15rem;\n    font-size: 1.5rem;\n  }\n']),_templateObject6=_taggedTemplateLiteral(['\n  width: 9rem;\n  font-size: 0.9rem;\n  padding: 9px;\n'],['\n  width: 9rem;\n  font-size: 0.9rem;\n  padding: 9px;\n']),_templateObject7=_taggedTemplateLiteral(['\n  display: flex;\n  div:not(:last-child) {\n    margin-right: 6rem;\n  }\n  @media (max-width: 767px) {\n    div:not(:last-child) {\n      margin-right: 2rem;\n    }\n  }\n'],['\n  display: flex;\n  div:not(:last-child) {\n    margin-right: 6rem;\n  }\n  @media (max-width: 767px) {\n    div:not(:last-child) {\n      margin-right: 2rem;\n    }\n  }\n']),_templateObject8=_taggedTemplateLiteral(['\n  color: #757575;\n  padding: 0px;\n'],['\n  color: #757575;\n  padding: 0px;\n']),_templateObject9=_taggedTemplateLiteral(['\n  position: relative;\n'],['\n  position: relative;\n']),_templateObject10=_taggedTemplateLiteral(['\n  position: relative;\n  width: 100%;\n  margin-bottom: 1rem;\n  padding-bottom: 0.5rem;\n  border-bottom: 1px solid #e6e7e8;\n  @media (min-width: 768px) {\n    padding-bottom: 1rem;\n  }\n'],['\n  position: relative;\n  width: 100%;\n  margin-bottom: 1rem;\n  padding-bottom: 0.5rem;\n  border-bottom: 1px solid #e6e7e8;\n  @media (min-width: 768px) {\n    padding-bottom: 1rem;\n  }\n']);function _taggedTemplateLiteral(strings,raw){return Object.freeze(Object.defineProperties(strings,{raw:{value:Object.freeze(raw)}}));}var Attention=__WEBPACK_IMPORTED_MODULE_0_styled_components__["default"].span(_templateObject,__WEBPACK_IMPORTED_MODULE_2__themes__["a" /* Colors */].attention);var LoanBody=Object(__WEBPACK_IMPORTED_MODULE_0_styled_components__["default"])(__WEBPACK_IMPORTED_MODULE_1_scuid_x__["FlexBox"])(_templateObject2);var LoanSummary=__WEBPACK_IMPORTED_MODULE_0_styled_components__["default"].div(_templateObject3,__WEBPACK_IMPORTED_MODULE_2__themes__["a" /* Colors */].loanAmount,__WEBPACK_IMPORTED_MODULE_2__themes__["a" /* Colors */].loanTitle);var LoanAction=__WEBPACK_IMPORTED_MODULE_0_styled_components__["default"].div(_templateObject4);var LoanAmount=__WEBPACK_IMPORTED_MODULE_0_styled_components__["default"].div(_templateObject5);var LoanButton=Object(__WEBPACK_IMPORTED_MODULE_0_styled_components__["default"])(__WEBPACK_IMPORTED_MODULE_1_scuid_x__["Button"])(_templateObject6);var LoanAdditionalInfo=__WEBPACK_IMPORTED_MODULE_0_styled_components__["default"].div(_templateObject7);var LoanDescription=Object(__WEBPACK_IMPORTED_MODULE_0_styled_components__["default"])(__WEBPACK_IMPORTED_MODULE_1_scuid_x__["Paragraph"])(_templateObject8);var DropdownContainer=__WEBPACK_IMPORTED_MODULE_0_styled_components__["default"].div(_templateObject9);var LoanBottomBorder=__WEBPACK_IMPORTED_MODULE_0_styled_components__["default"].div(_templateObject10);

/***/ }),
/* 1174 */,
/* 1175 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return ReasonContainer; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_styled_components__ = __webpack_require__(3);
var _templateObject=_taggedTemplateLiteral(['\n  font-size: 1rem;\n  ul {\n    padding-left: 1rem;\n  }\n  p {\n    margin-top: 10px;\n    &:first-child {\n      margin-top: 0;\n    }\n    @media only screen and (min-width: 20em) {\n      font-size: calc(0.875rem + 0.125 * ((100vw - 20em) / 48));\n    }\n  }\n  strong {\n    font-weight: 500;\n  }\n'],['\n  font-size: 1rem;\n  ul {\n    padding-left: 1rem;\n  }\n  p {\n    margin-top: 10px;\n    &:first-child {\n      margin-top: 0;\n    }\n    @media only screen and (min-width: 20em) {\n      font-size: calc(0.875rem + 0.125 * ((100vw - 20em) / 48));\n    }\n  }\n  strong {\n    font-weight: 500;\n  }\n']);function _taggedTemplateLiteral(strings,raw){return Object.freeze(Object.defineProperties(strings,{raw:{value:Object.freeze(raw)}}));}// import { Paragraph } from 'scuid-x';
var ReasonContainer=__WEBPACK_IMPORTED_MODULE_0_styled_components__["default"].div(_templateObject);

/***/ }),
/* 1176 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return FORMAT_CURRENCY; });
// To replace formatCurrency
var FORMAT_CURRENCY=function FORMAT_CURRENCY(val){var num=Number(val);if(num<0){// Handle negative formatting
return'-$'+Math.abs(num).toFixed(2).replace(/(\d)(?=(\d{3})+(?!\d))/g,'$1,');}return'$'+num.toFixed(2).replace(/(\d)(?=(\d{3})+(?!\d))/g,'$1,');};

/***/ }),
/* 1177 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return getStates; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__utilities_api_action_helpers__ = __webpack_require__(93);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__constants__ = __webpack_require__(79);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__constants_states_constants__ = __webpack_require__(330);
var getStates=function getStates(){return function(dispatch){Object(__WEBPACK_IMPORTED_MODULE_0__utilities_api_action_helpers__["b" /* performGet */])(dispatch,__WEBPACK_IMPORTED_MODULE_1__constants__["a" /* API_URL */]+'/states',{},__WEBPACK_IMPORTED_MODULE_2__constants_states_constants__["a" /* GET_STATES */]);};};

/***/ }),
/* 1178 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__colors__ = __webpack_require__(1179);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__fonts__ = __webpack_require__(1180);
/* harmony reexport (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return __WEBPACK_IMPORTED_MODULE_0__colors__["a"]; });
/* unused harmony reexport Fonts */


/***/ }),
/* 1179 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
var colors={defaultText:'#757575',loanAmount:'#262626',loanTitle:'#757575',attention:'#ee6352',policy:{text:'#797979',link:'#117db0',borderBottom:'#e6e7e8',footer:'#757575',tableHeader:'#262626'}};/* harmony default export */ __webpack_exports__["a"] = (colors);

/***/ }),
/* 1180 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
var size={h1:'3.2rem',h2:'2.4rem',h3:'2.2rem',h4:'1.8rem',h5:'1.6rem',h6:'1.1rem'};/* unused harmony default export */ var _unused_webpack_default_export = ({size:size});

/***/ }),
/* 1181 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return getApplications; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "b", function() { return getApplicationsServicing; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "d", function() { return getMortgageSso; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "e", function() { return postApplicationRetry; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "c", function() { return getDashboardAccounts; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__utilities_api_action_helpers__ = __webpack_require__(93);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__constants__ = __webpack_require__(79);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__constants_application_constants__ = __webpack_require__(332);
/**
 * Get all the customer applications
 */var getApplications=function getApplications(){return function(dispatch){return Object(__WEBPACK_IMPORTED_MODULE_0__utilities_api_action_helpers__["b" /* performGet */])(dispatch,__WEBPACK_IMPORTED_MODULE_1__constants__["a" /* API_URL */]+'/applications',{},__WEBPACK_IMPORTED_MODULE_2__constants_application_constants__["a" /* GET_APPLICATIONS */]);};};/**
 * Get all the applications currently in servicing
 */var getApplicationsServicing=function getApplicationsServicing(){return function(dispatch){Object(__WEBPACK_IMPORTED_MODULE_0__utilities_api_action_helpers__["b" /* performGet */])(dispatch,__WEBPACK_IMPORTED_MODULE_1__constants__["a" /* API_URL */]+'/applications/servicing',{},__WEBPACK_IMPORTED_MODULE_2__constants_application_constants__["b" /* GET_APPLICATIONS_SERVICING */]);};};/**
 * Get mortgage (if the customer has been servicing)
 */var getMortgageSso=function getMortgageSso(){return function(dispatch){Object(__WEBPACK_IMPORTED_MODULE_0__utilities_api_action_helpers__["b" /* performGet */])(dispatch,__WEBPACK_IMPORTED_MODULE_1__constants__["a" /* API_URL */]+'/applications/mortgage-sso',{},__WEBPACK_IMPORTED_MODULE_2__constants_application_constants__["d" /* GET_MORTGAGE_SSO */]);};};/**
 * Post application retry with correct SSN
 * @param {Object} appRetry { appId: number, appType: '', coSsnRequired: bool, ssn: '', coSsn: '' }
 * @param {function} setErrors Formik's setErrors function (needed for server validation errors)
 */var postApplicationRetry=function postApplicationRetry(appRetry,setErrors){return function(dispatch){return Object(__WEBPACK_IMPORTED_MODULE_0__utilities_api_action_helpers__["c" /* performPost */])(dispatch,__WEBPACK_IMPORTED_MODULE_1__constants__["a" /* API_URL */]+'/applications/retry',{},appRetry,__WEBPACK_IMPORTED_MODULE_2__constants_application_constants__["e" /* POST_APPLICATION_RETRY */],setErrors);};};/**
 * Get all the accounts for a member
 */var getDashboardAccounts=function getDashboardAccounts(){return function(dispatch){Object(__WEBPACK_IMPORTED_MODULE_0__utilities_api_action_helpers__["b" /* performGet */])(dispatch,__WEBPACK_IMPORTED_MODULE_1__constants__["b" /* DASHBOARD_API_URL */]+'/group?key=accountCards',{},__WEBPACK_IMPORTED_MODULE_2__constants_application_constants__["c" /* GET_DASHBOARD_ACCOUNTS */]);};};

/***/ }),
/* 1182 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return QueryParamPropTypes; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_prop_types__ = __webpack_require__(1);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_prop_types___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_prop_types__);
var QueryParamPropTypes=__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.shape({action:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string.isRequired,appId:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.number,appType:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string.isRequired,applicantCount:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.number.isRequired,reason:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string.isRequired});

/***/ }),
/* 1183 */,
/* 1184 */,
/* 1185 */,
/* 1186 */,
/* 1187 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.getAllFeatureFlags = exports.FeatureFlag = exports.LaunchDarkly = undefined;

var _utils = __webpack_require__(1216);

Object.defineProperty(exports, "getAllFeatureFlags", {
  enumerable: true,
  get: function get() {
    return _utils.getAllFeatureFlags;
  }
});

var _LaunchDarkly2 = __webpack_require__(1259);

var _LaunchDarkly3 = _interopRequireDefault(_LaunchDarkly2);

var _FeatureFlag2 = __webpack_require__(1262);

var _FeatureFlag3 = _interopRequireDefault(_FeatureFlag2);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.LaunchDarkly = _LaunchDarkly3.default;
exports.FeatureFlag = _FeatureFlag3.default;

/***/ }),
/* 1188 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "g", function() { return LAUNCH_DARKLY_CLIENT_ID_TEST; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "f", function() { return LAUNCH_DARKLY_CLIENT_ID_STAGING; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "e", function() { return LAUNCH_DARKLY_CLIENT_ID_PROD; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return FEATURE_FLAG_ACCOUNT_CARDS; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "d", function() { return FEATURE_FLAG_WEALTH_BANNER_AD; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "b", function() { return FEATURE_FLAG_DASHBOARD_CONTENT_CARDS; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "c", function() { return FEATURE_FLAG_MEMBER_DASHBOARD_CMS_PRODUCT_OFFERINGS; });
// Client Ids
var LAUNCH_DARKLY_CLIENT_ID_TEST='59d554b757557d0acab6119c';var LAUNCH_DARKLY_CLIENT_ID_STAGING='5ada0bfd42755c2e1c10ab0e';var LAUNCH_DARKLY_CLIENT_ID_PROD='59d554b757557d0acab6119d';// Feature Flags
var FEATURE_FLAG_ACCOUNT_CARDS='account-cards';var FEATURE_FLAG_WEALTH_BANNER_AD='wealth-banner-ad';var FEATURE_FLAG_DASHBOARD_CONTENT_CARDS='dashboard-content-cards';var FEATURE_FLAG_MEMBER_DASHBOARD_CMS_PRODUCT_OFFERINGS='member-dashboard-cms-product-offerings';

/***/ }),
/* 1189 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "c", function() { return PhotoCardsPropType; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return LinkCardPropType; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "b", function() { return MarketingCardPropType; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_prop_types__ = __webpack_require__(1);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_prop_types___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_prop_types__);
var PhotoCardsPropType=__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.arrayOf(__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.shape({src:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string.isRequired,srcSet:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string,altText:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string.isRequired,title:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string.isRequired,description:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.node.isRequired,linkText:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string.isRequired}));var LinkCardPropType=__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.arrayOf(__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.shape({linkText:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string.isRequired,link:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string.isRequired}));var MarketingCardPropType=__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.arrayOf(__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.shape({templateName:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string.isRequired,id:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.number.isRequired,data:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.shape({imgSrc:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string.isRequired,imgSrcSet:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string.isRequired,altText:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string.isRequired,title:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string.isRequired,description:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string.isRequired})}));

/***/ }),
/* 1190 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var strictUriEncode = __webpack_require__(1191);
var objectAssign = __webpack_require__(123);
var decodeComponent = __webpack_require__(1192);

function encoderForArrayFormat(opts) {
	switch (opts.arrayFormat) {
		case 'index':
			return function (key, value, index) {
				return value === null ? [
					encode(key, opts),
					'[',
					index,
					']'
				].join('') : [
					encode(key, opts),
					'[',
					encode(index, opts),
					']=',
					encode(value, opts)
				].join('');
			};

		case 'bracket':
			return function (key, value) {
				return value === null ? encode(key, opts) : [
					encode(key, opts),
					'[]=',
					encode(value, opts)
				].join('');
			};

		default:
			return function (key, value) {
				return value === null ? encode(key, opts) : [
					encode(key, opts),
					'=',
					encode(value, opts)
				].join('');
			};
	}
}

function parserForArrayFormat(opts) {
	var result;

	switch (opts.arrayFormat) {
		case 'index':
			return function (key, value, accumulator) {
				result = /\[(\d*)\]$/.exec(key);

				key = key.replace(/\[\d*\]$/, '');

				if (!result) {
					accumulator[key] = value;
					return;
				}

				if (accumulator[key] === undefined) {
					accumulator[key] = {};
				}

				accumulator[key][result[1]] = value;
			};

		case 'bracket':
			return function (key, value, accumulator) {
				result = /(\[\])$/.exec(key);
				key = key.replace(/\[\]$/, '');

				if (!result) {
					accumulator[key] = value;
					return;
				} else if (accumulator[key] === undefined) {
					accumulator[key] = [value];
					return;
				}

				accumulator[key] = [].concat(accumulator[key], value);
			};

		default:
			return function (key, value, accumulator) {
				if (accumulator[key] === undefined) {
					accumulator[key] = value;
					return;
				}

				accumulator[key] = [].concat(accumulator[key], value);
			};
	}
}

function encode(value, opts) {
	if (opts.encode) {
		return opts.strict ? strictUriEncode(value) : encodeURIComponent(value);
	}

	return value;
}

function keysSorter(input) {
	if (Array.isArray(input)) {
		return input.sort();
	} else if (typeof input === 'object') {
		return keysSorter(Object.keys(input)).sort(function (a, b) {
			return Number(a) - Number(b);
		}).map(function (key) {
			return input[key];
		});
	}

	return input;
}

function extract(str) {
	var queryStart = str.indexOf('?');
	if (queryStart === -1) {
		return '';
	}
	return str.slice(queryStart + 1);
}

function parse(str, opts) {
	opts = objectAssign({arrayFormat: 'none'}, opts);

	var formatter = parserForArrayFormat(opts);

	// Create an object with no prototype
	// https://github.com/sindresorhus/query-string/issues/47
	var ret = Object.create(null);

	if (typeof str !== 'string') {
		return ret;
	}

	str = str.trim().replace(/^[?#&]/, '');

	if (!str) {
		return ret;
	}

	str.split('&').forEach(function (param) {
		var parts = param.replace(/\+/g, ' ').split('=');
		// Firefox (pre 40) decodes `%3D` to `=`
		// https://github.com/sindresorhus/query-string/pull/37
		var key = parts.shift();
		var val = parts.length > 0 ? parts.join('=') : undefined;

		// missing `=` should be `null`:
		// http://w3.org/TR/2012/WD-url-20120524/#collect-url-parameters
		val = val === undefined ? null : decodeComponent(val);

		formatter(decodeComponent(key), val, ret);
	});

	return Object.keys(ret).sort().reduce(function (result, key) {
		var val = ret[key];
		if (Boolean(val) && typeof val === 'object' && !Array.isArray(val)) {
			// Sort object keys, not values
			result[key] = keysSorter(val);
		} else {
			result[key] = val;
		}

		return result;
	}, Object.create(null));
}

exports.extract = extract;
exports.parse = parse;

exports.stringify = function (obj, opts) {
	var defaults = {
		encode: true,
		strict: true,
		arrayFormat: 'none'
	};

	opts = objectAssign(defaults, opts);

	if (opts.sort === false) {
		opts.sort = function () {};
	}

	var formatter = encoderForArrayFormat(opts);

	return obj ? Object.keys(obj).sort(opts.sort).map(function (key) {
		var val = obj[key];

		if (val === undefined) {
			return '';
		}

		if (val === null) {
			return encode(key, opts);
		}

		if (Array.isArray(val)) {
			var result = [];

			val.slice().forEach(function (val2) {
				if (val2 === undefined) {
					return;
				}

				result.push(formatter(key, val2, result.length));
			});

			return result.join('&');
		}

		return encode(key, opts) + '=' + encode(val, opts);
	}).filter(function (x) {
		return x.length > 0;
	}).join('&') : '';
};

exports.parseUrl = function (str, opts) {
	return {
		url: str.split('?')[0] || '',
		query: parse(extract(str), opts)
	};
};


/***/ }),
/* 1191 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

module.exports = function (str) {
	return encodeURIComponent(str).replace(/[!'()*]/g, function (c) {
		return '%' + c.charCodeAt(0).toString(16).toUpperCase();
	});
};


/***/ }),
/* 1192 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var token = '%[a-f0-9]{2}';
var singleMatcher = new RegExp(token, 'gi');
var multiMatcher = new RegExp('(' + token + ')+', 'gi');

function decodeComponents(components, split) {
	try {
		// Try to decode the entire string first
		return decodeURIComponent(components.join(''));
	} catch (err) {
		// Do nothing
	}

	if (components.length === 1) {
		return components;
	}

	split = split || 1;

	// Split the array in 2 parts
	var left = components.slice(0, split);
	var right = components.slice(split);

	return Array.prototype.concat.call([], decodeComponents(left), decodeComponents(right));
}

function decode(input) {
	try {
		return decodeURIComponent(input);
	} catch (err) {
		var tokens = input.match(singleMatcher);

		for (var i = 1; i < tokens.length; i++) {
			input = decodeComponents(tokens, i).join('');

			tokens = input.match(singleMatcher);
		}

		return input;
	}
}

function customDecodeURIComponent(input) {
	// Keep track of all the replacements and prefill the map with the `BOM`
	var replaceMap = {
		'%FE%FF': '\uFFFD\uFFFD',
		'%FF%FE': '\uFFFD\uFFFD'
	};

	var match = multiMatcher.exec(input);
	while (match) {
		try {
			// Decode as big chunks as possible
			replaceMap[match[0]] = decodeURIComponent(match[0]);
		} catch (err) {
			var result = decode(match[0]);

			if (result !== match[0]) {
				replaceMap[match[0]] = result;
			}
		}

		match = multiMatcher.exec(input);
	}

	// Add `%C2` at the end of the map to make sure it does not replace the combinator before everything else
	replaceMap['%C2'] = '\uFFFD';

	var entries = Object.keys(replaceMap);

	for (var i = 0; i < entries.length; i++) {
		// Replace all decoded components
		var key = entries[i];
		input = input.replace(new RegExp(key, 'g'), replaceMap[key]);
	}

	return input;
}

module.exports = function (encodedURI) {
	if (typeof encodedURI !== 'string') {
		throw new TypeError('Expected `encodedURI` to be of type `string`, got `' + typeof encodedURI + '`');
	}

	try {
		encodedURI = encodedURI.replace(/\+/g, ' ');

		// Try the built in decoder first
		return decodeURIComponent(encodedURI);
	} catch (err) {
		// Fallback to a more advanced decoder
		return customDecodeURIComponent(encodedURI);
	}
};


/***/ }),
/* 1193 */,
/* 1194 */,
/* 1195 */,
/* 1196 */
/***/ (function(module, exports, __webpack_require__) {

var Base64 = __webpack_require__(1245);

// See http://ecmanaut.blogspot.com/2006/07/encoding-decoding-utf8-in-javascript.html
function btoa(s) {
  return Base64.btoa(unescape(encodeURIComponent(s)));
}

function base64URLEncode(s) {
  return btoa(s)
  .replace(/=/g, '')
  .replace(/\+/g, '-')
  .replace(/\//g, '_');
}

function clone(obj) {
  return JSON.parse(JSON.stringify(obj));
}

function modifications(oldObj, newObj) {
  var mods = {};
  if (!oldObj || !newObj) { return {}; }
  for (var prop in oldObj) {
    if (oldObj.hasOwnProperty(prop)) {
      if (newObj[prop] !== oldObj[prop]) {
        mods[prop] = {previous: oldObj[prop], current: newObj[prop]};
      }
    }
  }
  
  return mods;
}

module.exports = {
  btoa: btoa,
  base64URLEncode: base64URLEncode,
  clone: clone,
  modifications: modifications
};


/***/ }),
/* 1197 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return BankingPropTypes; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_prop_types__ = __webpack_require__(1);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_prop_types___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_prop_types__);
var BankingPropTypes=__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.shape({accountNumber:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string,accountHolder:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string,accountType:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string,balance:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string,available:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string,redirectUrl:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string,status:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string});

/***/ }),
/* 1198 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "d", function() { return formatUrl; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return emailHref; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "b", function() { return facebookHref; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "e", function() { return twitterHref; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "c", function() { return findHighestCampaigns; });
var _slicedToArray=function(){function sliceIterator(arr,i){var _arr=[];var _n=true;var _d=false;var _e=undefined;try{for(var _i=arr[Symbol.iterator](),_s;!(_n=(_s=_i.next()).done);_n=true){_arr.push(_s.value);if(i&&_arr.length===i)break;}}catch(err){_d=true;_e=err;}finally{try{if(!_n&&_i["return"])_i["return"]();}finally{if(_d)throw _e;}}return _arr;}return function(arr,i){if(Array.isArray(arr)){return arr;}else if(Symbol.iterator in Object(arr)){return sliceIterator(arr,i);}else{throw new TypeError("Invalid attempt to destructure non-iterable instance");}};}();var emailString=function emailString(url,welcomeBonus){return'mailto:?Subject=You%20should%20check%20out%20SoFi&Body=I%20recommend%20SoFi%20to%20refinance%20student%20loans%20and%20get%20low%20rate%20personal%20loans.%20Use%20my%20link%20to%20grab%20an%20extra%20'+encodeURI(welcomeBonus// eslint-disable-line
)+'%20bonus%20after%20your%20loan%20funds:%20'+encodeURI(url);};// eslint-disable-line
var facebookString=function facebookString(url){return'http://www.facebook.com/sharer.php?u='+encodeURI(url);};var twitterString=function twitterString(url,welcomeBonus){return'https://twitter.com/intent/tweet?text=@SoFi%20and%20I%20want%20to%20give%20you%20'+encodeURIComponent(welcomeBonus)+'.%20Just%20use%20my%20link%20to%20refinance%20student%20loans%20or%20get%20a%20personal%20loan:%20'+encodeURI(url);};// eslint-disable-line
var formatBonus=function formatBonus(bonus){return'$'+bonus.toFixed();};var formatUrl=function formatUrl(url){var newUrl=url;if(newUrl!==null){var _newUrl$split=newUrl.split('/share'),_newUrl$split2=_slicedToArray(_newUrl$split,2),one=_newUrl$split2[1];newUrl='sofi.com/share'+one;}return newUrl;};var emailHref=function emailHref(url,referral){if(referral&&referral.campaign&&referral.campaign.welcomeBonus){return emailString(formatUrl(url),formatBonus(referral.campaign.welcomeBonus));}return'';};var facebookHref=function facebookHref(url){return facebookString(formatUrl(url));};var twitterHref=function twitterHref(url,referral){if(referral&&referral.campaign&&referral.campaign.welcomeBonus){return twitterString(formatUrl(url),formatBonus(referral.campaign.welcomeBonus));}return'';};var findHighestCampaigns=function findHighestCampaigns(summary){if(!summary.referralProducts){return summary;}var products=summary.referralProducts;var types=[];var bestProducts=[];for(var i=0;i<products.length;i+=1){if(types.indexOf(products[i].campaign.target)<0){types.push(products[i].campaign.target);}}for(var _i=0;_i<types.length;_i+=1){var product=null;for(var j=0;j<products.length;j+=1){if(products[j].campaign.target===types[_i]){if(product==null){product=products[j];}else if(product.campaign.affiliateFee<products[j].campaign.affiliateFee){product=products[j];}else if(product.campaign.affiliateFee===products[j].campaign.affiliateFee){// TODO: find if products[j].campaign.affiliateFee is a date type
var c1=new Date(product.campaign.createdDate);var c2=new Date(products[j].campaign.affiliateFee);if(c2.getTime()<c1.getTime()){product=products[j];}}}}bestProducts.push(product);}summary.referralProducts=bestProducts;// eslint-disable-line
return summary;};

/***/ }),
/* 1199 */,
/* 1200 */,
/* 1201 */,
/* 1202 */,
/* 1203 */,
/* 1204 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return WaitForCosignerErrorPropTypes; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_prop_types__ = __webpack_require__(1);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_prop_types___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_prop_types__);
var WaitForCosignerErrorPropTypes=__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.shape({hasBeenDisplayed:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.bool.isRequired,showMessage:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.bool.isRequired,hasBeenClosed:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.bool.isRequired});

/***/ }),
/* 1205 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return NpsSurveyPropTypes; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_prop_types__ = __webpack_require__(1);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_prop_types___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_prop_types__);
var NpsSurveyPropTypes=__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.shape({name:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string,needsSurvey:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.bool,survey:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.shape({name:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string,title:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string,questions:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.arrayOf(__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.shape({id:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.number,questionType:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string,question:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string,questionOrder:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.number,choices:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.arrayOf(__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.shape({id:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.number,choice:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string,displayOreder:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.number})),required:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.bool,answer:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string}))})});

/***/ }),
/* 1206 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return ProductsPropTypes; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_prop_types__ = __webpack_require__(1);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_prop_types___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_prop_types__);
var ProductsPropTypes=__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.arrayOf(__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.shape({eligibility:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.object.isRequired,eligible:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.bool,rates:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.shape({benefitAmount:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.number.isRequired,fixedMax:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.number.isRequired,fixedMin:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.number.isRequired,libor:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.number.isRequired,maxVarCap:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.number.isRequired,minVarCap:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.number.isRequired,title:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string.isRequired,varMax:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.number.isRequired,varMin:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.number.isRequired}),reasons:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.arrayOf(__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.shape({code:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string.isRequired,reason:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string.isRequired,startUrl:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string.isRequired})),name:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string.isRequired,version:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.number.isRequired}));

/***/ }),
/* 1207 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__(0);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_react_router_dom__ = __webpack_require__(188);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_styled_components__ = __webpack_require__(3);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__constants_prop_types_application_prop_types__ = __webpack_require__(1168);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__utilities__ = __webpack_require__(328);
var _templateObject=_taggedTemplateLiteral(['\n  display: block;\n  position: absolute;\n  z-index: 5 !important;\n  min-width: 9rem;\n  right: 0;\n  margin-top: 5px;\n'],['\n  display: block;\n  position: absolute;\n  z-index: 5 !important;\n  min-width: 9rem;\n  right: 0;\n  margin-top: 5px;\n']),_templateObject2=_taggedTemplateLiteral(['\n  border: 1px solid #d1d2d4;\n  box-shadow: 0 2px 4px 0 rgba(0, 0, 0, 0.5);\n  border-radius: 3px;\n  list-style-type: none;\n  margin: 0;\n  padding: 0;\n  background: white;\n\n  > li {\n    display: flex;\n    justify-content: center;\n\n    &:hover,\n    &:active {\n      background: #ddf2fb;\n    }\n\n    + li {\n      border-top: 1px solid rgba(0, 0, 0, 0.15);\n    }\n\n    > a {\n      width: 100%;\n      padding: 0.5rem;\n      text-align: center;\n      font-size: 0.75rem;\n      cursor: pointer;\n      text-decoration: none;\n      color: rgb(61, 61, 61);\n      font-weight: 500;\n    }\n  }\n'],['\n  border: 1px solid #d1d2d4;\n  box-shadow: 0 2px 4px 0 rgba(0, 0, 0, 0.5);\n  border-radius: 3px;\n  list-style-type: none;\n  margin: 0;\n  padding: 0;\n  background: white;\n\n  > li {\n    display: flex;\n    justify-content: center;\n\n    &:hover,\n    &:active {\n      background: #ddf2fb;\n    }\n\n    + li {\n      border-top: 1px solid rgba(0, 0, 0, 0.15);\n    }\n\n    > a {\n      width: 100%;\n      padding: 0.5rem;\n      text-align: center;\n      font-size: 0.75rem;\n      cursor: pointer;\n      text-decoration: none;\n      color: rgb(61, 61, 61);\n      font-weight: 500;\n    }\n  }\n']);function _taggedTemplateLiteral(strings,raw){return Object.freeze(Object.defineProperties(strings,{raw:{value:Object.freeze(raw)}}));}/**
 * PropTypes imports
 *//**
 * Utilities/function imports
 *//**
 * Styled Components
 *//**
 * Important: The parent of the Dropdown component
 * will need to have a position of relative
 */var Dropdown=__WEBPACK_IMPORTED_MODULE_2_styled_components__["default"].div(_templateObject);var DropdownList=__WEBPACK_IMPORTED_MODULE_2_styled_components__["default"].ul(_templateObject2);var ButtonDropdown=function ButtonDropdown(_ref){var app=_ref.app;return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(Dropdown,{'data-qa':'accounts-button-dropdown'},__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(DropdownList,{'data-qa':'accounts-button-dropdown-list'},Object(__WEBPACK_IMPORTED_MODULE_4__utilities__["d" /* findDocument */])(app,'Signed Documents')&&Object(__WEBPACK_IMPORTED_MODULE_4__utilities__["w" /* statusIndicator */])(app)!=='inactive'&&__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('li',null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('a',{'data-qa':'accounts-SignedDocs',href:Object(__WEBPACK_IMPORTED_MODULE_4__utilities__["d" /* findDocument */])(app,'Signed Documents').url},'Signed documents')),Object(__WEBPACK_IMPORTED_MODULE_4__utilities__["d" /* findDocument */])(app,'Final Disclosure')&&Object(__WEBPACK_IMPORTED_MODULE_4__utilities__["w" /* statusIndicator */])(app)!=='inactive'&&__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('li',null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('a',{'data-qa':'accounts-FinalDisclosure',href:Object(__WEBPACK_IMPORTED_MODULE_4__utilities__["d" /* findDocument */])(app,'Final Disclosure').url},'Final disclosure')),Object(__WEBPACK_IMPORTED_MODULE_4__utilities__["d" /* findDocument */])(app,'PL TILA')&&Object(__WEBPACK_IMPORTED_MODULE_4__utilities__["w" /* statusIndicator */])(app)!=='inactive'&&__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('li',null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('a',{'data-qa':'accounts-PL-TILA',href:Object(__WEBPACK_IMPORTED_MODULE_4__utilities__["d" /* findDocument */])(app,'PL TILA').url},'PL TILA')),Object(__WEBPACK_IMPORTED_MODULE_4__utilities__["d" /* findDocument */])(app,'Adverse Action')&&__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('li',null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_1_react_router_dom__["b" /* Link */],{'data-qa':'accounts-AdverseActionLetter',to:'/decline/'+app.id},'Adverse action letter')),Object(__WEBPACK_IMPORTED_MODULE_4__utilities__["d" /* findDocument */])(app,'Mortgage Prequal Letter')&&__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('li',null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('a',{'data-qa':'accounts-dropdown-mort-prequal-link',href:Object(__WEBPACK_IMPORTED_MODULE_4__utilities__["d" /* findDocument */])(app,'Mortgage Prequal Letter').url},'Mortgage prequal letter')),Object(__WEBPACK_IMPORTED_MODULE_4__utilities__["d" /* findDocument */])(app,'Product Select Letter')&&__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('li',null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('a',{'data-qa':'accounts-dropdown-prod-select-link',href:Object(__WEBPACK_IMPORTED_MODULE_4__utilities__["d" /* findDocument */])(app,'Product Select Letter').url},'Product select letter')),Object(__WEBPACK_IMPORTED_MODULE_4__utilities__["d" /* findDocument */])(app,'Gift Letter Form')&&__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('li',null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('a',{'data-qa':'accounts-dropdown-gift-letter-link',href:Object(__WEBPACK_IMPORTED_MODULE_4__utilities__["d" /* findDocument */])(app,'Gift Letter Form').url},'Gift letter')),Object(__WEBPACK_IMPORTED_MODULE_4__utilities__["d" /* findDocument */])(app,'Authorization Form')&&__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('li',null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('a',{'data-qa':'accounts-dropdown-auth-form-link',href:Object(__WEBPACK_IMPORTED_MODULE_4__utilities__["d" /* findDocument */])(app,'Authorization Form').url},'Authorization form')),Object(__WEBPACK_IMPORTED_MODULE_4__utilities__["d" /* findDocument */])(app,'Balance Sheet')&&__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('li',null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('a',{'data-qa':'accounts-dropdown-balance-sheet-link',href:Object(__WEBPACK_IMPORTED_MODULE_4__utilities__["d" /* findDocument */])(app,'Balance Sheet').url},'Balance sheet')),Object(__WEBPACK_IMPORTED_MODULE_4__utilities__["d" /* findDocument */])(app,'Profit And Loss Statement')&&__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('li',null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('a',{'data-qa':'accounts-dropdown-profit-n-loss-link',href:Object(__WEBPACK_IMPORTED_MODULE_4__utilities__["d" /* findDocument */])(app,'Profit And Loss Statement').url},'Profit and loss statement')),Object(__WEBPACK_IMPORTED_MODULE_4__utilities__["d" /* findDocument */])(app,'Demographic Information Addendum')&&__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('li',null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('a',{'data-qa':'accounts-dropdown-demo-addendum-link',href:Object(__WEBPACK_IMPORTED_MODULE_4__utilities__["d" /* findDocument */])(app,'Demographic Information Addendum').url},'Demographic addendum')),Object(__WEBPACK_IMPORTED_MODULE_4__utilities__["d" /* findDocument */])(app,'Coborrower Demographic Information Addendum')&&__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('li',null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('a',{'data-qa':'accounts-dropdown-cobo-demo-addendum-link',href:Object(__WEBPACK_IMPORTED_MODULE_4__utilities__["d" /* findDocument */])(app,'Coborrower Demographic Information Addendum').url},'Coborrower Demographic addendum'))));};/* eslint react/no-typos: 0 */ButtonDropdown.propTypes={app:__WEBPACK_IMPORTED_MODULE_3__constants_prop_types_application_prop_types__["a" /* ApplicationPropType */].isRequired};/* harmony default export */ __webpack_exports__["a"] = (ButtonDropdown);

/***/ }),
/* 1208 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var deselectCurrent = __webpack_require__(1209);

var defaultMessage = 'Copy to clipboard: #{key}, Enter';

function format(message) {
  var copyKey = (/mac os x/i.test(navigator.userAgent) ? '⌘' : 'Ctrl') + '+C';
  return message.replace(/#{\s*key\s*}/g, copyKey);
}

function copy(text, options) {
  var debug, message, reselectPrevious, range, selection, mark, success = false;
  if (!options) { options = {}; }
  debug = options.debug || false;
  try {
    reselectPrevious = deselectCurrent();

    range = document.createRange();
    selection = document.getSelection();

    mark = document.createElement('span');
    mark.textContent = text;
    // reset user styles for span element
    mark.style.all = 'unset';
    // prevents scrolling to the end of the page
    mark.style.position = 'fixed';
    mark.style.top = 0;
    mark.style.clip = 'rect(0, 0, 0, 0)';
    // used to preserve spaces and line breaks
    mark.style.whiteSpace = 'pre';
    // do not inherit user-select (it may be `none`)
    mark.style.webkitUserSelect = 'text';
    mark.style.MozUserSelect = 'text';
    mark.style.msUserSelect = 'text';
    mark.style.userSelect = 'text';

    document.body.appendChild(mark);

    range.selectNode(mark);
    selection.addRange(range);

    var successful = document.execCommand('copy');
    if (!successful) {
      throw new Error('copy command was unsuccessful');
    }
    success = true;
  } catch (err) {
    debug && console.error('unable to copy using execCommand: ', err);
    debug && console.warn('trying IE specific stuff');
    try {
      window.clipboardData.setData('text', text);
      success = true;
    } catch (err) {
      debug && console.error('unable to copy using clipboardData: ', err);
      debug && console.error('falling back to prompt');
      message = format('message' in options ? options.message : defaultMessage);
      window.prompt(message, text);
    }
  } finally {
    if (selection) {
      if (typeof selection.removeRange == 'function') {
        selection.removeRange(range);
      } else {
        selection.removeAllRanges();
      }
    }

    if (mark) {
      document.body.removeChild(mark);
    }
    reselectPrevious();
  }

  return success;
}

module.exports = copy;


/***/ }),
/* 1209 */
/***/ (function(module, exports) {


module.exports = function () {
  var selection = document.getSelection();
  if (!selection.rangeCount) {
    return function () {};
  }
  var active = document.activeElement;

  var ranges = [];
  for (var i = 0; i < selection.rangeCount; i++) {
    ranges.push(selection.getRangeAt(i));
  }

  switch (active.tagName.toUpperCase()) { // .toUpperCase handles XHTML
    case 'INPUT':
    case 'TEXTAREA':
      active.blur();
      break;

    default:
      active = null;
      break;
  }

  selection.removeAllRanges();
  return function () {
    selection.type === 'Caret' &&
    selection.removeAllRanges();

    if (!selection.rangeCount) {
      ranges.forEach(function(range) {
        selection.addRange(range);
      });
    }

    active &&
    active.focus();
  };
};


/***/ }),
/* 1210 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* unused harmony export CardPropTypes */
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return DashboardAccountsPropTypes; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_prop_types__ = __webpack_require__(1);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_prop_types___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_prop_types__);
var CardPropTypes=__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.shape({title:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.shape({value:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.String}),titleIcon:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.shape({value:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.String}),heading1:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.shape({value:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.String}),heading2:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.shape({value:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.String}),heading3:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.shape({value:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.String}),heading4:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.shape({value:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.String}),topLeftData:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.shape({value:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.String}),topLeftLabel:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.shape({value:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.String}),topRightData:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.shape({value:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.String}),topRightLabel:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.shape({value:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.String}),bottomLeftLabel:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.shape({value:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.String}),bottomLeftData:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.shape({value:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.String}),bottomRightData:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.shape({value:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.String}),bottomRightLabel:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.shape({value:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.String}),callToAction1:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.shape({value:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.shape({text:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.shape({value:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.String}),type:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.shape({value:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.String}),url:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.shape({value:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.String}),icon:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.shape({value:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.String})})}),callToAction2:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.shape({value:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.shape({text:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.shape({value:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.String}),type:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.shape({value:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.String}),url:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.shape({value:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.String}),icon:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.shape({value:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.String})})}),fullWidthMessage:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.shape({value:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.String}),expandUrl:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.shape({value:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.String})});var DashboardAccountsPropTypes=__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.shape({accountCards:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.arrayOf(__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.shape({templateName:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.String,data:CardPropTypes,id:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.number}))});

/***/ }),
/* 1211 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return getBanking; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "b", function() { return getIsBanking; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__utilities_api_action_helpers__ = __webpack_require__(93);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__constants__ = __webpack_require__(79);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__constants_banking_constants__ = __webpack_require__(335);
var getBanking=function getBanking(){return function(dispatch){Object(__WEBPACK_IMPORTED_MODULE_0__utilities_api_action_helpers__["b" /* performGet */])(dispatch,__WEBPACK_IMPORTED_MODULE_1__constants__["a" /* API_URL */]+'/banking/summary',{},__WEBPACK_IMPORTED_MODULE_2__constants_banking_constants__["a" /* GET_BANKING */]);};};var getIsBanking=function getIsBanking(){return function(dispatch){Object(__WEBPACK_IMPORTED_MODULE_0__utilities_api_action_helpers__["b" /* performGet */])(dispatch,__WEBPACK_IMPORTED_MODULE_1__constants__["a" /* API_URL */]+'/banking/validate-customer',{},__WEBPACK_IMPORTED_MODULE_2__constants_banking_constants__["b" /* GET_IS_BANKING */]);};};

/***/ }),
/* 1212 */,
/* 1213 */,
/* 1214 */,
/* 1215 */,
/* 1216 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.getLocation = getLocation;
exports.ldClientWrapper = ldClientWrapper;
exports.ldOverrideFlag = ldOverrideFlag;
exports.getAllFeatureFlags = getAllFeatureFlags;

var _ldclientJs = __webpack_require__(1243);

var _ldclientJs2 = _interopRequireDefault(_ldclientJs);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var url = __webpack_require__(1253);

function getLocation() {
  if (window.location) {
    return window.location.toString();
  }
  return "";
}

var ldClient = void 0;
var ldClientReady = false;
function ldClientWrapper(key, user) {
  var options = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};

  var queue = [];

  if (!ldClient) {
    ldClient = _ldclientJs2.default.initialize(key, user, options);
  }

  if (!ldClientReady) {
    ldClient.on("ready", function () {
      ldClientReady = true;

      if (queue.length) {
        queue.forEach(function (callback) {
          callback();
        });
      }
    });
  }

  // Create our own implementation of the ldclient-js' `on` function.
  // Multiple calls with `on('ready')` seem to not fire after the original client has been initialized.
  // By implementing our own, we can track the initial "ready" fire and decide how to proceed.
  ldClient.onReady = function (callback) {
    if (ldClientReady) {
      callback();
    } else {
      queue.push(callback);
    }
  };

  return ldClient;
}

function ldOverrideFlag(flagKey, typeFlagValue) {
  var override = void 0;
  /*
   POST /users?features=send-onboarding-email
   # Overrides the `send-onboarding-email` boolean feature flag, setting it to `true`
   GET /users/101?features=show-user-email,user-nicknames,hide-inactive-users
   # Enables the `show-user-email`, `user-nicknames`, and `hide-inactive-users` feature flags
   POST /users?features.verify-email=false&features.email-frequency=weekly
   # Disables the `verify-email` feature flag and sets the `email-frequency` variation to "weekly"
   */
  var query = url.parse(exports.getLocation(), true).query;
  var queryFlag = query["features." + flagKey];
  var queryFeatures = query["features"];

  if (typeof queryFlag !== "undefined") {
    if (queryFlag === "") {
      override = true;
    } else if (queryFlag === "false") {
      override = false;
    } else {
      override = queryFlag;
    }

    if (typeFlagValue === "number") {
      override = parseFloat(override);
    }
  } else if (queryFeatures) {
    queryFeatures.split(",").forEach(function (f) {
      if (f === flagKey) {
        override = true;
      }
    });
  }
  return override;
}

function getAllFeatureFlags(key, user) {
  var ldClient = ldClientWrapper(key, user);
  return new Promise(function (resolve) {
    ldClient.onReady(function () {
      resolve(ldClient.allFlags());
    });
  });
}

/***/ }),
/* 1217 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;
exports.Subscriber = exports.Broadcast = undefined;

var _Broadcast2 = __webpack_require__(1260);

var _Broadcast3 = _interopRequireDefault(_Broadcast2);

var _Subscriber2 = __webpack_require__(1261);

var _Subscriber3 = _interopRequireDefault(_Subscriber2);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.Broadcast = _Broadcast3.default;
exports.Subscriber = _Subscriber3.default;

/***/ }),
/* 1218 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
var BROADCAST_CHANNEL = exports.BROADCAST_CHANNEL = "launchDarkly";

/***/ }),
/* 1219 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return UppSummaryPropTypes; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_prop_types__ = __webpack_require__(1);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_prop_types___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_prop_types__);
var UppSummaryPropTypes=__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.arrayOf(__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.shape({applicationEndDate:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string,city:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string,email:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string,employer:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string,enrollmentDate:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string,enrollmentStatus:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string,forbEndDate:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string,forbStartDate:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string,jobFunctions:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string,jobIndustry:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string,jobTitle:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string,linkedIn:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string,loanApplicationId:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.number,name:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string,phone:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string,salary:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.number,state:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string,streetAddress:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string,terminationDate:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string,terminationType:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string,uppApplicationId:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.number,userId:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.number,zip:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string}));

/***/ }),
/* 1220 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return TrackingBannerPropTypes; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_prop_types__ = __webpack_require__(1);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_prop_types___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_prop_types__);
var TrackingBannerPropTypes=__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.arrayOf(__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.shape({id:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.number,named:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string,targetType:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string,targetId:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string,active:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.bool,endDate:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string}));

/***/ }),
/* 1221 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "b", function() { return setWaitCosignerError; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return clearWaitCosignerError; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_redux_actions__ = __webpack_require__(15);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__constants_global_error_constants__ = __webpack_require__(340);
var setWaitCosignerError=function setWaitCosignerError(){return function(dispatch){dispatch(Object(__WEBPACK_IMPORTED_MODULE_0_redux_actions__["a" /* createAction */])(__WEBPACK_IMPORTED_MODULE_1__constants_global_error_constants__["b" /* SET_WAIT_COSIGNER_ERROR */])());};};var clearWaitCosignerError=function clearWaitCosignerError(){return function(dispatch){dispatch(Object(__WEBPACK_IMPORTED_MODULE_0_redux_actions__["a" /* createAction */])(__WEBPACK_IMPORTED_MODULE_1__constants_global_error_constants__["b" /* SET_WAIT_COSIGNER_ERROR */]+':NONE')());};};

/***/ }),
/* 1222 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "e", function() { return HAS_ERRORS; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "f", function() { return HAS_INFO; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "c", function() { return FIND_IF_STATE_IS_ELIGIBLE; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "g", function() { return NPS_SURVEY_SELECT_OPTIONS; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "h", function() { return REBUILD_SURVEY_OBJECT; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "i", function() { return REBUILD_WHERE_HEARD_SURVEY_OBJECT; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "b", function() { return DETERMINE_REVIEW_URL; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return CHECK_UPP_ALERT_NEEDS_DISPLAY; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "d", function() { return GET_VALUE_LABEL_PAIRS; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__utilities_cookie_helpers__ = __webpack_require__(333);
var HAS_ERRORS=function HAS_ERRORS(){var cookie=Object(__WEBPACK_IMPORTED_MODULE_0__utilities_cookie_helpers__["b" /* getErrorCookie */])();var cookieError=cookie||null;return cookieError;};var HAS_INFO=function HAS_INFO(){var cookie=Object(__WEBPACK_IMPORTED_MODULE_0__utilities_cookie_helpers__["c" /* getInfoCookie */])();var cookieInfo=cookie||null;return cookieInfo;};var FIND_IF_STATE_IS_ELIGIBLE=function FIND_IF_STATE_IS_ELIGIBLE(products){var eligiblityStatus=false;var matchList=['REFI','PL','PLUS','PARENT'];for(var i=0;i<products.length;i+=1){var p=products[i];if(p&&!p.eligibility.eligible&&matchList.indexOf(p.name)!==-1){// TODO: Redo this map down the road, works for now!
p.eligibility.reasons.map(function(r){// eslint-disable-line
if(r.code==='STATE'){eligiblityStatus=true;return eligiblityStatus;}});}}return eligiblityStatus;};var NPS_SURVEY_SELECT_OPTIONS=function NPS_SURVEY_SELECT_OPTIONS(data){var choices=data.choices;var options=choices.map(function(value){return{value:String(value.id),label:value.choice};});return options;};var ORIGINAL_SELECT_OPTIONS=[{id:12,choice:'Student Loan Refinancing',displayOrder:1},{id:13,choice:'MBA Loan (In-School)',displayOrder:2},{id:14,choice:'Mortgage',displayOrder:3},{id:15,choice:'Parent Loan',displayOrder:4},{id:16,choice:'Personal Loan',displayOrder:5},{id:17,choice:'Wealth',displayOrder:6}];// REBUILD NPS SURVEY OBJECT
var buildChosenProductAnswerObj=function buildChosenProductAnswerObj(option){var numOption=Number(option);var selectedObj=ORIGINAL_SELECT_OPTIONS.filter(function(obj){return numOption===obj.id;});return selectedObj[0].choice;};var REBUILD_SURVEY_OBJECT=function REBUILD_SURVEY_OBJECT(data,originalData){var chosenProductAnswer=data.chosenProduct?buildChosenProductAnswerObj(data.chosenProduct):null;var newSurveyObject={name:originalData.name,needsSurvey:false,survey:{name:originalData.survey.name,title:originalData.survey.title,questions:[{id:originalData.survey.questions[0].id,questionType:originalData.survey.questions[0].questionType,question:originalData.survey.questions[0].question,questionOrder:originalData.survey.questions[0].questionOrder,choices:originalData.survey.questions[0].choices,required:originalData.survey.questions[0].required,answer:data.radioChoiceRating},{id:originalData.survey.questions[1].id,questionType:originalData.survey.questions[1].questionType,question:originalData.survey.questions[1].question,questionOrder:originalData.survey.questions[1].questionOrder,choices:originalData.survey.questions[1].choices,required:originalData.survey.questions[1].required,answer:chosenProductAnswer},{id:originalData.survey.questions[2].id,questionType:originalData.survey.questions[2].questionType,question:originalData.survey.questions[2].question,questionOrder:originalData.survey.questions[2].questionOrder,choices:originalData.survey.questions[2].choices,required:originalData.survey.questions[2].required,answer:data.feedbackComment},{id:originalData.survey.questions[3].id,questionType:originalData.survey.questions[3].questionType,question:originalData.survey.questions[3].question,questionOrder:originalData.survey.questions[3].questionOrder,choices:originalData.survey.questions[3].choices,required:originalData.survey.questions[3].required,answer:data.recommendationComment}]}};return newSurveyObject;};// REBUILD WHERE HEARD SURVEY OBJECT
var REBUILD_WHERE_HEARD_SURVEY_OBJECT=function REBUILD_WHERE_HEARD_SURVEY_OBJECT(data,originalData){var newSurveyObject={name:originalData.name,needsSurvey:false,survey:{name:originalData.survey.name,title:originalData.survey.title,questions:[{id:originalData.survey.questions[0].id,questionType:originalData.survey.questions[0].questionType,question:originalData.survey.questions[0].question,questionOrder:originalData.survey.questions[0].questionOrder,choices:originalData.survey.questions[0].choices,required:originalData.survey.questions[0].required,answer:data}]}};return newSurveyObject;};// RANDOMIZE AND DETERMINE PROPERTY TO SEND MEMBER TO FOR REVIEW IF RATING IS >= 9
var DETERMINE_REVIEW_URL=function DETERMINE_REVIEW_URL(){var roll=Math.floor(Math.random()*9);var referralObj={};switch(roll){case 0:referralObj={reviewUrl:'https://www.creditkarma.com/reviews/student-loan/single/id/sofi-student-loan',reviewText:'REVIEW SOFI ON CREDIT KARMA'};break;case 1:referralObj={reviewUrl:'http://whitecoatinvestor.com/new-players-in-student-loan-refinancing/',reviewText:'REVIEW SOFI ON WHITE COAT INVESTOR'};break;case 2:referralObj={reviewUrl:'http://studentloansherpa.com/sofi-aka-social-finance-inc-student-loan-review/#comments',reviewText:'REVIEW SOFI ON STUDENT LOAN SHERPA'};break;case 3:referralObj={reviewUrl:'https://www.lendingtree.com/loan-companies/sofi-reviews-28905',reviewText:'REVIEW SOFI ON LENDING TREE'};break;case 4:referralObj={reviewUrl:'http://www.yelp.com/biz/sofi-san-francisco',reviewText:'REVIEW SOFI ON YELP'};break;case 5:referralObj={reviewUrl:'https://secure.creditsesame.com/s/public/personal-loans/marketplace/details?'+'lender=SOFI&intent=PERSONALLOAN_CARDPAYOFF&loanAmount=5000&loanTerm=THREE_YEARS&scrollSection=DETAILS_REVIEWS',reviewText:'REVIEW SOFI ON CREDIT SESAME'};break;case 6:referralObj={reviewUrl:'http://thebestcompanys.com/loans/company/sofi/',reviewText:'REVIEW SOFI ON THE BEST DEBT COMPANYS'};break;case 7:referralObj={reviewUrl:'https://www.supermoney.com/reviews/personal-loans/sofi',reviewText:'REVIEW SOFI ON SUPERMONEY'};break;default:referralObj={reviewUrl:'http://www.zillow.com/profile/SoFi-Lending-Corp/Reviews/',reviewText:'REVIEW SOFI ON ZILLOW'};break;}return referralObj;};// Determin whether to display the UPP alert
var CHECK_UPP_ALERT_NEEDS_DISPLAY=function CHECK_UPP_ALERT_NEEDS_DISPLAY(uppSummary){var isTrue=uppSummary.some(function(val){if(val.enrollmentStatus==='EMPLOYMENT_VERIFICATION'||val.enrollmentStatus==='PENDING_FORBEARANCE'){return true;}return false;});return isTrue;};var GET_VALUE_LABEL_PAIRS=function GET_VALUE_LABEL_PAIRS(account){var pairs=[];if(account.topLeftData){pairs.push([account.topLeftData,account.topLeftLabel?account.topLeftLabel:'']);}if(account.topRightData){pairs.push([account.topRightData,account.topRightLabel?account.topRightLabel:'']);}return pairs;};

/***/ }),
/* 1223 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return WealthProfilePropTypes; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_prop_types__ = __webpack_require__(1);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_prop_types___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_prop_types__);
var WealthProfilePropTypes=__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.shape({accountId:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.number,accountStrategy:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string,accountTypeDescription:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string,contributions:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.array,holdings:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.array,statistics:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.shape({}),// TODO: Update this
ctaInfo:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.shape({subText:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string,cta:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string,ctaLink:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string}),funded:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.bool,completed:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.bool,isNew:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.bool});

/***/ }),
/* 1224 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__affiliate__ = __webpack_require__(1303);
/* harmony reexport (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return __WEBPACK_IMPORTED_MODULE_0__affiliate__["a"]; });


/***/ }),
/* 1225 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return setupContacts; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react_redux_i18n__ = __webpack_require__(70);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react_redux_i18n___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react_redux_i18n__);
var setupContacts=function setupContacts(customer){var phoneKey=customer.corporateEmployer==='apple'?'applePhone':'sofiCustomerServicePhone';var emailKey=customer.corporateEmployer==='apple'?'appleEmail':'sofiCustomerServiceEmail';return{contactPhone:__WEBPACK_IMPORTED_MODULE_0_react_redux_i18n__["I18n"].t(phoneKey),contactEmail:__WEBPACK_IMPORTED_MODULE_0_react_redux_i18n__["I18n"].t(emailKey)};};

/***/ }),
/* 1226 */,
/* 1227 */,
/* 1228 */,
/* 1229 */,
/* 1230 */,
/* 1231 */,
/* 1232 */,
/* 1233 */,
/* 1234 */,
/* 1235 */,
/* 1236 */,
/* 1237 */,
/* 1238 */,
/* 1239 */,
/* 1240 */,
/* 1241 */,
/* 1242 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__(0);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_prop_types__ = __webpack_require__(1);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_prop_types___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_prop_types__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_react_redux__ = __webpack_require__(95);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_react_helmet__ = __webpack_require__(1075);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_react_helmet___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_3_react_helmet__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_react_router_prop_types__ = __webpack_require__(317);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_react_router_prop_types___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_4_react_router_prop_types__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5_react_launch_darkly__ = __webpack_require__(1187);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5_react_launch_darkly___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_5_react_launch_darkly__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__constants_prop_types_customer_prop_types__ = __webpack_require__(124);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__components_error_boundary__ = __webpack_require__(1085);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8__components_loading__ = __webpack_require__(316);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_9__alerts_container__ = __webpack_require__(1264);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_10__accounts_container__ = __webpack_require__(1291);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_11__products_container__ = __webpack_require__(1320);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_12__marketing_container__ = __webpack_require__(1334);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_13__modals_container__ = __webpack_require__(1347);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_14__actions_customer_actions__ = __webpack_require__(326);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_15__actions_application_actions__ = __webpack_require__(1181);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_16__actions_product_actions__ = __webpack_require__(1361);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_17__actions_wealth_actions__ = __webpack_require__(1362);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_18__actions_referral_actions__ = __webpack_require__(1172);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_19__actions_banking_actions__ = __webpack_require__(1211);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_20__utilities_launch_darkly_helpers__ = __webpack_require__(1363);
var _createClass=function(){function defineProperties(target,props){for(var i=0;i<props.length;i++){var descriptor=props[i];descriptor.enumerable=descriptor.enumerable||false;descriptor.configurable=true;if("value"in descriptor)descriptor.writable=true;Object.defineProperty(target,descriptor.key,descriptor);}}return function(Constructor,protoProps,staticProps){if(protoProps)defineProperties(Constructor.prototype,protoProps);if(staticProps)defineProperties(Constructor,staticProps);return Constructor;};}();function _classCallCheck(instance,Constructor){if(!(instance instanceof Constructor)){throw new TypeError("Cannot call a class as a function");}}function _possibleConstructorReturn(self,call){if(!self){throw new ReferenceError("this hasn't been initialised - super() hasn't been called");}return call&&(typeof call==="object"||typeof call==="function")?call:self;}function _inherits(subClass,superClass){if(typeof superClass!=="function"&&superClass!==null){throw new TypeError("Super expression must either be null or a function, not "+typeof superClass);}subClass.prototype=Object.create(superClass&&superClass.prototype,{constructor:{value:subClass,enumerable:false,writable:true,configurable:true}});if(superClass)Object.setPrototypeOf?Object.setPrototypeOf(subClass,superClass):subClass.__proto__=superClass;}/**
 * PropTypes imports
 *//**
 * Component imports
 *//**
 * Action imports
 *//**
 * Displays the dashboard including Accounts, Offerings, and Marketing
 */var DashboardContainer=function(_Component){_inherits(DashboardContainer,_Component);function DashboardContainer(){var _ref;var _temp,_this,_ret;_classCallCheck(this,DashboardContainer);for(var _len=arguments.length,args=Array(_len),_key=0;_key<_len;_key++){args[_key]=arguments[_key];}return _ret=(_temp=(_this=_possibleConstructorReturn(this,(_ref=DashboardContainer.__proto__||Object.getPrototypeOf(DashboardContainer)).call.apply(_ref,[this].concat(args))),_this),_this.state={ssnPopupMessage:null},_this.triggerAlert=function(){_this.setState({ssnPopupMessage:'nocredit'});var self=_this;_this.popUpTimer=setTimeout(function(){self.setState({ssnPopupMessage:null});},30000);},_temp),_possibleConstructorReturn(_this,_ret);}_createClass(DashboardContainer,[{key:'componentDidMount',value:function componentDidMount(){var _props=this.props,loadConsents=_props.loadConsents,loadApplications=_props.loadApplications,loadServicing=_props.loadServicing,loadProducts=_props.loadProducts,loadWealth=_props.loadWealth,loadConsentsTou=_props.loadConsentsTou,loadReferralSummary=_props.loadReferralSummary,loadReferralConsents=_props.loadReferralConsents,loadBanking=_props.loadBanking;/**
     * Load consents
     */loadConsents();/**
     * Specific to Your Accounts section
     */loadWealth();loadBanking();// Accounts and Offerings both
loadApplications();loadProducts();// Offerings section only
loadServicing();loadConsentsTou();loadReferralSummary();loadReferralConsents();}},{key:'componentWillReceiveProps',value:function componentWillReceiveProps(nextProps){/**
     * Check for consents
     * If the customer hasn't consented go to /consents
     */if(nextProps.consents&&nextProps.consents!==this.props.consents){var consents=nextProps.consents;if(!consents.consents){this.props.history.push('/consents');}}}},{key:'componentWillUnmount',value:function componentWillUnmount(){if(this.popUpTimer){clearTimeout(this.popUpTimer);this.popUpTimer=undefined;}}// Availing the timer here so we can clear it when user navigates away from page
// Trigger display for SSN Alert
},{key:'render',value:function render(){var _props2=this.props,applicationsLoaded=_props2.applicationsLoaded,customerLoaded=_props2.customerLoaded,productsLoaded=_props2.productsLoaded;var ssnPopupMessage=this.state.ssnPopupMessage;// Show Loading screen if we do not have customer, and products info
if(!customerLoaded||!applicationsLoaded)return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_8__components_loading__["a" /* default */],null);return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_5_react_launch_darkly__["LaunchDarkly"],{clientId:Object(__WEBPACK_IMPORTED_MODULE_20__utilities_launch_darkly_helpers__["a" /* getClientId */])(),user:Object(__WEBPACK_IMPORTED_MODULE_20__utilities_launch_darkly_helpers__["b" /* getUser */])(this.props.customer)},__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_0_react__["Fragment"],null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_3_react_helmet__["Helmet"],null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('title',null,'SoFi - My Home')),__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_13__modals_container__["a" /* default */],Object.assign({},this.props,{triggerAlert:this.triggerAlert})),__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_9__alerts_container__["a" /* default */],Object.assign({},this.props,{ssnPopupMessage:ssnPopupMessage})),__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_7__components_error_boundary__["a" /* default */],null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_10__accounts_container__["a" /* default */],this.props)),__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_7__components_error_boundary__["a" /* default */],null,productsLoaded&&__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_11__products_container__["a" /* default */],this.props)),__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_7__components_error_boundary__["a" /* default */],null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_12__marketing_container__["a" /* default */],this.props))));}}]);return DashboardContainer;}(__WEBPACK_IMPORTED_MODULE_0_react__["Component"]);DashboardContainer.propTypes={loadConsents:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.func.isRequired,loadApplications:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.func.isRequired,loadServicing:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.func.isRequired,loadProducts:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.func.isRequired,applicationsLoaded:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.bool.isRequired,customerLoaded:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.bool.isRequired,productsLoaded:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.bool.isRequired,loadWealth:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.func.isRequired,loadConsentsTou:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.func.isRequired,loadReferralSummary:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.func.isRequired,loadReferralConsents:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.func.isRequired,consents:__WEBPACK_IMPORTED_MODULE_6__constants_prop_types_customer_prop_types__["a" /* ConsentsPropTypes */].isRequired,history:__WEBPACK_IMPORTED_MODULE_4_react_router_prop_types___default.a.history.isRequired,loadBanking:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.func.isRequired,dashboardAccountsLoaded:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.bool.isRequired,loadDashboardAccounts:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.func.isRequired,customer:__WEBPACK_IMPORTED_MODULE_6__constants_prop_types_customer_prop_types__["b" /* CustomerPropTypes */].isRequired};var mapStateToProps=function mapStateToProps(state){return{consents:state.customerReducer.consents.data,customer:state.customerReducer.customer.data,customerLoaded:state.customerReducer.customer.loaded,applications:state.applicationReducer.applications.data,applicationsLoaded:state.applicationReducer.applications.loaded,dashboardAccounts:state.applicationReducer.dashboardAccounts.data,dashboardAccountsLoaded:state.applicationReducer.dashboardAccounts.loaded,products:state.productReducer.products.data,productsLoaded:state.productReducer.products.loaded,wealth:state.wealthReducer.wealth.data,wealthLoaded:state.wealthReducer.wealth.loaded,consentsTou:state.customerReducer.consentsTou.data,referralSummary:state.referralReducer.referralSummary.data,referralSummaryLoaded:state.referralReducer.referralSummary.loaded,referralConsents:state.referralReducer.referralConsents.data,referralConsentsLoaded:state.referralReducer.referralConsents.loaded,banking:state.bankingReducer.banking.data,bankingLoaded:state.bankingReducer.banking.loaded};};var mapDispatchToProps=function mapDispatchToProps(dispatch){return{loadConsents:function loadConsents(){return dispatch(Object(__WEBPACK_IMPORTED_MODULE_14__actions_customer_actions__["a" /* getConsents */])());},loadApplications:function loadApplications(){return dispatch(Object(__WEBPACK_IMPORTED_MODULE_15__actions_application_actions__["a" /* getApplications */])());},loadServicing:function loadServicing(){return dispatch(Object(__WEBPACK_IMPORTED_MODULE_15__actions_application_actions__["b" /* getApplicationsServicing */])());},loadProducts:function loadProducts(){return dispatch(Object(__WEBPACK_IMPORTED_MODULE_16__actions_product_actions__["a" /* getProducts */])());},loadWealth:function loadWealth(){return dispatch(Object(__WEBPACK_IMPORTED_MODULE_17__actions_wealth_actions__["a" /* getWealth */])());},loadConsentsTou:function loadConsentsTou(){return dispatch(Object(__WEBPACK_IMPORTED_MODULE_14__actions_customer_actions__["b" /* getConsentsTou */])());},loadReferralSummary:function loadReferralSummary(){return dispatch(Object(__WEBPACK_IMPORTED_MODULE_18__actions_referral_actions__["e" /* getReferralSummary */])());},loadReferralConsents:function loadReferralConsents(){return dispatch(Object(__WEBPACK_IMPORTED_MODULE_18__actions_referral_actions__["d" /* getReferralConsents */])());},loadBanking:function loadBanking(){return dispatch(Object(__WEBPACK_IMPORTED_MODULE_19__actions_banking_actions__["a" /* getBanking */])());},loadDashboardAccounts:function loadDashboardAccounts(){return dispatch(Object(__WEBPACK_IMPORTED_MODULE_15__actions_application_actions__["c" /* getDashboardAccounts */])());}};};/* harmony default export */ __webpack_exports__["a"] = (Object(__WEBPACK_IMPORTED_MODULE_2_react_redux__["b" /* connect */])(mapStateToProps,mapDispatchToProps)(DashboardContainer));

/***/ }),
/* 1243 */
/***/ (function(module, exports, __webpack_require__) {

var EventProcessor = __webpack_require__(1244);
var EventEmitter = __webpack_require__(1246);
var GoalTracker = __webpack_require__(1247);
var Stream = __webpack_require__(1249);
var Requestor = __webpack_require__(1250);
var Identity = __webpack_require__(1251);
var utils = __webpack_require__(1196);
var messages = __webpack_require__(1252);

var flags = {};
var environment;
var events;
var requestor;
var stream;
var emitter;
var hash;
var ident;
var baseUrl;
var eventsUrl;
var streamUrl;
var goalTracker;
var useLocalStorage;
var goals;

var readyEvent = 'ready';
var changeEvent = 'change';

var flushInterval = 2000;

var seenRequests = {};

function sendIdentifyEvent(user) {
  events.enqueue({
    kind: 'identify',
    key: user.key,
    user: user,
    creationDate: (new Date()).getTime()
  });
}

function sendFlagEvent(key, value, defaultValue) {
  var user = ident.getUser();
  var cacheKey = JSON.stringify(value) + (user && user.key ? user.key : '') + key;
  var now = new Date();
  var cached = seenRequests[cacheKey];

  if (cached && (now - cached) < 300000 /* five minutes, in ms */) {
    return;
  }

  seenRequests[cacheKey] = now;

  events.enqueue({
    kind: 'feature',
    key: key,
    user: user,
    value: value,
    'default': defaultValue,
    creationDate: now.getTime()
  });
}

function sendGoalEvent(kind, goal) {
  var event = {
    kind: kind,
    key: goal.key,
    data: null,
    url: window.location.href,
    creationDate: (new Date()).getTime()
  };

  if (kind === 'click') {
    event.selector = goal.selector;
  }

  return events.enqueue(event);
}

function identify(user, hash, onDone) {
  ident.setUser(user);
  requestor.fetchFlagSettings(ident.getUser(), hash, function(err, settings) {
    if (err) {
      console.warn('Error fetching flag settings: ', err);
    }
    if (settings) {
      updateSettings(settings);
    }
    onDone && onDone();
  });
}

function variation(key, defaultValue) {
  var value;

  if (flags && flags.hasOwnProperty(key)) {
    value = flags[key] === null ? defaultValue : flags[key];
  } else {
    value = defaultValue;
  }

  sendFlagEvent(key, value, defaultValue);

  return value;
}

function allFlags() {
  var results = {};

  if (!flags) { return results; }

  for (var key in flags) {
    if (flags.hasOwnProperty(key)) {
      results[key] = variation(key, null);
    }
  }

  return results;
}

function customEventExists(key) {
  if (!goals || goals.length === 0) { return false; }

  for (var i=0 ; i < goals.length ; i++) {
    if (goals[i].kind === 'custom' && goals[i].key === key) {
      return true;
    }
  }

  return false;
}

function track(key, data) {
  if (typeof key !== 'string') {
    throw messages.invalidKey();
  }

  // Validate key if we have goals
  if (!!goals && !customEventExists(key)) {
    console.warn(messages.unknownCustomEventKey(key));
  }

  events.enqueue({
    kind: 'custom',
    key: key,
    data: data,
    url: window.location.href,
    creationDate: (new Date()).getTime()
  });
}

function connectStream() {
  stream.connect(function() {
    requestor.fetchFlagSettings(ident.getUser(), hash, function(err, settings) {
      if (err) {
        console.warn('Error fetching flag settings: ', err);
      }      
      updateSettings(settings);
    });
  });
}

function updateSettings(settings) {
  var changes;
  var keys;

  if (!settings) { return; }

  changes = utils.modifications(flags, settings);
  keys = Object.keys(changes);

  flags = settings;

  if (useLocalStorage) {
    localStorage.setItem(lsKey(environment, ident.getUser()), JSON.stringify(flags));
  }

  if (keys.length > 0) {
    keys.forEach(function(key) {
      emitter.emit(changeEvent + ':' + key, changes[key].current, changes[key].previous);
    });

    emitter.emit(changeEvent, changes);

    keys.forEach(function(key) {
      sendFlagEvent(key, changes[key].current);
    });
  }
}

function on(event, handler, context) {
  if (event.substr(0, changeEvent.length) === changeEvent) {
    if (!stream.isConnected()) {
      connectStream();
    }
    emitter.on.apply(emitter, [event, handler, context]);
  } else {
    emitter.on.apply(emitter, Array.prototype.slice.call(arguments));
  }
}

function off() {
  emitter.off.apply(emitter, Array.prototype.slice.call(arguments));
}

function handleMessage(event) {
  if (event.origin !== baseUrl) { return; }
  if (event.data.type === 'SYN') {
    window.editorClientBaseUrl = baseUrl;
    var editorTag = document.createElement('script');
    editorTag.type = 'text/javascript';
    editorTag.async = true;
    editorTag.src = baseUrl + event.data.editorClientUrl;
    var s = document.getElementsByTagName('script')[0];
    s.parentNode.insertBefore(editorTag, s);
  }
}

var client = {
  identify: identify,
  variation: variation,
  track: track,
  on: on,
  off: off,
  allFlags: allFlags
};

function lsKey(env, user) {
  var uKey = '';
  if (user && user.key) {
    uKey = user.key;
  }
  return 'ld:' + env + ':' + uKey;
}

function initialize(env, user, options) {
  var localStorageKey;
  options = options || {};
  environment = env;
  flags = typeof(options.bootstrap) === 'object' ? options.bootstrap : {};
  hash = options.hash;
  baseUrl = options.baseUrl || 'https://app.launchdarkly.com';
  eventsUrl = options.eventsUrl || 'https://events.launchdarkly.com';
  streamUrl = options.streamUrl || 'https://clientstream.launchdarkly.com';
  stream = Stream(streamUrl, environment);
  events = EventProcessor(eventsUrl + '/a/' + environment + '.gif');
  emitter = EventEmitter();
  ident = Identity(user, sendIdentifyEvent);
  requestor = Requestor(baseUrl, environment);
  localStorageKey = lsKey(environment, ident.getUser());

  if (typeof options.bootstrap === 'object') {
    // Emitting the event here will happen before the consumer
    // can register a listener, so defer to next tick.
    setTimeout(function() { emitter.emit(readyEvent); }, 0);
  }
  else if (typeof(options.bootstrap) === 'string' && options.bootstrap.toUpperCase() === 'LOCALSTORAGE' && typeof(Storage) !== 'undefined') {
    useLocalStorage = true;
    // check if localstorage data is corrupted, if so clear it
    try {
      flags = JSON.parse(localStorage.getItem(localStorageKey));
    } catch (error) {
      localStorage.setItem(localStorageKey, null);
    }

    if (flags === null) {
      requestor.fetchFlagSettings(ident.getUser(), hash, function(err, settings) {
        if (err) {
          console.warn('Error fetching flag settings: ', err);
        }        
        flags = settings;
        settings && localStorage.setItem(localStorageKey, JSON.stringify(flags));
        emitter.emit(readyEvent);
      });
    } else {
      // We're reading the flags from local storage. Signal that we're ready,
      // then update localStorage for the next page load. We won't signal changes or update
      // the in-memory flags unless you subscribe for changes
      setTimeout(function() { emitter.emit(readyEvent); }, 0);
      requestor.fetchFlagSettings(ident.getUser(), hash, function(err, settings) {
        if (err) {
          console.warn('Error fetching flag settings: ', err);
        }
        settings && localStorage.setItem(localStorageKey, JSON.stringify(settings));
      });
    }
  }
  else {
    requestor.fetchFlagSettings(ident.getUser(), hash, function(err, settings) {
      if (err) {
        console.warn('Error fetching flag settings: ', err);
      }
      
      flags = settings;
      emitter.emit(readyEvent);
    });
  }

  requestor.fetchGoals(function(err, g) {
    if (err) { 
      console.warn('Error fetching goals: ', err);
    }
    if (g && g.length > 0) {
      goals = g;
      goalTracker = GoalTracker(goals, sendGoalEvent);
    }
  });

  function start() {
    setTimeout(function tick() {
      events.flush(ident.getUser());
      setTimeout(tick, flushInterval);
    }, flushInterval);
  }

  if (document.readyState !== 'complete') {
    window.addEventListener('load', start);
  } else {
    start();
  }

  window.addEventListener('beforeunload', function() {
    events.flush(ident.getUser(), true);
  });

  function refreshGoalTracker() {
    if (goalTracker) {
      goalTracker.dispose();
    }
    if (goals && goals.length) {
      goalTracker = GoalTracker(goals, sendGoalEvent);
    }
  }

  if (goals && goals.length > 0) {
    if (!!(window.history && history.pushState)) {
      window.addEventListener('popstate', refreshGoalTracker);
    } else {
      window.addEventListener('hashchange', refreshGoalTracker);
    }
  }

  window.addEventListener('message', handleMessage);

  return client;
}

module.exports = {
  initialize: initialize
};

if(typeof VERSION !== 'undefined') {
  module.exports.version = VERSION;
}


/***/ }),
/* 1244 */
/***/ (function(module, exports, __webpack_require__) {

var utils = __webpack_require__(1196);

function EventProcessor(eventsUrl) {
  var processor = {};
  var queue = [];
  var initialFlush = true;
  
  processor.enqueue = function(event) {
    queue.push(event);
  };
  
  processor.flush = function(user, sync) {
    var maxLength = 2000 - eventsUrl.length;
    var data = [];
    
    if (!user) {
      if (initialFlush) {
        console && console.warn && console.warn('Be sure to call `identify` in the LaunchDarkly client: http://docs.launchdarkly.com/docs/running-an-ab-test#include-the-client-side-snippet');
      }
      return false;
    }
    
    initialFlush = false;
    while (maxLength > 0 && queue.length > 0) {
      var event = queue.pop();
      event.user = user;
      maxLength = maxLength - utils.base64URLEncode(JSON.stringify(event)).length;
      // If we are over the max size, put this one back on the queue
      // to try in the next round, unless this event alone is larger 
      // than the limit, in which case, screw it, and try it anyway.
      if (maxLength < 0 && data.length > 0) {
        queue.push(event);
      } else {
        data.push(event);
      }
    }
    
    if (data.length > 0) {
      var src = eventsUrl + '?d=' + utils.base64URLEncode(JSON.stringify(data));
      //Detect browser support for CORS
      if ('withCredentials' in new XMLHttpRequest()) {
        /* supports cross-domain requests */
        var xhr = new XMLHttpRequest();
        xhr.open('GET', src, !sync);
        xhr.send();
      } else {
        var img = new Image();
        img.src = src;
      }
    }

    // if the queue is not empty, call settimeout to flush it again 
    // with a 0 timeout (stack-less recursion)
    // Or, just recursively call flush_queue with the remaining elements
    // if we're doing this on unload
    if (queue.length > 0) {
      if (sync) {
        processor.flush(user, sync);
      }
      else {
        setTimeout(function() {
          processor.flush(user);
        }, 0);
      }
    }
    return false;
  };
  
  return processor;
}

module.exports = EventProcessor;


/***/ }),
/* 1245 */
/***/ (function(module, exports, __webpack_require__) {

;(function () {

  var object =  true ? exports : self; // #8: web workers
  var chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=';

  function InvalidCharacterError(message) {
    this.message = message;
  }
  InvalidCharacterError.prototype = new Error;
  InvalidCharacterError.prototype.name = 'InvalidCharacterError';

  // encoder
  // [https://gist.github.com/999166] by [https://github.com/nignag]
  object.btoa || (
  object.btoa = function (input) {
    var str = String(input);
    for (
      // initialize result and counter
      var block, charCode, idx = 0, map = chars, output = '';
      // if the next str index does not exist:
      //   change the mapping table to "="
      //   check if d has no fractional digits
      str.charAt(idx | 0) || (map = '=', idx % 1);
      // "8 - idx % 1 * 8" generates the sequence 2, 4, 6, 8
      output += map.charAt(63 & block >> 8 - idx % 1 * 8)
    ) {
      charCode = str.charCodeAt(idx += 3/4);
      if (charCode > 0xFF) {
        throw new InvalidCharacterError("'btoa' failed: The string to be encoded contains characters outside of the Latin1 range.");
      }
      block = block << 8 | charCode;
    }
    return output;
  });

  // decoder
  // [https://gist.github.com/1020396] by [https://github.com/atk]
  object.atob || (
  object.atob = function (input) {
    var str = String(input).replace(/=+$/, '');
    if (str.length % 4 == 1) {
      throw new InvalidCharacterError("'atob' failed: The string to be decoded is not correctly encoded.");
    }
    for (
      // initialize result and counters
      var bc = 0, bs, buffer, idx = 0, output = '';
      // get next character
      buffer = str.charAt(idx++);
      // character found in table? initialize bit storage and add its ascii value;
      ~buffer && (bs = bc % 4 ? bs * 64 + buffer : buffer,
        // and if not first of each 4 characters,
        // convert the first 8 bits to one ascii character
        bc++ % 4) ? output += String.fromCharCode(255 & bs >> (-2 * bc & 6)) : 0
    ) {
      // try to find character in table (0-63, not found => -1)
      buffer = chars.indexOf(buffer);
    }
    return output;
  });

}());


/***/ }),
/* 1246 */
/***/ (function(module, exports) {

function EventEmitter() {
  var emitter = {};
  var events = {};
  
  emitter.on = function(event, handler, context) {
    events[event] = events[event] || [];
    events[event] = events[event].concat({handler: handler, context: context});
  };
  
  emitter.off = function(event, handler, context) {
    if (!events[event]) { return; }
    for (var i = 0; i < events[event].length ; i++) {
      if (events[event][i].handler === handler && events[event][i].context === context) {
        events[event] = events[event].slice(0, i).concat(events[event].slice(i + 1));
      }
    }
  };
  
  emitter.emit = function(event) { 
    if (!events[event]) { return; }
    for (var i = 0; i < events[event].length; i++) {
      events[event][i].handler.apply(events[event][i].context, Array.prototype.slice.call(arguments, 1));
    }
  };
  
  return emitter;
}

module.exports = EventEmitter;


/***/ }),
/* 1247 */
/***/ (function(module, exports, __webpack_require__) {

var escapeStringRegexp = __webpack_require__(1248);

function doesUrlMatch(matcher, href, search, hash) {
  var canonicalUrl = href.replace(search, '').replace(hash, '');
  var regex;
  var testUrl;
  
  switch (matcher.kind) {
  case 'exact':
    testUrl = href;
    regex = new RegExp('^' + escapeStringRegexp(matcher.url) + '/?$');
    break;
  case 'canonical':
    testUrl = canonicalUrl;
    regex = new RegExp('^' + escapeStringRegexp(matcher.url) + '/?$');
    break;
  case 'substring':
    testUrl = canonicalUrl;
    regex = new RegExp('.*' + escapeStringRegexp(matcher.substring) + '.*$');
    break;
  case 'regex':
    testUrl = canonicalUrl;
    regex = new RegExp(matcher.pattern);
    break;
  default:
    return false;
  }
  return regex.test(testUrl);
}

function findGoalsForClick(event, clickGoals) {
  var matches = [];
  
  for (var i = 0; i < clickGoals.length; i++) {
    var target = event.target;
    var goal = clickGoals[i];
    var selector = goal.selector;
    var elements = document.querySelectorAll(selector);
    while (target && elements.length > 0) {
      for (var j = 0; j < elements.length; j++) {
        if (target === elements[j])
          matches.push(goal);
      }
      target = target.parentNode;
    }
  }
  
  return matches;
}

function GoalTracker(goals, onEvent) {
  var tracker = {};
  var goals = goals;
  var listenerFn = null;
  
  var clickGoals = [];
  
  for (var i = 0; i < goals.length; i++) {
    var goal = goals[i];
    var urls = goal.urls || [];
    
    for (var j = 0; j < urls.length; j++) {
      if (doesUrlMatch(urls[j], location.href, location.search, location.hash)) {
        if (goal.kind === 'pageview') {
          onEvent('pageview', goal);
        } else {
          clickGoals.push(goal);
          onEvent('click_pageview', goal);
        }
        break;
      }
    }
  }
  
  if (clickGoals.length > 0) {
    listenerFn = function(event) {
      var goals = findGoalsForClick(event, clickGoals);
      for (var i = 0; i < goals.length; i++) {
        onEvent('click', goals[i]);
      }
    };

    document.addEventListener('click', listenerFn);
  }

  tracker.dispose = function() {
    document.removeEventListener('click', listenerFn);
  }
  
  return tracker;
}

module.exports = GoalTracker;


/***/ }),
/* 1248 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var matchOperatorsRe = /[|\\{}()[\]^$+*?.]/g;

module.exports = function (str) {
	if (typeof str !== 'string') {
		throw new TypeError('Expected a string');
	}

	return str.replace(matchOperatorsRe, '\\$&');
};


/***/ }),
/* 1249 */
/***/ (function(module, exports) {

function Stream(url, environment) {
  var stream = {};
  var url = url + '/ping/' + environment;
  var es = null;

  stream.connect = function(onPing) {
    if (typeof EventSource !== 'undefined') {
      es = new window.EventSource(url);
      es.addEventListener('ping', onPing);
    }
  }

  stream.disconnect = function() {
    es && es.close();
  }

  stream.isConnected = function() {
    return es && (es.readyState === EventSource.OPEN || es.readyState === EventSource.CONNECTING);
  }

  return stream;
}

module.exports = Stream;


/***/ }),
/* 1250 */
/***/ (function(module, exports, __webpack_require__) {

var utils = __webpack_require__(1196);

var json = 'application/json';

function fetchJSON(endpoint, callback) {
  var xhr = new XMLHttpRequest();
  
  xhr.addEventListener('load', function() {
    if (xhr.status === 200 && xhr.getResponseHeader('Content-type') === json) {
      callback(null, JSON.parse(xhr.responseText));
    } else {
      callback(xhr.statusText);
    }
  });
  
  xhr.addEventListener('error', function() {
    callback(xhr.statusText);
  });
  
  xhr.open('GET', endpoint);
  xhr.send();
  
  return xhr;
}

var flagSettingsRequest;
var lastFlagSettingsCallback;

function Requestor(baseUrl, environment) {
  var requestor = {};
  
  requestor.fetchFlagSettings = function(user, hash, callback) {
    var data = utils.base64URLEncode(JSON.stringify(user));
    var endpoint = [baseUrl, '/sdk/eval/', environment,  '/users/', data, hash ? '?h=' + hash : ''].join('');
    var cb;

    var wrappedCallback = (function(currentCallback) {
      return function() {
        currentCallback.apply(null, arguments);
        flagSettingsRequest = null;
        lastFlagSettingsCallback = null;
      };
    })(callback);
    

    if (flagSettingsRequest) {
      flagSettingsRequest.abort();
      cb = (function(prevCallback) {
        return function() {
          prevCallback && prevCallback.apply(null, arguments);
          wrappedCallback.apply(null, arguments);
        };
      })(lastFlagSettingsCallback);
    } else {
      cb = wrappedCallback;
    }

    lastFlagSettingsCallback = cb;
    flagSettingsRequest = fetchJSON(endpoint, cb);
  };
  
  requestor.fetchGoals = function(callback) {
    var endpoint = [baseUrl, '/sdk/goals/', environment].join('');
    fetchJSON(endpoint, callback);
  };
  
  return requestor;
}

module.exports = Requestor;


/***/ }),
/* 1251 */
/***/ (function(module, exports, __webpack_require__) {

var utils = __webpack_require__(1196);

function sanitizeUser(u) {
  var sane = utils.clone(u);
  if (sane.key) {
    sane.key = sane.key.toString();
  }
  return sane;
}

function Identity(initialUser, onChange) {
  var ident = {};
  var user;
  
  ident.setUser = function(u) {
    user = sanitizeUser(u);
    onChange(utils.clone(user));
  };
  
  ident.getUser = function() {
    return utils.clone(user);
  };
  
  if (initialUser) {
    ident.setUser(initialUser);
  }
  
  return ident;
}

module.exports = Identity;


/***/ }),
/* 1252 */
/***/ (function(module, exports) {

module.exports ={
  invalidKey: function() {
    return 'Event key must be a string';
  },
  unknownCustomEventKey: function(key) {
    return 'Custom event "' + key + '" does not exist'
  }
};


/***/ }),
/* 1253 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
// Copyright Joyent, Inc. and other Node contributors.
//
// Permission is hereby granted, free of charge, to any person obtaining a
// copy of this software and associated documentation files (the
// "Software"), to deal in the Software without restriction, including
// without limitation the rights to use, copy, modify, merge, publish,
// distribute, sublicense, and/or sell copies of the Software, and to permit
// persons to whom the Software is furnished to do so, subject to the
// following conditions:
//
// The above copyright notice and this permission notice shall be included
// in all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
// OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
// MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN
// NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
// DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
// OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE
// USE OR OTHER DEALINGS IN THE SOFTWARE.



var punycode = __webpack_require__(1254);
var util = __webpack_require__(1255);

exports.parse = urlParse;
exports.resolve = urlResolve;
exports.resolveObject = urlResolveObject;
exports.format = urlFormat;

exports.Url = Url;

function Url() {
  this.protocol = null;
  this.slashes = null;
  this.auth = null;
  this.host = null;
  this.port = null;
  this.hostname = null;
  this.hash = null;
  this.search = null;
  this.query = null;
  this.pathname = null;
  this.path = null;
  this.href = null;
}

// Reference: RFC 3986, RFC 1808, RFC 2396

// define these here so at least they only have to be
// compiled once on the first module load.
var protocolPattern = /^([a-z0-9.+-]+:)/i,
    portPattern = /:[0-9]*$/,

    // Special case for a simple path URL
    simplePathPattern = /^(\/\/?(?!\/)[^\?\s]*)(\?[^\s]*)?$/,

    // RFC 2396: characters reserved for delimiting URLs.
    // We actually just auto-escape these.
    delims = ['<', '>', '"', '`', ' ', '\r', '\n', '\t'],

    // RFC 2396: characters not allowed for various reasons.
    unwise = ['{', '}', '|', '\\', '^', '`'].concat(delims),

    // Allowed by RFCs, but cause of XSS attacks.  Always escape these.
    autoEscape = ['\''].concat(unwise),
    // Characters that are never ever allowed in a hostname.
    // Note that any invalid chars are also handled, but these
    // are the ones that are *expected* to be seen, so we fast-path
    // them.
    nonHostChars = ['%', '/', '?', ';', '#'].concat(autoEscape),
    hostEndingChars = ['/', '?', '#'],
    hostnameMaxLen = 255,
    hostnamePartPattern = /^[+a-z0-9A-Z_-]{0,63}$/,
    hostnamePartStart = /^([+a-z0-9A-Z_-]{0,63})(.*)$/,
    // protocols that can allow "unsafe" and "unwise" chars.
    unsafeProtocol = {
      'javascript': true,
      'javascript:': true
    },
    // protocols that never have a hostname.
    hostlessProtocol = {
      'javascript': true,
      'javascript:': true
    },
    // protocols that always contain a // bit.
    slashedProtocol = {
      'http': true,
      'https': true,
      'ftp': true,
      'gopher': true,
      'file': true,
      'http:': true,
      'https:': true,
      'ftp:': true,
      'gopher:': true,
      'file:': true
    },
    querystring = __webpack_require__(1256);

function urlParse(url, parseQueryString, slashesDenoteHost) {
  if (url && util.isObject(url) && url instanceof Url) return url;

  var u = new Url;
  u.parse(url, parseQueryString, slashesDenoteHost);
  return u;
}

Url.prototype.parse = function(url, parseQueryString, slashesDenoteHost) {
  if (!util.isString(url)) {
    throw new TypeError("Parameter 'url' must be a string, not " + typeof url);
  }

  // Copy chrome, IE, opera backslash-handling behavior.
  // Back slashes before the query string get converted to forward slashes
  // See: https://code.google.com/p/chromium/issues/detail?id=25916
  var queryIndex = url.indexOf('?'),
      splitter =
          (queryIndex !== -1 && queryIndex < url.indexOf('#')) ? '?' : '#',
      uSplit = url.split(splitter),
      slashRegex = /\\/g;
  uSplit[0] = uSplit[0].replace(slashRegex, '/');
  url = uSplit.join(splitter);

  var rest = url;

  // trim before proceeding.
  // This is to support parse stuff like "  http://foo.com  \n"
  rest = rest.trim();

  if (!slashesDenoteHost && url.split('#').length === 1) {
    // Try fast path regexp
    var simplePath = simplePathPattern.exec(rest);
    if (simplePath) {
      this.path = rest;
      this.href = rest;
      this.pathname = simplePath[1];
      if (simplePath[2]) {
        this.search = simplePath[2];
        if (parseQueryString) {
          this.query = querystring.parse(this.search.substr(1));
        } else {
          this.query = this.search.substr(1);
        }
      } else if (parseQueryString) {
        this.search = '';
        this.query = {};
      }
      return this;
    }
  }

  var proto = protocolPattern.exec(rest);
  if (proto) {
    proto = proto[0];
    var lowerProto = proto.toLowerCase();
    this.protocol = lowerProto;
    rest = rest.substr(proto.length);
  }

  // figure out if it's got a host
  // user@server is *always* interpreted as a hostname, and url
  // resolution will treat //foo/bar as host=foo,path=bar because that's
  // how the browser resolves relative URLs.
  if (slashesDenoteHost || proto || rest.match(/^\/\/[^@\/]+@[^@\/]+/)) {
    var slashes = rest.substr(0, 2) === '//';
    if (slashes && !(proto && hostlessProtocol[proto])) {
      rest = rest.substr(2);
      this.slashes = true;
    }
  }

  if (!hostlessProtocol[proto] &&
      (slashes || (proto && !slashedProtocol[proto]))) {

    // there's a hostname.
    // the first instance of /, ?, ;, or # ends the host.
    //
    // If there is an @ in the hostname, then non-host chars *are* allowed
    // to the left of the last @ sign, unless some host-ending character
    // comes *before* the @-sign.
    // URLs are obnoxious.
    //
    // ex:
    // http://a@b@c/ => user:a@b host:c
    // http://a@b?@c => user:a host:c path:/?@c

    // v0.12 TODO(isaacs): This is not quite how Chrome does things.
    // Review our test case against browsers more comprehensively.

    // find the first instance of any hostEndingChars
    var hostEnd = -1;
    for (var i = 0; i < hostEndingChars.length; i++) {
      var hec = rest.indexOf(hostEndingChars[i]);
      if (hec !== -1 && (hostEnd === -1 || hec < hostEnd))
        hostEnd = hec;
    }

    // at this point, either we have an explicit point where the
    // auth portion cannot go past, or the last @ char is the decider.
    var auth, atSign;
    if (hostEnd === -1) {
      // atSign can be anywhere.
      atSign = rest.lastIndexOf('@');
    } else {
      // atSign must be in auth portion.
      // http://a@b/c@d => host:b auth:a path:/c@d
      atSign = rest.lastIndexOf('@', hostEnd);
    }

    // Now we have a portion which is definitely the auth.
    // Pull that off.
    if (atSign !== -1) {
      auth = rest.slice(0, atSign);
      rest = rest.slice(atSign + 1);
      this.auth = decodeURIComponent(auth);
    }

    // the host is the remaining to the left of the first non-host char
    hostEnd = -1;
    for (var i = 0; i < nonHostChars.length; i++) {
      var hec = rest.indexOf(nonHostChars[i]);
      if (hec !== -1 && (hostEnd === -1 || hec < hostEnd))
        hostEnd = hec;
    }
    // if we still have not hit it, then the entire thing is a host.
    if (hostEnd === -1)
      hostEnd = rest.length;

    this.host = rest.slice(0, hostEnd);
    rest = rest.slice(hostEnd);

    // pull out port.
    this.parseHost();

    // we've indicated that there is a hostname,
    // so even if it's empty, it has to be present.
    this.hostname = this.hostname || '';

    // if hostname begins with [ and ends with ]
    // assume that it's an IPv6 address.
    var ipv6Hostname = this.hostname[0] === '[' &&
        this.hostname[this.hostname.length - 1] === ']';

    // validate a little.
    if (!ipv6Hostname) {
      var hostparts = this.hostname.split(/\./);
      for (var i = 0, l = hostparts.length; i < l; i++) {
        var part = hostparts[i];
        if (!part) continue;
        if (!part.match(hostnamePartPattern)) {
          var newpart = '';
          for (var j = 0, k = part.length; j < k; j++) {
            if (part.charCodeAt(j) > 127) {
              // we replace non-ASCII char with a temporary placeholder
              // we need this to make sure size of hostname is not
              // broken by replacing non-ASCII by nothing
              newpart += 'x';
            } else {
              newpart += part[j];
            }
          }
          // we test again with ASCII char only
          if (!newpart.match(hostnamePartPattern)) {
            var validParts = hostparts.slice(0, i);
            var notHost = hostparts.slice(i + 1);
            var bit = part.match(hostnamePartStart);
            if (bit) {
              validParts.push(bit[1]);
              notHost.unshift(bit[2]);
            }
            if (notHost.length) {
              rest = '/' + notHost.join('.') + rest;
            }
            this.hostname = validParts.join('.');
            break;
          }
        }
      }
    }

    if (this.hostname.length > hostnameMaxLen) {
      this.hostname = '';
    } else {
      // hostnames are always lower case.
      this.hostname = this.hostname.toLowerCase();
    }

    if (!ipv6Hostname) {
      // IDNA Support: Returns a punycoded representation of "domain".
      // It only converts parts of the domain name that
      // have non-ASCII characters, i.e. it doesn't matter if
      // you call it with a domain that already is ASCII-only.
      this.hostname = punycode.toASCII(this.hostname);
    }

    var p = this.port ? ':' + this.port : '';
    var h = this.hostname || '';
    this.host = h + p;
    this.href += this.host;

    // strip [ and ] from the hostname
    // the host field still retains them, though
    if (ipv6Hostname) {
      this.hostname = this.hostname.substr(1, this.hostname.length - 2);
      if (rest[0] !== '/') {
        rest = '/' + rest;
      }
    }
  }

  // now rest is set to the post-host stuff.
  // chop off any delim chars.
  if (!unsafeProtocol[lowerProto]) {

    // First, make 100% sure that any "autoEscape" chars get
    // escaped, even if encodeURIComponent doesn't think they
    // need to be.
    for (var i = 0, l = autoEscape.length; i < l; i++) {
      var ae = autoEscape[i];
      if (rest.indexOf(ae) === -1)
        continue;
      var esc = encodeURIComponent(ae);
      if (esc === ae) {
        esc = escape(ae);
      }
      rest = rest.split(ae).join(esc);
    }
  }


  // chop off from the tail first.
  var hash = rest.indexOf('#');
  if (hash !== -1) {
    // got a fragment string.
    this.hash = rest.substr(hash);
    rest = rest.slice(0, hash);
  }
  var qm = rest.indexOf('?');
  if (qm !== -1) {
    this.search = rest.substr(qm);
    this.query = rest.substr(qm + 1);
    if (parseQueryString) {
      this.query = querystring.parse(this.query);
    }
    rest = rest.slice(0, qm);
  } else if (parseQueryString) {
    // no query string, but parseQueryString still requested
    this.search = '';
    this.query = {};
  }
  if (rest) this.pathname = rest;
  if (slashedProtocol[lowerProto] &&
      this.hostname && !this.pathname) {
    this.pathname = '/';
  }

  //to support http.request
  if (this.pathname || this.search) {
    var p = this.pathname || '';
    var s = this.search || '';
    this.path = p + s;
  }

  // finally, reconstruct the href based on what has been validated.
  this.href = this.format();
  return this;
};

// format a parsed object into a url string
function urlFormat(obj) {
  // ensure it's an object, and not a string url.
  // If it's an obj, this is a no-op.
  // this way, you can call url_format() on strings
  // to clean up potentially wonky urls.
  if (util.isString(obj)) obj = urlParse(obj);
  if (!(obj instanceof Url)) return Url.prototype.format.call(obj);
  return obj.format();
}

Url.prototype.format = function() {
  var auth = this.auth || '';
  if (auth) {
    auth = encodeURIComponent(auth);
    auth = auth.replace(/%3A/i, ':');
    auth += '@';
  }

  var protocol = this.protocol || '',
      pathname = this.pathname || '',
      hash = this.hash || '',
      host = false,
      query = '';

  if (this.host) {
    host = auth + this.host;
  } else if (this.hostname) {
    host = auth + (this.hostname.indexOf(':') === -1 ?
        this.hostname :
        '[' + this.hostname + ']');
    if (this.port) {
      host += ':' + this.port;
    }
  }

  if (this.query &&
      util.isObject(this.query) &&
      Object.keys(this.query).length) {
    query = querystring.stringify(this.query);
  }

  var search = this.search || (query && ('?' + query)) || '';

  if (protocol && protocol.substr(-1) !== ':') protocol += ':';

  // only the slashedProtocols get the //.  Not mailto:, xmpp:, etc.
  // unless they had them to begin with.
  if (this.slashes ||
      (!protocol || slashedProtocol[protocol]) && host !== false) {
    host = '//' + (host || '');
    if (pathname && pathname.charAt(0) !== '/') pathname = '/' + pathname;
  } else if (!host) {
    host = '';
  }

  if (hash && hash.charAt(0) !== '#') hash = '#' + hash;
  if (search && search.charAt(0) !== '?') search = '?' + search;

  pathname = pathname.replace(/[?#]/g, function(match) {
    return encodeURIComponent(match);
  });
  search = search.replace('#', '%23');

  return protocol + host + pathname + search + hash;
};

function urlResolve(source, relative) {
  return urlParse(source, false, true).resolve(relative);
}

Url.prototype.resolve = function(relative) {
  return this.resolveObject(urlParse(relative, false, true)).format();
};

function urlResolveObject(source, relative) {
  if (!source) return relative;
  return urlParse(source, false, true).resolveObject(relative);
}

Url.prototype.resolveObject = function(relative) {
  if (util.isString(relative)) {
    var rel = new Url();
    rel.parse(relative, false, true);
    relative = rel;
  }

  var result = new Url();
  var tkeys = Object.keys(this);
  for (var tk = 0; tk < tkeys.length; tk++) {
    var tkey = tkeys[tk];
    result[tkey] = this[tkey];
  }

  // hash is always overridden, no matter what.
  // even href="" will remove it.
  result.hash = relative.hash;

  // if the relative url is empty, then there's nothing left to do here.
  if (relative.href === '') {
    result.href = result.format();
    return result;
  }

  // hrefs like //foo/bar always cut to the protocol.
  if (relative.slashes && !relative.protocol) {
    // take everything except the protocol from relative
    var rkeys = Object.keys(relative);
    for (var rk = 0; rk < rkeys.length; rk++) {
      var rkey = rkeys[rk];
      if (rkey !== 'protocol')
        result[rkey] = relative[rkey];
    }

    //urlParse appends trailing / to urls like http://www.example.com
    if (slashedProtocol[result.protocol] &&
        result.hostname && !result.pathname) {
      result.path = result.pathname = '/';
    }

    result.href = result.format();
    return result;
  }

  if (relative.protocol && relative.protocol !== result.protocol) {
    // if it's a known url protocol, then changing
    // the protocol does weird things
    // first, if it's not file:, then we MUST have a host,
    // and if there was a path
    // to begin with, then we MUST have a path.
    // if it is file:, then the host is dropped,
    // because that's known to be hostless.
    // anything else is assumed to be absolute.
    if (!slashedProtocol[relative.protocol]) {
      var keys = Object.keys(relative);
      for (var v = 0; v < keys.length; v++) {
        var k = keys[v];
        result[k] = relative[k];
      }
      result.href = result.format();
      return result;
    }

    result.protocol = relative.protocol;
    if (!relative.host && !hostlessProtocol[relative.protocol]) {
      var relPath = (relative.pathname || '').split('/');
      while (relPath.length && !(relative.host = relPath.shift()));
      if (!relative.host) relative.host = '';
      if (!relative.hostname) relative.hostname = '';
      if (relPath[0] !== '') relPath.unshift('');
      if (relPath.length < 2) relPath.unshift('');
      result.pathname = relPath.join('/');
    } else {
      result.pathname = relative.pathname;
    }
    result.search = relative.search;
    result.query = relative.query;
    result.host = relative.host || '';
    result.auth = relative.auth;
    result.hostname = relative.hostname || relative.host;
    result.port = relative.port;
    // to support http.request
    if (result.pathname || result.search) {
      var p = result.pathname || '';
      var s = result.search || '';
      result.path = p + s;
    }
    result.slashes = result.slashes || relative.slashes;
    result.href = result.format();
    return result;
  }

  var isSourceAbs = (result.pathname && result.pathname.charAt(0) === '/'),
      isRelAbs = (
          relative.host ||
          relative.pathname && relative.pathname.charAt(0) === '/'
      ),
      mustEndAbs = (isRelAbs || isSourceAbs ||
                    (result.host && relative.pathname)),
      removeAllDots = mustEndAbs,
      srcPath = result.pathname && result.pathname.split('/') || [],
      relPath = relative.pathname && relative.pathname.split('/') || [],
      psychotic = result.protocol && !slashedProtocol[result.protocol];

  // if the url is a non-slashed url, then relative
  // links like ../.. should be able
  // to crawl up to the hostname, as well.  This is strange.
  // result.protocol has already been set by now.
  // Later on, put the first path part into the host field.
  if (psychotic) {
    result.hostname = '';
    result.port = null;
    if (result.host) {
      if (srcPath[0] === '') srcPath[0] = result.host;
      else srcPath.unshift(result.host);
    }
    result.host = '';
    if (relative.protocol) {
      relative.hostname = null;
      relative.port = null;
      if (relative.host) {
        if (relPath[0] === '') relPath[0] = relative.host;
        else relPath.unshift(relative.host);
      }
      relative.host = null;
    }
    mustEndAbs = mustEndAbs && (relPath[0] === '' || srcPath[0] === '');
  }

  if (isRelAbs) {
    // it's absolute.
    result.host = (relative.host || relative.host === '') ?
                  relative.host : result.host;
    result.hostname = (relative.hostname || relative.hostname === '') ?
                      relative.hostname : result.hostname;
    result.search = relative.search;
    result.query = relative.query;
    srcPath = relPath;
    // fall through to the dot-handling below.
  } else if (relPath.length) {
    // it's relative
    // throw away the existing file, and take the new path instead.
    if (!srcPath) srcPath = [];
    srcPath.pop();
    srcPath = srcPath.concat(relPath);
    result.search = relative.search;
    result.query = relative.query;
  } else if (!util.isNullOrUndefined(relative.search)) {
    // just pull out the search.
    // like href='?foo'.
    // Put this after the other two cases because it simplifies the booleans
    if (psychotic) {
      result.hostname = result.host = srcPath.shift();
      //occationaly the auth can get stuck only in host
      //this especially happens in cases like
      //url.resolveObject('mailto:local1@domain1', 'local2@domain2')
      var authInHost = result.host && result.host.indexOf('@') > 0 ?
                       result.host.split('@') : false;
      if (authInHost) {
        result.auth = authInHost.shift();
        result.host = result.hostname = authInHost.shift();
      }
    }
    result.search = relative.search;
    result.query = relative.query;
    //to support http.request
    if (!util.isNull(result.pathname) || !util.isNull(result.search)) {
      result.path = (result.pathname ? result.pathname : '') +
                    (result.search ? result.search : '');
    }
    result.href = result.format();
    return result;
  }

  if (!srcPath.length) {
    // no path at all.  easy.
    // we've already handled the other stuff above.
    result.pathname = null;
    //to support http.request
    if (result.search) {
      result.path = '/' + result.search;
    } else {
      result.path = null;
    }
    result.href = result.format();
    return result;
  }

  // if a url ENDs in . or .., then it must get a trailing slash.
  // however, if it ends in anything else non-slashy,
  // then it must NOT get a trailing slash.
  var last = srcPath.slice(-1)[0];
  var hasTrailingSlash = (
      (result.host || relative.host || srcPath.length > 1) &&
      (last === '.' || last === '..') || last === '');

  // strip single dots, resolve double dots to parent dir
  // if the path tries to go above the root, `up` ends up > 0
  var up = 0;
  for (var i = srcPath.length; i >= 0; i--) {
    last = srcPath[i];
    if (last === '.') {
      srcPath.splice(i, 1);
    } else if (last === '..') {
      srcPath.splice(i, 1);
      up++;
    } else if (up) {
      srcPath.splice(i, 1);
      up--;
    }
  }

  // if the path is allowed to go above the root, restore leading ..s
  if (!mustEndAbs && !removeAllDots) {
    for (; up--; up) {
      srcPath.unshift('..');
    }
  }

  if (mustEndAbs && srcPath[0] !== '' &&
      (!srcPath[0] || srcPath[0].charAt(0) !== '/')) {
    srcPath.unshift('');
  }

  if (hasTrailingSlash && (srcPath.join('/').substr(-1) !== '/')) {
    srcPath.push('');
  }

  var isAbsolute = srcPath[0] === '' ||
      (srcPath[0] && srcPath[0].charAt(0) === '/');

  // put the host back
  if (psychotic) {
    result.hostname = result.host = isAbsolute ? '' :
                                    srcPath.length ? srcPath.shift() : '';
    //occationaly the auth can get stuck only in host
    //this especially happens in cases like
    //url.resolveObject('mailto:local1@domain1', 'local2@domain2')
    var authInHost = result.host && result.host.indexOf('@') > 0 ?
                     result.host.split('@') : false;
    if (authInHost) {
      result.auth = authInHost.shift();
      result.host = result.hostname = authInHost.shift();
    }
  }

  mustEndAbs = mustEndAbs || (result.host && srcPath.length);

  if (mustEndAbs && !isAbsolute) {
    srcPath.unshift('');
  }

  if (!srcPath.length) {
    result.pathname = null;
    result.path = null;
  } else {
    result.pathname = srcPath.join('/');
  }

  //to support request.http
  if (!util.isNull(result.pathname) || !util.isNull(result.search)) {
    result.path = (result.pathname ? result.pathname : '') +
                  (result.search ? result.search : '');
  }
  result.auth = relative.auth || result.auth;
  result.slashes = result.slashes || relative.slashes;
  result.href = result.format();
  return result;
};

Url.prototype.parseHost = function() {
  var host = this.host;
  var port = portPattern.exec(host);
  if (port) {
    port = port[0];
    if (port !== ':') {
      this.port = port.substr(1);
    }
    host = host.substr(0, host.length - port.length);
  }
  if (host) this.hostname = host;
};


/***/ }),
/* 1254 */
/***/ (function(module, exports, __webpack_require__) {

/* WEBPACK VAR INJECTION */(function(module, global) {var __WEBPACK_AMD_DEFINE_RESULT__;/*! https://mths.be/punycode v1.4.1 by @mathias */
;(function(root) {

	/** Detect free variables */
	var freeExports = typeof exports == 'object' && exports &&
		!exports.nodeType && exports;
	var freeModule = typeof module == 'object' && module &&
		!module.nodeType && module;
	var freeGlobal = typeof global == 'object' && global;
	if (
		freeGlobal.global === freeGlobal ||
		freeGlobal.window === freeGlobal ||
		freeGlobal.self === freeGlobal
	) {
		root = freeGlobal;
	}

	/**
	 * The `punycode` object.
	 * @name punycode
	 * @type Object
	 */
	var punycode,

	/** Highest positive signed 32-bit float value */
	maxInt = 2147483647, // aka. 0x7FFFFFFF or 2^31-1

	/** Bootstring parameters */
	base = 36,
	tMin = 1,
	tMax = 26,
	skew = 38,
	damp = 700,
	initialBias = 72,
	initialN = 128, // 0x80
	delimiter = '-', // '\x2D'

	/** Regular expressions */
	regexPunycode = /^xn--/,
	regexNonASCII = /[^\x20-\x7E]/, // unprintable ASCII chars + non-ASCII chars
	regexSeparators = /[\x2E\u3002\uFF0E\uFF61]/g, // RFC 3490 separators

	/** Error messages */
	errors = {
		'overflow': 'Overflow: input needs wider integers to process',
		'not-basic': 'Illegal input >= 0x80 (not a basic code point)',
		'invalid-input': 'Invalid input'
	},

	/** Convenience shortcuts */
	baseMinusTMin = base - tMin,
	floor = Math.floor,
	stringFromCharCode = String.fromCharCode,

	/** Temporary variable */
	key;

	/*--------------------------------------------------------------------------*/

	/**
	 * A generic error utility function.
	 * @private
	 * @param {String} type The error type.
	 * @returns {Error} Throws a `RangeError` with the applicable error message.
	 */
	function error(type) {
		throw new RangeError(errors[type]);
	}

	/**
	 * A generic `Array#map` utility function.
	 * @private
	 * @param {Array} array The array to iterate over.
	 * @param {Function} callback The function that gets called for every array
	 * item.
	 * @returns {Array} A new array of values returned by the callback function.
	 */
	function map(array, fn) {
		var length = array.length;
		var result = [];
		while (length--) {
			result[length] = fn(array[length]);
		}
		return result;
	}

	/**
	 * A simple `Array#map`-like wrapper to work with domain name strings or email
	 * addresses.
	 * @private
	 * @param {String} domain The domain name or email address.
	 * @param {Function} callback The function that gets called for every
	 * character.
	 * @returns {Array} A new string of characters returned by the callback
	 * function.
	 */
	function mapDomain(string, fn) {
		var parts = string.split('@');
		var result = '';
		if (parts.length > 1) {
			// In email addresses, only the domain name should be punycoded. Leave
			// the local part (i.e. everything up to `@`) intact.
			result = parts[0] + '@';
			string = parts[1];
		}
		// Avoid `split(regex)` for IE8 compatibility. See #17.
		string = string.replace(regexSeparators, '\x2E');
		var labels = string.split('.');
		var encoded = map(labels, fn).join('.');
		return result + encoded;
	}

	/**
	 * Creates an array containing the numeric code points of each Unicode
	 * character in the string. While JavaScript uses UCS-2 internally,
	 * this function will convert a pair of surrogate halves (each of which
	 * UCS-2 exposes as separate characters) into a single code point,
	 * matching UTF-16.
	 * @see `punycode.ucs2.encode`
	 * @see <https://mathiasbynens.be/notes/javascript-encoding>
	 * @memberOf punycode.ucs2
	 * @name decode
	 * @param {String} string The Unicode input string (UCS-2).
	 * @returns {Array} The new array of code points.
	 */
	function ucs2decode(string) {
		var output = [],
		    counter = 0,
		    length = string.length,
		    value,
		    extra;
		while (counter < length) {
			value = string.charCodeAt(counter++);
			if (value >= 0xD800 && value <= 0xDBFF && counter < length) {
				// high surrogate, and there is a next character
				extra = string.charCodeAt(counter++);
				if ((extra & 0xFC00) == 0xDC00) { // low surrogate
					output.push(((value & 0x3FF) << 10) + (extra & 0x3FF) + 0x10000);
				} else {
					// unmatched surrogate; only append this code unit, in case the next
					// code unit is the high surrogate of a surrogate pair
					output.push(value);
					counter--;
				}
			} else {
				output.push(value);
			}
		}
		return output;
	}

	/**
	 * Creates a string based on an array of numeric code points.
	 * @see `punycode.ucs2.decode`
	 * @memberOf punycode.ucs2
	 * @name encode
	 * @param {Array} codePoints The array of numeric code points.
	 * @returns {String} The new Unicode string (UCS-2).
	 */
	function ucs2encode(array) {
		return map(array, function(value) {
			var output = '';
			if (value > 0xFFFF) {
				value -= 0x10000;
				output += stringFromCharCode(value >>> 10 & 0x3FF | 0xD800);
				value = 0xDC00 | value & 0x3FF;
			}
			output += stringFromCharCode(value);
			return output;
		}).join('');
	}

	/**
	 * Converts a basic code point into a digit/integer.
	 * @see `digitToBasic()`
	 * @private
	 * @param {Number} codePoint The basic numeric code point value.
	 * @returns {Number} The numeric value of a basic code point (for use in
	 * representing integers) in the range `0` to `base - 1`, or `base` if
	 * the code point does not represent a value.
	 */
	function basicToDigit(codePoint) {
		if (codePoint - 48 < 10) {
			return codePoint - 22;
		}
		if (codePoint - 65 < 26) {
			return codePoint - 65;
		}
		if (codePoint - 97 < 26) {
			return codePoint - 97;
		}
		return base;
	}

	/**
	 * Converts a digit/integer into a basic code point.
	 * @see `basicToDigit()`
	 * @private
	 * @param {Number} digit The numeric value of a basic code point.
	 * @returns {Number} The basic code point whose value (when used for
	 * representing integers) is `digit`, which needs to be in the range
	 * `0` to `base - 1`. If `flag` is non-zero, the uppercase form is
	 * used; else, the lowercase form is used. The behavior is undefined
	 * if `flag` is non-zero and `digit` has no uppercase form.
	 */
	function digitToBasic(digit, flag) {
		//  0..25 map to ASCII a..z or A..Z
		// 26..35 map to ASCII 0..9
		return digit + 22 + 75 * (digit < 26) - ((flag != 0) << 5);
	}

	/**
	 * Bias adaptation function as per section 3.4 of RFC 3492.
	 * https://tools.ietf.org/html/rfc3492#section-3.4
	 * @private
	 */
	function adapt(delta, numPoints, firstTime) {
		var k = 0;
		delta = firstTime ? floor(delta / damp) : delta >> 1;
		delta += floor(delta / numPoints);
		for (/* no initialization */; delta > baseMinusTMin * tMax >> 1; k += base) {
			delta = floor(delta / baseMinusTMin);
		}
		return floor(k + (baseMinusTMin + 1) * delta / (delta + skew));
	}

	/**
	 * Converts a Punycode string of ASCII-only symbols to a string of Unicode
	 * symbols.
	 * @memberOf punycode
	 * @param {String} input The Punycode string of ASCII-only symbols.
	 * @returns {String} The resulting string of Unicode symbols.
	 */
	function decode(input) {
		// Don't use UCS-2
		var output = [],
		    inputLength = input.length,
		    out,
		    i = 0,
		    n = initialN,
		    bias = initialBias,
		    basic,
		    j,
		    index,
		    oldi,
		    w,
		    k,
		    digit,
		    t,
		    /** Cached calculation results */
		    baseMinusT;

		// Handle the basic code points: let `basic` be the number of input code
		// points before the last delimiter, or `0` if there is none, then copy
		// the first basic code points to the output.

		basic = input.lastIndexOf(delimiter);
		if (basic < 0) {
			basic = 0;
		}

		for (j = 0; j < basic; ++j) {
			// if it's not a basic code point
			if (input.charCodeAt(j) >= 0x80) {
				error('not-basic');
			}
			output.push(input.charCodeAt(j));
		}

		// Main decoding loop: start just after the last delimiter if any basic code
		// points were copied; start at the beginning otherwise.

		for (index = basic > 0 ? basic + 1 : 0; index < inputLength; /* no final expression */) {

			// `index` is the index of the next character to be consumed.
			// Decode a generalized variable-length integer into `delta`,
			// which gets added to `i`. The overflow checking is easier
			// if we increase `i` as we go, then subtract off its starting
			// value at the end to obtain `delta`.
			for (oldi = i, w = 1, k = base; /* no condition */; k += base) {

				if (index >= inputLength) {
					error('invalid-input');
				}

				digit = basicToDigit(input.charCodeAt(index++));

				if (digit >= base || digit > floor((maxInt - i) / w)) {
					error('overflow');
				}

				i += digit * w;
				t = k <= bias ? tMin : (k >= bias + tMax ? tMax : k - bias);

				if (digit < t) {
					break;
				}

				baseMinusT = base - t;
				if (w > floor(maxInt / baseMinusT)) {
					error('overflow');
				}

				w *= baseMinusT;

			}

			out = output.length + 1;
			bias = adapt(i - oldi, out, oldi == 0);

			// `i` was supposed to wrap around from `out` to `0`,
			// incrementing `n` each time, so we'll fix that now:
			if (floor(i / out) > maxInt - n) {
				error('overflow');
			}

			n += floor(i / out);
			i %= out;

			// Insert `n` at position `i` of the output
			output.splice(i++, 0, n);

		}

		return ucs2encode(output);
	}

	/**
	 * Converts a string of Unicode symbols (e.g. a domain name label) to a
	 * Punycode string of ASCII-only symbols.
	 * @memberOf punycode
	 * @param {String} input The string of Unicode symbols.
	 * @returns {String} The resulting Punycode string of ASCII-only symbols.
	 */
	function encode(input) {
		var n,
		    delta,
		    handledCPCount,
		    basicLength,
		    bias,
		    j,
		    m,
		    q,
		    k,
		    t,
		    currentValue,
		    output = [],
		    /** `inputLength` will hold the number of code points in `input`. */
		    inputLength,
		    /** Cached calculation results */
		    handledCPCountPlusOne,
		    baseMinusT,
		    qMinusT;

		// Convert the input in UCS-2 to Unicode
		input = ucs2decode(input);

		// Cache the length
		inputLength = input.length;

		// Initialize the state
		n = initialN;
		delta = 0;
		bias = initialBias;

		// Handle the basic code points
		for (j = 0; j < inputLength; ++j) {
			currentValue = input[j];
			if (currentValue < 0x80) {
				output.push(stringFromCharCode(currentValue));
			}
		}

		handledCPCount = basicLength = output.length;

		// `handledCPCount` is the number of code points that have been handled;
		// `basicLength` is the number of basic code points.

		// Finish the basic string - if it is not empty - with a delimiter
		if (basicLength) {
			output.push(delimiter);
		}

		// Main encoding loop:
		while (handledCPCount < inputLength) {

			// All non-basic code points < n have been handled already. Find the next
			// larger one:
			for (m = maxInt, j = 0; j < inputLength; ++j) {
				currentValue = input[j];
				if (currentValue >= n && currentValue < m) {
					m = currentValue;
				}
			}

			// Increase `delta` enough to advance the decoder's <n,i> state to <m,0>,
			// but guard against overflow
			handledCPCountPlusOne = handledCPCount + 1;
			if (m - n > floor((maxInt - delta) / handledCPCountPlusOne)) {
				error('overflow');
			}

			delta += (m - n) * handledCPCountPlusOne;
			n = m;

			for (j = 0; j < inputLength; ++j) {
				currentValue = input[j];

				if (currentValue < n && ++delta > maxInt) {
					error('overflow');
				}

				if (currentValue == n) {
					// Represent delta as a generalized variable-length integer
					for (q = delta, k = base; /* no condition */; k += base) {
						t = k <= bias ? tMin : (k >= bias + tMax ? tMax : k - bias);
						if (q < t) {
							break;
						}
						qMinusT = q - t;
						baseMinusT = base - t;
						output.push(
							stringFromCharCode(digitToBasic(t + qMinusT % baseMinusT, 0))
						);
						q = floor(qMinusT / baseMinusT);
					}

					output.push(stringFromCharCode(digitToBasic(q, 0)));
					bias = adapt(delta, handledCPCountPlusOne, handledCPCount == basicLength);
					delta = 0;
					++handledCPCount;
				}
			}

			++delta;
			++n;

		}
		return output.join('');
	}

	/**
	 * Converts a Punycode string representing a domain name or an email address
	 * to Unicode. Only the Punycoded parts of the input will be converted, i.e.
	 * it doesn't matter if you call it on a string that has already been
	 * converted to Unicode.
	 * @memberOf punycode
	 * @param {String} input The Punycoded domain name or email address to
	 * convert to Unicode.
	 * @returns {String} The Unicode representation of the given Punycode
	 * string.
	 */
	function toUnicode(input) {
		return mapDomain(input, function(string) {
			return regexPunycode.test(string)
				? decode(string.slice(4).toLowerCase())
				: string;
		});
	}

	/**
	 * Converts a Unicode string representing a domain name or an email address to
	 * Punycode. Only the non-ASCII parts of the domain name will be converted,
	 * i.e. it doesn't matter if you call it with a domain that's already in
	 * ASCII.
	 * @memberOf punycode
	 * @param {String} input The domain name or email address to convert, as a
	 * Unicode string.
	 * @returns {String} The Punycode representation of the given domain name or
	 * email address.
	 */
	function toASCII(input) {
		return mapDomain(input, function(string) {
			return regexNonASCII.test(string)
				? 'xn--' + encode(string)
				: string;
		});
	}

	/*--------------------------------------------------------------------------*/

	/** Define the public API */
	punycode = {
		/**
		 * A string representing the current Punycode.js version number.
		 * @memberOf punycode
		 * @type String
		 */
		'version': '1.4.1',
		/**
		 * An object of methods to convert from JavaScript's internal character
		 * representation (UCS-2) to Unicode code points, and back.
		 * @see <https://mathiasbynens.be/notes/javascript-encoding>
		 * @memberOf punycode
		 * @type Object
		 */
		'ucs2': {
			'decode': ucs2decode,
			'encode': ucs2encode
		},
		'decode': decode,
		'encode': encode,
		'toASCII': toASCII,
		'toUnicode': toUnicode
	};

	/** Expose `punycode` */
	// Some AMD build optimizers, like r.js, check for specific condition patterns
	// like the following:
	if (
		true
	) {
		!(__WEBPACK_AMD_DEFINE_RESULT__ = function() {
			return punycode;
		}.call(exports, __webpack_require__, exports, module),
				__WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));
	} else if (freeExports && freeModule) {
		if (module.exports == freeExports) {
			// in Node.js, io.js, or RingoJS v0.8.0+
			freeModule.exports = punycode;
		} else {
			// in Narwhal or RingoJS v0.7.0-
			for (key in punycode) {
				punycode.hasOwnProperty(key) && (freeExports[key] = punycode[key]);
			}
		}
	} else {
		// in Rhino or a web browser
		root.punycode = punycode;
	}

}(this));

/* WEBPACK VAR INJECTION */}.call(exports, __webpack_require__(73)(module), __webpack_require__(35)))

/***/ }),
/* 1255 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


module.exports = {
  isString: function(arg) {
    return typeof(arg) === 'string';
  },
  isObject: function(arg) {
    return typeof(arg) === 'object' && arg !== null;
  },
  isNull: function(arg) {
    return arg === null;
  },
  isNullOrUndefined: function(arg) {
    return arg == null;
  }
};


/***/ }),
/* 1256 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.decode = exports.parse = __webpack_require__(1257);
exports.encode = exports.stringify = __webpack_require__(1258);


/***/ }),
/* 1257 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
// Copyright Joyent, Inc. and other Node contributors.
//
// Permission is hereby granted, free of charge, to any person obtaining a
// copy of this software and associated documentation files (the
// "Software"), to deal in the Software without restriction, including
// without limitation the rights to use, copy, modify, merge, publish,
// distribute, sublicense, and/or sell copies of the Software, and to permit
// persons to whom the Software is furnished to do so, subject to the
// following conditions:
//
// The above copyright notice and this permission notice shall be included
// in all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
// OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
// MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN
// NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
// DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
// OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE
// USE OR OTHER DEALINGS IN THE SOFTWARE.



// If obj.hasOwnProperty has been overridden, then calling
// obj.hasOwnProperty(prop) will break.
// See: https://github.com/joyent/node/issues/1707
function hasOwnProperty(obj, prop) {
  return Object.prototype.hasOwnProperty.call(obj, prop);
}

module.exports = function(qs, sep, eq, options) {
  sep = sep || '&';
  eq = eq || '=';
  var obj = {};

  if (typeof qs !== 'string' || qs.length === 0) {
    return obj;
  }

  var regexp = /\+/g;
  qs = qs.split(sep);

  var maxKeys = 1000;
  if (options && typeof options.maxKeys === 'number') {
    maxKeys = options.maxKeys;
  }

  var len = qs.length;
  // maxKeys <= 0 means that we should not limit keys count
  if (maxKeys > 0 && len > maxKeys) {
    len = maxKeys;
  }

  for (var i = 0; i < len; ++i) {
    var x = qs[i].replace(regexp, '%20'),
        idx = x.indexOf(eq),
        kstr, vstr, k, v;

    if (idx >= 0) {
      kstr = x.substr(0, idx);
      vstr = x.substr(idx + 1);
    } else {
      kstr = x;
      vstr = '';
    }

    k = decodeURIComponent(kstr);
    v = decodeURIComponent(vstr);

    if (!hasOwnProperty(obj, k)) {
      obj[k] = v;
    } else if (isArray(obj[k])) {
      obj[k].push(v);
    } else {
      obj[k] = [obj[k], v];
    }
  }

  return obj;
};

var isArray = Array.isArray || function (xs) {
  return Object.prototype.toString.call(xs) === '[object Array]';
};


/***/ }),
/* 1258 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
// Copyright Joyent, Inc. and other Node contributors.
//
// Permission is hereby granted, free of charge, to any person obtaining a
// copy of this software and associated documentation files (the
// "Software"), to deal in the Software without restriction, including
// without limitation the rights to use, copy, modify, merge, publish,
// distribute, sublicense, and/or sell copies of the Software, and to permit
// persons to whom the Software is furnished to do so, subject to the
// following conditions:
//
// The above copyright notice and this permission notice shall be included
// in all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
// OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
// MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN
// NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
// DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
// OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE
// USE OR OTHER DEALINGS IN THE SOFTWARE.



var stringifyPrimitive = function(v) {
  switch (typeof v) {
    case 'string':
      return v;

    case 'boolean':
      return v ? 'true' : 'false';

    case 'number':
      return isFinite(v) ? v : '';

    default:
      return '';
  }
};

module.exports = function(obj, sep, eq, name) {
  sep = sep || '&';
  eq = eq || '=';
  if (obj === null) {
    obj = undefined;
  }

  if (typeof obj === 'object') {
    return map(objectKeys(obj), function(k) {
      var ks = encodeURIComponent(stringifyPrimitive(k)) + eq;
      if (isArray(obj[k])) {
        return map(obj[k], function(v) {
          return ks + encodeURIComponent(stringifyPrimitive(v));
        }).join(sep);
      } else {
        return ks + encodeURIComponent(stringifyPrimitive(obj[k]));
      }
    }).join(sep);

  }

  if (!name) return '';
  return encodeURIComponent(stringifyPrimitive(name)) + eq +
         encodeURIComponent(stringifyPrimitive(obj));
};

var isArray = Array.isArray || function (xs) {
  return Object.prototype.toString.call(xs) === '[object Array]';
};

function map (xs, f) {
  if (xs.map) return xs.map(f);
  var res = [];
  for (var i = 0; i < xs.length; i++) {
    res.push(f(xs[i], i));
  }
  return res;
}

var objectKeys = Object.keys || function (obj) {
  var res = [];
  for (var key in obj) {
    if (Object.prototype.hasOwnProperty.call(obj, key)) res.push(key);
  }
  return res;
};


/***/ }),
/* 1259 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = LaunchDarkly;

var _react = __webpack_require__(0);

var _react2 = _interopRequireDefault(_react);

var _reactBroadcast = __webpack_require__(1217);

var _LaunchDarkly = __webpack_require__(1218);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function LaunchDarkly(props) {
  var clientId = props.clientId,
      user = props.user,
      children = props.children,
      clientOptions = props.clientOptions;


  var config = null;

  // if clientId or user do not exist we still want to
  // render the Broadcast component but we want value
  // to be null.
  if (clientId && user) {
    config = {
      clientId: clientId,
      user: user,
      clientOptions: clientOptions
    };
  }

  return _react2.default.createElement(
    _reactBroadcast.Broadcast,
    { channel: _LaunchDarkly.BROADCAST_CHANNEL, value: config },
    children
  );
}

/***/ }),
/* 1260 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;

var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };

var _invariant = __webpack_require__(21);

var _invariant2 = _interopRequireDefault(_invariant);

var _react = __webpack_require__(0);

var _react2 = _interopRequireDefault(_react);

var _propTypes = __webpack_require__(1);

var _propTypes2 = _interopRequireDefault(_propTypes);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var createBroadcast = function createBroadcast(initialState) {
  var listeners = [];
  var currentState = initialState;

  var getState = function getState() {
    return currentState;
  };

  var setState = function setState(state) {
    currentState = state;
    listeners.forEach(function (listener) {
      return listener(currentState);
    });
  };

  var subscribe = function subscribe(listener) {
    listeners.push(listener);

    return function () {
      return listeners = listeners.filter(function (item) {
        return item !== listener;
      });
    };
  };

  return {
    getState: getState,
    setState: setState,
    subscribe: subscribe
  };
};

/**
 * A <Broadcast> provides a generic way for descendants to "subscribe"
 * to some value that changes over time, bypassing any intermediate
 * shouldComponentUpdate's in the hierarchy. It puts all subscription
 * functions on context.broadcasts, keyed by "channel".
 *
 * To use it, a subscriber must opt-in to context.broadcasts. See the
 * <Subscriber> component for a reference implementation.
 */

var Broadcast = function (_React$Component) {
  _inherits(Broadcast, _React$Component);

  function Broadcast() {
    var _temp, _this, _ret;

    _classCallCheck(this, Broadcast);

    for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    return _ret = (_temp = (_this = _possibleConstructorReturn(this, _React$Component.call.apply(_React$Component, [this].concat(args))), _this), _this.broadcast = createBroadcast(_this.props.value), _temp), _possibleConstructorReturn(_this, _ret);
  }

  Broadcast.prototype.getChildContext = function getChildContext() {
    var _extends2;

    return {
      broadcasts: _extends({}, this.context.broadcasts, (_extends2 = {}, _extends2[this.props.channel] = this.broadcast, _extends2))
    };
  };

  Broadcast.prototype.componentWillReceiveProps = function componentWillReceiveProps(nextProps) {
    (0, _invariant2.default)(this.props.channel === nextProps.channel, 'You cannot change <Broadcast channel>');

    if (this.props.value !== nextProps.value) this.broadcast.setState(nextProps.value);
  };

  Broadcast.prototype.render = function render() {
    return _react2.default.Children.only(this.props.children);
  };

  return Broadcast;
}(_react2.default.Component);

Broadcast.propTypes = {
  channel: _propTypes2.default.string.isRequired,
  children: _propTypes2.default.node.isRequired,
  value: _propTypes2.default.any
};
Broadcast.contextTypes = {
  broadcasts: _propTypes2.default.object
};
Broadcast.childContextTypes = {
  broadcasts: _propTypes2.default.object.isRequired
};
exports.default = Broadcast;

/***/ }),
/* 1261 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;

var _invariant = __webpack_require__(21);

var _invariant2 = _interopRequireDefault(_invariant);

var _react = __webpack_require__(0);

var _react2 = _interopRequireDefault(_react);

var _propTypes = __webpack_require__(1);

var _propTypes2 = _interopRequireDefault(_propTypes);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

/**
 * A <Subscriber> pulls the value for a channel off of context.broadcasts
 * and passes it to its children function.
 */
var Subscriber = function (_React$Component) {
  _inherits(Subscriber, _React$Component);

  function Subscriber() {
    var _temp, _this, _ret;

    _classCallCheck(this, Subscriber);

    for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    return _ret = (_temp = (_this = _possibleConstructorReturn(this, _React$Component.call.apply(_React$Component, [this].concat(args))), _this), _this.state = {
      value: null
    }, _temp), _possibleConstructorReturn(_this, _ret);
  }

  Subscriber.prototype.getBroadcast = function getBroadcast() {
    var broadcast = this.context.broadcasts[this.props.channel];

    (0, _invariant2.default)(broadcast, '<Subscriber channel="%s"> must be rendered in the context of a <Broadcast channel="%s">', this.props.channel, this.props.channel);

    return broadcast;
  };

  Subscriber.prototype.componentWillMount = function componentWillMount() {
    var broadcast = this.getBroadcast();

    this.setState({
      value: broadcast.getState()
    });
  };

  Subscriber.prototype.componentDidMount = function componentDidMount() {
    var _this2 = this;

    var broadcast = this.getBroadcast();

    this.unsubscribe = broadcast.subscribe(function (value) {
      _this2.setState({ value: value });
    });
  };

  Subscriber.prototype.componentWillUnmount = function componentWillUnmount() {
    this.unsubscribe();
  };

  Subscriber.prototype.render = function render() {
    return this.props.children(this.state.value);
  };

  return Subscriber;
}(_react2.default.Component);

Subscriber.propTypes = {
  channel: _propTypes2.default.string.isRequired,
  children: _propTypes2.default.func.isRequired
};
Subscriber.contextTypes = {
  broadcasts: _propTypes2.default.object
};
exports.default = Subscriber;

/***/ }),
/* 1262 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };

exports.default = FeatureFlag;

var _react = __webpack_require__(0);

var _react2 = _interopRequireDefault(_react);

var _reactBroadcast = __webpack_require__(1217);

var _LaunchDarkly = __webpack_require__(1218);

var _FeatureFlagRenderer = __webpack_require__(1263);

var _FeatureFlagRenderer2 = _interopRequireDefault(_FeatureFlagRenderer);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function FeatureFlag(props) {
  return _react2.default.createElement(
    _reactBroadcast.Subscriber,
    { channel: _LaunchDarkly.BROADCAST_CHANNEL },
    function (config) {
      if (config) {
        return _react2.default.createElement(_FeatureFlagRenderer2.default, _extends({}, config, props));
      }

      return null;
    }
  );
}

/***/ }),
/* 1263 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };

var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _react = __webpack_require__(0);

var _utils = __webpack_require__(1216);

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var FeatureFlagRenderer = function (_Component) {
  _inherits(FeatureFlagRenderer, _Component);

  function FeatureFlagRenderer(props) {
    _classCallCheck(this, FeatureFlagRenderer);

    var _this = _possibleConstructorReturn(this, (FeatureFlagRenderer.__proto__ || Object.getPrototypeOf(FeatureFlagRenderer)).call(this, props));

    var _this$props = _this.props,
        flagKey = _this$props.flagKey,
        clientOptions = _this$props.clientOptions;

    var bootstrap = clientOptions && clientOptions.bootstrap;

    _this.state = {
      checkFeatureFlagComplete: false,
      flagValue: bootstrap && (typeof bootstrap === "undefined" ? "undefined" : _typeof(bootstrap)) === "object" && bootstrap.hasOwnProperty(flagKey) ? bootstrap[flagKey] : false
    };
    return _this;
  }

  _createClass(FeatureFlagRenderer, [{
    key: "componentDidMount",
    value: function componentDidMount() {
      var _props = this.props,
          clientId = _props.clientId,
          user = _props.user,
          clientOptions = _props.clientOptions;


      this._isMounted = true;

      if (clientOptions && clientOptions.disableClient) {
        return;
      }

      // Only initialize the launch darkly js-client when in browser,
      // can not be initialized on SSR due to dependency on XMLHttpRequest.
      var ldClient = (0, _utils.ldClientWrapper)(clientId, user, clientOptions);

      this.checkFeatureFlag(ldClient);
      this.listenFlagChangeEvent(ldClient);
    }
  }, {
    key: "componentWillUnmount",
    value: function componentWillUnmount() {
      this._isMounted = false;
    }
  }, {
    key: "render",
    value: function render() {
      return this.renderLogic();
    }
  }, {
    key: "renderLogic",
    value: function renderLogic() {
      var _state = this.state,
          flagValue = _state.flagValue,
          checkFeatureFlagComplete = _state.checkFeatureFlagComplete;
      var _props2 = this.props,
          renderFeatureCallback = _props2.renderFeatureCallback,
          renderDefaultCallback = _props2.renderDefaultCallback,
          initialRenderCallback = _props2.initialRenderCallback;


      if (flagValue) {
        return renderFeatureCallback(flagValue);
      } else if (checkFeatureFlagComplete && renderDefaultCallback) {
        return renderDefaultCallback();
      }

      if (initialRenderCallback) {
        return initialRenderCallback();
      }

      return null;
    }
  }, {
    key: "checkFeatureFlag",
    value: function checkFeatureFlag(ldClient) {
      var _this2 = this;

      var flagKey = this.props.flagKey;


      ldClient.onReady(function () {
        var flagValue = ldClient.variation(flagKey, false);
        _this2.setStateFlagValue(flagValue);
      });
    }
  }, {
    key: "listenFlagChangeEvent",
    value: function listenFlagChangeEvent(ldClient) {
      var _this3 = this;

      var flagKey = this.props.flagKey;


      ldClient.on("change:" + flagKey, function (value) {
        _this3.setStateFlagValue(value);
      });
    }
  }, {
    key: "setStateFlagValue",
    value: function setStateFlagValue(flagValue) {
      var flagKey = this.props.flagKey;

      var typeFlagValue = typeof flagValue === "undefined" ? "undefined" : _typeof(flagValue);
      var defaultState = { checkFeatureFlagComplete: true };
      var override = (0, _utils.ldOverrideFlag)(flagKey, typeFlagValue);

      // Due to this function being called within a callback, we can run into issues
      // where we try to set the state for an unmounted component. Since `isMounted()` is deprecated
      // as part of a React class, we can create our own way to manage it within the protoype.
      // See https://github.com/facebook/react/issues/5465#issuecomment-157888325 for more info
      if (!this._isMounted) {
        return;
      }

      if (typeof override !== "undefined") {
        // Override is set for this flag key, use override instead
        this.setState(_extends({ flagValue: override }, defaultState));
      } else if (flagValue) {
        this.setState(_extends({ flagValue: flagValue }, defaultState));
      } else {
        this.setState(_extends({ flagValue: false }, defaultState));
      }
    }
  }]);

  return FeatureFlagRenderer;
}(_react.Component);

exports.default = FeatureFlagRenderer;

/***/ }),
/* 1264 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__(0);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_prop_types__ = __webpack_require__(1);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_prop_types___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_prop_types__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_react_redux__ = __webpack_require__(95);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_lodash_isEmpty__ = __webpack_require__(1171);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_lodash_isEmpty___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_3_lodash_isEmpty__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__components_alerts__ = __webpack_require__(1265);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__components_modals_nps_survey__ = __webpack_require__(1284);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__components_modals_where_heard_survey__ = __webpack_require__(1285);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__components_modals_post_survey_referral__ = __webpack_require__(1286);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8__actions_survey_actions__ = __webpack_require__(1287);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_9__actions_referral_actions__ = __webpack_require__(1172);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_10__actions_upp_summary_actions__ = __webpack_require__(1288);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_11__actions_cosign_error_actions__ = __webpack_require__(1221);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_12__actions_tracking_banner_actions__ = __webpack_require__(1289);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_13__constants_prop_types_products_prop_types__ = __webpack_require__(1206);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_14__constants_prop_types_nps_survey_prop_types__ = __webpack_require__(1205);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_15__constants_prop_types_upp_summary_prop_types__ = __webpack_require__(1219);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_16__constants_prop_types_wait_for_cosign_error_prop_types__ = __webpack_require__(1204);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_17__constants_prop_types_tracking_banner_prop_types__ = __webpack_require__(1220);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_18__utilities__ = __webpack_require__(1222);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_19__utilities_session_storage_helpers__ = __webpack_require__(1290);
var _createClass=function(){function defineProperties(target,props){for(var i=0;i<props.length;i++){var descriptor=props[i];descriptor.enumerable=descriptor.enumerable||false;descriptor.configurable=true;if("value"in descriptor)descriptor.writable=true;Object.defineProperty(target,descriptor.key,descriptor);}}return function(Constructor,protoProps,staticProps){if(protoProps)defineProperties(Constructor.prototype,protoProps);if(staticProps)defineProperties(Constructor,staticProps);return Constructor;};}();function _classCallCheck(instance,Constructor){if(!(instance instanceof Constructor)){throw new TypeError("Cannot call a class as a function");}}function _possibleConstructorReturn(self,call){if(!self){throw new ReferenceError("this hasn't been initialised - super() hasn't been called");}return call&&(typeof call==="object"||typeof call==="function")?call:self;}function _inherits(subClass,superClass){if(typeof superClass!=="function"&&superClass!==null){throw new TypeError("Super expression must either be null or a function, not "+typeof superClass);}subClass.prototype=Object.create(superClass&&superClass.prototype,{constructor:{value:subClass,enumerable:false,writable:true,configurable:true}});if(superClass)Object.setPrototypeOf?Object.setPrototypeOf(subClass,superClass):subClass.__proto__=superClass;}/**
 * Component imports
 *//**
 * Action imports
 *//**
 * PropTypes imports
 *//**
 * Utlilities imports
 */var AlertsContainer=function(_Component){_inherits(AlertsContainer,_Component);function AlertsContainer(){var _ref;var _temp,_this,_ret;_classCallCheck(this,AlertsContainer);for(var _len=arguments.length,args=Array(_len),_key=0;_key<_len;_key++){args[_key]=arguments[_key];}return _ret=(_temp=(_this=_possibleConstructorReturn(this,(_ref=AlertsContainer.__proto__||Object.getPrototypeOf(AlertsContainer)).call.apply(_ref,[this].concat(args))),_this),_this.state={isModalOpen:false,lowScore:false,isWhereHeardOpen:false,isThankYouOpen:false,highRating:false,referralLinkObj:{},showUppAlert:false},_this.submitSurvey=function(data){var originalData=_this.props.npsSurvey;var survey=Object(__WEBPACK_IMPORTED_MODULE_18__utilities__["h" /* REBUILD_SURVEY_OBJECT */])(data,originalData);_this.props.submitNpsSurvey(survey);// Close NPS Survey modal
_this.toggleOpen();// Open Where Heard Survey modal
_this.toggleWhereHeardOpen();_this.checkReferral(data.radioChoiceRating);},_this.submitWhereHeardSurvey=function(data){var questions=_this.props.whereHeardSurvey.survey.questions;var choices=questions[0].choices;var selectedChoices=[];var dataKeys=Object.keys(data);var _loop=function _loop(idx){if(data[dataKeys[idx]]){var choice=choices.find(function(value){return value.id===Number(dataKeys[idx].replace('survey_choice_',''));});selectedChoices.push(choice.choice);}};for(var idx=0;idx<dataKeys.length;idx+=1){_loop(idx);}var surveyResponseString=selectedChoices.join(',');var originalData=_this.props.whereHeardSurvey;var survey=Object(__WEBPACK_IMPORTED_MODULE_18__utilities__["i" /* REBUILD_WHERE_HEARD_SURVEY_OBJECT */])(surveyResponseString,originalData);_this.props.submitWhereHeardSurvey(survey);_this.toggleWhereHeardOpen();// Open Thank you modal with referral link to leave review
_this.toggleOpenThankYouModal();},_this.toggleOpen=function(){_this.setState({isModalOpen:!_this.state.isModalOpen});},_this.toggleWhereHeardOpen=function(){_this.setState({isWhereHeardOpen:!_this.state.isWhereHeardOpen});},_this.toggleOpenThankYouModal=function(){var referralObj=Object(__WEBPACK_IMPORTED_MODULE_18__utilities__["b" /* DETERMINE_REVIEW_URL */])();_this.setState({isThankYouOpen:!_this.state.isThankYouOpen,referralLinkObj:referralObj});},_this.scoreSet=function(number){var score=Number(number);if(score>9){_this.setState({lowScore:false});}else{_this.setState({lowScore:true});}},_this.checkReferral=function(score){if(score>=9){_this.setState({highRating:true});}},_temp),_possibleConstructorReturn(_this,_ret);}_createClass(AlertsContainer,[{key:'componentDidMount',value:function componentDidMount(){var _props=this.props,loadNpsSurvey=_props.loadNpsSurvey,loadW9ReferralInfo=_props.loadW9ReferralInfo,loadUppSummary=_props.loadUppSummary,loadWhereHeardSurvey=_props.loadWhereHeardSurvey,loadTrackingBanner=_props.loadTrackingBanner;loadNpsSurvey();loadWhereHeardSurvey();loadW9ReferralInfo();loadUppSummary();loadTrackingBanner();}},{key:'componentWillReceiveProps',value:function componentWillReceiveProps(nextProps){if(!__WEBPACK_IMPORTED_MODULE_3_lodash_isEmpty___default()(nextProps.uppSummary)&&nextProps.uppSummary!==this.props.uppSummary){var uppSummary=nextProps.uppSummary;var showUpp=Object(__WEBPACK_IMPORTED_MODULE_18__utilities__["a" /* CHECK_UPP_ALERT_NEEDS_DISPLAY */])(uppSummary);if(showUpp)this.setState({showUppAlert:true});}}// Call method in UTILS to prepare object for POST request
},{key:'render',value:function render(){var _props2=this.props,isNpsSurveyLoaded=_props2.isNpsSurveyLoaded,isW9ReferralInfoLoaded=_props2.isW9ReferralInfoLoaded,npsSurvey=_props2.npsSurvey,whereHeardSurvey=_props2.whereHeardSurvey,waitForCosignError=_props2.waitForCosignError,clearWaitForCosigner=_props2.clearWaitForCosigner,trackingBanner=_props2.trackingBanner;var _state=this.state,isModalOpen=_state.isModalOpen,lowScore=_state.lowScore,isWhereHeardOpen=_state.isWhereHeardOpen,isThankYouOpen=_state.isThankYouOpen,referralLinkObj=_state.referralLinkObj,highRating=_state.highRating,showUppAlert=_state.showUppAlert;var isStateIneligible=Object(__WEBPACK_IMPORTED_MODULE_18__utilities__["c" /* FIND_IF_STATE_IS_ELIGIBLE */])(this.props.products);return isW9ReferralInfoLoaded&&isNpsSurveyLoaded?__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_0_react__["Fragment"],null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_4__components_alerts__["a" /* default */],Object.assign({},this.props,{toggleOpen:this.toggleOpen,isStateIneligible:isStateIneligible,hasInfo:__WEBPACK_IMPORTED_MODULE_18__utilities__["f" /* HAS_INFO */],hasErrors:__WEBPACK_IMPORTED_MODULE_18__utilities__["e" /* HAS_ERRORS */],showUppAlert:showUppAlert,setAlertDismissableSession:__WEBPACK_IMPORTED_MODULE_19__utilities_session_storage_helpers__["b" /* setAlertDismissableSession */],getAlertSessionKey:__WEBPACK_IMPORTED_MODULE_19__utilities_session_storage_helpers__["a" /* getAlertSessionKey */],waitForCosignError:waitForCosignError,clearWaitForCosigner:clearWaitForCosigner,trackingBanner:trackingBanner})),isModalOpen&&__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_5__components_modals_nps_survey__["a" /* default */],{isModalOpen:isModalOpen,toggleOpen:this.toggleOpen,npsSurvey:npsSurvey,lowScore:lowScore,scoreSet:this.scoreSet,surveySelectOptions:__WEBPACK_IMPORTED_MODULE_18__utilities__["g" /* NPS_SURVEY_SELECT_OPTIONS */],submitSurvey:this.submitSurvey}),isWhereHeardOpen&&__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_6__components_modals_where_heard_survey__["a" /* default */],{isWhereHeardOpen:isWhereHeardOpen,toggleWhereHeardOpen:this.toggleWhereHeardOpen,whereHeardSurvey:whereHeardSurvey,submitWhereHeardSurvey:this.submitWhereHeardSurvey}),isThankYouOpen&&__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_7__components_modals_post_survey_referral__["a" /* default */],{isThankYouOpen:isThankYouOpen,toggleOpenThankYouModal:this.toggleOpenThankYouModal,referralLinkObj:referralLinkObj,highRating:highRating})):'';}}]);return AlertsContainer;}(__WEBPACK_IMPORTED_MODULE_0_react__["Component"]);AlertsContainer.propTypes={isNpsSurveyLoaded:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.bool.isRequired,loadNpsSurvey:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.func.isRequired,isW9ReferralInfoLoaded:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.bool.isRequired,loadW9ReferralInfo:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.func.isRequired,loadUppSummary:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.func.isRequired,products:__WEBPACK_IMPORTED_MODULE_13__constants_prop_types_products_prop_types__["a" /* ProductsPropTypes */].isRequired,npsSurvey:__WEBPACK_IMPORTED_MODULE_14__constants_prop_types_nps_survey_prop_types__["a" /* NpsSurveyPropTypes */].isRequired,whereHeardSurvey:__WEBPACK_IMPORTED_MODULE_14__constants_prop_types_nps_survey_prop_types__["a" /* NpsSurveyPropTypes */].isRequired,submitNpsSurvey:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.func.isRequired,loadWhereHeardSurvey:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.func.isRequired,submitWhereHeardSurvey:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.func.isRequired,uppSummary:__WEBPACK_IMPORTED_MODULE_15__constants_prop_types_upp_summary_prop_types__["a" /* UppSummaryPropTypes */].isRequired,waitForCosignError:__WEBPACK_IMPORTED_MODULE_16__constants_prop_types_wait_for_cosign_error_prop_types__["a" /* WaitForCosignerErrorPropTypes */].isRequired,clearWaitForCosigner:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.func.isRequired,loadTrackingBanner:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.func.isRequired,trackingBanner:__WEBPACK_IMPORTED_MODULE_17__constants_prop_types_tracking_banner_prop_types__["a" /* TrackingBannerPropTypes */].isRequired};var mapStateToProps=function mapStateToProps(state){return{isNpsSurveyLoaded:state.surveyReducer.npsSurvey.loaded,npsSurvey:state.surveyReducer.npsSurvey.data,isWhereHeardSurveyLoaded:state.surveyReducer.whereHeardSurvey.loaded,whereHeardSurvey:state.surveyReducer.whereHeardSurvey.data,w9ReferralInfo:state.referralReducer.w9.data,isW9ReferralInfoLoaded:state.referralReducer.w9.loadedGet,isUppSummaryLoaded:state.uppSummaryReducer.uppSummary.loaded,uppSummary:state.uppSummaryReducer.uppSummary.data,globalErrors:state.globalErrorReducer.globalErrors,waitForCosignError:state.globalErrorReducer.waitForCosignError,trackingBanner:state.trackingBannerReducer.banners.data};};var mapDispatchToProps=function mapDispatchToProps(dispatch){return{loadNpsSurvey:function loadNpsSurvey(){return dispatch(Object(__WEBPACK_IMPORTED_MODULE_8__actions_survey_actions__["a" /* getNpsSurvey */])());},loadWhereHeardSurvey:function loadWhereHeardSurvey(){return dispatch(Object(__WEBPACK_IMPORTED_MODULE_8__actions_survey_actions__["b" /* getWhereHeardSurvey */])());},loadUppSummary:function loadUppSummary(){return dispatch(Object(__WEBPACK_IMPORTED_MODULE_10__actions_upp_summary_actions__["a" /* getUppSummary */])());},loadW9ReferralInfo:function loadW9ReferralInfo(){return dispatch(Object(__WEBPACK_IMPORTED_MODULE_9__actions_referral_actions__["f" /* getReferralW9 */])());},loadTrackingBanner:function loadTrackingBanner(){return dispatch(Object(__WEBPACK_IMPORTED_MODULE_12__actions_tracking_banner_actions__["a" /* getTrackingBanner */])());},submitNpsSurvey:function submitNpsSurvey(data){return dispatch(Object(__WEBPACK_IMPORTED_MODULE_8__actions_survey_actions__["c" /* postNpsSurvey */])(data));},submitWhereHeardSurvey:function submitWhereHeardSurvey(data){return dispatch(Object(__WEBPACK_IMPORTED_MODULE_8__actions_survey_actions__["d" /* postWhereHeardSurvey */])(data));},clearWaitForCosigner:function clearWaitForCosigner(){return dispatch(Object(__WEBPACK_IMPORTED_MODULE_11__actions_cosign_error_actions__["a" /* clearWaitCosignerError */])());}};};/* harmony default export */ __webpack_exports__["a"] = (Object(__WEBPACK_IMPORTED_MODULE_2_react_redux__["b" /* connect */])(mapStateToProps,mapDispatchToProps)(AlertsContainer));

/***/ }),
/* 1265 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__alerts__ = __webpack_require__(1266);
/* harmony reexport (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return __WEBPACK_IMPORTED_MODULE_0__alerts__["a"]; });


/***/ }),
/* 1266 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__(0);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_prop_types__ = __webpack_require__(1);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_prop_types___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_prop_types__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__constants_prop_types_customer_prop_types__ = __webpack_require__(124);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__constants_prop_types_referral_prop_types__ = __webpack_require__(1082);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__constants_prop_types_survey_prop_types__ = __webpack_require__(1267);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__constants_prop_types_w9_referral_info_prop_types__ = __webpack_require__(1268);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__constants_prop_types_upp_summary_prop_types__ = __webpack_require__(1219);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__constants_prop_types_wait_for_cosign_error_prop_types__ = __webpack_require__(1204);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8__constants_prop_types_tracking_banner_prop_types__ = __webpack_require__(1220);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_9__nps_survey__ = __webpack_require__(1269);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_10__state_ineligible__ = __webpack_require__(1270);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_11__w9_claim__ = __webpack_require__(1271);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_12__wealth_advisor_ad__ = __webpack_require__(1272);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_13__affiliate_membership__ = __webpack_require__(1273);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_14__apple_employer__ = __webpack_require__(1276);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_15__unemployment_protection__ = __webpack_require__(1277);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_16__ssn_popup__ = __webpack_require__(1278);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_17__has_info__ = __webpack_require__(1279);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_18__has_errors__ = __webpack_require__(1280);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_19__global_error__ = __webpack_require__(1281);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_20__wait_for_cosigner__ = __webpack_require__(1282);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_21__welcome_kit__ = __webpack_require__(1283);
var _slicedToArray=function(){function sliceIterator(arr,i){var _arr=[];var _n=true;var _d=false;var _e=undefined;try{for(var _i=arr[Symbol.iterator](),_s;!(_n=(_s=_i.next()).done);_n=true){_arr.push(_s.value);if(i&&_arr.length===i)break;}}catch(err){_d=true;_e=err;}finally{try{if(!_n&&_i["return"])_i["return"]();}finally{if(_d)throw _e;}}return _arr;}return function(arr,i){if(Array.isArray(arr)){return arr;}else if(Symbol.iterator in Object(arr)){return sliceIterator(arr,i);}else{throw new TypeError("Invalid attempt to destructure non-iterable instance");}};}();/**
 * PropTypes imports
 *//**
 * Component imports
 *//**
 * Styled components
 */var Alerts=function Alerts(_ref){var customer=_ref.customer,referralSummary=_ref.referralSummary,npsSurvey=_ref.npsSurvey,toggleOpen=_ref.toggleOpen,uppSummary=_ref.uppSummary,w9ReferralInfo=_ref.w9ReferralInfo,isStateIneligible=_ref.isStateIneligible,hasInfo=_ref.hasInfo,hasErrors=_ref.hasErrors,ssnPopupMessage=_ref.ssnPopupMessage,showUppAlert=_ref.showUppAlert,globalErrors=_ref.globalErrors,setAlertDismissableSession=_ref.setAlertDismissableSession,getAlertSessionKey=_ref.getAlertSessionKey,waitForCosignError=_ref.waitForCosignError,clearWaitForCosigner=_ref.clearWaitForCosigner,trackingBanner=_ref.trackingBanner;return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_0_react__["Fragment"],null,trackingBanner&&trackingBanner.some(function(val){return val.name==='WELCOME_KIT';})&&__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_21__welcome_kit__["a" /* default */],null),!getAlertSessionKey('nps.survey')&&npsSurvey&&npsSurvey.needsSurvey&&__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_9__nps_survey__["a" /* default */],{toggleOpen:toggleOpen,setAlertDismissableSession:setAlertDismissableSession}),!getAlertSessionKey('wealth.advisor.ad')&&__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_12__wealth_advisor_ad__["a" /* default */],{setAlertDismissableSession:setAlertDismissableSession}),!getAlertSessionKey('state.ineligible')&&isStateIneligible&&__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_10__state_ineligible__["a" /* default */],{setAlertDismissableSession:setAlertDismissableSession}),!getAlertSessionKey('wait.for.cosigner')&&waitForCosignError.showMessage&&__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_20__wait_for_cosigner__["a" /* default */],{clearAlert:clearWaitForCosigner}),!getAlertSessionKey('w9.referral.info')&&w9ReferralInfo&&(w9ReferralInfo.w9Status==='UNSIGNED'||w9ReferralInfo.w9Status==='TAXABLE')&&__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_11__w9_claim__["a" /* default */],{referralSummary:referralSummary,setAlertDismissableSession:setAlertDismissableSession}),!getAlertSessionKey('upp.summary')&&uppSummary&&showUppAlert&&__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_15__unemployment_protection__["a" /* default */],{setAlertDismissableSession:setAlertDismissableSession}),!getAlertSessionKey('affiliate.membership.jetblue')&&trackingBanner&&trackingBanner.some(function(val){return val.name==='JETBLUE';})&&__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_13__affiliate_membership__["a" /* default */],{affiliateMembership:trackingBanner.find(function(val){return val.name==='JETBLUE';}),setAlertDismissableSession:setAlertDismissableSession}),!getAlertSessionKey('affiliate.membership.alaska')&&trackingBanner&&trackingBanner.some(function(val){return val.name==='ALASKA_AIRLINES';})&&__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_13__affiliate_membership__["a" /* default */],{affiliateMembership:trackingBanner.find(function(val){return val.name==='ALASKA_AIRLINES';}),setAlertDismissableSession:setAlertDismissableSession}),!getAlertSessionKey('apple.employer')&&customer.corporateEmployer==='apple'&&__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_14__apple_employer__["a" /* default */],{setAlertDismissableSession:setAlertDismissableSession}),!getAlertSessionKey('has.info')&&hasInfo()&&__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_17__has_info__["a" /* default */],{hasInfo:hasInfo,setAlertDismissableSession:setAlertDismissableSession}),!getAlertSessionKey('has.errors')&&hasErrors()&&!isStateIneligible&&__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_18__has_errors__["a" /* default */],{hasErrors:hasErrors,setAlertDismissableSession:setAlertDismissableSession}),Object.entries(globalErrors).map(function(_ref2){var _ref3=_slicedToArray(_ref2,2),errorCode=_ref3[0],error=_ref3[1];return!getAlertSessionKey(errorCode)&&__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_19__global_error__["a" /* default */],{key:errorCode,globalError:error,sessionKeyName:errorCode,setAlertDismissableSession:setAlertDismissableSession});}),!getAlertSessionKey('ssn.popup')&&!!ssnPopupMessage&&__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_16__ssn_popup__["a" /* default */],{ssnPopupMessage:ssnPopupMessage}));};/* eslint react/no-typos: 0 */Alerts.propTypes={customer:__WEBPACK_IMPORTED_MODULE_2__constants_prop_types_customer_prop_types__["b" /* CustomerPropTypes */].isRequired,referralSummary:__WEBPACK_IMPORTED_MODULE_3__constants_prop_types_referral_prop_types__["g" /* ReferralSummaryPropTypes */].isRequired,npsSurvey:__WEBPACK_IMPORTED_MODULE_4__constants_prop_types_survey_prop_types__["a" /* NpsSurveyPropTypes */].isRequired,toggleOpen:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.func.isRequired,isStateIneligible:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.bool.isRequired,hasInfo:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.func.isRequired,hasErrors:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.func.isRequired,w9ReferralInfo:__WEBPACK_IMPORTED_MODULE_5__constants_prop_types_w9_referral_info_prop_types__["a" /* W9ReferralInfoPropTypes */].isRequired,uppSummary:__WEBPACK_IMPORTED_MODULE_6__constants_prop_types_upp_summary_prop_types__["a" /* UppSummaryPropTypes */].isRequired,ssnPopupMessage:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.string,showUppAlert:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.bool.isRequired,globalErrors:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.objectOf(__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.shape({message:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.string,code:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.string})).isRequired,setAlertDismissableSession:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.func.isRequired,getAlertSessionKey:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.func.isRequired,waitForCosignError:__WEBPACK_IMPORTED_MODULE_7__constants_prop_types_wait_for_cosign_error_prop_types__["a" /* WaitForCosignerErrorPropTypes */].isRequired,clearWaitForCosigner:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.func.isRequired,trackingBanner:__WEBPACK_IMPORTED_MODULE_8__constants_prop_types_tracking_banner_prop_types__["a" /* TrackingBannerPropTypes */].isRequired};Alerts.defaultProps={ssnPopupMessage:null};/* harmony default export */ __webpack_exports__["a"] = (Alerts);

/***/ }),
/* 1267 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return NpsSurveyPropTypes; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_prop_types__ = __webpack_require__(1);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_prop_types___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_prop_types__);
var NpsSurveyPropTypes=__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.shape({name:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string,needsSurvey:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.bool,survey:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.shape({questions:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.arrayOf(__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.shape({question:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string,questionType:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string,choices:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.arrayOf(__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.shape({choice:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string}))}))})});

/***/ }),
/* 1268 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return W9ReferralInfoPropTypes; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_prop_types__ = __webpack_require__(1);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_prop_types___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_prop_types__);
var W9ReferralInfoPropTypes=__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.shape({docusignUrl:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string,userId:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.number.isRequired,w9DocumentId:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.number,w9Status:__WEBPACK_IMPORTED_MODULE_0_prop_types___default.a.string.isRequired});

/***/ }),
/* 1269 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__(0);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_prop_types__ = __webpack_require__(1);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_prop_types___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_prop_types__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__shared_styles__ = __webpack_require__(1169);
/**
 * Styled components
 */var _onKeyDown=function _onKeyDown(event,startSurvey){if(event.key==='Enter'){startSurvey();}};var NpsSurvey=function NpsSurvey(_ref){var toggleOpen=_ref.toggleOpen,setAlertDismissableSession=_ref.setAlertDismissableSession;return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2__shared_styles__["b" /* AlertNotification */],{dismissible:true,onDismiss:function onDismiss(){return setAlertDismissableSession('nps.survey');}},__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2__shared_styles__["a" /* AlertContent */],null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('span',null,'Hello! Please take one minute to provide feedback in the SoFi Welcome Survey.'),__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('a',{'data-qa':'nps-survey-begin-link',role:'link',tabIndex:0,onKeyDown:function onKeyDown(event){return _onKeyDown(event,toggleOpen);},onClick:toggleOpen},' ','Begin survey')));};NpsSurvey.propTypes={toggleOpen:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.func.isRequired,setAlertDismissableSession:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.func.isRequired};/* harmony default export */ __webpack_exports__["a"] = (NpsSurvey);

/***/ }),
/* 1270 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__(0);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_react_redux_i18n__ = __webpack_require__(70);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_react_redux_i18n___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_react_redux_i18n__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_prop_types__ = __webpack_require__(1);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_prop_types___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_prop_types__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__shared_styles__ = __webpack_require__(1169);
/**
 * Styled components
 */var StateIneligible=function StateIneligible(_ref){var setAlertDismissableSession=_ref.setAlertDismissableSession;return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_3__shared_styles__["b" /* AlertNotification */],{warning:true,dismissible:true,onDismiss:function onDismiss(){return setAlertDismissableSession('state.ineligible');}},__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_3__shared_styles__["a" /* AlertContent */],null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_1_react_redux_i18n__["Translate"],{value:'waitlistUnsupportedStateAll'})));};/* eslint react/no-typos: 0 */StateIneligible.propTypes={setAlertDismissableSession:__WEBPACK_IMPORTED_MODULE_2_prop_types___default.a.func.isRequired};/* harmony default export */ __webpack_exports__["a"] = (StateIneligible);

/***/ }),
/* 1271 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__(0);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_react_router_dom__ = __webpack_require__(188);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_prop_types__ = __webpack_require__(1);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_prop_types___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_prop_types__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__constants_prop_types_referral_prop_types__ = __webpack_require__(1082);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__shared_styles__ = __webpack_require__(1169);
/**
 * PropTypes imports
 *//**
 * Styled components
 */var W9Claim=function W9Claim(_ref){var referralSummary=_ref.referralSummary,setAlertDismissableSession=_ref.setAlertDismissableSession;return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_4__shared_styles__["b" /* AlertNotification */],{dismissible:true,onDismiss:function onDismiss(){return setAlertDismissableSession('w9.referral.info');}},__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_4__shared_styles__["a" /* AlertContent */],null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('span',null,'Complete form W-9 to claim your',referralSummary&&referralSummary.registrations>0?' referral or ':' ','welcome bonus. We will issue you a 1099 if you exceed $599 in bonus payments in a calendar year.'),__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_1_react_router_dom__["b" /* Link */],{'data-qa':'alerts-w9-claim-link',to:'/affiliate/w9'},'Click here')));};/* eslint react/no-typos: 0 */W9Claim.propTypes={referralSummary:__WEBPACK_IMPORTED_MODULE_3__constants_prop_types_referral_prop_types__["g" /* ReferralSummaryPropTypes */].isRequired,setAlertDismissableSession:__WEBPACK_IMPORTED_MODULE_2_prop_types___default.a.func.isRequired};/* harmony default export */ __webpack_exports__["a"] = (W9Claim);

/***/ }),
/* 1272 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__(0);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_prop_types__ = __webpack_require__(1);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_prop_types___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_prop_types__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_react_launch_darkly__ = __webpack_require__(1187);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_react_launch_darkly___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_react_launch_darkly__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__shared_styles__ = __webpack_require__(1169);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__constants_launch_darkly_constants__ = __webpack_require__(1188);
/**
 * Styled components
 */function renderAd(content,ctaText,ctaLink,dataQa,dataMjs,setAlertDismissableSession){return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_3__shared_styles__["b" /* AlertNotification */],{dismissible:true,onDismiss:function onDismiss(){return setAlertDismissableSession('wealth.advisor.ad');}},__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_3__shared_styles__["a" /* AlertContent */],null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('span',null,content),__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('a',{'data-qa':dataQa,'data-mjs':dataMjs,href:ctaLink},ctaText)));}function renderDefaultAd(setAlertDismissableSession){return renderAd('Want to know how to invest while paying down debt? SoFi Members get complimentary access to financial advisors.','Schedule an Appointment','/calendaring-ui','wealth-advisor-ad-schedule','dashboard-wealth-advisor-ad-schedule',setAlertDismissableSession);}var WealthAdvisorAd=function WealthAdvisorAd(_ref){var setAlertDismissableSession=_ref.setAlertDismissableSession;return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_react_launch_darkly__["FeatureFlag"],{flagKey:__WEBPACK_IMPORTED_MODULE_4__constants_launch_darkly_constants__["d" /* FEATURE_FLAG_WEALTH_BANNER_AD */],renderFeatureCallback:function renderFeatureCallback(val){switch(val.key){case'kfa-career':return renderAd(val.content,val.ctaText,val.ctaLink,'wealth-advisor-ad-kfa',val.dataMjs,setAlertDismissableSession);default:return renderDefaultAd(setAlertDismissableSession);}},renderDefaultCallback:function renderDefaultCallback(){return renderDefaultAd(setAlertDismissableSession);}});};WealthAdvisorAd.propTypes={setAlertDismissableSession:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.func.isRequired};/* harmony default export */ __webpack_exports__["a"] = (WealthAdvisorAd);

/***/ }),
/* 1273 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__(0);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_prop_types__ = __webpack_require__(1);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_prop_types___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_prop_types__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_styled_components__ = __webpack_require__(3);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__assets_img_TrueBlueBlack_svg__ = __webpack_require__(1274);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__assets_img_TrueBlueBlack_svg___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_3__assets_img_TrueBlueBlack_svg__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__assets_img_alaska_airlines_svg__ = __webpack_require__(1275);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__assets_img_alaska_airlines_svg___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_4__assets_img_alaska_airlines_svg__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__shared_styles__ = __webpack_require__(1169);
var _templateObject=_taggedTemplateLiteral(['\n  max-width: 100%;\n  display: block;\n  margin-top: 5px;\n  padding-left: 20px;\n'],['\n  max-width: 100%;\n  display: block;\n  margin-top: 5px;\n  padding-left: 20px;\n']),_templateObject2=_taggedTemplateLiteral(['\n  display: block;\n  max-width: 1440px;\n  margin: 0 auto;\n'],['\n  display: block;\n  max-width: 1440px;\n  margin: 0 auto;\n']);function _taggedTemplateLiteral(strings,raw){return Object.freeze(Object.defineProperties(strings,{raw:{value:Object.freeze(raw)}}));}/**
 * Image imports
 *//**
 * Styled components
 */var AffiliateImage=__WEBPACK_IMPORTED_MODULE_2_styled_components__["default"].img(_templateObject);var Container=__WEBPACK_IMPORTED_MODULE_2_styled_components__["default"].div(_templateObject2);var adjustMarginTop={marginTop:'12px'};var adjustPaddingBot={paddingBottom:'16px'};var AFFILIATE_JETBLUE='JETBLUE';var AFFILIATE_ALASKA_AIRLINES='ALASKA_AIRLINES';var AffiliateMembership=function AffiliateMembership(_ref){var affiliateMembership=_ref.affiliateMembership,setAlertDismissableSession=_ref.setAlertDismissableSession;return[AFFILIATE_JETBLUE,AFFILIATE_ALASKA_AIRLINES].find(function(i){return i===affiliateMembership.name;})?__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_5__shared_styles__["b" /* AlertNotification */],{style:adjustPaddingBot,dismissible:true,onDismiss:function onDismiss(){return setAlertDismissableSession('affiliate.membership');}},affiliateMembership.name===AFFILIATE_JETBLUE&&__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(Container,null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(AffiliateImage,{src:__WEBPACK_IMPORTED_MODULE_3__assets_img_TrueBlueBlack_svg___default.a,alt:AFFILIATE_JETBLUE}),__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_5__shared_styles__["a" /* AlertContent */],{style:adjustMarginTop},__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('span',null,'Want your bonus JetBlue points? All you need is your name and member number as it appears on your TrueBlue account. Expires',' ',affiliateMembership.endDate,'.'),__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('a',{'data-qa':'alerts-affiliate-claim-points',href:'/b/affiliate-membership/registration'},'Claim my points'))),affiliateMembership.name===AFFILIATE_ALASKA_AIRLINES&&__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(Container,null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(AffiliateImage,{src:__WEBPACK_IMPORTED_MODULE_4__assets_img_alaska_airlines_svg___default.a,alt:AFFILIATE_ALASKA_AIRLINES}),__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_5__shared_styles__["a" /* AlertContent */],{style:adjustMarginTop},__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('span',null,'Want your bonus Alaska Airlines miles? All you need is your name and member number as it appears on your Mileage Plan account. Expires ',affiliateMembership.endDate,'.\xA0'),__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('a',{'data-qa':'alerts-affiliate-claim-miles',href:'/b/affiliate-membership/registration'},'Claim my miles')))):null;};AffiliateMembership.propTypes={affiliateMembership:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.object.isRequired,// eslint-disable-line
setAlertDismissableSession:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.func.isRequired};/* harmony default export */ __webpack_exports__["a"] = (AffiliateMembership);

/***/ }),
/* 1274 */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/media/TrueBlueBlack.7579e2b6.svg";

/***/ }),
/* 1275 */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/media/alaska-airlines.732044c5.svg";

/***/ }),
/* 1276 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__(0);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_styled_components__ = __webpack_require__(3);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_prop_types__ = __webpack_require__(1);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_prop_types___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_prop_types__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__shared_styles__ = __webpack_require__(1169);
var _templateObject=_taggedTemplateLiteral(['\n  @media (max-width: 767px) {\n    display: none !important;\n    margin-top: 0 !important;\n  }\n'],['\n  @media (max-width: 767px) {\n    display: none !important;\n    margin-top: 0 !important;\n  }\n']);function _taggedTemplateLiteral(strings,raw){return Object.freeze(Object.defineProperties(strings,{raw:{value:Object.freeze(raw)}}));}/**
 * Styled components
 */var LineBreak=__WEBPACK_IMPORTED_MODULE_1_styled_components__["default"].br(_templateObject);var AppleEmployer=function AppleEmployer(_ref){var setAlertDismissableSession=_ref.setAlertDismissableSession;return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_3__shared_styles__["b" /* AlertNotification */],{dismissible:true,onDismiss:function onDismiss(){return setAlertDismissableSession('apple.employer');}},__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_3__shared_styles__["a" /* AlertContent */],null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('span',null,'Apple has partnered with SoFi to offer subsidized student loan refinancing products. ',__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(LineBreak,null),'All other SoFi products are not subsidized by Apple and are not part of the Apple program.')));};/* eslint react/no-typos: 0 */AppleEmployer.propTypes={setAlertDismissableSession:__WEBPACK_IMPORTED_MODULE_2_prop_types___default.a.func.isRequired};/* harmony default export */ __webpack_exports__["a"] = (AppleEmployer);

/***/ }),
/* 1277 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__(0);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_prop_types__ = __webpack_require__(1);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_prop_types___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_prop_types__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__shared_styles__ = __webpack_require__(1169);
/**
 * Styled components
 */var UnemploymentProtection=function UnemploymentProtection(_ref){var setAlertDismissableSession=_ref.setAlertDismissableSession;return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2__shared_styles__["b" /* AlertNotification */],{dismissible:true,onDismiss:function onDismiss(){return setAlertDismissableSession('upp.summary');}},__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2__shared_styles__["a" /* AlertContent */],null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('span',null,'Your application for SoFi\'s Unemployment Protection Program is being reviewed. You will receive a response in 3-5 business days. You must continue making monthly payments until the forbearance is approved. If you have questions, please contact our Servicing Team at 844-975-7634.')));};/* eslint react/no-typos: 0 */UnemploymentProtection.propTypes={setAlertDismissableSession:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.func.isRequired};/* harmony default export */ __webpack_exports__["a"] = (UnemploymentProtection);

/***/ }),
/* 1278 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__(0);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_prop_types__ = __webpack_require__(1);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_prop_types___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_prop_types__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_react_redux_i18n__ = __webpack_require__(70);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_react_redux_i18n___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_react_redux_i18n__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__shared_styles__ = __webpack_require__(1169);
/**
 * Styled components
 */var SsnPopup=function SsnPopup(_ref){var ssnPopupMessage=_ref.ssnPopupMessage,setAlertDismissableSession=_ref.setAlertDismissableSession;return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_3__shared_styles__["b" /* AlertNotification */],{warning:true,dismissible:true,onDismiss:function onDismiss(){return setAlertDismissableSession('ssn.popup');}},__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_3__shared_styles__["a" /* AlertContent */],null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_react_redux_i18n__["Translate"],{value:ssnPopupMessage})));};SsnPopup.propTypes={ssnPopupMessage:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.string.isRequired,setAlertDismissableSession:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.func.isRequired};/* harmony default export */ __webpack_exports__["a"] = (SsnPopup);

/***/ }),
/* 1279 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__(0);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_react_redux_i18n__ = __webpack_require__(70);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_react_redux_i18n___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_react_redux_i18n__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_prop_types__ = __webpack_require__(1);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_prop_types___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_prop_types__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__shared_styles__ = __webpack_require__(1169);
/**
 * Styled components
 */var HasInfo=function HasInfo(_ref){var hasInfo=_ref.hasInfo,setAlertDismissableSession=_ref.setAlertDismissableSession;return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_3__shared_styles__["b" /* AlertNotification */],{warning:true,dismissible:true,onDismiss:function onDismiss(){return setAlertDismissableSession('has.info');}},__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_3__shared_styles__["a" /* AlertContent */],null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_3__shared_styles__["c" /* AlertParagraph */],{dangerouslySetInnerHTML:{__html:__WEBPACK_IMPORTED_MODULE_1_react_redux_i18n__["I18n"].t(hasInfo())||hasInfo()}})));};HasInfo.propTypes={hasInfo:__WEBPACK_IMPORTED_MODULE_2_prop_types___default.a.func.isRequired,setAlertDismissableSession:__WEBPACK_IMPORTED_MODULE_2_prop_types___default.a.func.isRequired};/* harmony default export */ __webpack_exports__["a"] = (HasInfo);

/***/ }),
/* 1280 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__(0);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_react_redux_i18n__ = __webpack_require__(70);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_react_redux_i18n___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_react_redux_i18n__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_prop_types__ = __webpack_require__(1);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_prop_types___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_prop_types__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__shared_styles__ = __webpack_require__(1169);
/**
 * Styled components
 */var HasErrors=function HasErrors(_ref){var hasErrors=_ref.hasErrors,setAlertDismissableSession=_ref.setAlertDismissableSession;return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_3__shared_styles__["b" /* AlertNotification */],{warning:true,dismissible:true,onDismiss:function onDismiss(){return setAlertDismissableSession('has.errors');}},__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_3__shared_styles__["a" /* AlertContent */],null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_3__shared_styles__["c" /* AlertParagraph */],{dangerouslySetInnerHTML:{__html:__WEBPACK_IMPORTED_MODULE_1_react_redux_i18n__["I18n"].t(hasErrors())||hasErrors()}})));};HasErrors.propTypes={hasErrors:__WEBPACK_IMPORTED_MODULE_2_prop_types___default.a.func.isRequired,setAlertDismissableSession:__WEBPACK_IMPORTED_MODULE_2_prop_types___default.a.func.isRequired};/* harmony default export */ __webpack_exports__["a"] = (HasErrors);

/***/ }),
/* 1281 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__(0);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_prop_types__ = __webpack_require__(1);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_prop_types___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_prop_types__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__shared_styles__ = __webpack_require__(1169);
/**
 * Styled components
 */var GlobalError=function GlobalError(_ref){var message=_ref.globalError.message,setAlertDismissableSession=_ref.setAlertDismissableSession,sessionKeyName=_ref.sessionKeyName;return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2__shared_styles__["b" /* AlertNotification */],{warning:true,dismissible:true,onDismiss:function onDismiss(){return setAlertDismissableSession(sessionKeyName);}},__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2__shared_styles__["a" /* AlertContent */],null,message));};GlobalError.propTypes={globalError:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.object.isRequired,// eslint-disable-line
setAlertDismissableSession:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.func.isRequired,sessionKeyName:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.string.isRequired};/* harmony default export */ __webpack_exports__["a"] = (GlobalError);

/***/ }),
/* 1282 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__(0);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_react_redux_i18n__ = __webpack_require__(70);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_react_redux_i18n___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_react_redux_i18n__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_prop_types__ = __webpack_require__(1);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_prop_types___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_prop_types__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__shared_styles__ = __webpack_require__(1169);
/**
 * Styled components
 */var WaitForCosigner=function WaitForCosigner(_ref){var clearAlert=_ref.clearAlert;return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_3__shared_styles__["b" /* AlertNotification */],{warning:true,dismissible:true,onDismiss:function onDismiss(){return clearAlert();}},__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_3__shared_styles__["a" /* AlertContent */],null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_1_react_redux_i18n__["Translate"],{value:'waitForCosigner'})));};/* eslint react/no-typos: 0 */WaitForCosigner.propTypes={clearAlert:__WEBPACK_IMPORTED_MODULE_2_prop_types___default.a.func.isRequired};/* harmony default export */ __webpack_exports__["a"] = (WaitForCosigner);

/***/ }),
/* 1283 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__(0);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__shared_styles__ = __webpack_require__(1169);
/**
 * Styled components
 */var removeMarginTop={marginTop:'0px'};var WelcomeKit=function WelcomeKit(){return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_1__shared_styles__["b" /* AlertNotification */],null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_1__shared_styles__["a" /* AlertContent */],{style:removeMarginTop},__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('span',null,"We're going to send you an official SoFi member kit filled with essential info and a free gift. Please fill out your information"),__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('a',{'data-qa':'alerts-welcome-kit',href:'/dashboard/#/welcomekit'},'Get Welcome Kit!')));};/* harmony default export */ __webpack_exports__["a"] = (WelcomeKit);

/***/ }),
/* 1284 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__(0);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_prop_types__ = __webpack_require__(1);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_prop_types___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_prop_types__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_scuid_x__ = __webpack_require__(14);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_scuid_x___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_scuid_x__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_formik__ = __webpack_require__(1084);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_yup__ = __webpack_require__(1083);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_yup___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_4_yup__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5_styled_components__ = __webpack_require__(3);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__constants_prop_types_nps_survey_prop_types__ = __webpack_require__(1205);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__utilities_api_action_helpers__ = __webpack_require__(93);
var _templateObject=_taggedTemplateLiteral(['\n  display: inline-block;\n  margin-right: 20px;\n'],['\n  display: inline-block;\n  margin-right: 20px;\n']),_templateObject2=_taggedTemplateLiteral(['\n  width: 100%;\n  font-size: inherit;\n  padding: 10px;\n'],['\n  width: 100%;\n  font-size: inherit;\n  padding: 10px;\n']);function _taggedTemplateLiteral(strings,raw){return Object.freeze(Object.defineProperties(strings,{raw:{value:Object.freeze(raw)}}));}/**
 * PropTypes imports
 *//**
 * Utilities/function imports
 *//**
 * Styled Components
 */var SurveyRadio=Object(__WEBPACK_IMPORTED_MODULE_5_styled_components__["default"])(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["Radio"])(_templateObject);var TextArea=__WEBPACK_IMPORTED_MODULE_5_styled_components__["default"].textarea(_templateObject2);var NpsSurvey=function NpsSurvey(_ref){var isModalOpen=_ref.isModalOpen,toggleOpen=_ref.toggleOpen,npsSurvey=_ref.npsSurvey,scoreSet=_ref.scoreSet,lowScore=_ref.lowScore,surveySelectOptions=_ref.surveySelectOptions,values=_ref.values,errors=_ref.errors,handleChange=_ref.handleChange,handleSubmit=_ref.handleSubmit,setFieldValue=_ref.setFieldValue,touched=_ref.touched,isSubmitting=_ref.isSubmitting;return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["Modal"],{isOpen:isModalOpen,onDismiss:toggleOpen,title:'SoFi Welcome Survey',minWidth:window.innerWidth>=768?750:0},__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["Modal"].Body,null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["Paragraph"],null,'Thanks for taking the time to give us your feedback. Welcome to the SoFi Community!'),__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_3_formik__["a" /* Form */],{'data-qa':'nps-survey-form'},npsSurvey.survey.questions.map(function(value){return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_0_react__["Fragment"],{key:value.id},value.questionType==='RADIO_CHOICE_INLINE'&&value.id!==4&&__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["RadioGroup"],{legend:value.question,errorText:errors.radioChoiceRating},value.choices.map(function(option){return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(SurveyRadio,{group:'radioChoiceRating',qa:'npsSurvey-radioChoiceRating-'+option.value,value:option.choice,errorText:touched.radioChoiceRating&&errors.radioChoiceRating,checked:option.choice===values.radioChoiceRating,onChange:function onChange(e){scoreSet(e.target.value);setFieldValue('radioChoiceRating',e.target.value);}},option.choice);})),value.questionType==='SELECT_LIST'&&value.id!==4&&__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["DropDown"],{label:value.question,qa:'npsSurvey-chosen-product',onChange:function onChange(e){return setFieldValue('chosenProduct',e.target.value);},options:surveySelectOptions(value),value:values.chosenProduct}),value.questionType==='TEXT'&&value.id!==4&&__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_0_react__["Fragment"],null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["Paragraph"],null,value.question),__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(TextArea,{id:'feedbackComment',name:'feedbackComment','data-qa':'npsSurvey-feedbackComment',rows:'4',onChange:handleChange},values.feedbackComment)),value.questionType==='TEXT'&&value.id===4&&lowScore&&__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_0_react__["Fragment"],null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["Paragraph"],null,value.question),__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(TextArea,{id:'recommendationComment',name:'recommendationComment','data-qa':'npsSurvey-recommendationComment',rows:'4',onChange:handleChange},values.recommendationComment)));}))),__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["Modal"].Footer,null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["Button"],{'data-qa':'npsSurvey-close',small:true,onClick:toggleOpen},'Cancel'),__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["Button"],{'data-qa':'npsSurvey-submit',small:true,onClick:handleSubmit,disabled:isSubmitting},'Save')));};/* eslint react/no-typos: 0 */NpsSurvey.propTypes={isModalOpen:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.bool.isRequired,toggleOpen:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.func.isRequired,values:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.object.isRequired,// eslint-disable-line react/forbid-prop-types
errors:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.objectOf(__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.string).isRequired,handleChange:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.func.isRequired,handleSubmit:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.func.isRequired,setFieldValue:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.func.isRequired,touched:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.objectOf(__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.bool).isRequired,isSubmitting:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.bool.isRequired,npsSurvey:__WEBPACK_IMPORTED_MODULE_6__constants_prop_types_nps_survey_prop_types__["a" /* NpsSurveyPropTypes */].isRequired,surveySelectOptions:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.shape({value:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.string,label:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.string}).isRequired,scoreSet:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.func.isRequired,lowScore:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.bool.isRequired};/* harmony default export */ __webpack_exports__["a"] = (Object(__WEBPACK_IMPORTED_MODULE_3_formik__["b" /* withFormik */])({mapPropsToValues:function mapPropsToValues(){return{radioChoiceRating:'',chosenProduct:'',feedbackComment:'',recommendationComment:''};},validationSchema:function validationSchema(){return __WEBPACK_IMPORTED_MODULE_4_yup___default.a.object().shape({radioChoiceRating:__WEBPACK_IMPORTED_MODULE_4_yup___default.a.string().required('Please select one option between 0-10')});},handleSubmit:function handleSubmit(values,_ref2){var props=_ref2.props,setErrors=_ref2.setErrors,setSubmitting=_ref2.setSubmitting;props.submitSurvey(values,function(serverResponse){return setErrors(Object(__WEBPACK_IMPORTED_MODULE_7__utilities_api_action_helpers__["a" /* mapServerSideErrorsToFormikErrors */])(serverResponse));},setSubmitting,props.toggleOpen);}})(NpsSurvey));

/***/ }),
/* 1285 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__(0);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_prop_types__ = __webpack_require__(1);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_prop_types___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_prop_types__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_scuid_x__ = __webpack_require__(14);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_scuid_x___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_scuid_x__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_formik__ = __webpack_require__(1084);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_lodash_cloneDeep__ = __webpack_require__(334);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_lodash_cloneDeep___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_4_lodash_cloneDeep__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__constants_prop_types_nps_survey_prop_types__ = __webpack_require__(1205);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__utilities_api_action_helpers__ = __webpack_require__(93);
/**
 * PropTypes imports
 *//**
 * Utilities/function imports
 *//**
 * Styled Components
 */var WhereHeardSurvey=function WhereHeardSurvey(_ref){var isWhereHeardOpen=_ref.isWhereHeardOpen,toggleWhereHeardOpen=_ref.toggleWhereHeardOpen,whereHeardSurvey=_ref.whereHeardSurvey,values=_ref.values,handleChange=_ref.handleChange,handleSubmit=_ref.handleSubmit,isSubmitting=_ref.isSubmitting;return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["Modal"],{isOpen:isWhereHeardOpen,onDismiss:toggleWhereHeardOpen,title:whereHeardSurvey.survey.title,minWidth:window.innerWidth>=768?750:0},__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["Modal"].Body,null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_3_formik__["a" /* Form */],{'data-qa':'where-heard-survey-form'},whereHeardSurvey.survey.questions.map(function(value){return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_0_react__["Fragment"],{key:value.id},__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["Paragraph"],null,value.question),value.choices.map(function(option){return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["CheckBox"],{value:'survey_choice_'+option.id,group:'survey_choice_'+option.id,checked:values['survey_choice_'+option.id],quarterWidth:true,onChange:handleChange,qa:'profile-whereHeardAnswers'},option.choice);}));}))),__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["Modal"].Footer,null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["Button"],{'data-qa':'whereHeardSurvey-close',small:true,onClick:toggleWhereHeardOpen},'Cancel'),__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["Button"],{'data-qa':'whereHeardSurvey-submit',small:true,onClick:handleSubmit,disabled:isSubmitting},'Save')));};/* eslint react/no-typos: 0 */WhereHeardSurvey.propTypes={isWhereHeardOpen:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.bool.isRequired,values:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.object.isRequired,// eslint-disable-line react/forbid-prop-types
handleChange:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.func.isRequired,handleSubmit:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.func.isRequired,isSubmitting:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.bool.isRequired,whereHeardSurvey:__WEBPACK_IMPORTED_MODULE_5__constants_prop_types_nps_survey_prop_types__["a" /* NpsSurveyPropTypes */].isRequired,toggleWhereHeardOpen:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.func.isRequired};/* harmony default export */ __webpack_exports__["a"] = (Object(__WEBPACK_IMPORTED_MODULE_3_formik__["b" /* withFormik */])({mapPropsToValues:function mapPropsToValues(_ref2){var questions=_ref2.whereHeardSurvey.survey.questions;// Clone original object to avoid mutation
var surveyQuestionsClone=__WEBPACK_IMPORTED_MODULE_4_lodash_cloneDeep___default()(questions[0].choices);// Map choices array to Formik keys
var answerObj={};for(var idx=0;idx<surveyQuestionsClone.length;idx+=1){answerObj['survey_choice_'+surveyQuestionsClone[idx].id]=false;}return answerObj;},handleSubmit:function handleSubmit(values,_ref3){var props=_ref3.props,setErrors=_ref3.setErrors,setSubmitting=_ref3.setSubmitting;props.submitWhereHeardSurvey(values,function(serverResponse){return setErrors(Object(__WEBPACK_IMPORTED_MODULE_6__utilities_api_action_helpers__["a" /* mapServerSideErrorsToFormikErrors */])(serverResponse));},setSubmitting);}})(WhereHeardSurvey));

/***/ }),
/* 1286 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__(0);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_prop_types__ = __webpack_require__(1);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_prop_types___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_prop_types__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_scuid_x__ = __webpack_require__(14);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_scuid_x___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_scuid_x__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__shared_styles__ = __webpack_require__(1175);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__utilities_global_styles__ = __webpack_require__(80);
var _templateObject=_taggedTemplateLiteral(['\n  margin-top: -1.4rem;\n'],['\n  margin-top: -1.4rem;\n']);function _taggedTemplateLiteral(strings,raw){return Object.freeze(Object.defineProperties(strings,{raw:{value:Object.freeze(raw)}}));}/**
 * Styled Components
 */var Container=__WEBPACK_IMPORTED_MODULE_3__shared_styles__["a" /* ReasonContainer */].extend(_templateObject);var PostSurveyReferralModal=function PostSurveyReferralModal(_ref){var isThankYouOpen=_ref.isThankYouOpen,toggleOpenThankYouModal=_ref.toggleOpenThankYouModal,referralLinkObj=_ref.referralLinkObj,highRating=_ref.highRating;return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["Modal"],{isOpen:isThankYouOpen,onDismiss:toggleOpenThankYouModal,title:'Thank you!',minWidth:window.innerWidth>=768?750:0},__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["Modal"].Body,null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(Container,null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["Paragraph"],null,'Thank you for sharing your feedback! You will receive a series of welcome emails over the next few weeks explaining all the benefits you have as a SoFi member.',' '),__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["Paragraph"],null,'Before you go, will you give 3 minutes, write a review and help others find SoFi? '),__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["Paragraph"],null,'We value your feedback, and so do future SoFi customers. Online reviews are an important part of many customer\'s decision to fund a loan with SoFi. Your opinion will help others evaluate SoFi.',' '),highRating&&__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_4__utilities_global_styles__["d" /* ScuidLink */],{'data-qa':'post-survey-referral-review-link',href:referralLinkObj.reviewUrl,onClick:toggleOpenThankYouModal},referralLinkObj.reviewText))),__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["Modal"].Footer,null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["Button"],{'data-qa':'noEmployment-close',small:true,secondary:true,onClick:toggleOpenThankYouModal},'Ok, got it!')));};/* eslint react/no-typos: 0 */PostSurveyReferralModal.propTypes={isThankYouOpen:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.bool.isRequired,toggleOpenThankYouModal:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.func.isRequired,referralLinkObj:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.shape({reviewText:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.string.isRequired,reviewUrl:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.string.isRequired}).isRequired,highRating:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.bool.isRequired};/* harmony default export */ __webpack_exports__["a"] = (PostSurveyReferralModal);

/***/ }),
/* 1287 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return getNpsSurvey; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "c", function() { return postNpsSurvey; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "b", function() { return getWhereHeardSurvey; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "d", function() { return postWhereHeardSurvey; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__utilities_api_action_helpers__ = __webpack_require__(93);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__constants__ = __webpack_require__(79);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__constants_survey_constants__ = __webpack_require__(338);
var getNpsSurvey=function getNpsSurvey(){return function(dispatch){Object(__WEBPACK_IMPORTED_MODULE_0__utilities_api_action_helpers__["b" /* performGet */])(dispatch,__WEBPACK_IMPORTED_MODULE_1__constants__["a" /* API_URL */]+'/surveys/nps',{},__WEBPACK_IMPORTED_MODULE_2__constants_survey_constants__["a" /* GET_NPS_SURVEY */]);};};var postNpsSurvey=function postNpsSurvey(data,setErrors){return function(dispatch){Object(__WEBPACK_IMPORTED_MODULE_0__utilities_api_action_helpers__["c" /* performPost */])(dispatch,__WEBPACK_IMPORTED_MODULE_1__constants__["a" /* API_URL */]+'/surveys/nps',{},data,__WEBPACK_IMPORTED_MODULE_2__constants_survey_constants__["c" /* POST_NPS_SURVEY */],setErrors);};};var getWhereHeardSurvey=function getWhereHeardSurvey(){return function(dispatch){Object(__WEBPACK_IMPORTED_MODULE_0__utilities_api_action_helpers__["b" /* performGet */])(dispatch,__WEBPACK_IMPORTED_MODULE_1__constants__["a" /* API_URL */]+'/surveys/whereheard',{},__WEBPACK_IMPORTED_MODULE_2__constants_survey_constants__["b" /* GET_WHERE_HEARD_SURVEY */]);};};var postWhereHeardSurvey=function postWhereHeardSurvey(data,setErrors){return function(dispatch){Object(__WEBPACK_IMPORTED_MODULE_0__utilities_api_action_helpers__["c" /* performPost */])(dispatch,__WEBPACK_IMPORTED_MODULE_1__constants__["a" /* API_URL */]+'/surveys/whereheard',{},data,__WEBPACK_IMPORTED_MODULE_2__constants_survey_constants__["d" /* POST_WHERE_HEARD_SURVEY */],setErrors);};};

/***/ }),
/* 1288 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return getUppSummary; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__utilities_api_action_helpers__ = __webpack_require__(93);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__constants__ = __webpack_require__(79);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__constants_upp_summary_constants__ = __webpack_require__(339);
var getUppSummary=function getUppSummary(){return function(dispatch){Object(__WEBPACK_IMPORTED_MODULE_0__utilities_api_action_helpers__["b" /* performGet */])(dispatch,__WEBPACK_IMPORTED_MODULE_1__constants__["a" /* API_URL */]+'/upp/upp-summary',{},__WEBPACK_IMPORTED_MODULE_2__constants_upp_summary_constants__["a" /* GET_UPP_SUMMARY */]);};};

/***/ }),
/* 1289 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return getTrackingBanner; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__utilities_api_action_helpers__ = __webpack_require__(93);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__constants__ = __webpack_require__(79);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__constants_tracking_banner_constants__ = __webpack_require__(341);
var getTrackingBanner=function getTrackingBanner(){return function(dispatch){return Object(__WEBPACK_IMPORTED_MODULE_0__utilities_api_action_helpers__["b" /* performGet */])(dispatch,__WEBPACK_IMPORTED_MODULE_1__constants__["a" /* API_URL */]+'/tracking-banner',{},__WEBPACK_IMPORTED_MODULE_2__constants_tracking_banner_constants__["a" /* GET_TRACKING_BANNER */]);};};

/***/ }),
/* 1290 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return getAlertSessionKey; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "b", function() { return setAlertDismissableSession; });
/**
 * Returns the session value as a boolean
 * @param {String} key name of the session for the specific alert being dismissed
 */var getAlertSessionKey=function getAlertSessionKey(key){var res=sessionStorage.getItem(key);var sessionBool=res==='true';return sessionBool;};/**
 * Sets the session key/value to hide alert
 * @param {String} key name of the session for the specific alert being dismissed
 */var setAlertDismissableSession=function setAlertDismissableSession(key){var value=true;sessionStorage.setItem(key,value);};

/***/ }),
/* 1291 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_babel_runtime_regenerator__ = __webpack_require__(122);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_babel_runtime_regenerator___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_babel_runtime_regenerator__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_react__ = __webpack_require__(0);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_prop_types__ = __webpack_require__(1);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_prop_types___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_prop_types__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_styled_components__ = __webpack_require__(3);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_react_redux__ = __webpack_require__(95);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5_react_launch_darkly__ = __webpack_require__(1187);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5_react_launch_darkly___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_5_react_launch_darkly__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__constants_prop_types_application_prop_types__ = __webpack_require__(1168);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__components_accounts__ = __webpack_require__(1292);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8__components_accounts_accounts_section__ = __webpack_require__(1314);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_9__actions_referral_actions__ = __webpack_require__(1172);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_10__actions_application_actions__ = __webpack_require__(1181);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_11__utilities__ = __webpack_require__(1222);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_12__constants_launch_darkly_constants__ = __webpack_require__(1188);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_13__constants_prop_types_customer_prop_types__ = __webpack_require__(124);
var _createClass=function(){function defineProperties(target,props){for(var i=0;i<props.length;i++){var descriptor=props[i];descriptor.enumerable=descriptor.enumerable||false;descriptor.configurable=true;if("value"in descriptor)descriptor.writable=true;Object.defineProperty(target,descriptor.key,descriptor);}}return function(Constructor,protoProps,staticProps){if(protoProps)defineProperties(Constructor.prototype,protoProps);if(staticProps)defineProperties(Constructor,staticProps);return Constructor;};}();var _templateObject=_taggedTemplateLiteral(['\n  padding-top: 20px;\n  background: white;\n  section {\n    max-width: 1240px;\n    margin: 0px auto;\n    padding-left: 20px;\n    padding-right: 20px;\n  }\n'],['\n  padding-top: 20px;\n  background: white;\n  section {\n    max-width: 1240px;\n    margin: 0px auto;\n    padding-left: 20px;\n    padding-right: 20px;\n  }\n']);function _defineProperty(obj,key,value){if(key in obj){Object.defineProperty(obj,key,{value:value,enumerable:true,configurable:true,writable:true});}else{obj[key]=value;}return obj;}function _asyncToGenerator(fn){return function(){var gen=fn.apply(this,arguments);return new Promise(function(resolve,reject){function step(key,arg){try{var info=gen[key](arg);var value=info.value;}catch(error){reject(error);return;}if(info.done){resolve(value);}else{return Promise.resolve(value).then(function(value){step("next",value);},function(err){step("throw",err);});}}return step("next");});};}function _classCallCheck(instance,Constructor){if(!(instance instanceof Constructor)){throw new TypeError("Cannot call a class as a function");}}function _possibleConstructorReturn(self,call){if(!self){throw new ReferenceError("this hasn't been initialised - super() hasn't been called");}return call&&(typeof call==="object"||typeof call==="function")?call:self;}function _inherits(subClass,superClass){if(typeof superClass!=="function"&&superClass!==null){throw new TypeError("Super expression must either be null or a function, not "+typeof superClass);}subClass.prototype=Object.create(superClass&&superClass.prototype,{constructor:{value:subClass,enumerable:false,writable:true,configurable:true}});if(superClass)Object.setPrototypeOf?Object.setPrototypeOf(subClass,superClass):subClass.__proto__=superClass;}function _taggedTemplateLiteral(strings,raw){return Object.freeze(Object.defineProperties(strings,{raw:{value:Object.freeze(raw)}}));}/**
 * PropTypes imports
 *//**
 * Component imports
 */// Old accounts
// New accounts
/**
 * Action imports
 *//**
 * Utilties
 *//**
 * Styled Components
 */var OldContainer=__WEBPACK_IMPORTED_MODULE_3_styled_components__["default"].div(_templateObject);/**
 * Accounts container (at the top of the dashboard)
 */var Accounts=function(_Component){_inherits(Accounts,_Component);function Accounts(){var _ref,_this2=this;var _temp,_this,_ret;_classCallCheck(this,Accounts);for(var _len=arguments.length,args=Array(_len),_key=0;_key<_len;_key++){args[_key]=arguments[_key];}return _ret=(_temp=(_this=_possibleConstructorReturn(this,(_ref=Accounts.__proto__||Object.getPrototypeOf(Accounts)).call.apply(_ref,[this].concat(args))),_this),_this.state={showMohelaModal:false,showCenlarModal:false,caretRightCounter:0,customer:__WEBPACK_IMPORTED_MODULE_13__constants_prop_types_customer_prop_types__["b" /* CustomerPropTypes */].isRequired,modalContentUrl:''},_this.refreshReferralState=_asyncToGenerator(/*#__PURE__*/__WEBPACK_IMPORTED_MODULE_0_babel_runtime_regenerator___default.a.mark(function _callee(){var loadReferralSummary;return __WEBPACK_IMPORTED_MODULE_0_babel_runtime_regenerator___default.a.wrap(function _callee$(_context){while(1){switch(_context.prev=_context.next){case 0:loadReferralSummary=_this.props.loadReferralSummary;_context.next=3;return loadReferralSummary();case 3:case'end':return _context.stop();}}},_callee,_this2);})),_this.refreshConsentData=_asyncToGenerator(/*#__PURE__*/__WEBPACK_IMPORTED_MODULE_0_babel_runtime_regenerator___default.a.mark(function _callee2(){var isReferralSubscribed;return __WEBPACK_IMPORTED_MODULE_0_babel_runtime_regenerator___default.a.wrap(function _callee2$(_context2){while(1){switch(_context2.prev=_context2.next){case 0:_context2.next=2;return _this.refreshReferralState();case 2:isReferralSubscribed=_this.props.isReferralSubscribed;if(!isReferralSubscribed){// poll dashboard api until data has been propagated
setTimeout(function(){_this.refreshConsentData();},2000);}case 4:case'end':return _context2.stop();}}},_callee2,_this2);})),_this.postReferralConsent=function(){var _ref4=_asyncToGenerator(/*#__PURE__*/__WEBPACK_IMPORTED_MODULE_0_babel_runtime_regenerator___default.a.mark(function _callee3(referralConsent){var postUpdateReferralConsent;return __WEBPACK_IMPORTED_MODULE_0_babel_runtime_regenerator___default.a.wrap(function _callee3$(_context3){while(1){switch(_context3.prev=_context3.next){case 0:postUpdateReferralConsent=_this.props.postUpdateReferralConsent;_context3.next=3;return postUpdateReferralConsent(referralConsent);case 3:_this.refreshConsentData();case 4:case'end':return _context3.stop();}}},_callee3,_this2);}));return function(_x){return _ref4.apply(this,arguments);};}(),_this.handleCallback=function(action){// Check if we need to trigger a modal
var modalName=action.modalName,modalContentUrl=action.modalContentUrl;if(modalName){var name=modalName;switch(name){case'mohelaModal':{_this.setState({showMohelaModal:true});break;}case'mortgageModal':{_this.setState({showCenlarModal:true,modalContentUrl:modalContentUrl});break;}default:{// do nothing for now
}}}},_this.handleModalOpen=function(modalKey){return function(){_this.setState(_defineProperty({},modalKey,!_this.state[modalKey]));};},_temp),_possibleConstructorReturn(_this,_ret);}_createClass(Accounts,[{key:'componentDidMount',value:function componentDidMount(){var _props=this.props,loadMortgageSso=_props.loadMortgageSso,applications=_props.applications;var hasCelnarServicedApps=applications.filter(function(app){var isTrue=app.type==='MORT'&&app.servicing&&app.servicing.status==='CENLAR'&&app.servicing.statusDesc==='CENLAR_SOFI';return isTrue;}).length;if(hasCelnarServicedApps){loadMortgageSso();}}},{key:'render',value:function render(){var _this3=this;var _state=this.state,showMohelaModal=_state.showMohelaModal,showCenlarModal=_state.showCenlarModal,modalContentUrl=_state.modalContentUrl;return __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_5_react_launch_darkly__["FeatureFlag"],{flagKey:__WEBPACK_IMPORTED_MODULE_12__constants_launch_darkly_constants__["a" /* FEATURE_FLAG_ACCOUNT_CARDS */],renderFeatureCallback:function renderFeatureCallback(){return __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_8__components_accounts_accounts_section__["a" /* default */],Object.assign({},_this3.props,{postReferralConsent:_this3.postReferralConsent,getValueLabelPairs:__WEBPACK_IMPORTED_MODULE_11__utilities__["d" /* GET_VALUE_LABEL_PAIRS */],handleCallback:_this3.handleCallback,handleModalOpen:_this3.handleModalOpen,handleClickCaret:_this3.handleClickCaret,showMohelaModal:showMohelaModal,showCenlarModal:showCenlarModal,modalContentUrl:modalContentUrl}));},renderDefaultCallback:function renderDefaultCallback(){return __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(OldContainer,null,__WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_7__components_accounts__["a" /* default */],Object.assign({},_this3.props,{postReferralConsent:_this3.postReferralConsent})));}});}}]);return Accounts;}(__WEBPACK_IMPORTED_MODULE_1_react__["Component"]);Accounts.propTypes={applications:__WEBPACK_IMPORTED_MODULE_2_prop_types___default.a.arrayOf(__WEBPACK_IMPORTED_MODULE_6__constants_prop_types_application_prop_types__["a" /* ApplicationPropType */]).isRequired,servicing:__WEBPACK_IMPORTED_MODULE_2_prop_types___default.a.object.isRequired,// eslint-disable-line
postUpdateReferralConsent:__WEBPACK_IMPORTED_MODULE_2_prop_types___default.a.func.isRequired,loadMortgageSso:__WEBPACK_IMPORTED_MODULE_2_prop_types___default.a.func.isRequired,mortgageSsoLoaded:__WEBPACK_IMPORTED_MODULE_2_prop_types___default.a.bool.isRequired,isReferralSubscribed:__WEBPACK_IMPORTED_MODULE_2_prop_types___default.a.bool.isRequired,loadDashboardAccounts:__WEBPACK_IMPORTED_MODULE_2_prop_types___default.a.func.isRequired};var mapStateToProps=function mapStateToProps(state){return{mortgageSso:state.applicationReducer.mortgageSso.data,mortgageSsoLoaded:state.applicationReducer.mortgageSso.loaded,servicing:state.applicationReducer.servicing.data,servicingLoaded:state.applicationReducer.servicing.loaded,isReferralSubscribed:state.referralReducer.referralSummary.loaded&&state.referralReducer.referralSummary.data.isSubscribed};};var mapDispatchToProps=function mapDispatchToProps(dispatch){return{postUpdateReferralConsent:function postUpdateReferralConsent(referralConsent){return dispatch(Object(__WEBPACK_IMPORTED_MODULE_9__actions_referral_actions__["n" /* updateReferralConsent */])(referralConsent));},loadMortgageSso:function loadMortgageSso(){return dispatch(Object(__WEBPACK_IMPORTED_MODULE_10__actions_application_actions__["d" /* getMortgageSso */])());},loadReferralSummary:function loadReferralSummary(){return dispatch(Object(__WEBPACK_IMPORTED_MODULE_9__actions_referral_actions__["e" /* getReferralSummary */])());}};};/* harmony default export */ __webpack_exports__["a"] = (Object(__WEBPACK_IMPORTED_MODULE_4_react_redux__["b" /* connect */])(mapStateToProps,mapDispatchToProps)(Accounts));

/***/ }),
/* 1292 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__accounts__ = __webpack_require__(1293);
/* harmony reexport (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return __WEBPACK_IMPORTED_MODULE_0__accounts__["a"]; });


/***/ }),
/* 1293 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__(0);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_prop_types__ = __webpack_require__(1);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_prop_types___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_prop_types__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_styled_components__ = __webpack_require__(3);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_scuid_x__ = __webpack_require__(14);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_scuid_x___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_3_scuid_x__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_lodash_isEmpty__ = __webpack_require__(1171);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_lodash_isEmpty___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_4_lodash_isEmpty__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__constants_prop_types_application_prop_types__ = __webpack_require__(1168);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__constants_prop_types_customer_prop_types__ = __webpack_require__(124);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__constants_prop_types_wealth_prop_types__ = __webpack_require__(1223);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8__constants_prop_types_referral_prop_types__ = __webpack_require__(1082);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_9__constants_prop_types_banking_prop_types__ = __webpack_require__(1197);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_10__bankruptcy__ = __webpack_require__(1294);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_11__unboarded_loan__ = __webpack_require__(1295);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_12__forbearance__ = __webpack_require__(1296);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_13__chargeoff__ = __webpack_require__(1297);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_14__repayment__ = __webpack_require__(1298);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_15__not_in_servicing__ = __webpack_require__(1299);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_16__cannot_continue__ = __webpack_require__(1300);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_17__ecp__ = __webpack_require__(1302);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_18__affiliate__ = __webpack_require__(1224);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_19__wealth__ = __webpack_require__(1310);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_20__sofi_money__ = __webpack_require__(1313);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_21__utilities__ = __webpack_require__(328);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_22__shared_styles__ = __webpack_require__(1173);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_23__utilities_global_styles__ = __webpack_require__(80);
var _createClass=function(){function defineProperties(target,props){for(var i=0;i<props.length;i++){var descriptor=props[i];descriptor.enumerable=descriptor.enumerable||false;descriptor.configurable=true;if("value"in descriptor)descriptor.writable=true;Object.defineProperty(target,descriptor.key,descriptor);}}return function(Constructor,protoProps,staticProps){if(protoProps)defineProperties(Constructor.prototype,protoProps);if(staticProps)defineProperties(Constructor,staticProps);return Constructor;};}();var _templateObject=_taggedTemplateLiteral(['\n  font-size: 0.8rem;\n  font-weight: 700;\n  line-height: 1.28;\n  letter-spacing: 0.1rem;\n  color: #262626;\n  padding-top: 20px;\n  padding-bottom: 10px;\n'],['\n  font-size: 0.8rem;\n  font-weight: 700;\n  line-height: 1.28;\n  letter-spacing: 0.1rem;\n  color: #262626;\n  padding-top: 20px;\n  padding-bottom: 10px;\n']),_templateObject2=_taggedTemplateLiteral(['\n  padding-bottom: 15px;\n  padding-top: 0px;\n'],['\n  padding-bottom: 15px;\n  padding-top: 0px;\n']);function _classCallCheck(instance,Constructor){if(!(instance instanceof Constructor)){throw new TypeError("Cannot call a class as a function");}}function _possibleConstructorReturn(self,call){if(!self){throw new ReferenceError("this hasn't been initialised - super() hasn't been called");}return call&&(typeof call==="object"||typeof call==="function")?call:self;}function _inherits(subClass,superClass){if(typeof superClass!=="function"&&superClass!==null){throw new TypeError("Super expression must either be null or a function, not "+typeof superClass);}subClass.prototype=Object.create(superClass&&superClass.prototype,{constructor:{value:subClass,enumerable:false,writable:true,configurable:true}});if(superClass)Object.setPrototypeOf?Object.setPrototypeOf(subClass,superClass):subClass.__proto__=superClass;}function _taggedTemplateLiteral(strings,raw){return Object.freeze(Object.defineProperties(strings,{raw:{value:Object.freeze(raw)}}));}/**
 * PropTypes imports
 *//**
 * Component imports
 *//**
 * Utilities/function imports
 *//**
 * Styled Components
 */var Header=__WEBPACK_IMPORTED_MODULE_2_styled_components__["default"].h6(_templateObject);var Servicing=Object(__WEBPACK_IMPORTED_MODULE_2_styled_components__["default"])(__WEBPACK_IMPORTED_MODULE_3_scuid_x__["Paragraph"])(_templateObject2);/**
 * Displays all the customer accounts
 */var Accounts=function(_Component){_inherits(Accounts,_Component);function Accounts(){var _ref;var _temp,_this,_ret;_classCallCheck(this,Accounts);for(var _len=arguments.length,args=Array(_len),_key=0;_key<_len;_key++){args[_key]=arguments[_key];}return _ret=(_temp=(_this=_possibleConstructorReturn(this,(_ref=Accounts.__proto__||Object.getPrototypeOf(Accounts)).call.apply(_ref,[this].concat(args))),_this),_this.state={isOpen:[]},_this.toggleDropdown=function(i){var isOpen=_this.state.isOpen;// if the index does not exist, create it
if(!isOpen[i])isOpen[i]=false;// now toggle the index
isOpen[i]=!isOpen[i];// set state with the new toggled array
_this.setState({isOpen:isOpen});},_temp),_possibleConstructorReturn(_this,_ret);}_createClass(Accounts,[{key:'render',value:function render(){var _this2=this;var _props=this.props,customer=_props.customer,applications=_props.applications,consentsTou=_props.consentsTou,wealth=_props.wealth,wealthLoaded=_props.wealthLoaded,postReferralConsent=_props.postReferralConsent,referralSummary=_props.referralSummary,referralConsents=_props.referralConsents,referralSummaryLoaded=_props.referralSummaryLoaded,referralConsentsLoaded=_props.referralConsentsLoaded,mortgageSso=_props.mortgageSso,servicingLoaded=_props.servicingLoaded,servicing=_props.servicing,banking=_props.banking,bankingLoaded=_props.bankingLoaded;// isOpen is to track which drop-down is open
var isOpen=this.state.isOpen;// ecp is a type of account that sits outside of the map function in render
// so we find it (if it exists) from applications here
var ecp=applications.find(function(app){return Object(__WEBPACK_IMPORTED_MODULE_21__utilities__["j" /* isEcp */])(app);});if(mortgageSso){for(var idx=0;idx<applications.length;idx+=1){if(applications[idx].type==='MORT'&&applications[idx].servicing&&applications[idx].servicing.status==='CENLAR'&&applications[idx].servicing.statusDesc==='CENLAR_SOFI'){applications[idx].servicing.servicingUrl=mortgageSso[applications[idx].id];}}}// Only show the Accounts section if the following conditions match
// Customer either has application(s), wealth account, banking account or is eligible for the referral program
var showAccounts=applications.length>0||wealth.length>0&&!!wealth[0].accountId||!__WEBPACK_IMPORTED_MODULE_4_lodash_isEmpty___default()(banking)&&banking.status!=='NEW'||Object(__WEBPACK_IMPORTED_MODULE_21__utilities__["c" /* eligibleForReferralProgram */])(customer);return showAccounts?__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('section',null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(Header,null,'YOUR ACCOUNT'),servicingLoaded&&Object(__WEBPACK_IMPORTED_MODULE_21__utilities__["u" /* showServicing */])(applications)&&!!servicing.accessUrl&&__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(Servicing,null,'Access your account to make payments and see your balance.',' ',__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_23__utilities_global_styles__["d" /* ScuidLink */],{'data-qa':'accounts-access-accounts',href:servicing.accessUrl},'Access account')),wealthLoaded&&wealth.length>0&&!!wealth[0].accountId&&wealth.map(function(wealthProfile){return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_19__wealth__["a" /* default */],{key:wealthProfile.accountId,wealthProfile:wealthProfile});}),applications&&customer&&applications.map(function(app,i){return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_0_react__["Fragment"],{key:app.continueUrl},app.servicing&&Object(__WEBPACK_IMPORTED_MODULE_21__utilities__["h" /* isBankruptcy */])(app)&&__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_10__bankruptcy__["a" /* default */],{app:app,customer:customer}),app.servicing&&Object(__WEBPACK_IMPORTED_MODULE_21__utilities__["p" /* isUnboardedLoan */])(app)&&__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_11__unboarded_loan__["a" /* default */],{app:app,customer:customer}),app.servicing&&Object(__WEBPACK_IMPORTED_MODULE_21__utilities__["k" /* isForbearance */])(app)&&__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_12__forbearance__["a" /* default */],{app:app,customer:customer}),app.servicing&&Object(__WEBPACK_IMPORTED_MODULE_21__utilities__["i" /* isChargeOff */])(app)&&__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_13__chargeoff__["a" /* default */],{app:app,customer:customer}),(app.servicing&&Object(__WEBPACK_IMPORTED_MODULE_21__utilities__["l" /* isInRepayment */])(app)||app.servicing&&Object(__WEBPACK_IMPORTED_MODULE_21__utilities__["q" /* isUnknownStatus */])(app))&&__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_14__repayment__["a" /* default */],{app:app,customer:customer,index:i,toggleDropdown:_this2.toggleDropdown,isOpen:isOpen[i]||false}),!app.servicing&&Object(__WEBPACK_IMPORTED_MODULE_21__utilities__["b" /* canContinueApp */])(app)&&__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_15__not_in_servicing__["a" /* default */],{app:app,customer:customer,index:i,toggleDropdown:_this2.toggleDropdown,isOpen:isOpen[i]||false}),(!app.servicing||Object(__WEBPACK_IMPORTED_MODULE_21__utilities__["m" /* isMortCENLAR */])(app))&&!Object(__WEBPACK_IMPORTED_MODULE_21__utilities__["b" /* canContinueApp */])(app)&&__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_16__cannot_continue__["a" /* default */],{app:app,customer:customer,index:i,toggleDropdown:_this2.toggleDropdown,isOpen:isOpen[i]||false}),!Object(__WEBPACK_IMPORTED_MODULE_21__utilities__["j" /* isEcp */])(app)&&__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_22__shared_styles__["g" /* LoanBottomBorder */],null));}),applications&&customer&&ecp&&ecp.servicing&&__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_0_react__["Fragment"],null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_17__ecp__["a" /* default */],{ecp:ecp}),__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_22__shared_styles__["g" /* LoanBottomBorder */],null)),bankingLoaded&&!__WEBPACK_IMPORTED_MODULE_4_lodash_isEmpty___default()(banking)&&banking.status!=='NEW'&&__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_0_react__["Fragment"],null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_20__sofi_money__["a" /* default */],{banking:banking}),__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_22__shared_styles__["g" /* LoanBottomBorder */],null)),Object(__WEBPACK_IMPORTED_MODULE_21__utilities__["c" /* eligibleForReferralProgram */])(customer)&&consentsTou&&referralSummaryLoaded&&referralConsentsLoaded&&__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_18__affiliate__["a" /* default */],{customer:customer,referralSummary:referralSummary,referralConsents:referralConsents,consentsTou:consentsTou,postReferralConsent:postReferralConsent})):null;}}]);return Accounts;}(__WEBPACK_IMPORTED_MODULE_0_react__["Component"]);Accounts.propTypes={customer:__WEBPACK_IMPORTED_MODULE_6__constants_prop_types_customer_prop_types__["b" /* CustomerPropTypes */].isRequired,applications:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.arrayOf(__WEBPACK_IMPORTED_MODULE_5__constants_prop_types_application_prop_types__["a" /* ApplicationPropType */]).isRequired,consentsTou:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.number,wealth:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.arrayOf(__WEBPACK_IMPORTED_MODULE_7__constants_prop_types_wealth_prop_types__["a" /* WealthProfilePropTypes */]).isRequired,wealthLoaded:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.bool.isRequired,postReferralConsent:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.func.isRequired,referralSummary:__WEBPACK_IMPORTED_MODULE_8__constants_prop_types_referral_prop_types__["g" /* ReferralSummaryPropTypes */].isRequired,referralConsents:__WEBPACK_IMPORTED_MODULE_8__constants_prop_types_referral_prop_types__["a" /* ReferralConsentsPropTypes */].isRequired,referralSummaryLoaded:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.bool.isRequired,referralConsentsLoaded:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.bool.isRequired,mortgageSso:__WEBPACK_IMPORTED_MODULE_5__constants_prop_types_application_prop_types__["c" /* MortgageSsoPropType */].isRequired,servicingLoaded:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.bool.isRequired,servicing:__WEBPACK_IMPORTED_MODULE_5__constants_prop_types_application_prop_types__["d" /* ServicingPropTypes */].isRequired,banking:__WEBPACK_IMPORTED_MODULE_9__constants_prop_types_banking_prop_types__["a" /* BankingPropTypes */].isRequired,bankingLoaded:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.bool.isRequired};Accounts.defaultProps={consentsTou:null};/* harmony default export */ __webpack_exports__["a"] = (Accounts);

/***/ }),
/* 1294 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__(0);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_scuid_x__ = __webpack_require__(14);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_scuid_x___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_scuid_x__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__constants_prop_types_application_prop_types__ = __webpack_require__(1168);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__shared_styles__ = __webpack_require__(1173);
/**
 * PropTypes imports
 *//**
 * Styled Components
 */var Bankruptcy=function Bankruptcy(_ref){var app=_ref.app;return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_0_react__["Fragment"],null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_1_scuid_x__["SubheadFour"],null,app.productDesc,' (#',app.servicing.accountId,')'),__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_3__shared_styles__["i" /* LoanDescription */],null,app.servicing.statusDesc));};/* eslint react/no-typos: 0 */Bankruptcy.propTypes={app:__WEBPACK_IMPORTED_MODULE_2__constants_prop_types_application_prop_types__["a" /* ApplicationPropType */].isRequired};Bankruptcy.defaultProps={};/* harmony default export */ __webpack_exports__["a"] = (Bankruptcy);

/***/ }),
/* 1295 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__(0);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_scuid_x__ = __webpack_require__(14);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_scuid_x___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_scuid_x__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__constants_prop_types_application_prop_types__ = __webpack_require__(1168);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__shared_styles__ = __webpack_require__(1173);
/**
 * PropTypes imports
 *//**
 * Styled Components
 */var UnboardedLoan=function UnboardedLoan(_ref){var app=_ref.app;return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_0_react__["Fragment"],null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_1_scuid_x__["SubheadFour"],null,app.productDesc,' (#',app.servicing.accountId,')'),__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_3__shared_styles__["i" /* LoanDescription */],null,app.servicing.statusDesc));};/* eslint react/no-typos: 0 */UnboardedLoan.propTypes={app:__WEBPACK_IMPORTED_MODULE_2__constants_prop_types_application_prop_types__["a" /* ApplicationPropType */].isRequired};/* harmony default export */ __webpack_exports__["a"] = (UnboardedLoan);

/***/ }),
/* 1296 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__(0);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_scuid_x__ = __webpack_require__(14);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_scuid_x___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_scuid_x__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__constants_prop_types_application_prop_types__ = __webpack_require__(1168);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__utilities__ = __webpack_require__(328);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__shared_styles__ = __webpack_require__(1173);
/**
 * PropTypes imports
 *//**
 * Utilities/function imports
 *//**
 * Styled Components
 */var Forbearance=function Forbearance(_ref){var app=_ref.app;return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_0_react__["Fragment"],null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_1_scuid_x__["SubheadFour"],null,app.productDesc,' (#',app.servicing.accountId,')'),__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_4__shared_styles__["i" /* LoanDescription */],null,Object(__WEBPACK_IMPORTED_MODULE_3__utilities__["f" /* generateForbearanceStatus */])(app)),__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_4__shared_styles__["f" /* LoanBody */],null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_4__shared_styles__["c" /* LoanAction */],null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('a',{'data-qa':'accounts-forbearanceDetails',href:app.servicing.servicingUrl+'/#/'+app.servicing.loanId},__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_4__shared_styles__["h" /* LoanButton */],{'data-qa':'accounts-forbearanceDetails-button',small:true},'View details')))));};/* eslint react/no-typos: 0 */Forbearance.propTypes={app:__WEBPACK_IMPORTED_MODULE_2__constants_prop_types_application_prop_types__["a" /* ApplicationPropType */].isRequired};Forbearance.defaultProps={};/* harmony default export */ __webpack_exports__["a"] = (Forbearance);

/***/ }),
/* 1297 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__(0);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_scuid_x__ = __webpack_require__(14);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_scuid_x___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_scuid_x__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__constants_prop_types_application_prop_types__ = __webpack_require__(1168);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__shared_styles__ = __webpack_require__(1173);
/**
 * PropTypes imports
 *//**
 * Styled Components
 */var Chargeoff=function Chargeoff(_ref){var app=_ref.app;return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_0_react__["Fragment"],null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_1_scuid_x__["SubheadFour"],null,app.productDesc,' (#',app.servicing.accountId,')'),__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_3__shared_styles__["i" /* LoanDescription */],null,app.servicing.statusDesc));};/* eslint react/no-typos: 0 */Chargeoff.propTypes={app:__WEBPACK_IMPORTED_MODULE_2__constants_prop_types_application_prop_types__["a" /* ApplicationPropType */].isRequired};/* harmony default export */ __webpack_exports__["a"] = (Chargeoff);

/***/ }),
/* 1298 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__(0);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_scuid_x__ = __webpack_require__(14);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_scuid_x___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_scuid_x__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_prop_types__ = __webpack_require__(1);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_prop_types___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_prop_types__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_styled_components__ = __webpack_require__(3);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__constants_prop_types_application_prop_types__ = __webpack_require__(1168);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__button_dropdown__ = __webpack_require__(1207);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__utilities_currency_format_helpers__ = __webpack_require__(1176);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__shared_styles__ = __webpack_require__(1173);
var _templateObject=_taggedTemplateLiteral(['\n  margin-top: 0.5rem;\n  display: block;\n  div {\n    display: inline-flex;\n    margin-right: 2px;\n    margin-bottom: 2px;\n  }\n'],['\n  margin-top: 0.5rem;\n  display: block;\n  div {\n    display: inline-flex;\n    margin-right: 2px;\n    margin-bottom: 2px;\n  }\n']);function _taggedTemplateLiteral(strings,raw){return Object.freeze(Object.defineProperties(strings,{raw:{value:Object.freeze(raw)}}));}/**
 * PropTypes imports
 *//**
 * Component imports
 *//**
 * Utilities/function imports
 *//**
 * Styled Components
 */var RepaymentAction=Object(__WEBPACK_IMPORTED_MODULE_3_styled_components__["default"])(__WEBPACK_IMPORTED_MODULE_7__shared_styles__["c" /* LoanAction */])(_templateObject);var Repayment=function Repayment(_ref){var app=_ref.app,index=_ref.index,toggleDropdown=_ref.toggleDropdown,isOpen=_ref.isOpen;return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_0_react__["Fragment"],null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_1_scuid_x__["SubheadFour"],null,app.productDesc,' (#',app.servicing.accountId,'), ',__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('span',null,app.servicing.status)),__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_7__shared_styles__["i" /* LoanDescription */],null,app.servicing.statusDesc),__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_7__shared_styles__["f" /* LoanBody */],null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_7__shared_styles__["j" /* LoanSummary */],null,app.servicing.status!=='Paid in Full'&&__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_0_react__["Fragment"],null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_7__shared_styles__["e" /* LoanAmount */],{'data-qa':'loan-amount-due-'+app.type},Object(__WEBPACK_IMPORTED_MODULE_6__utilities_currency_format_helpers__["a" /* FORMAT_CURRENCY */])(app.servicing.paymentAmount),__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('span',null,'Amount due')),__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_7__shared_styles__["d" /* LoanAdditionalInfo */],null,app.servicing.status!=='Paid in Full'&&__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_0_react__["Fragment"],null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('div',{'data-qa':'loan-next-payment-'+app.type},app.servicing.nextPayment,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('span',null,'Next Payment')),__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('div',{'data-qa':'loan-remaining-balance-'+app.type},Object(__WEBPACK_IMPORTED_MODULE_6__utilities_currency_format_helpers__["a" /* FORMAT_CURRENCY */])(app.servicing.balance),__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('span',null,'Remaining balance')))))),__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(RepaymentAction,null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('div',null,app.docs&&app.docs.length>0&&__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_7__shared_styles__["b" /* DropdownContainer */],{'data-qa':'accounts-repayment-dropdown-container'},__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_7__shared_styles__["h" /* LoanButton */],{small:true,secondary:true,onClick:function onClick(){toggleDropdown(index);},'data-qa':'accounts-repaymentDropdown'},'View details ',isOpen?__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_1_scuid_x__["Icon"],{size:14,iconType:__WEBPACK_IMPORTED_MODULE_1_scuid_x__["IconType"].CaretUp}):__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_1_scuid_x__["Icon"],{size:14,iconType:__WEBPACK_IMPORTED_MODULE_1_scuid_x__["IconType"].CaretDown})),isOpen&&__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_5__button_dropdown__["a" /* default */],{'data-qa':'accounts-repayment-button-dropdown',app:app}))),__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('a',{'data-qa':'accounts-repaymentViewAccount',href:app.servicing.servicingUrl+'/#/'+app.servicing.loanId},__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_7__shared_styles__["h" /* LoanButton */],{'data-qa':'accounts-repaymentViewAccount-button',small:true},'View Account')))));};/* eslint react/no-typos: 0 */Repayment.propTypes={app:__WEBPACK_IMPORTED_MODULE_4__constants_prop_types_application_prop_types__["a" /* ApplicationPropType */].isRequired,toggleDropdown:__WEBPACK_IMPORTED_MODULE_2_prop_types___default.a.func.isRequired,isOpen:__WEBPACK_IMPORTED_MODULE_2_prop_types___default.a.bool.isRequired,index:__WEBPACK_IMPORTED_MODULE_2_prop_types___default.a.number.isRequired};Repayment.defaultProps={};/* harmony default export */ __webpack_exports__["a"] = (Repayment);

/***/ }),
/* 1299 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__(0);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_scuid_x__ = __webpack_require__(14);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_scuid_x___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_scuid_x__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_react_redux_i18n__ = __webpack_require__(70);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_react_redux_i18n___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_react_redux_i18n__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_prop_types__ = __webpack_require__(1);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_prop_types___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_3_prop_types__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__constants_prop_types_application_prop_types__ = __webpack_require__(1168);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__button_dropdown__ = __webpack_require__(1207);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__utilities__ = __webpack_require__(328);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__utilities_currency_format_helpers__ = __webpack_require__(1176);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8__shared_styles__ = __webpack_require__(1173);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_9__utilities_global_styles__ = __webpack_require__(80);
var _templateObject=_taggedTemplateLiteral(['\n  ',';\n'],['\n  ',';\n']),_templateObject2=_taggedTemplateLiteral(['\n  margin-left: 1px;\n  min-width: 0;\n  width: auto;\n  border-bottom-left-radius: 0;\n  border-top-left-radius: 0;\n  svg {\n    path {\n      fill: white !important;\n    }\n  }\n'],['\n  margin-left: 1px;\n  min-width: 0;\n  width: auto;\n  border-bottom-left-radius: 0;\n  border-top-left-radius: 0;\n  svg {\n    path {\n      fill: white !important;\n    }\n  }\n']);function _taggedTemplateLiteral(strings,raw){return Object.freeze(Object.defineProperties(strings,{raw:{value:Object.freeze(raw)}}));}/**
 * PropTypes imports
 *//**
 * Component imports
 *//**
 * Utilities/function imports
 *//**
 * Styled Components
 */var ServicingButton=__WEBPACK_IMPORTED_MODULE_8__shared_styles__["h" /* LoanButton */].extend(_templateObject,function(props){return props.flatSide&&'\n    border-bottom-right-radius: 0;\n    border-top-right-radius: 0;\n  ';});var ServicingDropdown=__WEBPACK_IMPORTED_MODULE_8__shared_styles__["h" /* LoanButton */].extend(_templateObject2);var NotInServicing=function NotInServicing(_ref){var app=_ref.app,index=_ref.index,toggleDropdown=_ref.toggleDropdown,isOpen=_ref.isOpen;return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_0_react__["Fragment"],null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_1_scuid_x__["SubheadFour"],null,app.productDesc,' (#',app.id,'),',app.type==='COSIGN'?' for '+app.primaryApplicantName:'',Object(__WEBPACK_IMPORTED_MODULE_6__utilities__["t" /* servicedPl */])(app)&&__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('span',null,' Transitioning to Servicing'),!Object(__WEBPACK_IMPORTED_MODULE_6__utilities__["t" /* servicedPl */])(app)&&__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('span',null,' ',__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_react_redux_i18n__["Translate"],{value:app.status}))),__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_8__shared_styles__["i" /* LoanDescription */],null,Object(__WEBPACK_IMPORTED_MODULE_6__utilities__["s" /* needsSigned */])(app)&&!app.rateLockDate&&__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_8__shared_styles__["a" /* Attention */],{'data-qa':'accounts-notInServicing-alert'},app.statusDesc),Object(__WEBPACK_IMPORTED_MODULE_6__utilities__["s" /* needsSigned */])(app)&&app.rateLockDate&&app.type==='COSIGN'&&__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_8__shared_styles__["a" /* Attention */],{'data-qa':'accounts-notInServicing-new-rate-expire'},app.statusDesc,' Your new rate will expire on ',app.rateLockDate,'.',' '),Object(__WEBPACK_IMPORTED_MODULE_6__utilities__["s" /* needsSigned */])(app)&&app.rateLockDate&&app.type!=='COSIGN'&&__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_8__shared_styles__["a" /* Attention */],{'data-qa':'accounts-notInServicing-selected-rate-expire'},app.statusDesc,' Your selected rate will expire on ',app.rateLockDate,'.',' '),!Object(__WEBPACK_IMPORTED_MODULE_6__utilities__["s" /* needsSigned */])(app)&&!Object(__WEBPACK_IMPORTED_MODULE_6__utilities__["t" /* servicedPl */])(app)&&__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('span',null,app.statusDesc+(app.rateLockDate&&Object(__WEBPACK_IMPORTED_MODULE_6__utilities__["o" /* isProductSelect */])(app)?' Your rates will expire on '+app.rateLockDate+'. ':' ')),!Object(__WEBPACK_IMPORTED_MODULE_6__utilities__["s" /* needsSigned */])(app)&&Object(__WEBPACK_IMPORTED_MODULE_6__utilities__["t" /* servicedPl */])(app)&&__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('span',null,' Transitioning to Servicing'),Object(__WEBPACK_IMPORTED_MODULE_6__utilities__["v" /* showWelcomeBonus */])(app)&&app.welcomeBonusUrl&&__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('span',null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_9__utilities_global_styles__["d" /* ScuidLink */],{'data-qa':'accounts-not-servicing-enter-bank-info-link',href:app.welcomeBonusUrl},' ','Enter bank information'),' ','for Welcome Bonus of $',app.welcomeBonusAmount),Object(__WEBPACK_IMPORTED_MODULE_6__utilities__["v" /* showWelcomeBonus */])(app)&&!app.welcomeBonusUrl&&app.welcomeBonusStatus==='Pending'&&Object(__WEBPACK_IMPORTED_MODULE_6__utilities__["n" /* isProcessingWelcomeBonus */])(app)&&__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('span',null,' Welcome Bonus of $',app.welcomeBonusAmount,' is processing. Please allow up to a few weeks for completion.'),Object(__WEBPACK_IMPORTED_MODULE_6__utilities__["v" /* showWelcomeBonus */])(app)&&!app.welcomeBonusUrl&&app.welcomeBonusStatus==='Pending'&&!Object(__WEBPACK_IMPORTED_MODULE_6__utilities__["n" /* isProcessingWelcomeBonus */])(app)&&__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('span',null,' Welcome Bonus of $',app.welcomeBonusAmount,' is pending loan completion.'),Object(__WEBPACK_IMPORTED_MODULE_6__utilities__["v" /* showWelcomeBonus */])(app)&&!app.welcomeBonusUrl&&app.welcomeBonusStatus==='W-9'&&__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('span',null,' Welcome Bonus of $',app.welcomeBonusAmount,' is processing. Please allow up to a few weeks for completion.'),Object(__WEBPACK_IMPORTED_MODULE_6__utilities__["v" /* showWelcomeBonus */])(app)&&!app.welcomeBonusUrl&&app.welcomeBonusStatus!=='Pending'&&app.welcomeBonusStatus!=='W-9'&&__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('span',null,' ','Welcome Bonus of $',app.welcomeBonusAmount,' is ',app.welcomeBonusStatus)),__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_8__shared_styles__["f" /* LoanBody */],null,!!app.amount&&__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_8__shared_styles__["j" /* LoanSummary */],null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_8__shared_styles__["e" /* LoanAmount */],{'data-qa':'loan-amount-'+app.type},Object(__WEBPACK_IMPORTED_MODULE_7__utilities_currency_format_helpers__["a" /* FORMAT_CURRENCY */])(app.amount),' ',__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('span',null,Object(__WEBPACK_IMPORTED_MODULE_6__utilities__["r" /* loanAmountTitle */])(app)))),__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_8__shared_styles__["c" /* LoanAction */],null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('div',null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('a',{'data-qa':'accounts-notInServicingContinue',href:app.continueUrl},__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(ServicingButton,{'data-qa':'accounts-notInServicingContinue-button',flatSide:app.docs&&app.docs.length>0,small:true},Object(__WEBPACK_IMPORTED_MODULE_6__utilities__["e" /* generateContinueText */])(app))),app.docs&&app.docs.length>0&&__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_0_react__["Fragment"],null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(ServicingDropdown,{small:true,onClick:function onClick(){toggleDropdown(index);},'data-qa':'accounts-notInServicingDropdown'},isOpen?__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_1_scuid_x__["Icon"],{size:14,iconType:__WEBPACK_IMPORTED_MODULE_1_scuid_x__["IconType"].CaretUp}):__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_1_scuid_x__["Icon"],{size:14,iconType:__WEBPACK_IMPORTED_MODULE_1_scuid_x__["IconType"].CaretDown})),__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_8__shared_styles__["b" /* DropdownContainer */],{'data-qa':'accounts-notInServicingContinue-dropdown-container'},isOpen&&__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_5__button_dropdown__["a" /* default */],{'data-qa':'accounts-notInServicingContinue-button-dropdown',app:app})))))));};/* eslint react/no-typos: 0 */NotInServicing.propTypes={app:__WEBPACK_IMPORTED_MODULE_4__constants_prop_types_application_prop_types__["a" /* ApplicationPropType */].isRequired,toggleDropdown:__WEBPACK_IMPORTED_MODULE_3_prop_types___default.a.func.isRequired,isOpen:__WEBPACK_IMPORTED_MODULE_3_prop_types___default.a.bool.isRequired,index:__WEBPACK_IMPORTED_MODULE_3_prop_types___default.a.number.isRequired};NotInServicing.defaultProps={};/* harmony default export */ __webpack_exports__["a"] = (NotInServicing);

/***/ }),
/* 1300 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__(0);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_prop_types__ = __webpack_require__(1);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_prop_types___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_prop_types__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_scuid_x__ = __webpack_require__(14);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_scuid_x___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_scuid_x__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_react_redux_i18n__ = __webpack_require__(70);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_react_redux_i18n___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_3_react_redux_i18n__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__constants_prop_types_application_prop_types__ = __webpack_require__(1168);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__utilities__ = __webpack_require__(328);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__utilities_currency_format_helpers__ = __webpack_require__(1176);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__mohela_modal__ = __webpack_require__(1301);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8__button_dropdown__ = __webpack_require__(1207);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_9__shared_styles__ = __webpack_require__(1173);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_10__utilities_global_styles__ = __webpack_require__(80);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_11__constants_referral_constants__ = __webpack_require__(315);
var _createClass=function(){function defineProperties(target,props){for(var i=0;i<props.length;i++){var descriptor=props[i];descriptor.enumerable=descriptor.enumerable||false;descriptor.configurable=true;if("value"in descriptor)descriptor.writable=true;Object.defineProperty(target,descriptor.key,descriptor);}}return function(Constructor,protoProps,staticProps){if(protoProps)defineProperties(Constructor.prototype,protoProps);if(staticProps)defineProperties(Constructor,staticProps);return Constructor;};}();function _classCallCheck(instance,Constructor){if(!(instance instanceof Constructor)){throw new TypeError("Cannot call a class as a function");}}function _possibleConstructorReturn(self,call){if(!self){throw new ReferenceError("this hasn't been initialised - super() hasn't been called");}return call&&(typeof call==="object"||typeof call==="function")?call:self;}function _inherits(subClass,superClass){if(typeof superClass!=="function"&&superClass!==null){throw new TypeError("Super expression must either be null or a function, not "+typeof superClass);}subClass.prototype=Object.create(superClass&&superClass.prototype,{constructor:{value:subClass,enumerable:false,writable:true,configurable:true}});if(superClass)Object.setPrototypeOf?Object.setPrototypeOf(subClass,superClass):subClass.__proto__=superClass;}/**
 * PropTypes imports
 *//**
 * Utilities/function imports
 *//**
 * Component imports
 *//**
 * Styled Components
 */var CannotContinue=function(_Component){_inherits(CannotContinue,_Component);function CannotContinue(){var _ref;var _temp,_this,_ret;_classCallCheck(this,CannotContinue);for(var _len=arguments.length,args=Array(_len),_key=0;_key<_len;_key++){args[_key]=arguments[_key];}return _ret=(_temp=(_this=_possibleConstructorReturn(this,(_ref=CannotContinue.__proto__||Object.getPrototypeOf(CannotContinue)).call.apply(_ref,[this].concat(args))),_this),_this.state={openMohela:false},_this.toggleOpen=function(){_this.setState({openMohela:!_this.state.openMohela});},_temp),_possibleConstructorReturn(_this,_ret);}_createClass(CannotContinue,[{key:'render',value:function render(){var _props=this.props,app=_props.app,index=_props.index,toggleDropdown=_props.toggleDropdown,isOpen=_props.isOpen;var openMohela=this.state.openMohela;return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_0_react__["Fragment"],null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["SubheadFour"],null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('span',null,app.productDesc,' (#',app.id,'),',app.type==='COSIGN'?' for '+app.primaryApplicantName:''),Object(__WEBPACK_IMPORTED_MODULE_5__utilities__["t" /* servicedPl */])(app)&&__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('span',null,' Transitioning to Servicing'),!Object(__WEBPACK_IMPORTED_MODULE_5__utilities__["t" /* servicedPl */])(app)&&__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('span',null,' ',__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_3_react_redux_i18n__["Translate"],{value:app.status}))),__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_9__shared_styles__["i" /* LoanDescription */],null,['REFI','PARENT','PLUS','MEDREFI','DENTREFI'].includes(app.type)&&app.status==='ServicerFunded'&&__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('span',null,'Make payments and see account details with our third party servicing partner, MOHELA.'),Object(__WEBPACK_IMPORTED_MODULE_5__utilities__["s" /* needsSigned */])(app)&&!app.rateLockDate&&__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_9__shared_styles__["a" /* Attention */],{'data-qa':'accounts-cannotContinue-alert'},app.statusDesc),Object(__WEBPACK_IMPORTED_MODULE_5__utilities__["s" /* needsSigned */])(app)&&!!app.rateLockDate&&app.type==='COSIGN'&&__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_9__shared_styles__["a" /* Attention */],{'data-qa':'accounts-cannotContinue-new-rate-expire'},app.statusDesc,' Your new rate will expire on ',app.rateLockDate,'.',' '),Object(__WEBPACK_IMPORTED_MODULE_5__utilities__["s" /* needsSigned */])(app)&&!!app.rateLockDate&&app.type!=='COSIGN'&&__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_9__shared_styles__["a" /* Attention */],{'data-qa':'accounts-cannotContinue-selected-rate-expire'},app.statusDesc,' Your selected rate will expire on ',app.rateLockDate,'.'),!Object(__WEBPACK_IMPORTED_MODULE_5__utilities__["s" /* needsSigned */])(app)&&!Object(__WEBPACK_IMPORTED_MODULE_5__utilities__["t" /* servicedPl */])(app)&&!(app.status==='AdverseAction'&&!Object(__WEBPACK_IMPORTED_MODULE_5__utilities__["d" /* findDocument */])(app,'Adverse Action'))&&__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('span',null,app.statusDesc),app.status==='AdverseAction'&&!Object(__WEBPACK_IMPORTED_MODULE_5__utilities__["d" /* findDocument */])(app,'Adverse Action')&&__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('span',null,app.statusDesc,' We are currently collecting the details for the decline - please wait a couple of seconds and refresh the page.'),!Object(__WEBPACK_IMPORTED_MODULE_5__utilities__["s" /* needsSigned */])(app)&&Object(__WEBPACK_IMPORTED_MODULE_5__utilities__["t" /* servicedPl */])(app)&&__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('span',null,' Transitioning to Servicing'),Object(__WEBPACK_IMPORTED_MODULE_5__utilities__["m" /* isMortCENLAR */])(app)&&!Object(__WEBPACK_IMPORTED_MODULE_5__utilities__["g" /* hasMortServicingAccess */])(app)&&app.servicing.statusDesc==='OTHER'&&__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('span',null,' Your loan is no longer held by SoFi'),Object(__WEBPACK_IMPORTED_MODULE_5__utilities__["m" /* isMortCENLAR */])(app)&&!Object(__WEBPACK_IMPORTED_MODULE_5__utilities__["g" /* hasMortServicingAccess */])(app)&&app.servicing.statusDesc!=='OTHER'&&__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('span',null,'Your Servicer online portal is loading and may take up to 30 seconds to appear. Please contact',' ',__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('a',{'data-qa':'accounts-mort-phone-link',href:'tel:+'+__WEBPACK_IMPORTED_MODULE_3_react_redux_i18n__["I18n"].t('mortgagePhoneUnformat')},__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_3_react_redux_i18n__["Translate"],{value:'mortgagePhoneReg'})),' ','for further assistance if it still has not appeared after that time.'),Object(__WEBPACK_IMPORTED_MODULE_5__utilities__["v" /* showWelcomeBonus */])(app)&&!!app.welcomeBonusUrl&&__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('span',null,' ',__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_10__utilities_global_styles__["c" /* RouterLink */],{'data-qa':'accounts-enterBankInfo',to:__WEBPACK_IMPORTED_MODULE_11__constants_referral_constants__["c" /* AFFILIATE_REGISTER_URL */]},'Enter bank information'),' ','for Welcome Bonus of $',app.welcomeBonusAmount),Object(__WEBPACK_IMPORTED_MODULE_5__utilities__["v" /* showWelcomeBonus */])(app)&&!app.welcomeBonusUrl&&app.welcomeBonusStatus==='Pending'&&Object(__WEBPACK_IMPORTED_MODULE_5__utilities__["n" /* isProcessingWelcomeBonus */])(app)&&__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('span',null,' Welcome Bonus of $',app.welcomeBonusAmount,' is processing. Please allow up to a few weeks for completion.'),Object(__WEBPACK_IMPORTED_MODULE_5__utilities__["v" /* showWelcomeBonus */])(app)&&!app.welcomeBonusUrl&&app.welcomeBonusStatus==='Pending'&&!Object(__WEBPACK_IMPORTED_MODULE_5__utilities__["n" /* isProcessingWelcomeBonus */])(app)&&__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('span',null,' Welcome Bonus of $',app.welcomeBonusAmount,' is pending loan completion.'),Object(__WEBPACK_IMPORTED_MODULE_5__utilities__["v" /* showWelcomeBonus */])(app)&&!app.welcomeBonusUrl&&app.welcomeBonusStatus==='W-9'&&__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('span',null,' Welcome Bonus of $',app.welcomeBonusAmount,' is processing. Please allow up to a few weeks for completion.'),Object(__WEBPACK_IMPORTED_MODULE_5__utilities__["v" /* showWelcomeBonus */])(app)&&!app.welcomeBonusUrl&&app.welcomeBonusStatus!=='Pending'&&app.welcomeBonusStatus!=='W-9'&&__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('span',null,' ','Welcome Bonus of $',app.welcomeBonusAmount,' is ',app.welcomeBonusStatus)),__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_9__shared_styles__["f" /* LoanBody */],null,!!app.amount&&__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_9__shared_styles__["j" /* LoanSummary */],null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_9__shared_styles__["e" /* LoanAmount */],{'data-qa':'loan-amount-'+app.type},Object(__WEBPACK_IMPORTED_MODULE_6__utilities_currency_format_helpers__["a" /* FORMAT_CURRENCY */])(app.amount),' ',__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('span',null,Object(__WEBPACK_IMPORTED_MODULE_5__utilities__["r" /* loanAmountTitle */])(app)))),__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_9__shared_styles__["c" /* LoanAction */],null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('div',null,['REFI','PARENT','PLUS','MEDREFI','DENTREFI'].includes(app.type)&&app.status==='ServicerFunded'&&__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_9__shared_styles__["h" /* LoanButton */],{'data-qa':'accounts-clickMohelaPopup',small:true,onClick:this.toggleOpen},'Manage account'),__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_7__mohela_modal__["a" /* default */],{open:openMohela,toggleOpen:this.toggleOpen}),Object(__WEBPACK_IMPORTED_MODULE_5__utilities__["m" /* isMortCENLAR */])(app)&&Object(__WEBPACK_IMPORTED_MODULE_5__utilities__["g" /* hasMortServicingAccess */])(app)&&__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('a',{target:'_blank',href:Object(__WEBPACK_IMPORTED_MODULE_5__utilities__["g" /* hasMortServicingAccess */])(app),'data-qa':'accounts-mortgageCenlar','data-mjs':'dashboard-mort-cenlar'},__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_9__shared_styles__["h" /* LoanButton */],{'data-qa':'accounts-cannot-continue-loan-details',small:true},'Loan details')),app.docs&&app.docs.length>0&&__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_9__shared_styles__["b" /* DropdownContainer */],{'data-qa':'accounts-cenlar-dropdown-container'},['REFI','PARENT','PLUS','MEDREFI','DENTREFI'].includes(app.type)&&app.status==='ServicerFunded'||Object(__WEBPACK_IMPORTED_MODULE_5__utilities__["m" /* isMortCENLAR */])(app)&&Object(__WEBPACK_IMPORTED_MODULE_5__utilities__["g" /* hasMortServicingAccess */])(app)?''// do nothing
:__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_9__shared_styles__["h" /* LoanButton */],{small:true,secondary:true,onClick:function onClick(){toggleDropdown(index);},'data-qa':'accounts-cenlarDropdown'},'View details',' ',isOpen?__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["Icon"],{size:14,blueIcon:true,iconType:__WEBPACK_IMPORTED_MODULE_2_scuid_x__["IconType"].CaretUp}):__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["Icon"],{size:14,blueIcon:true,iconType:__WEBPACK_IMPORTED_MODULE_2_scuid_x__["IconType"].CaretDown})),isOpen&&__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_8__button_dropdown__["a" /* default */],{'data-qa':'accounts-cenlar-button-dropdown',app:app}))))));}}]);return CannotContinue;}(__WEBPACK_IMPORTED_MODULE_0_react__["Component"]);CannotContinue.propTypes={index:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.number.isRequired,app:__WEBPACK_IMPORTED_MODULE_4__constants_prop_types_application_prop_types__["a" /* ApplicationPropType */].isRequired,toggleDropdown:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.func.isRequired,isOpen:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.bool.isRequired};/* harmony default export */ __webpack_exports__["a"] = (CannotContinue);

/***/ }),
/* 1301 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__(0);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_prop_types__ = __webpack_require__(1);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_prop_types___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_prop_types__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_scuid_x__ = __webpack_require__(14);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_scuid_x___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_scuid_x__);
var redirect=function redirect(toggleOpen){var mohela=window.open('https://sofi.mohela.com/');mohela.opener=null;// prevent phishing attempts
toggleOpen();};var MohelaModal=function MohelaModal(_ref){var open=_ref.open,toggleOpen=_ref.toggleOpen;return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["Modal"],{isOpen:open,onDismiss:toggleOpen,title:'You are about to leave SoFi',minWidth:window.innerWidth>=768?650:0},__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["Modal"].Body,null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["Paragraph"],null,'To manage your Student Loan ReFi, we\'re directing you to MOHELA, SoFi\'s third-party loan servicer for student loans.'),__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["Paragraph"],null,'Make payments and get account details at',' ',__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["HyperLink"],{'data-qa':'mohela-goToMohela',href:'https://sofi.mohela.com/',target:'_blank',rel:'noopener noreferrer'},'sofi.mohela.com'),' ','or by calling ',__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["HyperLink"],{'data-qa':'mohela-telephone-number',href:'tel:8772927470'},'(877) 292-7470'),'. While your loan will be serviced by MOHELA, you will still be a SoFi member and be able to take advantage of our unique member benefits.')),__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["Modal"].Footer,null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["Button"],{'data-qa':'mohela-backToSoFi','data-mjs':'dashboard-slr-popup-close',small:true,secondary:true,onClick:function onClick(){toggleOpen();}},'Back to SoFi'),__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["Button"],{'data-qa':'mohela-continueToMohela','data-mjs':'dashboard-slr-popup-continue',small:true,onClick:function onClick(){redirect(toggleOpen);}},'Continue to MOHELA')));};MohelaModal.propTypes={open:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.bool.isRequired,toggleOpen:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.func.isRequired};/* harmony default export */ __webpack_exports__["a"] = (MohelaModal);

/***/ }),
/* 1302 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__(0);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_prop_types__ = __webpack_require__(1);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_prop_types___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_prop_types__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_scuid_x__ = __webpack_require__(14);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_scuid_x___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_scuid_x__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__utilities_currency_format_helpers__ = __webpack_require__(1176);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__shared_styles__ = __webpack_require__(1173);
/**
 * Utilities/functions imports
 *//**
 * Styled Components
 */var Ecp=function Ecp(_ref){var ecp=_ref.ecp;return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_0_react__["Fragment"],null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["SubheadFour"],null,ecp.servicing.servicerPlan,' ',ecp.servicing.servicerName),__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_4__shared_styles__["i" /* LoanDescription */],null,ecp.servicing.statusDesc),__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_4__shared_styles__["f" /* LoanBody */],null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_4__shared_styles__["j" /* LoanSummary */],null,!!ecp.servicing.monthlyContrib&&__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_4__shared_styles__["e" /* LoanAmount */],null,Object(__WEBPACK_IMPORTED_MODULE_3__utilities_currency_format_helpers__["a" /* FORMAT_CURRENCY */])(ecp.servicing.monthlyContrib),__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('span',null,'Monthly contribution')),!!ecp.servicing.yearlyContrib&&__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_4__shared_styles__["e" /* LoanAmount */],null,Object(__WEBPACK_IMPORTED_MODULE_3__utilities_currency_format_helpers__["a" /* FORMAT_CURRENCY */])(ecp.servicing.yearlyContrib),__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('span',null,'Yearly contribution')),!ecp.servicing.monthlyContrib&&!ecp.servicing.yearlyContrib&&__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_4__shared_styles__["e" /* LoanAmount */],null,ecp.servicing.status,'...')),!!ecp.servicing.servicingUrl&&__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_4__shared_styles__["c" /* LoanAction */],null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('a',{'data-qa':'accounts-ecpContinue',href:ecp.servicing.servicingUrl},__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_4__shared_styles__["h" /* LoanButton */],{'data-qa':'accounts-ecpContinue-button',small:true},'Continue'))),!ecp.servicing.servicingUrl&&ecp.servicing.contribDetailsUrl&&__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_4__shared_styles__["c" /* LoanAction */],null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('a',{'data-qa':'accounts-ecpViewDetails',href:ecp.servicing.contribDetailsUrl},__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_4__shared_styles__["h" /* LoanButton */],{'data-qa':'accounts-ecpViewDetails-button',small:true},'View Details')))));};Ecp.propTypes={ecp:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.object.isRequired// eslint-disable-line
};/* harmony default export */ __webpack_exports__["a"] = (Ecp);

/***/ }),
/* 1303 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__(0);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_prop_types__ = __webpack_require__(1);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_prop_types___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_prop_types__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_react_router_dom__ = __webpack_require__(188);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_styled_components__ = __webpack_require__(3);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_copy_to_clipboard__ = __webpack_require__(1208);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_copy_to_clipboard___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_4_copy_to_clipboard__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__constants_prop_types_customer_prop_types__ = __webpack_require__(124);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__constants_prop_types_referral_prop_types__ = __webpack_require__(1082);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__affiliate_modal__ = __webpack_require__(1304);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8__assets_img_share_svg__ = __webpack_require__(1309);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8__assets_img_share_svg___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_8__assets_img_share_svg__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_9__utilities__ = __webpack_require__(1198);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_10__utilities__ = __webpack_require__(328);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_11__constants_referral_constants__ = __webpack_require__(315);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_12__utilities_currency_format_helpers__ = __webpack_require__(1176);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_13__shared_styles__ = __webpack_require__(1173);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_14__utilities_global_styles__ = __webpack_require__(80);
var _createClass=function(){function defineProperties(target,props){for(var i=0;i<props.length;i++){var descriptor=props[i];descriptor.enumerable=descriptor.enumerable||false;descriptor.configurable=true;if("value"in descriptor)descriptor.writable=true;Object.defineProperty(target,descriptor.key,descriptor);}}return function(Constructor,protoProps,staticProps){if(protoProps)defineProperties(Constructor.prototype,protoProps);if(staticProps)defineProperties(Constructor,staticProps);return Constructor;};}();var _templateObject=_taggedTemplateLiteral(['\n  padding-bottom: 1.5rem;\n\n  @media (min-width: 768px) {\n    padding-bottom: 2rem;\n  }\n'],['\n  padding-bottom: 1.5rem;\n\n  @media (min-width: 768px) {\n    padding-bottom: 2rem;\n  }\n']),_templateObject2=_taggedTemplateLiteral(['\n  color: #117db0;\n  font-weight: 500;\n'],['\n  color: #117db0;\n  font-weight: 500;\n']),_templateObject3=_taggedTemplateLiteral(['\n  text-align: center;\n  text-decoration: none;\n  margin-top: 0.5rem;\n\n  @media (max-width: 767px) {\n    margin-top: 0;\n    margin-left: 1rem;\n  }\n'],['\n  text-align: center;\n  text-decoration: none;\n  margin-top: 0.5rem;\n\n  @media (max-width: 767px) {\n    margin-top: 0;\n    margin-left: 1rem;\n  }\n']),_templateObject4=_taggedTemplateLiteral(['\n  margin-left: 5px;\n  margin-bottom: -3px;\n'],['\n  margin-left: 5px;\n  margin-bottom: -3px;\n']),_templateObject5=_taggedTemplateLiteral(['\n  display: flex;\n  flex-direction: column;\n  font-size: 1.6rem;\n  font-weight: 500;\n  span {\n    font-size: initial;\n    font-weight: 400;\n  }\n'],['\n  display: flex;\n  flex-direction: column;\n  font-size: 1.6rem;\n  font-weight: 500;\n  span {\n    font-size: initial;\n    font-weight: 400;\n  }\n']),_templateObject6=_taggedTemplateLiteral(['\n  flex-direction: row;\n  align-items: flex-end;\n  justify-content: space-between;\n'],['\n  flex-direction: row;\n  align-items: flex-end;\n  justify-content: space-between;\n']);function _classCallCheck(instance,Constructor){if(!(instance instanceof Constructor)){throw new TypeError("Cannot call a class as a function");}}function _possibleConstructorReturn(self,call){if(!self){throw new ReferenceError("this hasn't been initialised - super() hasn't been called");}return call&&(typeof call==="object"||typeof call==="function")?call:self;}function _inherits(subClass,superClass){if(typeof superClass!=="function"&&superClass!==null){throw new TypeError("Super expression must either be null or a function, not "+typeof superClass);}subClass.prototype=Object.create(superClass&&superClass.prototype,{constructor:{value:subClass,enumerable:false,writable:true,configurable:true}});if(superClass)Object.setPrototypeOf?Object.setPrototypeOf(subClass,superClass):subClass.__proto__=superClass;}function _taggedTemplateLiteral(strings,raw){return Object.freeze(Object.defineProperties(strings,{raw:{value:Object.freeze(raw)}}));}/**
 * PropTypes imports
 *//**
 * Component imports
 *//**
 * Image imports
 *//**
 * Utilities/function imports
 *//**
 * Styled Components
 */var Container=__WEBPACK_IMPORTED_MODULE_3_styled_components__["default"].div(_templateObject);var ReferSpan=__WEBPACK_IMPORTED_MODULE_3_styled_components__["default"].span(_templateObject2);var RLink=__WEBPACK_IMPORTED_MODULE_14__utilities_global_styles__["c" /* RouterLink */].extend(_templateObject3);var ShareIcon=__WEBPACK_IMPORTED_MODULE_3_styled_components__["default"].img(_templateObject4);var ShareSoFi=__WEBPACK_IMPORTED_MODULE_3_styled_components__["default"].div(_templateObject5);var ReferSummary=Object(__WEBPACK_IMPORTED_MODULE_3_styled_components__["default"])(__WEBPACK_IMPORTED_MODULE_13__shared_styles__["j" /* LoanSummary */])(_templateObject6);var touAutoConsentMinVersion=3;var autoEnroll=function autoEnroll(postReferralConsent){var consentObj={referralConsent:true};postReferralConsent(consentObj);};var Affiliate=function(_Component){_inherits(Affiliate,_Component);function Affiliate(){var _ref;var _temp,_this,_ret;_classCallCheck(this,Affiliate);for(var _len=arguments.length,args=Array(_len),_key=0;_key<_len;_key++){args[_key]=arguments[_key];}return _ret=(_temp=(_this=_possibleConstructorReturn(this,(_ref=Affiliate.__proto__||Object.getPrototypeOf(Affiliate)).call.apply(_ref,[this].concat(args))),_this),_this.state={open:false,copy:false},_this.toggleOpen=function(){_this.setState({open:!_this.state.open,copy:false});},_this.toggleCopy=function(url){__WEBPACK_IMPORTED_MODULE_4_copy_to_clipboard___default()(Object(__WEBPACK_IMPORTED_MODULE_9__utilities__["d" /* formatUrl */])(url));if(!_this.state.copy){_this.setState({copy:true});}},_temp),_possibleConstructorReturn(_this,_ret);}_createClass(Affiliate,[{key:'componentDidMount',value:function componentDidMount(){var _props=this.props,consentsTou=_props.consentsTou,referralConsents=_props.referralConsents,postReferralConsent=_props.postReferralConsent;var displayCampaigns=referralConsents.referralConsent||false;if(consentsTou>=touAutoConsentMinVersion&&!displayCampaigns){autoEnroll(postReferralConsent);}}},{key:'render',value:function render(){var _this2=this;var _props2=this.props,consentsTou=_props2.consentsTou,customer=_props2.customer,referralSummary=_props2.referralSummary,referralConsents=_props2.referralConsents;var _state=this.state,open=_state.open,copy=_state.copy;var displayCampaigns=referralConsents.referralConsent||false;var isReferralConsented=consentsTou>=touAutoConsentMinVersion;var summary=Object(__WEBPACK_IMPORTED_MODULE_9__utilities__["c" /* findHighestCampaigns */])(referralSummary);return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(Container,null,displayCampaigns&&summary&&__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_0_react__["Fragment"],null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(ReferSpan,null,'Refer a Friend, Get $300.'),__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_13__shared_styles__["f" /* LoanBody */],null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(ReferSummary,null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_13__shared_styles__["e" /* LoanAmount */],{'data-qa':'dashboard-total-bonus-earned'},(summary.paid||Number.isInteger(summary.paid))&&Object(__WEBPACK_IMPORTED_MODULE_12__utilities_currency_format_helpers__["a" /* FORMAT_CURRENCY */])(summary.paid),__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('span',null,'Total bonuses earned')),__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_13__shared_styles__["d" /* LoanAdditionalInfo */],{'data-qa':'dashboard-pending-bonus-payments'},__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('div',null,(summary.pending||Number.isInteger(summary.pending))&&Object(__WEBPACK_IMPORTED_MODULE_12__utilities_currency_format_helpers__["a" /* FORMAT_CURRENCY */])(summary.pending),__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('span',null,'Pending bonus payments')))),__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_13__shared_styles__["c" /* LoanAction */],null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_13__shared_styles__["h" /* LoanButton */],{small:true,onClick:function onClick(){_this2.toggleOpen();},'data-qa':'affiliate-share','data-mjs':'dashboard-share-button'},'Share ',__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(ShareIcon,{src:__WEBPACK_IMPORTED_MODULE_8__assets_img_share_svg___default.a})),__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_7__affiliate_modal__["a" /* default */],{open:open,copy:copy,toggleOpen:this.toggleOpen,toggleCopy:this.toggleCopy,summary:summary}),__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(RLink,{to:__WEBPACK_IMPORTED_MODULE_11__constants_referral_constants__["b" /* AFFILIATE_OVERVIEW_URL */],'data-qa':'affiliate-viewDetails','data-mjs':'dashboard-share-view-details'},'View details')))),!isReferralConsented&&!displayCampaigns&&customer&&Object(__WEBPACK_IMPORTED_MODULE_10__utilities__["c" /* eligibleForReferralProgram */])(customer)&&__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_0_react__["Fragment"],null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(ReferSpan,null,'Referral Program'),__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_13__shared_styles__["f" /* LoanBody */],null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(ShareSoFi,null,'Share SoFi. Earn Money.',__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('span',null,'You\'ll get a $300 referral bonus and they\'ll get a $100.')),consentsTou<3&&__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_13__shared_styles__["c" /* LoanAction */],null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_react_router_dom__["b" /* Link */],{to:'/affiliate/consent','data-qa':'affiliate-enrollNow','data-mjs':'dashboard-refer-enroll-now'},__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_13__shared_styles__["h" /* LoanButton */],{'data-qa':'affiliate-enrollNow-button'},'Enroll now'))))));}}]);return Affiliate;}(__WEBPACK_IMPORTED_MODULE_0_react__["Component"]);Affiliate.propTypes={customer:__WEBPACK_IMPORTED_MODULE_5__constants_prop_types_customer_prop_types__["b" /* CustomerPropTypes */].isRequired,referralSummary:__WEBPACK_IMPORTED_MODULE_6__constants_prop_types_referral_prop_types__["g" /* ReferralSummaryPropTypes */].isRequired,consentsTou:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.number.isRequired,referralConsents:__WEBPACK_IMPORTED_MODULE_6__constants_prop_types_referral_prop_types__["a" /* ReferralConsentsPropTypes */].isRequired,postReferralConsent:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.func.isRequired};/* harmony default export */ __webpack_exports__["a"] = (Affiliate);

/***/ }),
/* 1304 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__(0);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_prop_types__ = __webpack_require__(1);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_prop_types___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_prop_types__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_scuid_x__ = __webpack_require__(14);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_scuid_x___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_scuid_x__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_styled_components__ = __webpack_require__(3);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__constants_prop_types_referral_prop_types__ = __webpack_require__(1082);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__assets_img_icons_icon_facebook_svg__ = __webpack_require__(1305);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__assets_img_icons_icon_facebook_svg___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_5__assets_img_icons_icon_facebook_svg__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__assets_img_icons_icon_twitter_svg__ = __webpack_require__(1306);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__assets_img_icons_icon_twitter_svg___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_6__assets_img_icons_icon_twitter_svg__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__assets_img_icons_icon_email_svg__ = __webpack_require__(1307);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__assets_img_icons_icon_email_svg___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_7__assets_img_icons_icon_email_svg__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8__assets_img_icons_icon_link_svg__ = __webpack_require__(1308);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8__assets_img_icons_icon_link_svg___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_8__assets_img_icons_icon_link_svg__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_9__utilities__ = __webpack_require__(1198);
var _templateObject=_taggedTemplateLiteral(['\n  color: #24bdf4;\n  display: flex;\n  flex-direction: row;\n  align-items: baseline;\n\n  @media (min-width: 768px) {\n    min-width: 650px;\n  }\n\n  @media (max-width: 450px) {\n    flex-direction: column;\n\n    div:last-child {\n      margin-top: 0.8rem;\n    }\n  }\n\n  span {\n    margin-right: 1.5rem;\n\n    @media (min-width: 768px) {\n      margin-right: 3rem;\n    }\n  }\n\n  a {\n    &:not(:last-child) {\n      margin-right: 1.5rem;\n    }\n  }\n\n  &:hover,\n  &:active {\n    text-decoration: none;\n  }\n'],['\n  color: #24bdf4;\n  display: flex;\n  flex-direction: row;\n  align-items: baseline;\n\n  @media (min-width: 768px) {\n    min-width: 650px;\n  }\n\n  @media (max-width: 450px) {\n    flex-direction: column;\n\n    div:last-child {\n      margin-top: 0.8rem;\n    }\n  }\n\n  span {\n    margin-right: 1.5rem;\n\n    @media (min-width: 768px) {\n      margin-right: 3rem;\n    }\n  }\n\n  a {\n    &:not(:last-child) {\n      margin-right: 1.5rem;\n    }\n  }\n\n  &:hover,\n  &:active {\n    text-decoration: none;\n  }\n']),_templateObject2=_taggedTemplateLiteral(['\n  padding: 15px;\n  margin-top: 0.8rem;\n'],['\n  padding: 15px;\n  margin-top: 0.8rem;\n']);function _taggedTemplateLiteral(strings,raw){return Object.freeze(Object.defineProperties(strings,{raw:{value:Object.freeze(raw)}}));}/**
 * PropTypes imports
 *//**
 * Image imports
 *//**
 * Utilities/function imports
 *//**
 * Styled Components
 */var ShareLink=__WEBPACK_IMPORTED_MODULE_3_styled_components__["default"].div(_templateObject);var CustomNotificationBar=Object(__WEBPACK_IMPORTED_MODULE_3_styled_components__["default"])(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["NotificationBar"])(_templateObject2);var ShareModal=function ShareModal(_ref){var open=_ref.open,copy=_ref.copy,toggleOpen=_ref.toggleOpen,toggleCopy=_ref.toggleCopy,summary=_ref.summary;return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["Modal"],{isOpen:open,onDismiss:toggleOpen,title:'Share your link with friends:'},__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["Modal"].Body,null,summary.unifiedUrl&&__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_0_react__["Fragment"],null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(ShareLink,null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('div',null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('span',null,Object(__WEBPACK_IMPORTED_MODULE_9__utilities__["d" /* formatUrl */])(summary.unifiedUrl))),__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('div',null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('a',{title:'Share referral on Facebook',href:Object(__WEBPACK_IMPORTED_MODULE_9__utilities__["b" /* facebookHref */])(summary.unifiedUrl),target:'_blank',rel:'noopener noreferrer','data-qa':'accounts-shareFacebook'},__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('img',{src:__WEBPACK_IMPORTED_MODULE_5__assets_img_icons_icon_facebook_svg___default.a,alt:'Facebook','data-mjs':'dashboard-share-popup-facebook'})),__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('a',{title:'Tweet this referral',href:Object(__WEBPACK_IMPORTED_MODULE_9__utilities__["e" /* twitterHref */])(summary.unifiedUrl,summary.referralProducts[0]),target:'_blank',rel:'noopener noreferrer','data-qa':'accounts-shareTwitter'},__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('img',{src:__WEBPACK_IMPORTED_MODULE_6__assets_img_icons_icon_twitter_svg___default.a,alt:'Tweet','data-mjs':'dashboard-share-popup-twitter'})),__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('a',{title:'Share referral through email',href:Object(__WEBPACK_IMPORTED_MODULE_9__utilities__["a" /* emailHref */])(summary.unifiedUrl,summary.referralProducts[0]),target:'_blank',rel:'noopener noreferrer','data-qa':'accounts-shareEmail'},__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('img',{src:__WEBPACK_IMPORTED_MODULE_7__assets_img_icons_icon_email_svg___default.a,alt:'Email','data-mjs':'dashboard-share-popup-email'})),__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["HyperLink"],{'data-qa':'accounts-affiliateCopy',onClick:function onClick(){toggleCopy(summary.unifiedUrl);}},__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('img',{src:__WEBPACK_IMPORTED_MODULE_8__assets_img_icons_icon_link_svg___default.a,alt:'Copy to Clipboard','data-mjs':'dashboard-share-popup-copy'})))),summary.unifiedUrl&&copy&&__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(CustomNotificationBar,null,'Your link has been copied to the clipboard.'))),__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["Modal"].Footer,null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["Button"],{'data-qa':'accounts-affiliate-done-button',small:true,onClick:toggleOpen},'Done')));};/* eslint react/no-typos: 0 */ShareModal.propTypes={open:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.bool.isRequired,copy:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.bool.isRequired,toggleOpen:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.func.isRequired,toggleCopy:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.func.isRequired,summary:__WEBPACK_IMPORTED_MODULE_4__constants_prop_types_referral_prop_types__["g" /* ReferralSummaryPropTypes */].isRequired};/* harmony default export */ __webpack_exports__["a"] = (ShareModal);

/***/ }),
/* 1305 */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/media/icon-facebook.c2d86c8b.svg";

/***/ }),
/* 1306 */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/media/icon-twitter.0e2a77f9.svg";

/***/ }),
/* 1307 */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/media/icon-email.b2c76f90.svg";

/***/ }),
/* 1308 */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/media/icon-link.ec99023d.svg";

/***/ }),
/* 1309 */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/media/share.fa7d2269.svg";

/***/ }),
/* 1310 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__wealth__ = __webpack_require__(1311);
/* harmony reexport (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return __WEBPACK_IMPORTED_MODULE_0__wealth__["a"]; });


/***/ }),
/* 1311 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__(0);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_scuid_x__ = __webpack_require__(14);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_scuid_x___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_scuid_x__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__constants_prop_types_wealth_prop_types__ = __webpack_require__(1223);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__utilities__ = __webpack_require__(1312);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__utilities_currency_format_helpers__ = __webpack_require__(1176);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__shared_styles__ = __webpack_require__(1173);
/**
 * PropTypes imports
 *//**
 * Utilities/function imports
 *//**
 * Styled Components
 *//**
 * Wealth component/card in Accounts
 */var Wealth=function Wealth(_ref){var wealthProfile=_ref.wealthProfile;var profileData=Object(__WEBPACK_IMPORTED_MODULE_3__utilities__["b" /* buildProfileData */])(wealthProfile);var profileHtml=Object(__WEBPACK_IMPORTED_MODULE_3__utilities__["a" /* buildFromCta */])(wealthProfile.ctaInfo);return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_0_react__["Fragment"],null,Object(__WEBPACK_IMPORTED_MODULE_3__utilities__["c" /* isAccountFunded */])(profileData)&&__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_0_react__["Fragment"],null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_1_scuid_x__["SubheadFour"],null,profileData.accountTypeDescription,' (#',profileData.account,')'),__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_5__shared_styles__["f" /* LoanBody */],null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_5__shared_styles__["j" /* LoanSummary */],null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_5__shared_styles__["e" /* LoanAmount */],null,Object(__WEBPACK_IMPORTED_MODULE_4__utilities_currency_format_helpers__["a" /* FORMAT_CURRENCY */])(profileData.currentBalance),__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('span',null,'Current value')),__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_5__shared_styles__["d" /* LoanAdditionalInfo */],null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('div',null,Object(__WEBPACK_IMPORTED_MODULE_4__utilities_currency_format_helpers__["a" /* FORMAT_CURRENCY */])(profileData.dayChange),__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('span',null,'Day change')))),__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_5__shared_styles__["c" /* LoanAction */],null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('a',{'data-qa':'accounts-wealthCtaLink',href:profileHtml.ctaLink?profileHtml.ctaLink:'/wealth/#/'},__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_5__shared_styles__["h" /* LoanButton */],{'data-qa':'accounts-wealthCtaLink-button',small:true},profileData.funded?'View Details':'Continue'))))),!Object(__WEBPACK_IMPORTED_MODULE_3__utilities__["c" /* isAccountFunded */])(profileData)&&__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_0_react__["Fragment"],null,Object(__WEBPACK_IMPORTED_MODULE_3__utilities__["d" /* isCompletedAccount */])(profileData)&&__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_1_scuid_x__["SubheadFour"],null,profileData.accountTypeDescription,' (#',profileData.account,')'),!Object(__WEBPACK_IMPORTED_MODULE_3__utilities__["d" /* isCompletedAccount */])(profileData)&&__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_1_scuid_x__["SubheadFour"],null,'Wealth Plan'),__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_5__shared_styles__["i" /* LoanDescription */],null,profileHtml.subText),__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_5__shared_styles__["f" /* LoanBody */],null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_5__shared_styles__["j" /* LoanSummary */],null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_5__shared_styles__["e" /* LoanAmount */],null,Object(__WEBPACK_IMPORTED_MODULE_4__utilities_currency_format_helpers__["a" /* FORMAT_CURRENCY */])(profileData.currentBalance),__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('span',null,'Current value'))),__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_5__shared_styles__["c" /* LoanAction */],null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('a',{'data-qa':'accounts-wealthCtaLink',href:profileHtml.ctaLink?profileHtml.ctaLink:'/wealth/#/'},__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_5__shared_styles__["h" /* LoanButton */],{'data-qa':'accounts-wealthCtaLink-button',small:true},profileHtml.cta))))),__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_5__shared_styles__["g" /* LoanBottomBorder */],null));};/* eslint react/no-typos: 0 */Wealth.propTypes={wealthProfile:__WEBPACK_IMPORTED_MODULE_2__constants_prop_types_wealth_prop_types__["a" /* WealthProfilePropTypes */].isRequired};/* harmony default export */ __webpack_exports__["a"] = (Wealth);

/***/ }),
/* 1312 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "c", function() { return isAccountFunded; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "d", function() { return isCompletedAccount; });
/* unused harmony export isInactiveWealth */
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return buildFromCta; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "b", function() { return buildProfileData; });
var isAccountFunded=function isAccountFunded(profileData){return profileData.strategy&&profileData.account&&profileData.funded;};var isCompletedAccount=function isCompletedAccount(profileData){return profileData.completed;};var isInactiveWealth=function isInactiveWealth(profileData){return profileData.new;};var buildFromCta=function buildFromCta(ctaInfo){var profileHtml={};profileHtml.subText=ctaInfo.subText;profileHtml.cta=ctaInfo.cta;profileHtml.ctaLink=ctaInfo.ctaLink;return profileHtml;};var buildProfileData=function buildProfileData(data){var profileData={};profileData.accountId=data.accountId;profileData.strategy=data.accountStrategy;profileData.account=data.accountNumber;profileData.dayChange=data.statistics&&data.statistics.dayChange?data.statistics.dayChange.toString():'0';profileData.totalChangePercentage=data.statistics&&data.statistics.totalChangePercentage?data.statistics.totalChangePercentage.toFixed(2)+'%':'0.00%';profileData.isDayLoss=data.statistics&&data.statistics.dayChange&&data.statistics.dayChange<0?'daily-loss':null;profileData.isTotalLoss=data.statistics&&data.statistics.dayChange&&data.statistics.totalChangePercentage<0?'daily-loss':null;profileData.currentBalance=data.statistics&&data.statistics.currentBalance?data.statistics.currentBalance:0;profileData.accountTypeDescription=data.accountTypeDescription;profileData.funded=data.funded;profileData.completed=data.completed;profileData.new=data.new;return profileData;};

/***/ }),
/* 1313 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__(0);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_scuid_x__ = __webpack_require__(14);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_scuid_x___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_scuid_x__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__constants_prop_types_banking_prop_types__ = __webpack_require__(1197);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__utilities_currency_format_helpers__ = __webpack_require__(1176);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__shared_styles__ = __webpack_require__(1173);
/**
 * PropTypes imports
 *//**
 * Utilities/function imports
 *//**
 * Styled Components
 */var SofiMoney=function SofiMoney(_ref){var banking=_ref.banking;var accountNumber=banking.accountNumber||'';// We are not using balance currently
// Remove the eslint-disable once/if we use it in the future
// eslint-disable-next-line no-unused-vars
var balance=banking.balance||'0';return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_0_react__["Fragment"],null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_1_scuid_x__["SubheadFour"],null,'SoFi Money (#',accountNumber.slice(-4),')'),__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_4__shared_styles__["f" /* LoanBody */],null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_4__shared_styles__["j" /* LoanSummary */],null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_4__shared_styles__["e" /* LoanAmount */],null,Object(__WEBPACK_IMPORTED_MODULE_3__utilities_currency_format_helpers__["a" /* FORMAT_CURRENCY */])(banking.available),__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('span',null,'Available balance'))),__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_4__shared_styles__["c" /* LoanAction */],null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('a',{'data-qa':'accounts-money-redirect-link',href:banking.redirectUrl},__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_4__shared_styles__["h" /* LoanButton */],{'data-qa':'accounts-money-redirect-button',small:true},'View account')))));};/* eslint react/no-typos: 0 */SofiMoney.propTypes={banking:__WEBPACK_IMPORTED_MODULE_2__constants_prop_types_banking_prop_types__["a" /* BankingPropTypes */].isRequired};/* harmony default export */ __webpack_exports__["a"] = (SofiMoney);

/***/ }),
/* 1314 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__(0);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_styled_components__ = __webpack_require__(3);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_prop_types__ = __webpack_require__(1);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_prop_types___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_prop_types__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__constants_prop_types_customer_prop_types__ = __webpack_require__(124);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__constants_prop_types_dashboard_accounts_prop_types__ = __webpack_require__(1210);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__constants_prop_types_referral_prop_types__ = __webpack_require__(1082);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__account_cards__ = __webpack_require__(1315);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__affiliate__ = __webpack_require__(1224);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8__components_loading__ = __webpack_require__(316);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_9__utilities__ = __webpack_require__(328);
var _createClass=function(){function defineProperties(target,props){for(var i=0;i<props.length;i++){var descriptor=props[i];descriptor.enumerable=descriptor.enumerable||false;descriptor.configurable=true;if("value"in descriptor)descriptor.writable=true;Object.defineProperty(target,descriptor.key,descriptor);}}return function(Constructor,protoProps,staticProps){if(protoProps)defineProperties(Constructor.prototype,protoProps);if(staticProps)defineProperties(Constructor,staticProps);return Constructor;};}();var _templateObject=_taggedTemplateLiteral(['\n  font-size: 1.5rem;\n  font-weight: 700;\n  line-height: 1.28;\n  letter-spacing: 0.05rem;\n  color: #262626;\n  padding-top: 20px;\n'],['\n  font-size: 1.5rem;\n  font-weight: 700;\n  line-height: 1.28;\n  letter-spacing: 0.05rem;\n  color: #262626;\n  padding-top: 20px;\n']),_templateObject2=_taggedTemplateLiteral(['\n  max-width: 1240px;\n  margin: 0px auto;\n  padding-left: 20px;\n  padding-right: 20px;\n'],['\n  max-width: 1240px;\n  margin: 0px auto;\n  padding-left: 20px;\n  padding-right: 20px;\n']),_templateObject3=_taggedTemplateLiteral(['\n  background-color: #fff;\n  padding: 2rem 1rem 0.625rem 1rem;\n  margin-top: 2rem;\n'],['\n  background-color: #fff;\n  padding: 2rem 1rem 0.625rem 1rem;\n  margin-top: 2rem;\n']);function _classCallCheck(instance,Constructor){if(!(instance instanceof Constructor)){throw new TypeError("Cannot call a class as a function");}}function _possibleConstructorReturn(self,call){if(!self){throw new ReferenceError("this hasn't been initialised - super() hasn't been called");}return call&&(typeof call==="object"||typeof call==="function")?call:self;}function _inherits(subClass,superClass){if(typeof superClass!=="function"&&superClass!==null){throw new TypeError("Super expression must either be null or a function, not "+typeof superClass);}subClass.prototype=Object.create(superClass&&superClass.prototype,{constructor:{value:subClass,enumerable:false,writable:true,configurable:true}});if(superClass)Object.setPrototypeOf?Object.setPrototypeOf(subClass,superClass):subClass.__proto__=superClass;}function _taggedTemplateLiteral(strings,raw){return Object.freeze(Object.defineProperties(strings,{raw:{value:Object.freeze(raw)}}));}/**
 * PropTypes imports
 *//**
 * Component imports
 *//**
 * Utilities/function imports
 */var Header=__WEBPACK_IMPORTED_MODULE_1_styled_components__["default"].h6(_templateObject);var Container=__WEBPACK_IMPORTED_MODULE_1_styled_components__["default"].div(_templateObject2);var ReferralSection=__WEBPACK_IMPORTED_MODULE_1_styled_components__["default"].section(_templateObject3);/**
 * Displays all the customer accounts
 */var AccountsSection=function(_Component){_inherits(AccountsSection,_Component);function AccountsSection(){_classCallCheck(this,AccountsSection);return _possibleConstructorReturn(this,(AccountsSection.__proto__||Object.getPrototypeOf(AccountsSection)).apply(this,arguments));}_createClass(AccountsSection,[{key:'componentDidMount',value:function componentDidMount(){var loadDashboardAccounts=this.props.loadDashboardAccounts;loadDashboardAccounts();}},{key:'render',value:function render(){var _props=this.props,customer=_props.customer,dashboardAccounts=_props.dashboardAccounts,dashboardAccountsLoaded=_props.dashboardAccountsLoaded,consentsTou=_props.consentsTou,referralSummaryLoaded=_props.referralSummaryLoaded,referralConsentsLoaded=_props.referralConsentsLoaded,referralSummary=_props.referralSummary,referralConsents=_props.referralConsents,postReferralConsent=_props.postReferralConsent,getValueLabelPairs=_props.getValueLabelPairs,handleCallback=_props.handleCallback,handleModalOpen=_props.handleModalOpen,showMohelaModal=_props.showMohelaModal,showCenlarModal=_props.showCenlarModal,modalContentUrl=_props.modalContentUrl;if(!dashboardAccountsLoaded){return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_8__components_loading__["a" /* default */],null);}return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_0_react__["Fragment"],null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(Container,null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(Header,null,'Hello, ',customer.firstName,'!'),dashboardAccounts.accountCards&&dashboardAccounts.accountCards.length>0&&__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_6__account_cards__["a" /* default */],{dashboardAccounts:dashboardAccounts,getValueLabelPairs:getValueLabelPairs,handleCallback:handleCallback,handleModalOpen:handleModalOpen,showMohelaModal:showMohelaModal,showCenlarModal:showCenlarModal,modalContentUrl:modalContentUrl})),__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(Container,null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(ReferralSection,null,Object(__WEBPACK_IMPORTED_MODULE_9__utilities__["c" /* eligibleForReferralProgram */])(customer)&&consentsTou&&referralSummaryLoaded&&referralConsentsLoaded&&__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_7__affiliate__["a" /* default */],{customer:customer,referralSummary:referralSummary,referralConsents:referralConsents,consentsTou:consentsTou,postReferralConsent:postReferralConsent}))));}}]);return AccountsSection;}(__WEBPACK_IMPORTED_MODULE_0_react__["Component"]);AccountsSection.propTypes={customer:__WEBPACK_IMPORTED_MODULE_3__constants_prop_types_customer_prop_types__["b" /* CustomerPropTypes */].isRequired,dashboardAccounts:__WEBPACK_IMPORTED_MODULE_4__constants_prop_types_dashboard_accounts_prop_types__["a" /* DashboardAccountsPropTypes */].isRequired,dashboardAccountsLoaded:__WEBPACK_IMPORTED_MODULE_2_prop_types___default.a.bool.isRequired,loadDashboardAccounts:__WEBPACK_IMPORTED_MODULE_2_prop_types___default.a.func.isRequired,getValueLabelPairs:__WEBPACK_IMPORTED_MODULE_2_prop_types___default.a.func.isRequired,handleCallback:__WEBPACK_IMPORTED_MODULE_2_prop_types___default.a.func.isRequired,handleModalOpen:__WEBPACK_IMPORTED_MODULE_2_prop_types___default.a.func.isRequired,showMohelaModal:__WEBPACK_IMPORTED_MODULE_2_prop_types___default.a.bool.isRequired,showCenlarModal:__WEBPACK_IMPORTED_MODULE_2_prop_types___default.a.bool.isRequired,consentsTou:__WEBPACK_IMPORTED_MODULE_2_prop_types___default.a.number,referralSummaryLoaded:__WEBPACK_IMPORTED_MODULE_2_prop_types___default.a.bool.isRequired,referralConsentsLoaded:__WEBPACK_IMPORTED_MODULE_2_prop_types___default.a.bool.isRequired,referralSummary:__WEBPACK_IMPORTED_MODULE_5__constants_prop_types_referral_prop_types__["g" /* ReferralSummaryPropTypes */].isRequired,referralConsents:__WEBPACK_IMPORTED_MODULE_5__constants_prop_types_referral_prop_types__["a" /* ReferralConsentsPropTypes */].isRequired,postReferralConsent:__WEBPACK_IMPORTED_MODULE_2_prop_types___default.a.func.isRequired,modalContentUrl:__WEBPACK_IMPORTED_MODULE_2_prop_types___default.a.string.isRequired};AccountsSection.defaultProps={consentsTou:null};/* harmony default export */ __webpack_exports__["a"] = (AccountsSection);

/***/ }),
/* 1315 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__(0);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_styled_components__ = __webpack_require__(3);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_scuid_x__ = __webpack_require__(14);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_scuid_x___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_scuid_x__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_prop_types__ = __webpack_require__(1);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_prop_types___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_3_prop_types__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_lodash_debounce__ = __webpack_require__(327);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_lodash_debounce___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_4_lodash_debounce__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__constants_prop_types_dashboard_accounts_prop_types__ = __webpack_require__(1210);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__account_card_footer__ = __webpack_require__(1316);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__wealth_card__ = __webpack_require__(1317);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8__mohela_modal_v2__ = __webpack_require__(1318);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_9__cenlar_modal__ = __webpack_require__(1319);
var _createClass=function(){function defineProperties(target,props){for(var i=0;i<props.length;i++){var descriptor=props[i];descriptor.enumerable=descriptor.enumerable||false;descriptor.configurable=true;if("value"in descriptor)descriptor.writable=true;Object.defineProperty(target,descriptor.key,descriptor);}}return function(Constructor,protoProps,staticProps){if(protoProps)defineProperties(Constructor.prototype,protoProps);if(staticProps)defineProperties(Constructor,staticProps);return Constructor;};}();var _templateObject=_taggedTemplateLiteral(['\n  position: relative;\n  margin-top: 20px;\n  margin-bottom: 20px;\n'],['\n  position: relative;\n  margin-top: 20px;\n  margin-bottom: 20px;\n']),_templateObject2=_taggedTemplateLiteral(['\n  display: flex;\n  flex-flow: row nowrap;\n  overflow-x: hidden;\n  overflow-y: auto;\n  white-space: nowrap;\n\n  &::-webkit-scrollbar {\n    display: none;\n  }\n\n  @media (max-width: 479px) {\n    transition: all 0.4s ease-out;\n    flex-direction: column;\n    overflow: unset !important;\n  }\n\n  @media (min-width: 480px) {\n    ',';\n  }\n'],['\n  display: flex;\n  flex-flow: row nowrap;\n  overflow-x: hidden;\n  overflow-y: auto;\n  white-space: nowrap;\n\n  &::-webkit-scrollbar {\n    display: none;\n  }\n\n  @media (max-width: 479px) {\n    transition: all 0.4s ease-out;\n    flex-direction: column;\n    overflow: unset !important;\n  }\n\n  @media (min-width: 480px) {\n    ',';\n  }\n']),_templateObject3=_taggedTemplateLiteral(['\n  position: absolute;\n  min-width: 40px;\n  width: 40px;\n  height: 40px;\n  padding: 0;\n  border-radius: 40px;\n  text-align: center;\n  box-shadow: 2px 2px 3px #999;\n  z-index: 5;\n  top: 50%;\n  transform: translateY(-50%);\n  margin-left: 0 !important;\n  left: ','px;\n  right: ','px;\n\n  svg {\n    position: absolute;\n    top: 50%;\n    right: 50%;\n    transform: translate(50%, -50%);\n  }\n\n  @media (max-width: 479px) {\n    display: none !important;\n  }\n'],['\n  position: absolute;\n  min-width: 40px;\n  width: 40px;\n  height: 40px;\n  padding: 0;\n  border-radius: 40px;\n  text-align: center;\n  box-shadow: 2px 2px 3px #999;\n  z-index: 5;\n  top: 50%;\n  transform: translateY(-50%);\n  margin-left: 0 !important;\n  left: ','px;\n  right: ','px;\n\n  svg {\n    position: absolute;\n    top: 50%;\n    right: 50%;\n    transform: translate(50%, -50%);\n  }\n\n  @media (max-width: 479px) {\n    display: none !important;\n  }\n']),_templateObject4=_taggedTemplateLiteral(['\n  top: 0.625rem;\n  right: 0.625rem;\n'],['\n  top: 0.625rem;\n  right: 0.625rem;\n']),_templateObject5=_taggedTemplateLiteral(['\n  text-decoration: none !important;\n  color: #262626;\n  &:hover {\n    text-decoration: none !important;\n    color: #262626;\n  }\n'],['\n  text-decoration: none !important;\n  color: #262626;\n  &:hover {\n    text-decoration: none !important;\n    color: #262626;\n  }\n']);function _classCallCheck(instance,Constructor){if(!(instance instanceof Constructor)){throw new TypeError("Cannot call a class as a function");}}function _possibleConstructorReturn(self,call){if(!self){throw new ReferenceError("this hasn't been initialised - super() hasn't been called");}return call&&(typeof call==="object"||typeof call==="function")?call:self;}function _inherits(subClass,superClass){if(typeof superClass!=="function"&&superClass!==null){throw new TypeError("Super expression must either be null or a function, not "+typeof superClass);}subClass.prototype=Object.create(superClass&&superClass.prototype,{constructor:{value:subClass,enumerable:false,writable:true,configurable:true}});if(superClass)Object.setPrototypeOf?Object.setPrototypeOf(subClass,superClass):subClass.__proto__=superClass;}function _taggedTemplateLiteral(strings,raw){return Object.freeze(Object.defineProperties(strings,{raw:{value:Object.freeze(raw)}}));}/**
 * PropTypes imports
 *//**
 * Component imports
 *//**
 * Styled Components
 */var translateXonClick=function translateXonClick(props){var cardWidth=props.cardWidth||0;var caretRightCounter=props.caretRightCounter;// eslint-disable-next-line no-mixed-operators
var x=cardWidth*caretRightCounter+caretRightCounter*20;return'\n    .member-card:nth-child(-n + '+caretRightCounter+') {\n      transform: translateX(-'+x+'px);\n      transition: all 0.4s ease-out;\n      opacity: 0;\n      visibility: hidden;\n    }\n\n    .member-card:not(:nth-child(-n + '+caretRightCounter+')) {\n        transform: translateX(-'+x+'px);\n        opacity: 1;\n        visibility: visible;\n        transition: all 0.4s ease-out;\n    }\n  ';};var CardContainer=__WEBPACK_IMPORTED_MODULE_1_styled_components__["default"].div(_templateObject);var Cards=__WEBPACK_IMPORTED_MODULE_1_styled_components__["default"].div(_templateObject2,translateXonClick);var FloatingScrollButton=Object(__WEBPACK_IMPORTED_MODULE_1_styled_components__["default"])(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["Button"])(_templateObject3,function(_ref){var isLeft=_ref.isLeft;return isLeft&&-17;},function(_ref2){var isRight=_ref2.isRight;return isRight&&-17;});var StyledHeaderDropdown=Object(__WEBPACK_IMPORTED_MODULE_1_styled_components__["default"])(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["AccountDropdown"])(_templateObject4);var CardLink=Object(__WEBPACK_IMPORTED_MODULE_1_styled_components__["default"])(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["HyperLink"])(_templateObject5);var AccountCards=function(_Component){_inherits(AccountCards,_Component);function AccountCards(){var _ref3;var _temp,_this,_ret;_classCallCheck(this,AccountCards);for(var _len=arguments.length,args=Array(_len),_key=0;_key<_len;_key++){args[_key]=arguments[_key];}return _ret=(_temp=(_this=_possibleConstructorReturn(this,(_ref3=AccountCards.__proto__||Object.getPrototypeOf(AccountCards)).call.apply(_ref3,[this].concat(args))),_this),_this.state={cardsToSkip:null,cardWidth:null,caretRightCounter:0},_this.handleWidthChange=__WEBPACK_IMPORTED_MODULE_4_lodash_debounce___default()(function(){// get the width of the container
var containerWidth=_this.cardContainerNode.clientWidth;// get the width of the first card
var cardWidth=_this.accountCardNode0.clientWidth;var extraWidth=0;// calculate extra width to add to the cardWidth (because of margin-left on the card)
if(containerWidth>=970){extraWidth+=Math.floor(40/3);}else{extraWidth+=10;}// calculate how many cards are being displayed fully on the screen
var cardsToSkip=Math.floor(containerWidth/(cardWidth+extraWidth));if(cardsToSkip!==_this.state.cardsToSkip||cardWidth!==_this.state.cardWidth){_this.setState(function(){return{cardsToSkip:cardsToSkip,cardWidth:cardWidth};});}},66,{trailing:true}),_this.handleClickCaret=function(add){_this.setState(function(state){return{caretRightCounter:add?state.caretRightCounter+1:state.caretRightCounter-1};});},_this.resizeEventAdded=undefined,_temp),_possibleConstructorReturn(_this,_ret);}_createClass(AccountCards,[{key:'componentDidMount',value:function componentDidMount(){this.resizeEventAdded=true;this.handleWidthChange();// add resize event listener for responsiveness
window.addEventListener('resize',this.handleWidthChange,false);}},{key:'componentWillUnmount',value:function componentWillUnmount(){if(this.resizeEventAdded){window.removeEventListener('resize',this.handleWidthChange,false);this.resizeEventAdded=undefined;}}/**
   * Calculates cards to skip based on cardContainerNode's width
   * Based on it, we either show the right arrow or hide it
   * Debounce set to 66ms (15fps)
   */},{key:'render',value:function render(){var _this2=this;var _props=this.props,dashboardAccounts=_props.dashboardAccounts,getValueLabelPairs=_props.getValueLabelPairs,handleCallback=_props.handleCallback,handleModalOpen=_props.handleModalOpen,showMohelaModal=_props.showMohelaModal,showCenlarModal=_props.showCenlarModal,modalContentUrl=_props.modalContentUrl;var _state=this.state,cardsToSkip=_state.cardsToSkip,cardWidth=_state.cardWidth,caretRightCounter=_state.caretRightCounter;return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_0_react__["Fragment"],null,showMohelaModal&&__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_8__mohela_modal_v2__["a" /* default */],{open:showMohelaModal,toggleOpen:handleModalOpen('showMohelaModal')}),showCenlarModal&&__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_9__cenlar_modal__["a" /* default */],{open:showCenlarModal,toggleOpen:handleModalOpen('showCenlarModal'),modalContentUrl:modalContentUrl}),__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(CardContainer,{innerRef:function innerRef(cardContainerNode){_this2.cardContainerNode=cardContainerNode;}},__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(Cards,{caretRightCounter:caretRightCounter,cardWidth:cardWidth},dashboardAccounts.accountCards.map(function(account,index){return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["AccountCard"]// add reference to the Account card(s) for responsive purpose
,{innerRef:function innerRef(accountCardNode){_this2['accountCardNode'+index]=accountCardNode;},className:'member-card',key:account.id},__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(CardLink,{href:account.data.mainAction},__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["AccountCardHeader"],{title:account.data.title,status:account.data.subTitle?account.data.subTitle:'',iconType:__WEBPACK_IMPORTED_MODULE_2_scuid_x__["IconType"][account.data.titleIcon],hasActions:Boolean(account.data.cardActions),renderActions:function renderActions(_ref4){var handleOpen=_ref4.handleOpen;return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(StyledHeaderDropdown,{actions:account.data.cardActions?account.data.cardActions:null,handleOpen:handleOpen,handleCallback:handleCallback});}})),__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["AccountCardContent"],null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(CardLink,{href:account.data.mainAction},account.data.mainData&&__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["BigNumber"],{value:account.data.mainData,label:account.data.mainLabel}),account.data.title==='Wealth'&&__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_7__wealth_card__["a" /* default */],{account:account}),account.data.title!=='Wealth'&&account.data.topLeftData&&__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["ValuesWithLabels"],{valueLabelPairs:getValueLabelPairs(account.data)}),account.data.fullWidthMessage&&__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["AccountNotes"],null,account.data.fullWidthMessage))),(account.data.callToAction1||account.data.callToAction2)&&__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["AccountCardFooter"],null,account.data.callToAction1&&__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_6__account_card_footer__["a" /* default */],{title:account.data.title,callToAction:account.data.callToAction1,handleCallback:handleCallback}),account.data.callToAction2&&__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_6__account_card_footer__["a" /* default */],{title:account.data.title,callToAction:account.data.callToAction2,handleCallback:handleCallback})));}),dashboardAccounts.accountCards&&dashboardAccounts.accountCards.length>=2&&__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_0_react__["Fragment"],null,Number.isInteger(cardsToSkip)&&caretRightCounter<dashboardAccounts.accountCards.length-cardsToSkip&&__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(FloatingScrollButton,{isRight:true,onClick:function onClick(){return _this2.handleClickCaret(true);}},__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["Icon"],{iconType:__WEBPACK_IMPORTED_MODULE_2_scuid_x__["IconType"].CaretRight,iconColor:'White'})),caretRightCounter>=1&&__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(FloatingScrollButton,{isLeft:true,onClick:function onClick(){return _this2.handleClickCaret(false);}},__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["Icon"],{iconType:__WEBPACK_IMPORTED_MODULE_2_scuid_x__["IconType"].CaretLeft,iconColor:'White'}))))));}}]);return AccountCards;}(__WEBPACK_IMPORTED_MODULE_0_react__["Component"]);AccountCards.propTypes={dashboardAccounts:__WEBPACK_IMPORTED_MODULE_5__constants_prop_types_dashboard_accounts_prop_types__["a" /* DashboardAccountsPropTypes */].isRequired,getValueLabelPairs:__WEBPACK_IMPORTED_MODULE_3_prop_types___default.a.func.isRequired,handleCallback:__WEBPACK_IMPORTED_MODULE_3_prop_types___default.a.func.isRequired,handleModalOpen:__WEBPACK_IMPORTED_MODULE_3_prop_types___default.a.func.isRequired,showMohelaModal:__WEBPACK_IMPORTED_MODULE_3_prop_types___default.a.bool.isRequired,showCenlarModal:__WEBPACK_IMPORTED_MODULE_3_prop_types___default.a.bool.isRequired,modalContentUrl:__WEBPACK_IMPORTED_MODULE_3_prop_types___default.a.string.isRequired};/* harmony default export */ __webpack_exports__["a"] = (AccountCards);

/***/ }),
/* 1316 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__(0);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_prop_types__ = __webpack_require__(1);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_prop_types___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_prop_types__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_styled_components__ = __webpack_require__(3);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_scuid_x__ = __webpack_require__(14);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_scuid_x___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_3_scuid_x__);
var _templateObject=_taggedTemplateLiteral(['\n  bottom: 0.625rem;\n  right: 0.625rem;\n'],['\n  bottom: 0.625rem;\n  right: 0.625rem;\n']);function _taggedTemplateLiteral(strings,raw){return Object.freeze(Object.defineProperties(strings,{raw:{value:Object.freeze(raw)}}));}var StyledFooterDropdown=Object(__WEBPACK_IMPORTED_MODULE_2_styled_components__["default"])(__WEBPACK_IMPORTED_MODULE_3_scuid_x__["AccountDropdown"])(_templateObject);var AccountCardFooter=function AccountCardFooter(_ref){var title=_ref.title,callToAction=_ref.callToAction,handleCallback=_ref.handleCallback;return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_0_react__["Fragment"],null,callToAction.type==='button'?__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_3_scuid_x__["IconAction"],Object.assign({'data-mjs':'dashboard-'+title+'-'+callToAction.text,label:callToAction.text,iconType:__WEBPACK_IMPORTED_MODULE_3_scuid_x__["IconType"][callToAction.icon],hasActions:Boolean(callToAction.actions),link:callToAction.url?callToAction.url:null,renderActions:function renderActions(_ref2){var handleOpen=_ref2.handleOpen;return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(StyledFooterDropdown,{'data-mjs':'dashboard-'+title+'-'+callToAction.text,actions:callToAction.actions?callToAction.actions:null,handleOpen:handleOpen,handleCallback:handleCallback});}// is only checking for Modal currently
},callToAction.modalName?{onClick:function onClick(){return handleCallback(callToAction);}}:{})):__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_3_scuid_x__["StandardAction"],Object.assign({'data-mjs':'dashboard-'+title+'-'+callToAction.text,iconType:callToAction.icon?__WEBPACK_IMPORTED_MODULE_3_scuid_x__["IconType"][callToAction.icon]:null,link:callToAction.url?callToAction.url:null,hasActions:Boolean(callToAction.actions),renderActions:function renderActions(_ref3){var handleOpen=_ref3.handleOpen;return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(StyledFooterDropdown,{'data-mjs':'dashboard-'+title+'-'+callToAction.text,actions:callToAction.actions?callToAction.actions:null,handleOpen:handleOpen,handleCallback:handleCallback});}// is only checking for Modal currently
},callToAction.modalName?{onClick:function onClick(){return handleCallback(callToAction);}}:{}),callToAction.text));};AccountCardFooter.propTypes={callToAction:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.shape({text:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.string,type:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.string,url:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.string}).isRequired,handleCallback:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.func.isRequired,title:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.string.isRequired};/* harmony default export */ __webpack_exports__["a"] = (AccountCardFooter);

/***/ }),
/* 1317 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__(0);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_styled_components__ = __webpack_require__(3);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__constants_prop_types_dashboard_accounts_prop_types__ = __webpack_require__(1210);
var _templateObject=_taggedTemplateLiteral(['\n  display: flex;\n  flex-wrap: wrap;\n  flex: 1;\n'],['\n  display: flex;\n  flex-wrap: wrap;\n  flex: 1;\n']),_templateObject2=_taggedTemplateLiteral(['\n  max-width: 50%;\n  margin-top: 0.5rem;\n  flex: 0 0 50%;\n  font-weight: 500;\n  font-family: \'TT Norms\', \'proxima-nova\', \'Helvetica Neue\', Verdana, Arial, Helvetica, sans-serif;\n  font-size: 1.125rem;\n'],['\n  max-width: 50%;\n  margin-top: 0.5rem;\n  flex: 0 0 50%;\n  font-weight: 500;\n  font-family: \'TT Norms\', \'proxima-nova\', \'Helvetica Neue\', Verdana, Arial, Helvetica, sans-serif;\n  font-size: 1.125rem;\n']),_templateObject3=_taggedTemplateLiteral(['\n  color: #008000;\n'],['\n  color: #008000;\n']),_templateObject4=_taggedTemplateLiteral(['\n  color: #ff0000;\n'],['\n  color: #ff0000;\n']),_templateObject5=_taggedTemplateLiteral(['\n  color: #262626;\n'],['\n  color: #262626;\n']),_templateObject6=_taggedTemplateLiteral(['\n  font-size: 0.813rem;\n  letter-spacing: 0.04em;\n  color: #757575;\n  display: block;\n'],['\n  font-size: 0.813rem;\n  letter-spacing: 0.04em;\n  color: #757575;\n  display: block;\n']);function _taggedTemplateLiteral(strings,raw){return Object.freeze(Object.defineProperties(strings,{raw:{value:Object.freeze(raw)}}));}/**
 * PropTypes imports
 */var WealthData=__WEBPACK_IMPORTED_MODULE_1_styled_components__["default"].div(_templateObject);var ValuesWrapper=__WEBPACK_IMPORTED_MODULE_1_styled_components__["default"].div(_templateObject2);var Gain=__WEBPACK_IMPORTED_MODULE_1_styled_components__["default"].p(_templateObject3);var Loss=__WEBPACK_IMPORTED_MODULE_1_styled_components__["default"].p(_templateObject4);var NoChange=__WEBPACK_IMPORTED_MODULE_1_styled_components__["default"].p(_templateObject5);var ValueLabel=__WEBPACK_IMPORTED_MODULE_1_styled_components__["default"].span(_templateObject6);var checkFluctuation=function checkFluctuation(data){if(data.match('▲')){return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(Gain,null,data);}else if(data.match('▼')){return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(Loss,null,data);}return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(NoChange,null,data);};var WealthCard=function WealthCard(_ref){var account=_ref.account;return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(WealthData,null,account.data.topLeftData&&__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(ValuesWrapper,null,checkFluctuation(account.data.topLeftData),__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(ValueLabel,null,account.data.topLeftLabel)),account.data.topRightData&&__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(ValuesWrapper,null,checkFluctuation(account.data.topRightData),__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(ValueLabel,null,account.data.topRightLabel)));};/* eslint react/no-typos: 0 */WealthCard.propTypes={account:__WEBPACK_IMPORTED_MODULE_2__constants_prop_types_dashboard_accounts_prop_types__["a" /* DashboardAccountsPropTypes */].isRequired};/* harmony default export */ __webpack_exports__["a"] = (WealthCard);

/***/ }),
/* 1318 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__(0);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_prop_types__ = __webpack_require__(1);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_prop_types___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_prop_types__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_scuid_x__ = __webpack_require__(14);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_scuid_x___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_scuid_x__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__utilities_global_styles__ = __webpack_require__(80);
var redirect=function redirect(toggleOpen){var mohela=window.open('https://sofi.mohela.com/');mohela.opener=null;// prevent phishing attempts
toggleOpen();};var MohelaModal=function MohelaModal(_ref){var open=_ref.open,toggleOpen=_ref.toggleOpen;return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["Modal"],{isOpen:open,onDismiss:toggleOpen,title:'You are about to leave SoFi'},__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["Modal"].Body,null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_3__utilities_global_styles__["a" /* ResponsiveModalContent */],null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["Paragraph"],null,'To manage your Student Loan ReFi, we\'re directing you to MOHELA, SoFi\'s third-party loan servicer for student loans.'),__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["Paragraph"],null,'Make payments and get account details at',' ',__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["HyperLink"],{'data-qa':'mohela-goToMohela',href:'https://sofi.mohela.com/',target:'_blank',rel:'noopener noreferrer'},'sofi.mohela.com'),' ','or by calling',' ',__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["HyperLink"],{'data-qa':'mohela-telephone-number',href:'tel:8772927470'},'(877) 292-7470'),'. While your loan will be serviced by MOHELA, you will still be a SoFi member and be able to take advantage of our unique member benefits.'))),__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["Modal"].Footer,null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_3__utilities_global_styles__["b" /* ResponsiveModalFooter */],null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["Button"],{'data-qa':'mohela-backToSoFi','data-mjs':'slr-popup-close mohela',secondary:true,onClick:function onClick(){toggleOpen();}},'Back to SoFi'),__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["Button"],{'data-qa':'mohela-continueToMohela','data-mjs':'slr-popup-continue to mohela',onClick:function onClick(){redirect(toggleOpen);}},'Continue to MOHELA'))));};MohelaModal.propTypes={open:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.bool.isRequired,toggleOpen:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.func.isRequired};/* harmony default export */ __webpack_exports__["a"] = (MohelaModal);

/***/ }),
/* 1319 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__(0);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_prop_types__ = __webpack_require__(1);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_prop_types___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_prop_types__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_scuid_x__ = __webpack_require__(14);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_scuid_x___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_scuid_x__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__utilities_global_styles__ = __webpack_require__(80);
var redirect=function redirect(toggleOpen,modalContentUrl){var cenlar=window.open(modalContentUrl);cenlar.opener=null;// prevent phishing attempts
toggleOpen();};var CenlarModal=function CenlarModal(_ref){var open=_ref.open,toggleOpen=_ref.toggleOpen,modalContentUrl=_ref.modalContentUrl;return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["Modal"],{isOpen:open,onDismiss:toggleOpen,title:'You are about to leave SoFi'},__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["Modal"].Body,null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_3__utilities_global_styles__["a" /* ResponsiveModalContent */],null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["Paragraph"],null,'To manage your Mortgage, we\'re directing you to CENLAR, SoFi\'s third-party loan servicer for mortgage loans.'),__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["Paragraph"],null,'Make payments and get account details at',' ',__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["HyperLink"],{'data-qa':'redirect-mort-link',href:modalContentUrl},'Cenlar'),' ','for further assistance.',__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["Paragraph"],null,'While your loan will be serviced by CENLAR, you will still be a SoFi member and be able to take advantage of our unique member benefits.')))),__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["Modal"].Footer,null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_3__utilities_global_styles__["b" /* ResponsiveModalFooter */],null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["Button"],{'data-qa':'cenlar-backToSoFi','data-mjs':'slr-popup-close cenlar',secondary:true,onClick:function onClick(){toggleOpen();}},'Back to SoFi'),__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["Button"],{'data-qa':'cenlar-continueToCenlar','data-mjs':'slr-popup-continue to cenlar',onClick:function onClick(){redirect(toggleOpen,modalContentUrl);}},'Continue to CENLAR'))));};CenlarModal.defaultProps={modalContentUrl:''};CenlarModal.propTypes={open:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.bool.isRequired,toggleOpen:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.func.isRequired,modalContentUrl:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.string};/* harmony default export */ __webpack_exports__["a"] = (CenlarModal);

/***/ }),
/* 1320 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__(0);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_prop_types__ = __webpack_require__(1);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_prop_types___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_prop_types__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_styled_components__ = __webpack_require__(3);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_react_launch_darkly__ = __webpack_require__(1187);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_react_launch_darkly___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_3_react_launch_darkly__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__constants_prop_types_products_prop_types__ = __webpack_require__(1206);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__constants_prop_types_customer_prop_types__ = __webpack_require__(124);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__constants_prop_types_banking_prop_types__ = __webpack_require__(1197);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__components_products__ = __webpack_require__(1321);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8__constants_launch_darkly_constants__ = __webpack_require__(1188);
var _templateObject=_taggedTemplateLiteral(['\n  max-width: 1240px;\n  margin: 0px auto;\n  padding-left: 20px;\n  padding-right: 20px;\n'],['\n  max-width: 1240px;\n  margin: 0px auto;\n  padding-left: 20px;\n  padding-right: 20px;\n']),_templateObject2=_taggedTemplateLiteral(['\n  font-size: 0.8rem;\n  font-weight: 700;\n  line-height: 1.28;\n  letter-spacing: 0.1rem;\n  color: #262626;\n  padding-top: 20px;\n  padding-bottom: 10px;\n'],['\n  font-size: 0.8rem;\n  font-weight: 700;\n  line-height: 1.28;\n  letter-spacing: 0.1rem;\n  color: #262626;\n  padding-top: 20px;\n  padding-bottom: 10px;\n']),_templateObject3=_taggedTemplateLiteral(['\n  display: flex;\n  flex-flow: row wrap;\n  align-content: flex-end;\n  margin: 0px;\n  padding: 0px;\n'],['\n  display: flex;\n  flex-flow: row wrap;\n  align-content: flex-end;\n  margin: 0px;\n  padding: 0px;\n']);function _taggedTemplateLiteral(strings,raw){return Object.freeze(Object.defineProperties(strings,{raw:{value:Object.freeze(raw)}}));}/**
 * PropTypes imports
 *//**
 * Component imports
 *//**
 * Styled components
 */var Container=__WEBPACK_IMPORTED_MODULE_2_styled_components__["default"].div(_templateObject);var Header=__WEBPACK_IMPORTED_MODULE_2_styled_components__["default"].h6(_templateObject2);var Offerings=__WEBPACK_IMPORTED_MODULE_2_styled_components__["default"].div(_templateObject3);/**
 * May change into a Container in the future
 */var Products=function Products(_ref){var customer=_ref.customer,products=_ref.products,banking=_ref.banking,bankingLoaded=_ref.bankingLoaded;return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(Container,null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(Header,null,'OUR OFFERINGS'),__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_3_react_launch_darkly__["FeatureFlag"],{flagKey:__WEBPACK_IMPORTED_MODULE_8__constants_launch_darkly_constants__["c" /* FEATURE_FLAG_MEMBER_DASHBOARD_CMS_PRODUCT_OFFERINGS */],renderFeatureCallback:function renderFeatureCallback(){return(// TODO new product cards go here
__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(Offerings,null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_7__components_products__["a" /* default */],{customer:customer,products:products,banking:banking,bankingLoaded:bankingLoaded})));},renderDefaultCallback:function renderDefaultCallback(){return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(Offerings,null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_7__components_products__["a" /* default */],{customer:customer,products:products,banking:banking,bankingLoaded:bankingLoaded}));}}));};/* eslint react/no-typos: 0 */Products.propTypes={customer:__WEBPACK_IMPORTED_MODULE_5__constants_prop_types_customer_prop_types__["b" /* CustomerPropTypes */].isRequired,products:__WEBPACK_IMPORTED_MODULE_4__constants_prop_types_products_prop_types__["a" /* ProductsPropTypes */].isRequired,banking:__WEBPACK_IMPORTED_MODULE_6__constants_prop_types_banking_prop_types__["a" /* BankingPropTypes */].isRequired,bankingLoaded:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.bool.isRequired};/* harmony default export */ __webpack_exports__["a"] = (Products);

/***/ }),
/* 1321 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__products__ = __webpack_require__(1322);
/* harmony reexport (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return __WEBPACK_IMPORTED_MODULE_0__products__["a"]; });


/***/ }),
/* 1322 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__(0);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_scuid_x__ = __webpack_require__(14);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_scuid_x___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_scuid_x__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_styled_components__ = __webpack_require__(3);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_prop_types__ = __webpack_require__(1);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_prop_types___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_3_prop_types__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_lodash_isEmpty__ = __webpack_require__(1171);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_lodash_isEmpty___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_4_lodash_isEmpty__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5_lodash_cloneDeep__ = __webpack_require__(334);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5_lodash_cloneDeep___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_5_lodash_cloneDeep__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6_lodash_isEqual__ = __webpack_require__(1323);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6_lodash_isEqual___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_6_lodash_isEqual__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__constants_prop_types_products_prop_types__ = __webpack_require__(1206);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8__constants_prop_types_customer_prop_types__ = __webpack_require__(124);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_9__constants_prop_types_banking_prop_types__ = __webpack_require__(1197);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_10__payments_modal__ = __webpack_require__(1324);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_11__utilities__ = __webpack_require__(1325);
var _createClass=function(){function defineProperties(target,props){for(var i=0;i<props.length;i++){var descriptor=props[i];descriptor.enumerable=descriptor.enumerable||false;descriptor.configurable=true;if("value"in descriptor)descriptor.writable=true;Object.defineProperty(target,descriptor.key,descriptor);}}return function(Constructor,protoProps,staticProps){if(protoProps)defineProperties(Constructor.prototype,protoProps);if(staticProps)defineProperties(Constructor,staticProps);return Constructor;};}();var _templateObject=_taggedTemplateLiteral(['\n  padding-left: 5px;\n  padding-right: 5px;\n'],['\n  padding-left: 5px;\n  padding-right: 5px;\n']),_templateObject2=_taggedTemplateLiteral(['\n  padding: 1rem 0.6rem 1rem 0.8rem;\n  background: white;\n  width: 100%;\n  height: 100%;\n  position: relative;\n  z-index: 0;\n'],['\n  padding: 1rem 0.6rem 1rem 0.8rem;\n  background: white;\n  width: 100%;\n  height: 100%;\n  position: relative;\n  z-index: 0;\n']),_templateObject3=_taggedTemplateLiteral(['\n  display: flex;\n  flex-direction: row;\n  justify-content: flex-start;\n  height: 100%;\n  padding-bottom: 2rem;\n'],['\n  display: flex;\n  flex-direction: row;\n  justify-content: flex-start;\n  height: 100%;\n  padding-bottom: 2rem;\n']),_templateObject4=_taggedTemplateLiteral(['\n  width: 100%;\n  padding-top: 0.5rem;\n  display: flex;\n  flex-flow: column wrap;\n  align-content: flex-start;\n'],['\n  width: 100%;\n  padding-top: 0.5rem;\n  display: flex;\n  flex-flow: column wrap;\n  align-content: flex-start;\n']),_templateObject5=_taggedTemplateLiteral(['\n  min-width: 56px;\n  height: 56px;\n  margin-right: 15px;\n'],['\n  min-width: 56px;\n  height: 56px;\n  margin-right: 15px;\n']),_templateObject6=_taggedTemplateLiteral(['\n  color: #262626;\n  font-weight: 500;\n  font-size: 1.1rem;\n  padding: 0px;\n'],['\n  color: #262626;\n  font-weight: 500;\n  font-size: 1.1rem;\n  padding: 0px;\n']),_templateObject7=_taggedTemplateLiteral(['\n  color: #757575;\n  padding: 0px;\n  font-size: 0.9rem;\n\n  // Set z-index to 2 so the anchor tag with superscript becomes active for banking\n  ',';\n'],['\n  color: #757575;\n  padding: 0px;\n  font-size: 0.9rem;\n\n  // Set z-index to 2 so the anchor tag with superscript becomes active for banking\n  ',';\n']),_templateObject8=_taggedTemplateLiteral(['\n  width: 100%;\n  height: 100%;\n  top: 0;\n  left: 0;\n  z-index: 1;\n  cursor: pointer;\n  text-decoration: none;\n  position: absolute;\n'],['\n  width: 100%;\n  height: 100%;\n  top: 0;\n  left: 0;\n  z-index: 1;\n  cursor: pointer;\n  text-decoration: none;\n  position: absolute;\n']),_templateObject9=_taggedTemplateLiteral(['\n  display: flex;\n  position: absolute;\n  bottom: 10px;\n  left: 0;\n  right: 0;\n'],['\n  display: flex;\n  position: absolute;\n  bottom: 10px;\n  left: 0;\n  right: 0;\n']),_templateObject10=_taggedTemplateLiteral(['\n  flex: 1;\n  display: flex;\n'],['\n  flex: 1;\n  display: flex;\n']),_templateObject11=_taggedTemplateLiteral(['\n  min-width: calc(71px + 0.8rem);\n'],['\n  min-width: calc(71px + 0.8rem);\n']);function _classCallCheck(instance,Constructor){if(!(instance instanceof Constructor)){throw new TypeError("Cannot call a class as a function");}}function _possibleConstructorReturn(self,call){if(!self){throw new ReferenceError("this hasn't been initialised - super() hasn't been called");}return call&&(typeof call==="object"||typeof call==="function")?call:self;}function _inherits(subClass,superClass){if(typeof superClass!=="function"&&superClass!==null){throw new TypeError("Super expression must either be null or a function, not "+typeof superClass);}subClass.prototype=Object.create(superClass&&superClass.prototype,{constructor:{value:subClass,enumerable:false,writable:true,configurable:true}});if(superClass)Object.setPrototypeOf?Object.setPrototypeOf(subClass,superClass):subClass.__proto__=superClass;}function _taggedTemplateLiteral(strings,raw){return Object.freeze(Object.defineProperties(strings,{raw:{value:Object.freeze(raw)}}));}/**
 * PropTypes imports
 *//**
 * Component imports
 *//**
 * Utilities/function imports
 *//**
 * Styled components
 */var CustomColumn=Object(__WEBPACK_IMPORTED_MODULE_2_styled_components__["default"])(__WEBPACK_IMPORTED_MODULE_1_scuid_x__["Column"])(_templateObject);var Container=__WEBPACK_IMPORTED_MODULE_2_styled_components__["default"].div(_templateObject2);var ProductCard=__WEBPACK_IMPORTED_MODULE_2_styled_components__["default"].div(_templateObject3);var ProductDetails=__WEBPACK_IMPORTED_MODULE_2_styled_components__["default"].div(_templateObject4);var ProductImage=__WEBPACK_IMPORTED_MODULE_2_styled_components__["default"].img(_templateObject5);var ProductTitle=Object(__WEBPACK_IMPORTED_MODULE_2_styled_components__["default"])(__WEBPACK_IMPORTED_MODULE_1_scuid_x__["Paragraph"])(_templateObject6);var ProductDescription=Object(__WEBPACK_IMPORTED_MODULE_2_styled_components__["default"])(__WEBPACK_IMPORTED_MODULE_1_scuid_x__["Paragraph"])(_templateObject7,function(_ref){var name=_ref.name;return name==='SoFi Money'&&'z-index: 2';});var ProductLink=Object(__WEBPACK_IMPORTED_MODULE_2_styled_components__["default"])(__WEBPACK_IMPORTED_MODULE_1_scuid_x__["HyperLink"])(_templateObject8);var FlexContainer=__WEBPACK_IMPORTED_MODULE_2_styled_components__["default"].span(_templateObject9);var RightFlex=__WEBPACK_IMPORTED_MODULE_2_styled_components__["default"].span(_templateObject10);var LeftFlex=RightFlex.extend(_templateObject11);/**
 * Breakpoints for the Cards
 */var BASE={medium:480,// two cards minimum width
large:768,// three cards
xlarge:992// four cards (current max)
};var Products=function(_Component){_inherits(Products,_Component);function Products(){var _ref2;var _temp,_this,_ret;_classCallCheck(this,Products);for(var _len=arguments.length,args=Array(_len),_key=0;_key<_len;_key++){args[_key]=arguments[_key];}return _ret=(_temp=(_this=_possibleConstructorReturn(this,(_ref2=Products.__proto__||Object.getPrototypeOf(Products)).call.apply(_ref2,[this].concat(args))),_this),_this.state={newProducts:[],open:false},_this.bankTile=function(banking){if(__WEBPACK_IMPORTED_MODULE_4_lodash_isEmpty___default()(banking))return{name:'BANK_WAITLIST'};if(banking.status==='NEW')return Object.assign({},banking,{name:'BANK'});return null;},_this.toggleOpen=function(){_this.setState({open:!_this.state.open});},_this.handleOnClick=function(eligibleProduct){// If the product is Personal Loan, check if the user has an account with us already
// and if the user does, check if he/she has made at least 3 payments
if(eligibleProduct.name==='PL'){if(!Object(__WEBPACK_IMPORTED_MODULE_11__utilities__["e" /* hasMetPaymentRequirements */])(eligibleProduct)){// User hasn't made 3 payments, open Modal to say so
// Prevent the user from applying for another PL
_this.toggleOpen();}}},_this.manualHide=function(cardName){return{Wealth:true,BANK:true,BANK_WAITLIST:true}[cardName];},_temp),_possibleConstructorReturn(_this,_ret);}_createClass(Products,[{key:'componentDidMount',value:function componentDidMount(){var _props=this.props,products=_props.products,banking=_props.banking,bankingLoaded=_props.bankingLoaded;var offerings=products;if(bankingLoaded){var bankObject=this.bankTile(banking);if(bankObject){offerings=__WEBPACK_IMPORTED_MODULE_5_lodash_cloneDeep___default()(products);offerings.push(bankObject);}}// Transform product into an Array that we can map over below in our render method
// We pass 'this' to the function because we setState in the function
Object(__WEBPACK_IMPORTED_MODULE_11__utilities__["d" /* handleTransformProducts */])(offerings,this);}},{key:'componentWillReceiveProps',value:function componentWillReceiveProps(_ref3){var bankingLoaded=_ref3.bankingLoaded,banking=_ref3.banking,products=_ref3.products;if(!this.props.bankingLoaded&&bankingLoaded||!__WEBPACK_IMPORTED_MODULE_6_lodash_isEqual___default()(products,this.props.products)){var offerings=__WEBPACK_IMPORTED_MODULE_5_lodash_cloneDeep___default()(products);var bankObject=this.bankTile(banking);if(bankObject)offerings.push(bankObject);Object(__WEBPACK_IMPORTED_MODULE_11__utilities__["d" /* handleTransformProducts */])(offerings,this);}}},{key:'render',value:function render(){var _this2=this;var customer=this.props.customer;var _state=this.state,newProducts=_state.newProducts,open=_state.open;return newProducts.filter(function(product){return product.eligibility.eligible===true;}).map(function(eligibleProduct){// don't return the wealth or banking cards if customer's age is less than 18
if(_this2.manualHide(eligibleProduct.name)&&!Object(__WEBPACK_IMPORTED_MODULE_11__utilities__["b" /* checkIsOfAge */])(customer))return'';return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(CustomColumn,{base:BASE,medium:6,large:4,xlarge:3,key:eligibleProduct.displayName},__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(Container,null,eligibleProduct.name==='PL'&&!Object(__WEBPACK_IMPORTED_MODULE_11__utilities__["e" /* hasMetPaymentRequirements */])(eligibleProduct)&&__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_10__payments_modal__["a" /* default */],{open:open,toggleOpen:_this2.toggleOpen}),__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(ProductCard,null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(ProductImage,{src:eligibleProduct.imageUrl,alt:eligibleProduct.displayName}),__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(ProductDetails,null,customer.corporateEmployer==='apple'?__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(ProductTitle,null,eligibleProduct.appleDisplayName?eligibleProduct.appleDisplayName:eligibleProduct.displayName):__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(ProductTitle,null,eligibleProduct.displayName),!eligibleProduct.eligibility.rates&&__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(ProductDescription,{name:eligibleProduct.displayName},eligibleProduct.description),eligibleProduct.eligibility.rates&&__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(ProductDescription,null,'Rates as low as ',Object(__WEBPACK_IMPORTED_MODULE_11__utilities__["a" /* calcBestRate */])(eligibleProduct.name,eligibleProduct.eligibility.rates),'%',__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('sup',null,eligibleProduct.footNote),eligibleProduct.name==='MORT'&&eligibleProduct.eligibility.rates.benefitAmount>0&&eligibleProduct.eligibility.rates.libor>0&&__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_0_react__["Fragment"],null,' with ',Object(__WEBPACK_IMPORTED_MODULE_11__utilities__["c" /* getApr */])(eligibleProduct.eligibility.rates),'% APR')))),__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(ProductLink,{href:eligibleProduct.name!=='PL'?eligibleProduct.eligibility.startUrl:Object(__WEBPACK_IMPORTED_MODULE_11__utilities__["e" /* hasMetPaymentRequirements */])(eligibleProduct)&&eligibleProduct.eligibility.startUrl||null,onClick:function onClick(){return _this2.handleOnClick(eligibleProduct);},'data-qa':'offerings-'+eligibleProduct.displayName.replace(/\s+/g,''),'data-mjs':'dashboard-product-card-'+eligibleProduct.displayName.replace(/\s+/g,'-')},__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(FlexContainer,null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(LeftFlex,null),__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('span',null,eligibleProduct.linkName),__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(RightFlex,null)))));});}}]);return Products;}(__WEBPACK_IMPORTED_MODULE_0_react__["Component"]);Products.propTypes={products:__WEBPACK_IMPORTED_MODULE_7__constants_prop_types_products_prop_types__["a" /* ProductsPropTypes */].isRequired,customer:__WEBPACK_IMPORTED_MODULE_8__constants_prop_types_customer_prop_types__["b" /* CustomerPropTypes */].isRequired,banking:__WEBPACK_IMPORTED_MODULE_9__constants_prop_types_banking_prop_types__["a" /* BankingPropTypes */].isRequired,bankingLoaded:__WEBPACK_IMPORTED_MODULE_3_prop_types___default.a.bool.isRequired};/* harmony default export */ __webpack_exports__["a"] = (Products);

/***/ }),
/* 1323 */
/***/ (function(module, exports, __webpack_require__) {

var baseIsEqual = __webpack_require__(1060);

/**
 * Performs a deep comparison between two values to determine if they are
 * equivalent.
 *
 * **Note:** This method supports comparing arrays, array buffers, booleans,
 * date objects, error objects, maps, numbers, `Object` objects, regexes,
 * sets, strings, symbols, and typed arrays. `Object` objects are compared
 * by their own, not inherited, enumerable properties. Functions and DOM
 * nodes are compared by strict equality, i.e. `===`.
 *
 * @static
 * @memberOf _
 * @since 0.1.0
 * @category Lang
 * @param {*} value The value to compare.
 * @param {*} other The other value to compare.
 * @returns {boolean} Returns `true` if the values are equivalent, else `false`.
 * @example
 *
 * var object = { 'a': 1 };
 * var other = { 'a': 1 };
 *
 * _.isEqual(object, other);
 * // => true
 *
 * object === other;
 * // => false
 */
function isEqual(value, other) {
  return baseIsEqual(value, other);
}

module.exports = isEqual;


/***/ }),
/* 1324 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__(0);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_prop_types__ = __webpack_require__(1);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_prop_types___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_prop_types__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_scuid_x__ = __webpack_require__(14);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_scuid_x___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_scuid_x__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__utilities_global_styles__ = __webpack_require__(80);
/**
 * Styled components
 */var PaymentsModal=function PaymentsModal(_ref){var open=_ref.open,toggleOpen=_ref.toggleOpen;return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["Modal"],{isOpen:open,onDismiss:toggleOpen,title:'It looks like you already have a personal loan with us.'},__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["Modal"].Body,null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_3__utilities_global_styles__["a" /* ResponsiveModalContent */],null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["Paragraph"],null,'Once you\'ve made at least three payments, you\'re welcome to apply for another.'))),__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["Modal"].Footer,null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["Button"],{'data-qa':'offers-closePaymentsModal',small:true,onClick:toggleOpen},'Close')));};PaymentsModal.propTypes={open:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.bool.isRequired,toggleOpen:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.func.isRequired};/* harmony default export */ __webpack_exports__["a"] = (PaymentsModal);

/***/ }),
/* 1325 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "e", function() { return hasMetPaymentRequirements; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "c", function() { return getApr; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return calcBestRate; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "d", function() { return handleTransformProducts; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "b", function() { return checkIsOfAge; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__(0);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__assets_img_icons_icon_56_wealth_svg__ = __webpack_require__(1326);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__assets_img_icons_icon_56_wealth_svg___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1__assets_img_icons_icon_56_wealth_svg__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__assets_img_icons_icon_56_loanPersonal_svg__ = __webpack_require__(1327);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__assets_img_icons_icon_56_loanPersonal_svg___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2__assets_img_icons_icon_56_loanPersonal_svg__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__assets_img_icons_icon_56_loanMortgage_svg__ = __webpack_require__(1328);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__assets_img_icons_icon_56_loanMortgage_svg___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_3__assets_img_icons_icon_56_loanMortgage_svg__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__assets_img_icons_icon_56_loanStudent_svg__ = __webpack_require__(1329);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__assets_img_icons_icon_56_loanStudent_svg___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_4__assets_img_icons_icon_56_loanStudent_svg__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__assets_img_icons_icon_56_loanParentPlus_svg__ = __webpack_require__(1330);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__assets_img_icons_icon_56_loanParentPlus_svg___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_5__assets_img_icons_icon_56_loanParentPlus_svg__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__assets_img_icons_icon_56_loanResidentRefi_svg__ = __webpack_require__(1331);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__assets_img_icons_icon_56_loanResidentRefi_svg___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_6__assets_img_icons_icon_56_loanResidentRefi_svg__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__assets_img_icons_icon_56_loanParent_svg__ = __webpack_require__(1332);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__assets_img_icons_icon_56_loanParent_svg___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_7__assets_img_icons_icon_56_loanParent_svg__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8__assets_img_icons_icon_56_banking_svg__ = __webpack_require__(1333);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8__assets_img_icons_icon_56_banking_svg___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_8__assets_img_icons_icon_56_banking_svg__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_9__utilities_global_styles__ = __webpack_require__(80);
var _templateObject=_taggedTemplateLiteral(['\n  display: block;\n  font-size: 0.9rem;\n  color: #757575;\n  font-weight: normal;\n  &:hover {\n    color: #1A7BB3;\n  }\n'],['\n  display: block;\n  font-size: 0.9rem;\n  color: #757575;\n  font-weight: normal;\n  &:hover {\n    color: #1A7BB3;\n  }\n']);function _taggedTemplateLiteral(strings,raw){return Object.freeze(Object.defineProperties(strings,{raw:{value:Object.freeze(raw)}}));}/**
 * Image imports
 *//**
 * Styled components
 */var BankingLink=__WEBPACK_IMPORTED_MODULE_9__utilities_global_styles__["d" /* ScuidLink */].extend(_templateObject);/**
 * Wealth is here outside because it is not tied to the products endpoint
 */var extraProducts=[{name:'Wealth',displayName:'Wealth Management',description:'No SoFi fees for borrowers',startUrl:'/wealth/',imageUrl:__WEBPACK_IMPORTED_MODULE_1__assets_img_icons_icon_56_wealth_svg___default.a,displayPosition:5,footNote:'',linkName:'Invest now',eligibility:{eligible:true,startUrl:'/wealth/'},mjsLabel:'wealth'}];/**
 * Handle products attributes update
 * @param {Object} prod Product/offering
 */var handleProductsAttrUpdate=function handleProductsAttrUpdate(prod){var product=prod;// Most of the products have the same linkName
// Those that don't (Banking), we update the property again in the switch-case
product.linkName='Apply now';switch(product.name){case'REFI':{// Name that users see for the product
product.displayName='Student Loan Refi';// If the user is an apple employee, we display this name instead
product.appleDisplayName='Apple Subsidized Student Loan Refi';// Superscript number (all products have it with the exception of Banking)
product.footNote='1';// What position/order the product should appear
product.displayPosition=1;// Image to be displayed
product.imageUrl=__WEBPACK_IMPORTED_MODULE_4__assets_img_icons_icon_56_loanStudent_svg___default.a;// Measurementjs tag to fire when user clicks on the product
product.mjsLabel='student loan refi';break;}case'PL':{product.displayName='Personal Loan';product.footNote='2';product.displayPosition=2;product.imageUrl=__WEBPACK_IMPORTED_MODULE_2__assets_img_icons_icon_56_loanPersonal_svg___default.a;product.mjsLabel='personal loan';break;}case'MORT':{product.displayName='Mortgage';product.footNote='3';product.displayPosition=3;product.imageUrl=__WEBPACK_IMPORTED_MODULE_3__assets_img_icons_icon_56_loanMortgage_svg___default.a;product.mjsLabel='mortgage';break;}case'DENTREFI':case'MEDREFI':{product.displayName='Resident Refi (MD/DDS)';product.footNote='1';product.displayPosition=6;product.imageUrl=__WEBPACK_IMPORTED_MODULE_6__assets_img_icons_icon_56_loanResidentRefi_svg___default.a;product.mjsLabel='residency refi';break;}case'PARENT':{product.displayName='Parent (In School)';product.footNote='4';product.displayPosition=7;product.imageUrl=__WEBPACK_IMPORTED_MODULE_7__assets_img_icons_icon_56_loanParent_svg___default.a;product.mjsLabel='parent';break;}case'PLUS':{product.displayName='Parent Plus Refi';product.appleDisplayName='Apple Subsidized Parent Plus Refi';product.footNote='1';product.displayPosition=8;product.imageUrl=__WEBPACK_IMPORTED_MODULE_5__assets_img_icons_icon_56_loanParentPlus_svg___default.a;product.mjsLabel='parent plus';break;}case'BANK':{product.displayName='SoFi Money';// We are adding description because the API does not give it to us
// Banking is unique in the sense its description links to its own page
product.description=__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(BankingLink,{'data-qa':'utilities-banking-link',href:'/money-waitlist/#2'},'Higher interest, no account fees and free ATMs',__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('sup',null,'*'));// Is the fourth one on the offerings list
product.displayPosition=4;product.imageUrl=__WEBPACK_IMPORTED_MODULE_8__assets_img_icons_icon_56_banking_svg___default.a;// change the linkName to 'Open an account'
product.linkName='Open an account';// add eligibility object (our filter looks for it in the render method)
product.eligibility={eligible:true,startUrl:'/my/money/setup/'};product.mjsLabel='money';break;}case'BANK_WAITLIST':{product.displayName='SoFi Money';product.description=__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(BankingLink,{'data-qa':'utilities-banking-waitlist-link',href:'/money-waitlist/#2'},'Higher interest, no account fees and free ATMs',__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('sup',null,'*'));product.displayPosition=9;product.imageUrl=__WEBPACK_IMPORTED_MODULE_8__assets_img_icons_icon_56_banking_svg___default.a;product.linkName='Join the waitlist';product.eligibility={eligible:true,startUrl:'/money-waitlist/'};product.mjsLabel='money-waitlist';break;}default:{product.eligibility={eligible:false,startUrl:'/dashboard'};}}return product;};/**
 * Check if Payments Modal needs to be shown onClick
 * @param {Object} product Our offering/product
 */var hasMetPaymentRequirements=function hasMetPaymentRequirements(product){return!product.eligibility||!product.eligibility.reasons||product.eligibility.reasons.filter(function(r){return r.code==='PAYMENTS';}).length<1;};/**
 * Get APR to display to member
 * @param {Object} rates Rates object inside Mortgage
 */var getApr=function getApr(rates){// let rates = product.eligibility.rates;
var number=rates.libor*100;var longRate=number.toPrecision(5);var wholeNumberPart=longRate.split('.')[0];var decimalPart=longRate.split('.')[1];// strip trailing 0s
while(decimalPart.charAt(decimalPart.length-1)==='0'&&decimalPart.length>2){decimalPart=decimalPart.substr(0,decimalPart.length-1);}if(decimalPart.length>3){decimalPart=''+ +Math.round(+decimalPart/10);}return String(+wholeNumberPart+'.'+decimalPart);};/**
 * Get us best rate to display to member
 * @param {String} product product/offering name
 * @param {Object} rates our rates object for the offering
 */var calcBestRate=function calcBestRate(product,rates){// let rates = product.eligibility.rates;
// rates come in as fractions, but need to be displayed as percents
// compare which min rate is actually the lowest
var minRate=rates.varMin&&rates.varMin<=rates.fixedMin?rates.varMin:rates.fixedMin;var benefitAmount=product==='MORT'?0:rates.benefitAmount;var bestRate=(minRate-benefitAmount)*100;// We need the rate to be displayed with either 2 or 3 decimal places, but without trailing 0s
// The rate has at most 2 digits before the decimal point, so we get the first 5 digits - ex 12.500
var longRate=bestRate.toPrecision(5);var wholeNumberPart=longRate.split('.')[0];var decimalPart=longRate.split('.')[1];// Then we make sure that in case we had 1.2345, we turn the decimal part into .234
var shortDecimal=String(decimalPart);// .toPrecision(3);;
// strip trailing 0s
while(shortDecimal.charAt(shortDecimal.length-1)==='0'&&shortDecimal.length>2){shortDecimal=shortDecimal.substr(0,shortDecimal.length-1);}// force to 2 digit length
if(shortDecimal.length>3){shortDecimal=''+ +Math.round(+shortDecimal/10);}return String(+wholeNumberPart+'.'+shortDecimal);};/**
 * Add needed product attributes that don't initially come with our products array
 * @param {Array} productsArray array of products/offerings from the API (with banking added to it)
 * @param {Object} self refers to 'this' from whatever scope it is called from
 */var handleTransformProducts=function handleTransformProducts(productsArray,self){var newProductsArray=[];productsArray.forEach(function(value){if(value){var newValue=handleProductsAttrUpdate(value);newProductsArray.push(newValue);}});// Push all the extra products not in the API
newProductsArray.push.apply(newProductsArray,extraProducts);// Filter out products without a display position and then sort it based on its displayPosition
var sortedArray=newProductsArray.filter(function(val){return Number(val.displayPosition);}).sort(function(a,b){return a.displayPosition>b.displayPosition;});self.setState({newProducts:sortedArray});};/**
 * Check if a customer is of age (> 18)
 * @param {Object} customer Our customer object from the API
 */var checkIsOfAge=function checkIsOfAge(customer){var date=new Date();if(date.getFullYear()-customer.dobYear<18){return false;}else if(date.getFullYear()-customer.dobYear===18&&date.getMonth()+1<customer.dobMonth.number){return false;}else if(date.getFullYear()-customer.dobYear===18&&date.getMonth()+1===customer.dobMonth.number&&date.getDate()<customer.dobDay){return false;}return true;};

/***/ }),
/* 1326 */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/media/icon-56_wealth.59170008.svg";

/***/ }),
/* 1327 */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/media/icon-56_loanPersonal.d63d60dc.svg";

/***/ }),
/* 1328 */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/media/icon-56_loanMortgage.a0d5982f.svg";

/***/ }),
/* 1329 */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/media/icon-56_loanStudent.3273bd50.svg";

/***/ }),
/* 1330 */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/media/icon-56_loanParentPlus.70d23751.svg";

/***/ }),
/* 1331 */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/media/icon-56_loanResidentRefi.83195ab0.svg";

/***/ }),
/* 1332 */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/media/icon-56_loanParent.9622e2b1.svg";

/***/ }),
/* 1333 */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/media/icon-56_banking.4d729200.svg";

/***/ }),
/* 1334 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__(0);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_styled_components__ = __webpack_require__(3);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_react_redux__ = __webpack_require__(95);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_prop_types__ = __webpack_require__(1);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_prop_types___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_3_prop_types__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_react_launch_darkly__ = __webpack_require__(1187);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_react_launch_darkly___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_4_react_launch_darkly__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__assets_img_EventsImage_1x_png__ = __webpack_require__(1335);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__assets_img_EventsImage_1x_png___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_5__assets_img_EventsImage_1x_png__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__assets_img_EventsImage_2x_png__ = __webpack_require__(1336);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__assets_img_EventsImage_2x_png___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_6__assets_img_EventsImage_2x_png__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__assets_img_SocialComparison_1x_png__ = __webpack_require__(1337);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__assets_img_SocialComparison_1x_png___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_7__assets_img_SocialComparison_1x_png__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8__assets_img_SocialComparison_2x_png__ = __webpack_require__(1338);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8__assets_img_SocialComparison_2x_png___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_8__assets_img_SocialComparison_2x_png__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_9__assets_img_CrossSellImage_SoFi_Mortgages_1x_jpg__ = __webpack_require__(1339);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_9__assets_img_CrossSellImage_SoFi_Mortgages_1x_jpg___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_9__assets_img_CrossSellImage_SoFi_Mortgages_1x_jpg__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_10__assets_img_CrossSellImage_SoFi_Mortgages_2x_jpg__ = __webpack_require__(1340);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_10__assets_img_CrossSellImage_SoFi_Mortgages_2x_jpg___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_10__assets_img_CrossSellImage_SoFi_Mortgages_2x_jpg__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_11__components_marketing___ = __webpack_require__(1341);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_12__utilities_global_styles__ = __webpack_require__(80);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_13__constants_prop_types_marketing_prop_types__ = __webpack_require__(1189);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_14__actions_marketing_cards_actions__ = __webpack_require__(1345);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_15__components_marketing_marketing_cards__ = __webpack_require__(1346);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_16__constants_launch_darkly_constants__ = __webpack_require__(1188);
var _createClass=function(){function defineProperties(target,props){for(var i=0;i<props.length;i++){var descriptor=props[i];descriptor.enumerable=descriptor.enumerable||false;descriptor.configurable=true;if("value"in descriptor)descriptor.writable=true;Object.defineProperty(target,descriptor.key,descriptor);}}return function(Constructor,protoProps,staticProps){if(protoProps)defineProperties(Constructor.prototype,protoProps);if(staticProps)defineProperties(Constructor,staticProps);return Constructor;};}();var _templateObject=_taggedTemplateLiteral(['\n  max-width: 1240px;\n  margin: 0px auto;\n  padding: 30px 20px 30px 20px;\n'],['\n  max-width: 1240px;\n  margin: 0px auto;\n  padding: 30px 20px 30px 20px;\n']),_templateObject2=_taggedTemplateLiteral(['\n  display: flex;\n  flex-wrap: wrap;\n  list-style-type: none;\n  margin: 0px;\n  padding: 0px;\n'],['\n  display: flex;\n  flex-wrap: wrap;\n  list-style-type: none;\n  margin: 0px;\n  padding: 0px;\n']),_templateObject3=_taggedTemplateLiteral(['\n  font-size: 0.88rem;\n  font-weight: 400;\n'],['\n  font-size: 0.88rem;\n  font-weight: 400;\n']);function _classCallCheck(instance,Constructor){if(!(instance instanceof Constructor)){throw new TypeError("Cannot call a class as a function");}}function _possibleConstructorReturn(self,call){if(!self){throw new ReferenceError("this hasn't been initialised - super() hasn't been called");}return call&&(typeof call==="object"||typeof call==="function")?call:self;}function _inherits(subClass,superClass){if(typeof superClass!=="function"&&superClass!==null){throw new TypeError("Super expression must either be null or a function, not "+typeof superClass);}subClass.prototype=Object.create(superClass&&superClass.prototype,{constructor:{value:subClass,enumerable:false,writable:true,configurable:true}});if(superClass)Object.setPrototypeOf?Object.setPrototypeOf(subClass,superClass):subClass.__proto__=superClass;}function _taggedTemplateLiteral(strings,raw){return Object.freeze(Object.defineProperties(strings,{raw:{value:Object.freeze(raw)}}));}/**
 * Image imports
 */// TODO remove images after successful release with LD
/**
 * Component imports
 */// TODO remove component after successful release with LD
/**
 * Styled components
 */// dashboard content card release dependencies
var Container=__WEBPACK_IMPORTED_MODULE_1_styled_components__["default"].div(_templateObject);var Marketing=__WEBPACK_IMPORTED_MODULE_1_styled_components__["default"].div(_templateObject2);var EventsLink=__WEBPACK_IMPORTED_MODULE_12__utilities_global_styles__["d" /* ScuidLink */].extend(_templateObject3);// holds all the marketing card with images
var photoCards=[{src:__WEBPACK_IMPORTED_MODULE_5__assets_img_EventsImage_1x_png___default.a,srcSet:__WEBPACK_IMPORTED_MODULE_5__assets_img_EventsImage_1x_png___default.a+' 1x, '+__WEBPACK_IMPORTED_MODULE_6__assets_img_EventsImage_2x_png___default.a+' 2x',altText:'SoFi Events',title:'Join us for an event in your city',description:__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_0_react__["Fragment"],null,'Discover happy hours, educational events, and member dinners happening in your neighborhood. Questions or concerns? Email',' ',__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(EventsLink,{'data-qa':'dashboard-marketing-events-link',href:'mailto:events@sofi.com'},'events@sofi.com')),linkText:'',// has been removed for now
linkHref:window.location.origin+'/events'},{src:__WEBPACK_IMPORTED_MODULE_7__assets_img_SocialComparison_1x_png___default.a,srcSet:__WEBPACK_IMPORTED_MODULE_7__assets_img_SocialComparison_1x_png___default.a+' 1x, '+__WEBPACK_IMPORTED_MODULE_8__assets_img_SocialComparison_2x_png___default.a+' 2x',altText:'Social Comparison',title:'Social Comparison',description:'See how you compare to other SoFi members.',linkText:'Compare now',linkHref:window.location.origin+'/b/social-compare'},{src:'https://unsplash.it/380/174',altText:'Apple Employer',title:'Apple Subsidized Student Loan Refi for Spouse or Domestic Partner',description:'Register your spouse or domestic partner to refinance his or her student loan with the Apple subsidy.',linkText:'+ Spouse/Domestic partner',linkHref:'/apple/spouse'},{src:__WEBPACK_IMPORTED_MODULE_9__assets_img_CrossSellImage_SoFi_Mortgages_1x_jpg___default.a,srcSet:__WEBPACK_IMPORTED_MODULE_9__assets_img_CrossSellImage_SoFi_Mortgages_1x_jpg___default.a+' 1x, '+__WEBPACK_IMPORTED_MODULE_10__assets_img_CrossSellImage_SoFi_Mortgages_2x_jpg___default.a+' 2x',altText:'choose your mortgage terms',title:'SoFi Mortgages',description:'10% down. 100% home. Discounted member rates. Mortgages up to $3M with no origination fees or borrower-paid private mortgage insurance.',linkText:'See your rate in 2 min',linkHref:'/mortgage-loan/'}];// holds the marketing with the links
var links=[{linkText:'See upcoming events',link:'https://www.sofi.com/events/'},{linkText:'Explore our blog',link:'https://www.sofi.com/blog/'},{linkText:'Contact Career Advisory Group',link:window.location.origin+'/career-assistance/'}];var MarketingContainer=function(_Component){_inherits(MarketingContainer,_Component);function MarketingContainer(){_classCallCheck(this,MarketingContainer);return _possibleConstructorReturn(this,(MarketingContainer.__proto__||Object.getPrototypeOf(MarketingContainer)).apply(this,arguments));}_createClass(MarketingContainer,[{key:'componentDidMount',value:function componentDidMount(){var loadMarketingCards=this.props.loadMarketingCards;loadMarketingCards();}},{key:'render',value:function render(){var _this2=this;var _props=this.props,marketingCards=_props.marketingCards,marketingCardsLoaded=_props.marketingCardsLoaded;return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(Container,null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(Marketing,null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_4_react_launch_darkly__["FeatureFlag"],{flagKey:__WEBPACK_IMPORTED_MODULE_16__constants_launch_darkly_constants__["b" /* FEATURE_FLAG_DASHBOARD_CONTENT_CARDS */],renderFeatureCallback:function renderFeatureCallback(){return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_15__components_marketing_marketing_cards__["a" /* default */],{marketingCards:marketingCards,marketingCardsLoaded:marketingCardsLoaded});},renderDefaultCallback:function renderDefaultCallback(){return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_11__components_marketing___["a" /* default */],Object.assign({photoCards:photoCards,links:links},_this2.props));}})));}}]);return MarketingContainer;}(__WEBPACK_IMPORTED_MODULE_0_react__["Component"]);MarketingContainer.propTypes={marketingCards:__WEBPACK_IMPORTED_MODULE_13__constants_prop_types_marketing_prop_types__["b" /* MarketingCardPropType */].isRequired,loadMarketingCards:__WEBPACK_IMPORTED_MODULE_3_prop_types___default.a.func.isRequired,marketingCardsLoaded:__WEBPACK_IMPORTED_MODULE_3_prop_types___default.a.bool.isRequired};var mapStateToProps=function mapStateToProps(state){return{marketingCards:state.marketingCardsReducer.marketingCards.data,marketingCardsLoaded:state.marketingCardsReducer.marketingCards.loaded};};var mapDispatchToProps=function mapDispatchToProps(dispatch){return{loadMarketingCards:function loadMarketingCards(){return dispatch(Object(__WEBPACK_IMPORTED_MODULE_14__actions_marketing_cards_actions__["a" /* getMarketingCards */])());}};};/* harmony default export */ __webpack_exports__["a"] = (Object(__WEBPACK_IMPORTED_MODULE_2_react_redux__["b" /* connect */])(mapStateToProps,mapDispatchToProps)(MarketingContainer));

/***/ }),
/* 1335 */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/media/EventsImage@1x.8e9e039d.png";

/***/ }),
/* 1336 */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/media/EventsImage@2x.608661bf.png";

/***/ }),
/* 1337 */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/media/SocialComparison@1x.c7c31f60.png";

/***/ }),
/* 1338 */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/media/SocialComparison@2x.79def1be.png";

/***/ }),
/* 1339 */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/media/CrossSellImage-SoFi-Mortgages@1x.89300870.jpg";

/***/ }),
/* 1340 */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/media/CrossSellImage-SoFi-Mortgages@2x.b75fbe04.jpg";

/***/ }),
/* 1341 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__marketing__ = __webpack_require__(1342);
/* harmony reexport (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return __WEBPACK_IMPORTED_MODULE_0__marketing__["a"]; });


/***/ }),
/* 1342 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__(0);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__constants_prop_types_marketing_prop_types__ = __webpack_require__(1189);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__constants_prop_types_customer_prop_types__ = __webpack_require__(124);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__marketing_photo_card__ = __webpack_require__(1343);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__marketing_links_card__ = __webpack_require__(1344);
/**
 * PropTypes imports
 *//**
 * Component imports
 */var Marketing=function Marketing(_ref){var photoCards=_ref.photoCards,links=_ref.links,customer=_ref.customer;return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_0_react__["Fragment"],null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_3__marketing_photo_card__["a" /* default */],{photoCards:photoCards,customer:customer}),__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_4__marketing_links_card__["a" /* default */],{links:links}));};/* eslint react/no-typos: 0 */Marketing.propTypes={photoCards:__WEBPACK_IMPORTED_MODULE_1__constants_prop_types_marketing_prop_types__["c" /* PhotoCardsPropType */].isRequired,links:__WEBPACK_IMPORTED_MODULE_1__constants_prop_types_marketing_prop_types__["a" /* LinkCardPropType */].isRequired,customer:__WEBPACK_IMPORTED_MODULE_2__constants_prop_types_customer_prop_types__["b" /* CustomerPropTypes */].isRequired};/* harmony default export */ __webpack_exports__["a"] = (Marketing);

/***/ }),
/* 1343 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__(0);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_styled_components__ = __webpack_require__(3);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_scuid_x__ = __webpack_require__(14);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_scuid_x___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_scuid_x__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_react_router_dom__ = __webpack_require__(188);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__constants_prop_types_marketing_prop_types__ = __webpack_require__(1189);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__constants_prop_types_customer_prop_types__ = __webpack_require__(124);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__utilities_global_styles__ = __webpack_require__(80);
var _templateObject=_taggedTemplateLiteral(['\n  padding-left: 5px;\n  padding-right: 5px;\n'],['\n  padding-left: 5px;\n  padding-right: 5px;\n']),_templateObject2=_taggedTemplateLiteral(['\n  position: relative;\n  background: white;\n  min-height: 20rem;\n  height: 100%;\n'],['\n  position: relative;\n  background: white;\n  min-height: 20rem;\n  height: 100%;\n']),_templateObject3=_taggedTemplateLiteral(['\n  width: 100%;\n  height: auto;\n  border-radius: 4px 4px 0 0;\n  max-width: 100%;\n  margin: 0px;\n'],['\n  width: 100%;\n  height: auto;\n  border-radius: 4px 4px 0 0;\n  max-width: 100%;\n  margin: 0px;\n']),_templateObject4=_taggedTemplateLiteral(['\n  padding: 1rem 1.5rem 2.7rem;\n'],['\n  padding: 1rem 1.5rem 2.7rem;\n']),_templateObject5=_taggedTemplateLiteral(['\n  color: #757575;\n  font-size: 0.88rem;\n  padding: 0;\n'],['\n  color: #757575;\n  font-size: 0.88rem;\n  padding: 0;\n']),_templateObject6=_taggedTemplateLiteral(['\n  position: absolute;\n  bottom: 0.6rem;\n  border-bottom: 2px solid;\n  padding-bottom: 0.25rem;\n'],['\n  position: absolute;\n  bottom: 0.6rem;\n  border-bottom: 2px solid;\n  padding-bottom: 0.25rem;\n']),_templateObject7=_taggedTemplateLiteral(['\n  color: #1A7BB3;\n  font-weight: 500;\n  &:hover {\n    color: #103955;\n  }\n  @media only screen and (min-width: 20em) {\n    font-size: calc(0.875rem + 0.125 * ((100vw - 20em) / 48));\n  }\n  @media only screen and (min-width: 68em) {\n    font-size: 1rem;\n  }\n'],['\n  color: #1A7BB3;\n  font-weight: 500;\n  &:hover {\n    color: #103955;\n  }\n  @media only screen and (min-width: 20em) {\n    font-size: calc(0.875rem + 0.125 * ((100vw - 20em) / 48));\n  }\n  @media only screen and (min-width: 68em) {\n    font-size: 1rem;\n  }\n']);function _taggedTemplateLiteral(strings,raw){return Object.freeze(Object.defineProperties(strings,{raw:{value:Object.freeze(raw)}}));}/**
 * PropTypes imports
 *//**
 * Styled Components
 */var CustomColumn=Object(__WEBPACK_IMPORTED_MODULE_1_styled_components__["default"])(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["Column"])(_templateObject);var Container=__WEBPACK_IMPORTED_MODULE_1_styled_components__["default"].div(_templateObject2);var Image=__WEBPACK_IMPORTED_MODULE_1_styled_components__["default"].img(_templateObject3);var Details=__WEBPACK_IMPORTED_MODULE_1_styled_components__["default"].div(_templateObject4);var Description=Object(__WEBPACK_IMPORTED_MODULE_1_styled_components__["default"])(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["Paragraph"])(_templateObject5);var MarketingLink=__WEBPACK_IMPORTED_MODULE_6__utilities_global_styles__["d" /* ScuidLink */].extend(_templateObject6);var RouterLink=MarketingLink.withComponent(__WEBPACK_IMPORTED_MODULE_3_react_router_dom__["b" /* Link */]).extend(_templateObject7);var MarketingPhotoCard=function MarketingPhotoCard(_ref){var photoCards=_ref.photoCards,customer=_ref.customer;return photoCards.map(function(value){if(value.altText==='Apple Employer'&&customer.corporateEmployer!=='apple'){return'';}return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(CustomColumn,{medium:6,large:4,key:value.title},__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(Container,null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(Image,Object.assign({src:value.src},value.srcSet?{srcSet:value.srcSet}:{},{alt:value.altText})),__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(Details,null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["SubheadFour"],null,value.title),__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(Description,null,value.description),customer.corporateEmployer==='apple'?__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(RouterLink,{to:value.linkHref,'data-qa':'marketing-photo-card-'+value.title},value.linkText):__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(MarketingLink,{href:value.linkHref,'data-qa':'marketing-photo-card-'+value.title,'data-mjs':'dashboard-photo-card-'+value.title},value.linkText))));});};MarketingPhotoCard.propTypes={photoCards:__WEBPACK_IMPORTED_MODULE_4__constants_prop_types_marketing_prop_types__["c" /* PhotoCardsPropType */].isRequired,customer:__WEBPACK_IMPORTED_MODULE_5__constants_prop_types_customer_prop_types__["b" /* CustomerPropTypes */].isRequired};/* harmony default export */ __webpack_exports__["a"] = (MarketingPhotoCard);

/***/ }),
/* 1344 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__(0);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_styled_components__ = __webpack_require__(3);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_scuid_x__ = __webpack_require__(14);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_scuid_x___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_scuid_x__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__constants_prop_types_marketing_prop_types__ = __webpack_require__(1189);
var _templateObject=_taggedTemplateLiteral(['\n  padding-left: 5px;\n  padding-right: 5px;\n'],['\n  padding-left: 5px;\n  padding-right: 5px;\n']),_templateObject2=_taggedTemplateLiteral(['\n  position: relative;\n  background: white;\n  min-height: 20rem;\n  padding-top: 2rem;\n  padding-left: 1.6rem;\n  height: 100%;\n'],['\n  position: relative;\n  background: white;\n  min-height: 20rem;\n  padding-top: 2rem;\n  padding-left: 1.6rem;\n  height: 100%;\n']),_templateObject3=_taggedTemplateLiteral(['\n  text-decoration: none;\n  &:hover {\n    text-decoration: none;\n  }\n'],['\n  text-decoration: none;\n  &:hover {\n    text-decoration: none;\n  }\n']);function _taggedTemplateLiteral(strings,raw){return Object.freeze(Object.defineProperties(strings,{raw:{value:Object.freeze(raw)}}));}/**
 * PropTypes imports
 *//**
 * Styled Components
 */var CustomColumn=Object(__WEBPACK_IMPORTED_MODULE_1_styled_components__["default"])(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["Column"])(_templateObject);var Container=__WEBPACK_IMPORTED_MODULE_1_styled_components__["default"].div(_templateObject2);var MarketingLink=Object(__WEBPACK_IMPORTED_MODULE_1_styled_components__["default"])(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["HyperLink"])(_templateObject3);var MarketingLinksCard=function MarketingLinksCard(_ref){var links=_ref.links;return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(CustomColumn,{medium:6,large:4},__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(Container,null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["SubheadFour"],null,'Other Links'),links.map(function(value){return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["Paragraph"],{key:value.link},__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(MarketingLink,{href:value.link,'data-qa':'marketing-links-card-'+value.linkText,'data-mjs':'dashboard-marketing-'+value.linkText},value.linkText));})));};MarketingLinksCard.propTypes={links:__WEBPACK_IMPORTED_MODULE_3__constants_prop_types_marketing_prop_types__["a" /* LinkCardPropType */]};MarketingLinksCard.defaultProps={links:null};/* harmony default export */ __webpack_exports__["a"] = (MarketingLinksCard);

/***/ }),
/* 1345 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return getMarketingCards; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_babel_runtime_regenerator__ = __webpack_require__(122);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_babel_runtime_regenerator___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_babel_runtime_regenerator__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__utilities_api_action_helpers__ = __webpack_require__(93);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__constants__ = __webpack_require__(79);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__constants_marketing_cards_constants__ = __webpack_require__(342);
var _this=this;function _asyncToGenerator(fn){return function(){var gen=fn.apply(this,arguments);return new Promise(function(resolve,reject){function step(key,arg){try{var info=gen[key](arg);var value=info.value;}catch(error){reject(error);return;}if(info.done){resolve(value);}else{return Promise.resolve(value).then(function(value){step("next",value);},function(err){step("throw",err);});}}return step("next");});};}// TODO update this to piggy back off call that is being made to get account cards. (we can make one call to get all cards)
var getMarketingCards=function getMarketingCards(){return function(){var _ref=_asyncToGenerator(/*#__PURE__*/__WEBPACK_IMPORTED_MODULE_0_babel_runtime_regenerator___default.a.mark(function _callee(dispatch){return __WEBPACK_IMPORTED_MODULE_0_babel_runtime_regenerator___default.a.wrap(function _callee$(_context){while(1){switch(_context.prev=_context.next){case 0:Object(__WEBPACK_IMPORTED_MODULE_1__utilities_api_action_helpers__["b" /* performGet */])(dispatch,__WEBPACK_IMPORTED_MODULE_2__constants__["c" /* DASHBOARD_CONTENT_URL */]+'/group/dashboardCards',{},__WEBPACK_IMPORTED_MODULE_3__constants_marketing_cards_constants__["a" /* GET_MARKETING_CARDS */]);case 1:case'end':return _context.stop();}}},_callee,_this);}));return function(_x){return _ref.apply(this,arguments);};}();};

/***/ }),
/* 1346 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__(0);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_scuid_x__ = __webpack_require__(14);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_scuid_x___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_scuid_x__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_prop_types__ = __webpack_require__(1);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_prop_types___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_prop_types__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__constants_prop_types_marketing_prop_types__ = __webpack_require__(1189);
var MarketingCards=function MarketingCards(_ref){var marketingCards=_ref.marketingCards,marketingCardsLoaded=_ref.marketingCardsLoaded;return marketingCardsLoaded&&__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_1_scuid_x__["FlexBox"],{direction:'row',justifyContent:'space-between'},marketingCards.map(function(c){var card=c.data;var callToAction=card.callToAction1;return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_1_scuid_x__["Card"],{rounded:true,boxShadow:true,backgroundColor:'White',style:{width:'49.5%'}},__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_1_scuid_x__["CardImage"],null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('img',{src:card.imgSrc,alt:card.altText,srcSet:card.imgSrcSet})),__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_1_scuid_x__["CardContent"],null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_1_scuid_x__["SubheadTwo"],null,card.title),__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_1_scuid_x__["Paragraph"],null,card.description),callToAction&&__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_1_scuid_x__["HyperLink"],{link:callToAction.url,target:'_blank',style:{display:'block',marginBottom:'25px'}},callToAction.text)));}));};MarketingCards.propTypes={marketingCards:__WEBPACK_IMPORTED_MODULE_3__constants_prop_types_marketing_prop_types__["b" /* MarketingCardPropType */].isRequired,// eslint-disable-line react/no-typos
marketingCardsLoaded:__WEBPACK_IMPORTED_MODULE_2_prop_types___default.a.bool.isRequired};/* harmony default export */ __webpack_exports__["a"] = (MarketingCards);

/***/ }),
/* 1347 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_babel_runtime_regenerator__ = __webpack_require__(122);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_babel_runtime_regenerator___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_babel_runtime_regenerator__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_react__ = __webpack_require__(0);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_prop_types__ = __webpack_require__(1);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_prop_types___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_prop_types__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_react_redux__ = __webpack_require__(95);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_lodash_debounce__ = __webpack_require__(327);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_lodash_debounce___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_4_lodash_debounce__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5_query_string__ = __webpack_require__(1190);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5_query_string___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_5_query_string__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6_react_router_prop_types__ = __webpack_require__(317);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6_react_router_prop_types___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_6_react_router_prop_types__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__actions_state_actions__ = __webpack_require__(1177);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8__actions_customer_actions__ = __webpack_require__(326);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_9__actions_application_actions__ = __webpack_require__(1181);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_10__actions_cosign_error_actions__ = __webpack_require__(1221);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_11__components_modals__ = __webpack_require__(1348);
var _createClass=function(){function defineProperties(target,props){for(var i=0;i<props.length;i++){var descriptor=props[i];descriptor.enumerable=descriptor.enumerable||false;descriptor.configurable=true;if("value"in descriptor)descriptor.writable=true;Object.defineProperty(target,descriptor.key,descriptor);}}return function(Constructor,protoProps,staticProps){if(protoProps)defineProperties(Constructor.prototype,protoProps);if(staticProps)defineProperties(Constructor,staticProps);return Constructor;};}();function _asyncToGenerator(fn){return function(){var gen=fn.apply(this,arguments);return new Promise(function(resolve,reject){function step(key,arg){try{var info=gen[key](arg);var value=info.value;}catch(error){reject(error);return;}if(info.done){resolve(value);}else{return Promise.resolve(value).then(function(value){step("next",value);},function(err){step("throw",err);});}}return step("next");});};}function _classCallCheck(instance,Constructor){if(!(instance instanceof Constructor)){throw new TypeError("Cannot call a class as a function");}}function _possibleConstructorReturn(self,call){if(!self){throw new ReferenceError("this hasn't been initialised - super() hasn't been called");}return call&&(typeof call==="object"||typeof call==="function")?call:self;}function _inherits(subClass,superClass){if(typeof superClass!=="function"&&superClass!==null){throw new TypeError("Super expression must either be null or a function, not "+typeof superClass);}subClass.prototype=Object.create(superClass&&superClass.prototype,{constructor:{value:subClass,enumerable:false,writable:true,configurable:true}});if(superClass)Object.setPrototypeOf?Object.setPrototypeOf(subClass,superClass):subClass.__proto__=superClass;}/**
 * Action imports
 *//**
 * Component imports
 */var ModalsContainer=function(_Component){_inherits(ModalsContainer,_Component);function ModalsContainer(){var _ref,_this2=this;var _temp,_this,_ret;_classCallCheck(this,ModalsContainer);for(var _len=arguments.length,args=Array(_len),_key=0;_key<_len;_key++){args[_key]=arguments[_key];}return _ret=(_temp=(_this=_possibleConstructorReturn(this,(_ref=ModalsContainer.__proto__||Object.getPrototypeOf(ModalsContainer)).call.apply(_ref,[this].concat(args))),_this),_this.state={appParams:{action:'',appId:null,appType:'',reason:'',applicantCount:0}},_this.updateAppParams=function(appParams){return _this.setState({appParams:appParams});},_this.loadStates=function(){var loadStates=_this.props.loadStates;loadStates();},_this.updateState=__WEBPACK_IMPORTED_MODULE_4_lodash_debounce___default()(function(){var _ref2=_asyncToGenerator(/*#__PURE__*/__WEBPACK_IMPORTED_MODULE_0_babel_runtime_regenerator___default.a.mark(function _callee(newState,toggleModal){var updateState;return __WEBPACK_IMPORTED_MODULE_0_babel_runtime_regenerator___default.a.wrap(function _callee$(_context){while(1){switch(_context.prev=_context.next){case 0:updateState=_this.props.updateState;_context.next=3;return updateState(newState);case 3:toggleModal();case 4:case'end':return _context.stop();}}},_callee,_this2);}));return function(_x,_x2){return _ref2.apply(this,arguments);};}(),200,{trailing:true}),_this.retryService=__WEBPACK_IMPORTED_MODULE_4_lodash_debounce___default()(function(){var _ref3=_asyncToGenerator(/*#__PURE__*/__WEBPACK_IMPORTED_MODULE_0_babel_runtime_regenerator___default.a.mark(function _callee2(values,setErrors,setSubmitting,toggleModal){var appParams,data,retryApplication,applicationRetrySuccess;return __WEBPACK_IMPORTED_MODULE_0_babel_runtime_regenerator___default.a.wrap(function _callee2$(_context2){while(1){switch(_context2.prev=_context2.next){case 0:appParams=_this.state.appParams;data={appId:appParams.appId,appType:appParams.appType,coSsnRequired:appParams.applicantCount>1,ssn:values.ssn,coSsn:values.coSsn};retryApplication=_this.props.retryApplication;_context2.next=5;return retryApplication(data,setErrors);case 5:/**
       * Check if the POST request was successful
       */applicationRetrySuccess=_this.props.applicationRetrySuccess;if(applicationRetrySuccess){// Close Modal
toggleModal();}else{// Enable submit button
setSubmitting(false);}case 7:case'end':return _context2.stop();}}},_callee2,_this2);}));return function(_x3,_x4,_x5,_x6){return _ref3.apply(this,arguments);};}(),200,{trailing:true}),_this.updateCosigner=__WEBPACK_IMPORTED_MODULE_4_lodash_debounce___default()(function(){var _ref4=_asyncToGenerator(/*#__PURE__*/__WEBPACK_IMPORTED_MODULE_0_babel_runtime_regenerator___default.a.mark(function _callee3(values,mapServerSideErrorsToFormik,setSubmitting,toggleModal){var appParams,data,_this$props,updateCosigner,loadApplications,cosignerUpdated;return __WEBPACK_IMPORTED_MODULE_0_babel_runtime_regenerator___default.a.wrap(function _callee3$(_context3){while(1){switch(_context3.prev=_context3.next){case 0:appParams=_this.state.appParams;data={appId:appParams.appId,cosignerFirstName:values.cosignerFirstName,cosignerLastName:values.cosignerLastName,cosignerEmail:values.cosignerEmail};_this$props=_this.props,updateCosigner=_this$props.updateCosigner,loadApplications=_this$props.loadApplications;_context3.next=5;return updateCosigner(data,mapServerSideErrorsToFormik);case 5:/**
       * Check if the POST request was successful
       */cosignerUpdated=_this.props.cosignerUpdated;if(cosignerUpdated){// Refresh applications
loadApplications();// Close modal
toggleModal();}else{// Enable submit button
setSubmitting(false);}case 7:case'end':return _context3.stop();}}},_callee3,_this2);}));return function(_x7,_x8,_x9,_x10){return _ref4.apply(this,arguments);};}(),200,{trailing:true}),_temp),_possibleConstructorReturn(_this,_ret);}_createClass(ModalsContainer,[{key:'componentDidMount',value:function componentDidMount(){/**
     * Parse QueryParams to see if/which modal needs to be shown
     */var parsedQueryString=__WEBPACK_IMPORTED_MODULE_5_query_string___default.a.parse(this.props.location.search);if(parsedQueryString.action){var action=parsedQueryString.action,appId=parsedQueryString.appId,appType=parsedQueryString.appType,applicantCount=parsedQueryString.applicantCount,reason=parsedQueryString.reason;var appParams={action:action,appType:appType,reason:reason,appId:Number(appId)||null,applicantCount:parseInt(applicantCount,10)||0};this.updateAppParams(appParams);}}// To avoid using setState in componentDidMount (react/no-did-mount-set-state)
/**
   * Load all the states (USA)
   *//**
   * Update customer's state of residence
   *//**
   * Common retryService POST
   * Used by ssn-missing, and mortgage-credit modals
   *//**
   * Update customer's cosigner information
   */},{key:'render',value:function render(){var appParams=this.state.appParams;return __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_11__components_modals__["a" /* default */],Object.assign({},this.props,{appParams:appParams,loadStates:this.loadStates,updateState:this.updateState,retryService:this.retryService,updateCosigner:this.updateCosigner}));}}]);return ModalsContainer;}(__WEBPACK_IMPORTED_MODULE_1_react__["Component"]);ModalsContainer.propTypes={loadStates:__WEBPACK_IMPORTED_MODULE_2_prop_types___default.a.func.isRequired,updateState:__WEBPACK_IMPORTED_MODULE_2_prop_types___default.a.func.isRequired,location:__WEBPACK_IMPORTED_MODULE_6_react_router_prop_types___default.a.location.isRequired};var mapStateToProps=function mapStateToProps(state){return{states:state.statesReducer.states.data,statesLoaded:state.statesReducer.states.loaded,cosignerUpdated:state.customerReducer.cosignerUpdated,applicationRetrySuccess:state.applicationReducer.applicationRetrySuccess,waitForCosignError:state.globalErrorReducer.waitForCosignError};};var mapDispatchToProps=function mapDispatchToProps(dispatch){return{loadStates:function loadStates(){return dispatch(Object(__WEBPACK_IMPORTED_MODULE_7__actions_state_actions__["a" /* getStates */])());},updateState:function updateState(newState){return dispatch(Object(__WEBPACK_IMPORTED_MODULE_8__actions_customer_actions__["f" /* postCustomerState */])(newState));},retryApplication:function retryApplication(appObj,setErrors){return dispatch(Object(__WEBPACK_IMPORTED_MODULE_9__actions_application_actions__["e" /* postApplicationRetry */])(appObj,setErrors));},updateCosigner:function updateCosigner(data,setErrors){return dispatch(Object(__WEBPACK_IMPORTED_MODULE_8__actions_customer_actions__["e" /* postCustomerCosign */])(data,setErrors));},loadApplications:function loadApplications(){return dispatch(Object(__WEBPACK_IMPORTED_MODULE_9__actions_application_actions__["a" /* getApplications */])());},setWaitForCosigner:function setWaitForCosigner(){return dispatch(Object(__WEBPACK_IMPORTED_MODULE_10__actions_cosign_error_actions__["b" /* setWaitCosignerError */])());},clearWaitForCosigner:function clearWaitForCosigner(){return dispatch(Object(__WEBPACK_IMPORTED_MODULE_10__actions_cosign_error_actions__["a" /* clearWaitCosignerError */])());}};};/* harmony default export */ __webpack_exports__["a"] = (Object(__WEBPACK_IMPORTED_MODULE_3_react_redux__["b" /* connect */])(mapStateToProps,mapDispatchToProps)(ModalsContainer));

/***/ }),
/* 1348 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__modals__ = __webpack_require__(1349);
/* harmony reexport (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return __WEBPACK_IMPORTED_MODULE_0__modals__["a"]; });


/***/ }),
/* 1349 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__(0);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_prop_types__ = __webpack_require__(1);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_prop_types___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_prop_types__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__utilities_measurementjs_helpers__ = __webpack_require__(331);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__constants_prop_types_customer_prop_types__ = __webpack_require__(124);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__constants_prop_types_states_prop_types__ = __webpack_require__(1170);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__constants_prop_types_modals_prop_types__ = __webpack_require__(1182);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__constants_prop_types_application_prop_types__ = __webpack_require__(1168);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__constants_prop_types_wait_for_cosign_error_prop_types__ = __webpack_require__(1204);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8__state_missing__ = __webpack_require__(1350);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_9__ssn_missing__ = __webpack_require__(1351);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_10__frozen_credit__ = __webpack_require__(1352);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_11__mortgage_credit__ = __webpack_require__(1353);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_12__declined__ = __webpack_require__(1354);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_13__declined_cosign__ = __webpack_require__(1355);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_14__voluntary_job_loss__ = __webpack_require__(1356);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_15__no_employment__ = __webpack_require__(1357);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_16__self_employment__ = __webpack_require__(1358);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_17__no_loans_qualify__ = __webpack_require__(1359);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_18__mortgage_frozen_credit__ = __webpack_require__(1360);
var _createClass=function(){function defineProperties(target,props){for(var i=0;i<props.length;i++){var descriptor=props[i];descriptor.enumerable=descriptor.enumerable||false;descriptor.configurable=true;if("value"in descriptor)descriptor.writable=true;Object.defineProperty(target,descriptor.key,descriptor);}}return function(Constructor,protoProps,staticProps){if(protoProps)defineProperties(Constructor.prototype,protoProps);if(staticProps)defineProperties(Constructor,staticProps);return Constructor;};}();function _classCallCheck(instance,Constructor){if(!(instance instanceof Constructor)){throw new TypeError("Cannot call a class as a function");}}function _possibleConstructorReturn(self,call){if(!self){throw new ReferenceError("this hasn't been initialised - super() hasn't been called");}return call&&(typeof call==="object"||typeof call==="function")?call:self;}function _inherits(subClass,superClass){if(typeof superClass!=="function"&&superClass!==null){throw new TypeError("Super expression must either be null or a function, not "+typeof superClass);}subClass.prototype=Object.create(superClass&&superClass.prototype,{constructor:{value:subClass,enumerable:false,writable:true,configurable:true}});if(superClass)Object.setPrototypeOf?Object.setPrototypeOf(subClass,superClass):subClass.__proto__=superClass;}/**
 * Measurementjs
 *//**
 * PropTypes imports
 *//**
 * Component imports
 */var eventForAppType=function eventForAppType(appType){if(appType){if(['REFI','PLUS','MEDREFI','DENTREFI'].includes(appType.toUpperCase())){return'refiDeclinedSubmit';}else if(appType.toUpperCase()==='PARENT'){return'parentDeclinedSubmit';}else if(appType.toUpperCase()==='MORT'){return'mortDeclinedSubmit';}}return null;};var Modals=function(_Component){_inherits(Modals,_Component);function Modals(){var _ref;var _temp,_this,_ret;_classCallCheck(this,Modals);for(var _len=arguments.length,args=Array(_len),_key=0;_key<_len;_key++){args[_key]=arguments[_key];}return _ret=(_temp=(_this=_possibleConstructorReturn(this,(_ref=Modals.__proto__||Object.getPrototypeOf(Modals)).call.apply(_ref,[this].concat(args))),_this),_this.state={open:true},_this.toggleOpen=function(){_this.setState({open:!_this.state.open});},_temp),_possibleConstructorReturn(_this,_ret);}_createClass(Modals,[{key:'componentDidMount',value:function componentDidMount(){var customer=this.props.customer;if(!customer.state){this.props.loadStates();}}},{key:'render',value:function render(){var _props=this.props,customer=_props.customer,appParams=_props.appParams,retryService=_props.retryService,triggerAlert=_props.triggerAlert,setWaitForCosigner=_props.setWaitForCosigner,waitForCosignError=_props.waitForCosignError;var open=this.state.open;// Get the action
var action=appParams.action;if(!customer.state){var _props2=this.props,statesLoaded=_props2.statesLoaded,states=_props2.states,updateState=_props2.updateState;return statesLoaded&&__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_8__state_missing__["a" /* default */],{isOpen:open,toggleOpen:this.toggleOpen,states:states,updateState:updateState});}switch(action){case'ssn':{return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_9__ssn_missing__["a" /* default */],{isOpen:open,toggleOpen:this.toggleOpen,customer:customer,appParams:appParams,retryService:retryService,triggerAlert:triggerAlert});}case'frozenCredit':{return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_10__frozen_credit__["a" /* default */],{isOpen:open,toggleOpen:this.toggleOpen,appParams:appParams});}case'mortCredit':{return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_11__mortgage_credit__["a" /* default */],{isOpen:open,toggleOpen:this.toggleOpen,customer:customer,appParams:appParams,retryService:retryService});}case'mortFrozenCredit':{return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_18__mortgage_frozen_credit__["a" /* default */],{isOpen:open,toggleOpen:this.toggleOpen});}case'declined':{var appId=appParams.appId,appType=appParams.appType,reason=appParams.reason;var event=eventForAppType(appType);if(event){Object(__WEBPACK_IMPORTED_MODULE_2__utilities_measurementjs_helpers__["a" /* fireEvent */])({event:event,mjs_app_id:appId,mjs_app_type:appType});}if(appId&&['parentUnqualifiedCosignerNeeded','refiUnqualifiedCosignerNeeded','plusUnqualifiedCosignerNeeded'].indexOf(reason)>=0){var applicationsList=this.props.applications.filter(function(app){return!(app.type==='CONTRIB'||app.type==='COSIGN');});var isTrue=applicationsList.some(function(app){return appId===app.id;});if(isTrue){var waitingForCosigner=applicationsList.some(function(app){return appId===app.id&&app.status==='WFCosigner';});if(waitingForCosigner){if(!waitForCosignError.hasBeenDisplayed||waitForCosignError.hasBeenClosed){setWaitForCosigner();}return'';}var updateCosigner=this.props.updateCosigner;return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_13__declined_cosign__["a" /* default */],{isOpen:open,toggleOpen:this.toggleOpen,customer:customer,appParams:appParams,updateCosigner:updateCosigner});}}else if(reason){return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_12__declined__["a" /* default */],{isOpen:open,toggleOpen:this.toggleOpen,customer:customer,appParams:appParams});}return'';}case'upp':{var _reason=appParams.reason;if(_reason==='voluntary')return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_14__voluntary_job_loss__["a" /* default */],{isOpen:open,toggleOpen:this.toggleOpen});else if(_reason==='noEmployment')return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_15__no_employment__["a" /* default */],{isOpen:open,toggleOpen:this.toggleOpen});else if(_reason==='selfEmployment')return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_16__self_employment__["a" /* default */],{isOpen:open,toggleOpen:this.toggleOpen});else if(_reason==='noEligibleLoans')return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_17__no_loans_qualify__["a" /* default */],{isOpen:open,toggleOpen:this.toggleOpen});// No modals need to be shown
return'';}default:// No modals need to be shown
return'';}}}]);return Modals;}(__WEBPACK_IMPORTED_MODULE_0_react__["Component"]);Modals.propTypes={customer:__WEBPACK_IMPORTED_MODULE_3__constants_prop_types_customer_prop_types__["b" /* CustomerPropTypes */].isRequired,loadStates:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.func.isRequired,statesLoaded:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.bool,states:__WEBPACK_IMPORTED_MODULE_4__constants_prop_types_states_prop_types__["a" /* StatesPropTypes */].isRequired,updateState:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.func.isRequired,appParams:__WEBPACK_IMPORTED_MODULE_5__constants_prop_types_modals_prop_types__["a" /* QueryParamPropTypes */].isRequired,retryService:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.func.isRequired,updateCosigner:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.func.isRequired,applications:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.arrayOf(__WEBPACK_IMPORTED_MODULE_6__constants_prop_types_application_prop_types__["a" /* ApplicationPropType */]).isRequired,triggerAlert:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.func.isRequired,setWaitForCosigner:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.func.isRequired,waitForCosignError:__WEBPACK_IMPORTED_MODULE_7__constants_prop_types_wait_for_cosign_error_prop_types__["a" /* WaitForCosignerErrorPropTypes */].isRequired};Modals.defaultProps={statesLoaded:false};/* harmony default export */ __webpack_exports__["a"] = (Modals);

/***/ }),
/* 1350 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__(0);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_prop_types__ = __webpack_require__(1);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_prop_types___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_prop_types__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_scuid_x__ = __webpack_require__(14);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_scuid_x___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_scuid_x__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_formik__ = __webpack_require__(1084);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_yup__ = __webpack_require__(1083);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_yup___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_4_yup__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__constants_prop_types_states_prop_types__ = __webpack_require__(1170);
/**
 * PropTypes imports
 */var StateMissing=function StateMissing(_ref){var isOpen=_ref.isOpen,toggleOpen=_ref.toggleOpen,states=_ref.states,values=_ref.values,errors=_ref.errors,setFieldValue=_ref.setFieldValue,handleSubmit=_ref.handleSubmit,touched=_ref.touched,isSubmitting=_ref.isSubmitting;return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["Modal"],{isOpen:isOpen,onDismiss:toggleOpen,title:'Select State of Residence',minWidth:window.innerWidth>=768?750:0},__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["Modal"].Body,null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["Paragraph"],null,'The products SoFi can offer you may vary based on state law. Please provide your state of residence to continue.'),__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_3_formik__["a" /* Form */],{'data-qa':'state-missing-form'},__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["DropDown"],{name:'selectedState',value:values.selectedState,onChange:function onChange(e){return setFieldValue('selectedState',e.target.value);},options:states,qa:'state-dropdown',label:'State',errorText:touched.selectedState&&errors.selectedState}))),__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["Modal"].Footer,null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["Button"],{'data-qa':'state-close',small:true,onClick:toggleOpen},'Cancel'),__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["Button"],{'data-qa':'state-submit',small:true,onClick:handleSubmit,disabled:isSubmitting},'Save')));};/* eslint react/no-typos: 0 */StateMissing.propTypes={isOpen:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.bool.isRequired,toggleOpen:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.func.isRequired,values:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.object.isRequired,// eslint-disable-line react/forbid-prop-types
errors:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.objectOf(__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.string).isRequired,setFieldValue:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.func.isRequired,handleSubmit:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.func.isRequired,touched:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.objectOf(__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.bool).isRequired,isSubmitting:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.bool.isRequired,states:__WEBPACK_IMPORTED_MODULE_5__constants_prop_types_states_prop_types__["a" /* StatesPropTypes */].isRequired};/* harmony default export */ __webpack_exports__["a"] = (Object(__WEBPACK_IMPORTED_MODULE_3_formik__["b" /* withFormik */])({mapPropsToValues:function mapPropsToValues(){return{selectedState:''};},validationSchema:function validationSchema(){return __WEBPACK_IMPORTED_MODULE_4_yup___default.a.object().shape({selectedState:__WEBPACK_IMPORTED_MODULE_4_yup___default.a.string().required('Please select a State')});},handleSubmit:function handleSubmit(values,_ref2){var props=_ref2.props;/**
     * Convert the selected state back to the original object
     * original = { alpha2: UT , name: Utah }, values.selectedState = 'UT'
     */var data=props.states.find(function(element){return element.alpha2===values.selectedState;});props.updateState(data,props.toggleOpen);}})(StateMissing));

/***/ }),
/* 1351 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__(0);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_prop_types__ = __webpack_require__(1);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_prop_types___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_prop_types__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_scuid_x__ = __webpack_require__(14);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_scuid_x___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_scuid_x__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_formik__ = __webpack_require__(1084);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_yup__ = __webpack_require__(1083);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_yup___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_4_yup__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5_react_redux_i18n__ = __webpack_require__(70);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5_react_redux_i18n___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_5_react_redux_i18n__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6_styled_components__ = __webpack_require__(3);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__constants_prop_types_modals_prop_types__ = __webpack_require__(1182);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8__utilities_api_action_helpers__ = __webpack_require__(93);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_9__shared_styles__ = __webpack_require__(1175);
var _templateObject=_taggedTemplateLiteral(['\n  margin-top: -1.4rem;\n'],['\n  margin-top: -1.4rem;\n']);function _taggedTemplateLiteral(strings,raw){return Object.freeze(Object.defineProperties(strings,{raw:{value:Object.freeze(raw)}}));}/**
 * PropTypes imports
 *//**
 * Utilities/function imports
 *//**
 * Styled Components
 */var FormikForm=Object(__WEBPACK_IMPORTED_MODULE_6_styled_components__["default"])(__WEBPACK_IMPORTED_MODULE_3_formik__["a" /* Form */])(_templateObject);var SsnMissing=function SsnMissing(_ref){var isOpen=_ref.isOpen,toggleOpen=_ref.toggleOpen,values=_ref.values,errors=_ref.errors,handleChange=_ref.handleChange,handleSubmit=_ref.handleSubmit,touched=_ref.touched,isSubmitting=_ref.isSubmitting,appParams=_ref.appParams,triggerAlert=_ref.triggerAlert;var coSsnRequired=appParams.applicantCount>1;var reason='nocreditSSN';// exists in the translation file
return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["Modal"],{isOpen:isOpen,onDismiss:toggleOpen,title:'',minWidth:window.innerWidth>=768?750:0},__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["Modal"].Body,null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(FormikForm,{'data-qa':'ssn-missing-form'},__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_9__shared_styles__["a" /* ReasonContainer */],{dangerouslySetInnerHTML:{__html:__WEBPACK_IMPORTED_MODULE_5_react_redux_i18n__["I18n"].t(reason)}}),__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["SsnInput"],{id:'ssn',name:'ssn',halfWidth:window.innerWidth<540,quarterWidth:window.innerWidth>=540,label:'SSN',placeholder:'***-**-****',onChange:handleChange,value:values.ssn,errorText:touched.ssn&&errors.ssn,qa:'ssn-input'}),coSsnRequired?__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["SsnInput"],{id:'coSsn',name:'coSsn',halfWidth:window.innerWidth<540,quarterWidth:window.innerWidth>=540,label:'CO-SSN',placeholder:'***-**-****',onChange:handleChange,value:values.coSsn,errorText:touched.coSsn&&errors.coSsn,qa:'cossn-input'}):'')),__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["Modal"].Footer,null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["Button"],{'data-qa':'ssn-close',small:true,onClick:function onClick(){toggleOpen();triggerAlert();}},'Cancel'),__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["Button"],{'data-qa':'ssn-submit',small:true,onClick:handleSubmit,disabled:isSubmitting},'Save')));};/* eslint react/no-typos: 0 */SsnMissing.propTypes={isOpen:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.bool.isRequired,toggleOpen:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.func.isRequired,values:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.object.isRequired,// eslint-disable-line react/forbid-prop-types
errors:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.objectOf(__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.string).isRequired,handleChange:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.func.isRequired,handleSubmit:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.func.isRequired,touched:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.objectOf(__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.bool).isRequired,isSubmitting:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.bool.isRequired,appParams:__WEBPACK_IMPORTED_MODULE_7__constants_prop_types_modals_prop_types__["a" /* QueryParamPropTypes */].isRequired,triggerAlert:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.func.isRequired};/* harmony default export */ __webpack_exports__["a"] = (Object(__WEBPACK_IMPORTED_MODULE_3_formik__["b" /* withFormik */])({mapPropsToValues:function mapPropsToValues(){return{ssn:'',coSsn:''};},validationSchema:function validationSchema(props){return __WEBPACK_IMPORTED_MODULE_4_yup___default.a.lazy(function(values){return __WEBPACK_IMPORTED_MODULE_4_yup___default.a.object().shape({ssn:__WEBPACK_IMPORTED_MODULE_4_yup___default.a.string().required('SSN is a required field').min(9,'Must be 9 characters'),coSsn:props.appParams.applicantCount>1?__WEBPACK_IMPORTED_MODULE_4_yup___default.a.string().required('CO-SSN is a required field').min(9,'Must be 9 characters').notOneOf([values.ssn],'CO-SSN cannot be the same as SSN'):__WEBPACK_IMPORTED_MODULE_4_yup___default.a.string().nullable()});});},handleSubmit:function handleSubmit(values,_ref2){var props=_ref2.props,setErrors=_ref2.setErrors,setSubmitting=_ref2.setSubmitting;/**
     * values -> { ssn: '', coSsn: '' }
     */props.retryService(values,function(serverResponse){return setErrors(Object(__WEBPACK_IMPORTED_MODULE_8__utilities_api_action_helpers__["a" /* mapServerSideErrorsToFormikErrors */])(serverResponse));},setSubmitting,props.toggleOpen);}})(SsnMissing));

/***/ }),
/* 1352 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__(0);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_prop_types__ = __webpack_require__(1);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_prop_types___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_prop_types__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_scuid_x__ = __webpack_require__(14);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_scuid_x___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_scuid_x__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_styled_components__ = __webpack_require__(3);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_react_redux_i18n__ = __webpack_require__(70);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_react_redux_i18n___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_4_react_redux_i18n__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__constants_prop_types_modals_prop_types__ = __webpack_require__(1182);
var _templateObject=_taggedTemplateLiteral(['\n  margin-top: -1.4rem;\n'],['\n  margin-top: -1.4rem;\n']);function _taggedTemplateLiteral(strings,raw){return Object.freeze(Object.defineProperties(strings,{raw:{value:Object.freeze(raw)}}));}/**
 * PropTypes imports
 *//**
 * Styled Components
 */var Content=__WEBPACK_IMPORTED_MODULE_3_styled_components__["default"].div(_templateObject);var FrozenCredit=function FrozenCredit(_ref){var isOpen=_ref.isOpen,toggleOpen=_ref.toggleOpen,appParams=_ref.appParams;var hasCoborrowers=appParams.applicantCount>1;return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["Modal"],{isOpen:isOpen,onDismiss:toggleOpen,title:'',minWidth:window.innerWidth>=768?750:0},__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["Modal"].Body,null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(Content,null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["Paragraph"],null,'Unfortunately, it looks like',hasCoborrowers?__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_0_react__["Fragment"],null,' the credit files for both you and your co-borrower are '):__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_0_react__["Fragment"],null,' your credit file is '),'frozen.'),__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["Paragraph"],null,'We are unfortunately unable to access',hasCoborrowers?__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_0_react__["Fragment"],null,' the credit files for both you and your co-borrower '):__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_0_react__["Fragment"],null,' your credit report details '),'until the \'freeze\' is lifted.',hasCoborrowers?__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_0_react__["Fragment"],null,' You and your co-borrower '):__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_0_react__["Fragment"],null,' You '),'can ask Experian to temporarily remove a freeze by visiting',' ',__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["HyperLink"],{'data-qa':'frozen-credit-lift-freeze-link',href:'http://www.experian.com/blogs/ask-experian/how-to-lift-a-security-freeze/',title:'How to Lift a Security Freeze'},'here'),'.'),__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["Paragraph"],null,'Once the freeze has been lifted, please return to this page to continue your application. You can always \'re-freeze\' your report after your application is completed. If you ',hasCoborrowers&&__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_0_react__["Fragment"],null,'or your co-borrower '),'have not requested that Experian \'freeze\' your credit, give us a call at ',__WEBPACK_IMPORTED_MODULE_4_react_redux_i18n__["I18n"].t('sofiCustomerServicePhoneReg'),', so we can try to help.'))),__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["Modal"].Footer,null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["Button"],{'data-qa':'frozen-ssn-close',small:true,secondary:true,onClick:toggleOpen},'Close')));};/* eslint react/no-typos: 0 */FrozenCredit.propTypes={isOpen:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.bool.isRequired,toggleOpen:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.func.isRequired,appParams:__WEBPACK_IMPORTED_MODULE_5__constants_prop_types_modals_prop_types__["a" /* QueryParamPropTypes */].isRequired};/* harmony default export */ __webpack_exports__["a"] = (FrozenCredit);

/***/ }),
/* 1353 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__(0);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_prop_types__ = __webpack_require__(1);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_prop_types___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_prop_types__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_scuid_x__ = __webpack_require__(14);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_scuid_x___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_scuid_x__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_formik__ = __webpack_require__(1084);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_yup__ = __webpack_require__(1083);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_yup___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_4_yup__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5_styled_components__ = __webpack_require__(3);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__constants_prop_types_modals_prop_types__ = __webpack_require__(1182);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__utilities_api_action_helpers__ = __webpack_require__(93);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8__shared_styles__ = __webpack_require__(1175);
var _templateObject=_taggedTemplateLiteral(['\n  margin-top: -1.4rem;\n'],['\n  margin-top: -1.4rem;\n']);function _taggedTemplateLiteral(strings,raw){return Object.freeze(Object.defineProperties(strings,{raw:{value:Object.freeze(raw)}}));}/**
 * PropTypes imports
 *//**
 * Utilities/function imports
 *//**
 * Styled Components
 */var FormikForm=Object(__WEBPACK_IMPORTED_MODULE_5_styled_components__["default"])(__WEBPACK_IMPORTED_MODULE_3_formik__["a" /* Form */])(_templateObject);var MortgageCredit=function MortgageCredit(_ref){var isOpen=_ref.isOpen,toggleOpen=_ref.toggleOpen,values=_ref.values,errors=_ref.errors,handleChange=_ref.handleChange,handleSubmit=_ref.handleSubmit,touched=_ref.touched,isSubmitting=_ref.isSubmitting,appParams=_ref.appParams;var coSsnRequired=appParams.applicantCount>1;return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["Modal"],{isOpen:isOpen,onDismiss:toggleOpen,title:'',minWidth:window.innerWidth>=768?750:0},__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["Modal"].Body,null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(FormikForm,{'data-qa':'mortgage-credit-form'},__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_8__shared_styles__["a" /* ReasonContainer */],null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('p',null,'Unfortunately we\'ve been unable to obtain your credit information from the information provided. This sometimes happens if:'),__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('ul',null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('li',null,'You\'ve recently moved or changed your name'),__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('li',null,'You have a typo in the name or address in your SoFi application'),__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('li',null,'You requested that the credit bureau \'freeze\' your credit report')),__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('p',null,'If you\'ve requested that one or more of the credit bureaus \'freeze\' your report, you can remove the freeze from your ',__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('a',{'data-qa':'mortgage-credit-experian-freeze-link',href:'https://www.experian.com/freeze/center.html'},'Experian'),',',' ',__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('a',{'data-qa':'mortgage-credit-equifax-freeze-link',href:'https://www.freeze.equifax.com/Freeze/jsp/SFF_PersonalIDInfo.jsp'},'Equifax'),', and',' ',__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('a',{'data-qa':'mortgage-credit-transunion-freeze-link',href:'https://freeze.transunion.com/sf/securityFreeze/landingPage.jsp'},'Transunion'),'credit reports.\xA0We\'ll be unable to access your credit report and give you your rate if there is a freeze on your report.'),__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('p',null,'If you\'re certain that your application details and credit bureau information are correct, please provide your social security number (SSN) below. This will not impact your credit score, but it will allow SoFi to access your credit report, which helps us understand your track record of meeting financial obligations and offer low rates to our borrowers.'),__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('p',null,'We\'ll never share your SSN, and we use internationally recognized security standards, regulations, and industry-based best practices to keep it safe.')),__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["SsnInput"],{id:'ssn',name:'ssn',halfWidth:window.innerWidth<540,quarterWidth:window.innerWidth>=540,label:'SSN',placeholder:'***-**-****',onChange:handleChange,value:values.ssn,errorText:touched.ssn&&errors.ssn,qa:'mortgage-input'}),coSsnRequired?__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["SsnInput"],{id:'coSsn',name:'coSsn',halfWidth:window.innerWidth<540,quarterWidth:window.innerWidth>=540,label:'CO-SSN',placeholder:'***-**-****',onChange:handleChange,value:values.coSsn,errorText:touched.coSsn&&errors.coSsn,qa:'mortgage-input'}):'')),__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["Modal"].Footer,null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["Button"],{'data-qa':'mortgage-close',small:true,onClick:toggleOpen},'Cancel'),__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["Button"],{'data-qa':'mortgage-submit',small:true,onClick:handleSubmit,disabled:isSubmitting},'Save')));};/* eslint react/no-typos: 0 */MortgageCredit.propTypes={isOpen:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.bool.isRequired,toggleOpen:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.func.isRequired,values:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.object.isRequired,// eslint-disable-line react/forbid-prop-types
errors:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.objectOf(__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.string).isRequired,handleChange:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.func.isRequired,handleSubmit:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.func.isRequired,touched:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.objectOf(__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.bool).isRequired,isSubmitting:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.bool.isRequired,appParams:__WEBPACK_IMPORTED_MODULE_6__constants_prop_types_modals_prop_types__["a" /* QueryParamPropTypes */].isRequired};/* harmony default export */ __webpack_exports__["a"] = (Object(__WEBPACK_IMPORTED_MODULE_3_formik__["b" /* withFormik */])({mapPropsToValues:function mapPropsToValues(){return{ssn:'',coSsn:''};},validationSchema:function validationSchema(props){return __WEBPACK_IMPORTED_MODULE_4_yup___default.a.object().shape({ssn:__WEBPACK_IMPORTED_MODULE_4_yup___default.a.string().required('SSN is a required field').min(9,'Must be 9 characters'),coSsn:props.appParams.applicantCount>1?__WEBPACK_IMPORTED_MODULE_4_yup___default.a.string().required('CO-SSN is a required field').min(9,'Must be 9 characters'):__WEBPACK_IMPORTED_MODULE_4_yup___default.a.string().nullable()});},handleSubmit:function handleSubmit(values,_ref2){var props=_ref2.props,setErrors=_ref2.setErrors,setSubmitting=_ref2.setSubmitting;/**
     * values -> { ssn: '', coSsn: '' }
     */props.retryService(values,function(serverResponse){return setErrors(Object(__WEBPACK_IMPORTED_MODULE_7__utilities_api_action_helpers__["a" /* mapServerSideErrorsToFormikErrors */])(serverResponse));},setSubmitting,props.toggleOpen);}})(MortgageCredit));

/***/ }),
/* 1354 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__(0);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_prop_types__ = __webpack_require__(1);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_prop_types___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_prop_types__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_scuid_x__ = __webpack_require__(14);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_scuid_x___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_scuid_x__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_react_redux_i18n__ = __webpack_require__(70);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_react_redux_i18n___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_3_react_redux_i18n__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__constants_prop_types_modals_prop_types__ = __webpack_require__(1182);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__constants_prop_types_customer_prop_types__ = __webpack_require__(124);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__utilities__ = __webpack_require__(1225);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__shared_styles__ = __webpack_require__(1175);
var _templateObject=_taggedTemplateLiteral(['\n  margin-top: -1.4rem;\n'],['\n  margin-top: -1.4rem;\n']);function _taggedTemplateLiteral(strings,raw){return Object.freeze(Object.defineProperties(strings,{raw:{value:Object.freeze(raw)}}));}/**
 * PropTypes imports
 *//**
 * Utilities/function imports
 *//**
 * Styled Components
 */var Container=__WEBPACK_IMPORTED_MODULE_7__shared_styles__["a" /* ReasonContainer */].extend(_templateObject);var Declined=function Declined(_ref){var isOpen=_ref.isOpen,toggleOpen=_ref.toggleOpen,appParams=_ref.appParams,customer=_ref.customer;var reason=appParams.reason;// reason maps to a key in the translation file
/**
   * We pass in the contact information to the I18n translation
   */var contacts=Object(__WEBPACK_IMPORTED_MODULE_6__utilities__["a" /* setupContacts */])(customer);var contactPhone=contacts.contactPhone,contactEmail=contacts.contactEmail;return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["Modal"],{isOpen:isOpen,onDismiss:toggleOpen,title:'',minWidth:window.innerWidth>=768?750:0},__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["Modal"].Body,null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(Container,{dangerouslySetInnerHTML:{__html:__WEBPACK_IMPORTED_MODULE_3_react_redux_i18n__["I18n"].t(reason,{contactPhone:contactPhone,contactEmail:contactEmail})}})),__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["Modal"].Footer,null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["Button"],{'data-qa':'declined-close',small:true,secondary:true,onClick:toggleOpen},'Close')));};/* eslint react/no-typos: 0 */Declined.propTypes={isOpen:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.bool.isRequired,toggleOpen:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.func.isRequired,appParams:__WEBPACK_IMPORTED_MODULE_4__constants_prop_types_modals_prop_types__["a" /* QueryParamPropTypes */].isRequired,customer:__WEBPACK_IMPORTED_MODULE_5__constants_prop_types_customer_prop_types__["b" /* CustomerPropTypes */].isRequired};/* harmony default export */ __webpack_exports__["a"] = (Declined);

/***/ }),
/* 1355 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__(0);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_prop_types__ = __webpack_require__(1);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_prop_types___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_prop_types__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_scuid_x__ = __webpack_require__(14);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_scuid_x___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_scuid_x__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_formik__ = __webpack_require__(1084);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_yup__ = __webpack_require__(1083);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_yup___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_4_yup__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5_react_redux_i18n__ = __webpack_require__(70);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5_react_redux_i18n___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_5_react_redux_i18n__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6_styled_components__ = __webpack_require__(3);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__constants_prop_types_modals_prop_types__ = __webpack_require__(1182);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8__constants_prop_types_customer_prop_types__ = __webpack_require__(124);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_9__utilities_api_action_helpers__ = __webpack_require__(93);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_10__utilities__ = __webpack_require__(1225);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_11__shared_styles__ = __webpack_require__(1175);
var _templateObject=_taggedTemplateLiteral(['\n  margin-top: -1.4rem;\n'],['\n  margin-top: -1.4rem;\n']);function _taggedTemplateLiteral(strings,raw){return Object.freeze(Object.defineProperties(strings,{raw:{value:Object.freeze(raw)}}));}/**
 * PropTypes imports
 *//**
 * Utilities/function imports
 *//**
 * Styled Components
 */var FormikForm=Object(__WEBPACK_IMPORTED_MODULE_6_styled_components__["default"])(__WEBPACK_IMPORTED_MODULE_3_formik__["a" /* Form */])(_templateObject);var DeclinedCosign=function DeclinedCosign(_ref){var isOpen=_ref.isOpen,toggleOpen=_ref.toggleOpen,values=_ref.values,errors=_ref.errors,handleChange=_ref.handleChange,handleSubmit=_ref.handleSubmit,touched=_ref.touched,isSubmitting=_ref.isSubmitting,appParams=_ref.appParams,customer=_ref.customer;var reason=appParams.reason;// reason maps to a key in the translation file
/**
   * We pass in the contact information to the I18n translation
   */var contacts=Object(__WEBPACK_IMPORTED_MODULE_10__utilities__["a" /* setupContacts */])(customer);var contactPhone=contacts.contactPhone,contactEmail=contacts.contactEmail;return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["Modal"],{isOpen:isOpen,onDismiss:toggleOpen,title:'',minWidth:window.innerWidth>=768?750:0},__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["Modal"].Body,null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(FormikForm,{'data-qa':'declined-cosign-form'},__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_11__shared_styles__["a" /* ReasonContainer */],{dangerouslySetInnerHTML:{__html:__WEBPACK_IMPORTED_MODULE_5_react_redux_i18n__["I18n"].t(reason,{contactPhone:contactPhone,contactEmail:contactEmail})}}),__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["TextInput"],{id:'cosignerFirstName',name:'cosignerFirstName',label:'Co-Signer First Name',type:'text',qa:'declinedCoSign-cosignerFirstName',value:values.cosignerFirstName,onChange:handleChange,errorText:touched.cosignerFirstName&&errors.cosignerFirstName}),__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["TextInput"],{id:'cosignerLastName',name:'cosignerLastName',label:'Co-Signer Last Name',type:'text',qa:'declinedCoSign-cosignerLastName',value:values.cosignerLastName,onChange:handleChange,errorText:touched.cosignerLastName&&errors.cosignerLastName}),__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["EmailInput"],{id:'cosignerEmail',name:'cosignerEmail',label:'Co-Signer Email',type:'text',qa:'declinedCoSign-cosignerEmail',value:values.cosignerEmail,onChange:handleChange,errorText:touched.cosignerEmail&&errors.cosignerEmail||errors.globalErrorCode==='cosigner.error'&&errors.globalError}))),__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["Modal"].Footer,null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["Button"],{'data-qa':'declinedCoSign-close',small:true,onClick:toggleOpen},'Cancel'),__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["Button"],{'data-qa':'declinedCoSign-submit',small:true,onClick:handleSubmit,disabled:isSubmitting},'Save')));};/* eslint react/no-typos: 0 */DeclinedCosign.propTypes={isOpen:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.bool.isRequired,toggleOpen:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.func.isRequired,values:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.object.isRequired,// eslint-disable-line react/forbid-prop-types
errors:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.objectOf(__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.string).isRequired,handleChange:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.func.isRequired,handleSubmit:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.func.isRequired,touched:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.objectOf(__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.bool).isRequired,isSubmitting:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.bool.isRequired,appParams:__WEBPACK_IMPORTED_MODULE_7__constants_prop_types_modals_prop_types__["a" /* QueryParamPropTypes */].isRequired,customer:__WEBPACK_IMPORTED_MODULE_8__constants_prop_types_customer_prop_types__["b" /* CustomerPropTypes */].isRequired};/* harmony default export */ __webpack_exports__["a"] = (Object(__WEBPACK_IMPORTED_MODULE_3_formik__["b" /* withFormik */])({mapPropsToValues:function mapPropsToValues(){return{cosignerFirstName:'',cosignerLastName:'',cosignerEmail:''};},validationSchema:function validationSchema(){return __WEBPACK_IMPORTED_MODULE_4_yup___default.a.object().shape({cosignerFirstName:__WEBPACK_IMPORTED_MODULE_4_yup___default.a.string().required("Please enter the cosigner's first name."),cosignerLastName:__WEBPACK_IMPORTED_MODULE_4_yup___default.a.string().required("Please enter the cosigner's last name."),cosignerEmail:__WEBPACK_IMPORTED_MODULE_4_yup___default.a.string().email('Invalid Cosigner Email.').required('Email is required!')});},handleSubmit:function handleSubmit(values,_ref2){var props=_ref2.props,setErrors=_ref2.setErrors,setSubmitting=_ref2.setSubmitting;/**
     * values -> { cosignerFirstName: '', cosignerLastName: '', cosignerEmail: '' }
     */props.updateCosigner(values,function(serverResponse){return setErrors(Object(__WEBPACK_IMPORTED_MODULE_9__utilities_api_action_helpers__["a" /* mapServerSideErrorsToFormikErrors */])(serverResponse));},setSubmitting,props.toggleOpen);}})(DeclinedCosign));

/***/ }),
/* 1356 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__(0);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_prop_types__ = __webpack_require__(1);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_prop_types___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_prop_types__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_scuid_x__ = __webpack_require__(14);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_scuid_x___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_scuid_x__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__shared_styles__ = __webpack_require__(1175);
var _templateObject=_taggedTemplateLiteral(['\n  margin-top: -1.4rem;\n'],['\n  margin-top: -1.4rem;\n']);function _taggedTemplateLiteral(strings,raw){return Object.freeze(Object.defineProperties(strings,{raw:{value:Object.freeze(raw)}}));}/**
 * Styled Components
 */var Container=__WEBPACK_IMPORTED_MODULE_3__shared_styles__["a" /* ReasonContainer */].extend(_templateObject);var VoluntaryJobLoss=function VoluntaryJobLoss(_ref){var isOpen=_ref.isOpen,toggleOpen=_ref.toggleOpen;return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["Modal"],{isOpen:isOpen,onDismiss:toggleOpen,title:'',minWidth:window.innerWidth>=768?750:0},__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["Modal"].Body,null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(Container,null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["Paragraph"],null,'You have self-identified as having lost your job voluntarily.'),__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["Paragraph"],null,'Unfortunately, the Unemployment Protection Program does not apply to those who have voluntarily left work.'))),__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["Modal"].Footer,null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["Button"],{'data-qa':'voluntaryJobLoss-close',small:true,secondary:true,onClick:toggleOpen},'Close')));};/* eslint react/no-typos: 0 */VoluntaryJobLoss.propTypes={isOpen:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.bool.isRequired,toggleOpen:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.func.isRequired};/* harmony default export */ __webpack_exports__["a"] = (VoluntaryJobLoss);

/***/ }),
/* 1357 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__(0);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_prop_types__ = __webpack_require__(1);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_prop_types___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_prop_types__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_scuid_x__ = __webpack_require__(14);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_scuid_x___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_scuid_x__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__shared_styles__ = __webpack_require__(1175);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__utilities_global_styles__ = __webpack_require__(80);
var _templateObject=_taggedTemplateLiteral(['\n  margin-top: -1.4rem;\n'],['\n  margin-top: -1.4rem;\n']);function _taggedTemplateLiteral(strings,raw){return Object.freeze(Object.defineProperties(strings,{raw:{value:Object.freeze(raw)}}));}/**
 * Styled Components
 */var Container=__WEBPACK_IMPORTED_MODULE_3__shared_styles__["a" /* ReasonContainer */].extend(_templateObject);var NoEmployment=function NoEmployment(_ref){var isOpen=_ref.isOpen,toggleOpen=_ref.toggleOpen;return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["Modal"],{isOpen:isOpen,onDismiss:toggleOpen,title:'',minWidth:window.innerWidth>=768?750:0},__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["Modal"].Body,null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(Container,null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["Paragraph"],null,'Unfortunately it looks like you have not saved any employment information with us currently.'),__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["Paragraph"],null,'If you would like to be a part of the Unemployment Protection Program, please update your employment information',' ',__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_4__utilities_global_styles__["c" /* RouterLink */],{'data-qa':'no-employment-profile-link',to:'/profile',onClick:toggleOpen},'here'),'. You must also have a funded loan with SoFi in order to continue.'))),__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["Modal"].Footer,null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["Button"],{'data-qa':'noEmployment-close',small:true,secondary:true,onClick:toggleOpen},'Close')));};/* eslint react/no-typos: 0 */NoEmployment.propTypes={isOpen:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.bool.isRequired,toggleOpen:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.func.isRequired};/* harmony default export */ __webpack_exports__["a"] = (NoEmployment);

/***/ }),
/* 1358 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__(0);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_prop_types__ = __webpack_require__(1);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_prop_types___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_prop_types__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_scuid_x__ = __webpack_require__(14);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_scuid_x___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_scuid_x__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__shared_styles__ = __webpack_require__(1175);
var _templateObject=_taggedTemplateLiteral(['\n  margin-top: -1.4rem;\n'],['\n  margin-top: -1.4rem;\n']);function _taggedTemplateLiteral(strings,raw){return Object.freeze(Object.defineProperties(strings,{raw:{value:Object.freeze(raw)}}));}/**
 * Styled Components
 */var Container=__WEBPACK_IMPORTED_MODULE_3__shared_styles__["a" /* ReasonContainer */].extend(_templateObject);var SelfEmployment=function SelfEmployment(_ref){var isOpen=_ref.isOpen,toggleOpen=_ref.toggleOpen;return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["Modal"],{isOpen:isOpen,onDismiss:toggleOpen,title:'',minWidth:window.innerWidth>=768?750:0},__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["Modal"].Body,null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(Container,null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["Paragraph"],null,'Our records show that you have identified as self-employed.'),__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["Paragraph"],null,'Unfortunately, the Unemployment Protection Program does not apply to those who have identified as self-employed. Should you gain outside employment and require assistance, please contact us again.'))),__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["Modal"].Footer,null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["Button"],{'data-qa':'selfEmployment-close',small:true,secondary:true,onClick:toggleOpen},'Close')));};/* eslint react/no-typos: 0 */SelfEmployment.propTypes={isOpen:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.bool.isRequired,toggleOpen:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.func.isRequired};/* harmony default export */ __webpack_exports__["a"] = (SelfEmployment);

/***/ }),
/* 1359 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__(0);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_prop_types__ = __webpack_require__(1);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_prop_types___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_prop_types__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_scuid_x__ = __webpack_require__(14);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_scuid_x___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_scuid_x__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__shared_styles__ = __webpack_require__(1175);
var _templateObject=_taggedTemplateLiteral(['\n  margin-top: -1.4rem;\n'],['\n  margin-top: -1.4rem;\n']);function _taggedTemplateLiteral(strings,raw){return Object.freeze(Object.defineProperties(strings,{raw:{value:Object.freeze(raw)}}));}/**
 * Styled Components
 */var Container=__WEBPACK_IMPORTED_MODULE_3__shared_styles__["a" /* ReasonContainer */].extend(_templateObject);var NoLoansQualify=function NoLoansQualify(_ref){var isOpen=_ref.isOpen,toggleOpen=_ref.toggleOpen;return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["Modal"],{isOpen:isOpen,onDismiss:toggleOpen,title:'',minWidth:window.innerWidth>=768?750:0},__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["Modal"].Body,null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(Container,null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["Paragraph"],null,'Unfortunately it looks like you do not have any qualifying loans with us'),__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["Paragraph"],null,'The Unemployment Protection Program only applies to serviced Personal Loans and Refi Loans.'))),__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["Modal"].Footer,null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["Button"],{'data-qa':'noLoansQualify-close',small:true,secondary:true,onClick:toggleOpen},'Close')));};/* eslint react/no-typos: 0 */NoLoansQualify.propTypes={isOpen:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.bool.isRequired,toggleOpen:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.func.isRequired};/* harmony default export */ __webpack_exports__["a"] = (NoLoansQualify);

/***/ }),
/* 1360 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__(0);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_prop_types__ = __webpack_require__(1);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_prop_types___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_prop_types__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_scuid_x__ = __webpack_require__(14);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_scuid_x___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_scuid_x__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_styled_components__ = __webpack_require__(3);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_react_redux_i18n__ = __webpack_require__(70);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_react_redux_i18n___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_4_react_redux_i18n__);
var _templateObject=_taggedTemplateLiteral(['\n  margin-top: -1.4rem;\n'],['\n  margin-top: -1.4rem;\n']);function _taggedTemplateLiteral(strings,raw){return Object.freeze(Object.defineProperties(strings,{raw:{value:Object.freeze(raw)}}));}/**
 * Styled Components
 */var Content=__WEBPACK_IMPORTED_MODULE_3_styled_components__["default"].div(_templateObject);var MortgageFrozenCredit=function MortgageFrozenCredit(_ref){var isOpen=_ref.isOpen,toggleOpen=_ref.toggleOpen;return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["Modal"],{isOpen:isOpen,onDismiss:toggleOpen,title:''},__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["Modal"].Body,null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(Content,null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["Paragraph"],null,'Unfortunately we failed to fetch all necessary credit information.'),__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["Paragraph"],null,'This can happen for a number of reasons, including having a \'freeze\' put on your credit report. Without proper credit information, we are unable to continue your mortgage application at this time. Please verify all the information you have entered is correct and up to date. If you have any questions or concerns, please give us a call at',' ',__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('a',{'data-qa':'mortgage-frozen-cust-service-phone',href:'tel:+'+__WEBPACK_IMPORTED_MODULE_4_react_redux_i18n__["I18n"].t('sofiCustomerServicePhoneUnformat')},__WEBPACK_IMPORTED_MODULE_4_react_redux_i18n__["I18n"].t('sofiCustomerServicePhoneReg')),'so we can try to help.'),__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["Paragraph"],null,'If your mortgage application has one or more coborrowers attached, the above cautions apply to them as well. SoFi requires pulled credit for all parties involved in a mortgage application to be valid before proceeding.'))),__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["Modal"].Footer,null,__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_scuid_x__["Button"],{'data-qa':'mortgage-frozen-credit-close',small:true,secondary:true,onClick:toggleOpen},'Close')));};/* eslint react/no-typos: 0 */MortgageFrozenCredit.propTypes={isOpen:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.bool.isRequired,toggleOpen:__WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.func.isRequired};/* harmony default export */ __webpack_exports__["a"] = (MortgageFrozenCredit);

/***/ }),
/* 1361 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return getProducts; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__utilities_api_action_helpers__ = __webpack_require__(93);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__constants__ = __webpack_require__(79);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__constants_product_constants__ = __webpack_require__(343);
var getProducts=function getProducts(){return function(dispatch){Object(__WEBPACK_IMPORTED_MODULE_0__utilities_api_action_helpers__["b" /* performGet */])(dispatch,__WEBPACK_IMPORTED_MODULE_1__constants__["a" /* API_URL */]+'/products',{},__WEBPACK_IMPORTED_MODULE_2__constants_product_constants__["a" /* GET_PRODUCTS */],true);};};

/***/ }),
/* 1362 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return getWealth; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__utilities_api_action_helpers__ = __webpack_require__(93);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__constants__ = __webpack_require__(79);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__constants_wealth_constants__ = __webpack_require__(344);
/**
 * Important: This action uses the wealth service instead of dashboard-service
 * So url starts with /wealth
 */var getWealth=function getWealth(){return function(dispatch){Object(__WEBPACK_IMPORTED_MODULE_0__utilities_api_action_helpers__["b" /* performGet */])(dispatch,__WEBPACK_IMPORTED_MODULE_1__constants__["f" /* WEALTH_URL */]+'/backend/v1/json/dashboard/summary',{},__WEBPACK_IMPORTED_MODULE_2__constants_wealth_constants__["a" /* GET_WEALTH */]);};};

/***/ }),
/* 1363 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return getClientId; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "b", function() { return getUser; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__constants_launch_darkly_constants__ = __webpack_require__(1188);
/**
 * Get the LaunchDarkly client id
 *
 * @returns string environment id
 */var getClientId=function getClientId(){var windowLocationHostName=window.location.hostname;if(windowLocationHostName==='www.sofi.com'){return __WEBPACK_IMPORTED_MODULE_0__constants_launch_darkly_constants__["e" /* LAUNCH_DARKLY_CLIENT_ID_PROD */];}else if(windowLocationHostName==='www.sofitest.com'){return __WEBPACK_IMPORTED_MODULE_0__constants_launch_darkly_constants__["f" /* LAUNCH_DARKLY_CLIENT_ID_STAGING */];}return __WEBPACK_IMPORTED_MODULE_0__constants_launch_darkly_constants__["g" /* LAUNCH_DARKLY_CLIENT_ID_TEST */];};/**
 * Get the LaunchDarkly user
 *
 * @param customer the customer data object
 * @returns {{key: string}} the LaunchDarkly user object
 */var getUser=function getUser(customer){return{key:''+customer.id};};

/***/ })
]));


// WEBPACK FOOTER //
// static/js/0.bd276203.chunk.js