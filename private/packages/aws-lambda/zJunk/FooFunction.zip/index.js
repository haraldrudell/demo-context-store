'use strict'

exports.handler = function() {
  console.log('foo');
}